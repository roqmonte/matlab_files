function [data,info,determ] = data_make(data_ini,info,cte,trend,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 03/Sept/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Generates data for VAR model.
% Input:
%   data_ini        : Matriz with all data.
%   info:
%   -.px            : Lag order exo variables.
%   -.labels_all    : Labels all variables of the model.
%   -.exo_names     : Labels for y1t block (1 x n_1).
%   -.endo_names    : Labels for y2t block (1 x n_2).
%   -.names         : Labels variables in the VAR.
%   -.shock_names   : Shock labels.
%   -.dates_ini     : Setting for dates: (year,month,freq).
%                     Where, freq: (1) monthly;(2) quaterly data.
%   cte             : (0) No constant; (1) Constant (default).
%   trend           : (0) No trend (default); (1) linear trend; (2) quadratic trend.
%   exo             : Exogenous variables of the model.
%
% Output:
%   data:
%   -.all           : All data.
%   -.exo           : Data for y1_t block.
%   -.endo          : Data for y2_t block.
%   -.prior_endo    : Pre sample data endo variables.
%   -.prior_all     : Pre sample data all variables.
%   -.prior_determ  : Pre sample data determ variables.
%   info:
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%   -.n_exo         : Number of variables exo block.
%   -.n_endo        : Number of variables endo block.
%   -.determ_cte    : Contant term.
%   -.determ_trend  : Linear trend.
%   -.determ_trend2 : Quadratic term.
%   -.determ_exo    : Exogebous variable.
%   -.px            : Lag order exo variables.
%   determ          : Constant term, trends and exo variables for VAR.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Checking exo variables
if exist('exo','var') == 0
    exo = [];
    px = 0;
else
    px = info.px*(1-isempty(exo));
end

% Getting inputs
var_names  = info.labels_all;
exo_names  = info.exo_names;
endo_names = info.endo_names;
n_exo      = length(exo_names);
n_endo     = length(endo_names);
nvar       = n_exo + n_endo;
T = length(data_ini);
% Locate positions of variables in group y_1t
for i=1:n_exo
    pos_exo(i) = loc(char(var_names),char(exo_names(i)));
end
% Locate positions of variables in group y_2t
for i=1:n_endo
    pos_endo(i) = loc(char(var_names),char(endo_names(i)));
end

% Results
data.exo   = data_ini(1+px:end,pos_exo);
data.endo  = data_ini(1+px:end,pos_endo);
data.all   = [data.exo data.endo];
% Labels for variables.
if isfield(info,'names') == 0
    info.names = var_names([pos_exo pos_endo]);
end
% Labels for shocks.
aux_t1 = {'Shock '}; aux_t2 = {};
for i0 = 1:nvar
    aux_t2 = [aux_t2 strcat(aux_t1,num2str(i0))];
end
% Checking consistency for shocks labels
if isfield(info,'shock_names') == 0
    info.shock_names = aux_t2;
else
    if size(info.shock_names,2) < nvar
        info.shock_names = [info.shock_names aux_t2(:,size(info.shock_names,2)+1:end)];
    end
end
clear aux_t1 aux_t2 i0;

% Building exo variables.
% Constant term
if cte == 0
    info.determ_cte = [];
elseif cte == 1
    info.determ_cte = ones(size(data_ini,1),1);    
else
   error('Check cte variable'); 
end
% Trends
if trend == 0
    info.determ_trend = [];
    info.determ_trend2= [];
elseif trend == 1
    info.determ_trend = (1:size(data_ini,1))';
    info.determ_trend2= [];
elseif trend == 2
    info.determ_trend = (1:size(data_ini,1))';
    info.determ_trend2= ((1:size(data_ini,1)).^(2))';
else
   error('Check trend variable'); 
end
% Exo variables.
if size(exo,2) == 0 
    info.determ_exo = [];
elseif size(exo,2) > 0
    exo2 = LagN(exo,px);
    info.determ_exo = exo2;
end
% Deterministic variables.
determ = [info.determ_cte(1+px:end) info.determ_trend(1+px:end) info.determ_trend2(1+px:end) info.determ_exo];

% Generating dates.
T = length(data_ini);
if info.dates_ini(end) == 1
	freq = 'm';
elseif info.dates_ini(end) == 2
	freq = 'q';
end
[time1,time2] = calendar(info.dates_ini(1),info.dates_ini(2),T,freq);
info.dates_xTick = time1;
info.dates_label = time2;
info.px    = px;

% Variables per block
info.n_exo = n_exo;
info.n_endo= n_endo;

% Building final data
data.prior_exo    = data.exo(1:info.presmaple,:);
data.prior_endo   = data.endo(1:info.presmaple,:);
data.prior_all    = data.all(1:info.presmaple,:);
data.prior_determ = determ(1:info.presmaple,:);
% Data
data.exo  = data.exo(info.presmaple+1:end,:);
data.endo = data.endo(info.presmaple+1:end,:);
data.all  = data.all(info.presmaple+1:end,:);
determ    = determ(info.presmaple+1:end,:);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
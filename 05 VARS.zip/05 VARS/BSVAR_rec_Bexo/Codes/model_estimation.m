function results = model_estimation(data,info,prior,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 31/Oct/2018
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimate recursive SVAR using Gibbs Sampling.
% Inputs:
%   data:
%   -.all         : All data.
%   info:
%   -.p           : Lag order of the VAR.
%   -.rep         : Number of draws from posterior.
%   -.burn        : Burning sample.
%   -.conf        : Significance levels for error bands.
%   -.horizon     : Horizon impulse response functions.
%   -.do_norm     : (1) Normalized impulse responses; (0) otherwise.
%   -.norm_fac    : (1) Normalization factor in percent.
%   -.prior       : (1) Noninformative Prior; (2) Independent Normal Wishart.
%   prior:
%   -.B0          : Prior for beta.
%   -.H           : Prior for var/cov matrix coefficients.
%   exo           : Exogenous variables (optional).
%
% Outputs:
%   results:
%   -.irf          : Draws from Impulse responses of the structural model.
%   -.irf_full     : IRF with extended horizon for FEVD and Hdecomp.
%   -.fitted       : Fitted values
%   -.resid        : Regression residuals
%   -.LogL         : Log-likelihood
%   -.aic          : Akaike information criterion (1 x z+1 vector).
%   -.hqc          : Hannan-Quinn information criterion (1 x z+1 vector).
%   -.sic          : Schwarz information criterion (1 x z+1 vector).
%   -.Y            : Left hand variables.
%   -.X            : Right hand variables.
%   -.B_draws      : Draws from the reduced form parameters.
%   -.F_draws      : Draws Companion form.
%   -.C_draws      : Draws parameters exo variables.
%   -.SG_draws     : Draws from Sigama of the reduced form VAR.
%   -.A0_draws     : Draws from the structural matrix A0.
%   -.B            : Median estimates for B.
%   -.A0           : Median estimates for A0.
%   -.Sig          : Median estimates for Sg2.
%   -.data_prior   : Data from priors.
%   -.mlik         : Marginal likelihood.
%
% Index:
% 1. Setup of the model.
% 2. Simulations.
% 3. Results.
% 4. Functions
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup of the model.
% Data for model.
if exist('exo','var') == 0
    exo = [];
end

% Generating dependent variables.
nvar = size(data.all,2);
nexo = size(exo,2);
Y = data.all(1+info.p:end,:);
% Generating lags of dependent variables.
X = []; i = 1;
while i <= info.p
    X = [X data.all(1+info.p-i:end-i,:)];
    i = i + 1;
end;
% Adding exogenous variables
X = [X exo(1+info.p:end,:)];

% Setting the prior
S     = eye(nvar);  % Prior scale matrix for sigma the VAR covariance
alpha = nvar+2;     % Prior degrees of freedom
B0    = vec(prior.B0);
H     = prior.H;    

% Starting values for the Gibbs sampling algorithm
Sigma   = eye(nvar);
betaols = vec((X'*X)^(-1)*(X'*Y));

% Max horizon for IRF.
hmax = info.horizon;

% Getting info from the code.
T     = size(Y,1);
k     = size(H,2);
p     = info.p;
draws = info.rep;
burn  = info.burn;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Simulations.
% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');
disp('-Note: Explosive roots are discarded from simulations.');

% Simulations.
record= 0;
ndraw = 1;
J = [eye(nvar) zeros(nvar,nvar*(p-1))];
while record < burn + draws + 1
    % Posterior mean for betas.
    M = (H^(-1) + kron(Sigma^(-1),X'*X))^(-1) * (H^(-1)*B0 + kron(Sigma^(-1),X'*X)*betaols);
    V = (H^(-1) + kron(Sigma^(-1),X'*X))^(-1);
    [Vchol,z1] = chol(V);
    if z1 == 0    
        % Draw form posterior
        beta  = M + (randn(1,nvar*(nvar*p+1)) * Vchol)';
        Bdraw = reshape(beta,nvar*p+nexo,nvar)';
        % Draw sigma from the IW distribution
        e = Y - X*Bdraw';
        % Scale matrix
        scale = e'*e + S;
        Sigma = iwpQ(T+alpha,inv(scale));

        % Computing the companion form.
        A = Bdraw(:,1:nvar*p);
        if p == 1
            F = A;
        elseif p > 1
            F = [A; [eye(nvar*(p-1)) zeros(nvar*(p-1),nvar)]];
        end
        clear Sinv R Bvar A;

        % Checking stability of the system.
        if max(abs(eig(F))) < 1
            % Computing Cholesky for Signa
            A0inv = chol(Sigma,'lower');
            % Storing the draws after the burning period.
            if record > burn
                % Update waitbar
                waitbar(ndraw/draws,h_wait);
                % IRF for each structural shock identified
                irf_all_temp(:,:,1) = (J*(F^0)*J')*A0inv;
                for h = 1:hmax
                    irf_all_temp(:,:,h+1) = (J*(F^h)*J')*A0inv;
                end
                % Bulding IRF.
                for i0 = 1:nvar
                    irf_all(:,:,i0,ndraw) = squeeze(irf_all_temp(:,i0,:))';
                end         
                % Normalization of IRF.
                if info.do_norm == 1
                    for i0 = 1:nvar
                        temp = squeeze(irf_all(1:info.horizon,:,i0,ndraw));
                        temp_irf(:,:,i0,ndraw) = info.norm_fac*temp/temp(1,i0);
                        clear temp;
                    end
                    clear i0;
                end

                % Storing the draws.
                SG_draws(:,:,ndraw)  = Sigma;
                B_draws(:,:,ndraw)   = Bdraw;
                A0_draws(:,:,ndraw)  = (A0inv)^(-1);
                F_store(:,:,ndraw)   = F;
                C_store(:,:,ndraw)   = Bdraw(:,nvar*p+1:end);
                ndraw = ndraw + 1;
                clear irf_all_temp;
            end
            % Moving top next draw if all conditions are satisfied.            
            record = record + 1;
        end
    else
        % New draw for Sigma
        Sigma = iwpQ(T+alpha,inv(scale));
    end
    clear i0 A0 F Bdraw i1;
end
close(h_wait);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Impulse response of the model.
% Normalization
if info.do_norm == 1
    results.irf = temp_irf;
else
    results.irf = irf_all(1:info.horizon,:,:,:);
end
results.irf_full = irf_all;

% Fit of the model.
results.fitted    = X*median(B_draws,3)';
results.resid     = Y - results.fitted;
results.Sig       = median(SG_draws,3);
% Log likelihood
results.LogL      = -T*nvar/2*(1+log(2*pi)) - T/2*log(det(results.Sig));
% Information criteria
results.aic       = -2*results.LogL/T + 2*k/T;
results.sic       = -2*results.LogL/T + k*log(T)/T;
results.hqc       = -2*results.LogL/T + 2*k*log(log(T))/T;
% Data
results.Y         = Y;
results.X         = X;
% Saving draws.
results.B_draws   = B_draws;
results.F_draws   = F_store;
results.C_draws   = C_store;
results.SG_draws  = SG_draws;
results.A0_draws  = A0_draws;
% Median estimates
results.B  = median(B_draws,3);
results.A0 = median(A0_draws,3);
% Data from priors.
results.data_prior= prior;

% Marginal likelihood for VAR model using Chib (1995)'s method
betam = vec(median(B_draws,3)');
if info.prior == 1
    bp = 0;
    sp = 0;
elseif info.prior == 2
    % Evaluate priors
    b0  = B0;
    % Evaluate log-prior distribution VAR coefficients.    
    bp  = multivariatenormal(betam,vec(b0),H^(-1));
    % Evaluate log prior for VAR covariance
    sp  = invwishpdf(results.Sig,S,alpha);
end
    
% Evaluate log likelihood
lik = loglik(results.B,results.Sig,Y,X);
% Evaluate H(Bstar\sigmastar);
M = (H^(-1) + kron(results.Sig^(-1),X'*X))^(-1) * (H^(-1)*B0 + kron(results.Sig^(-1),X'*X)*betaols);
V = (H^(-1) + kron(results.Sig^(-1),X'*X))^(-1);
H1  = multivariatenormal(betam,M,V);
% Evaluate H(sigmastar\beta[j])
H2i = [];
for j = 1:info.rep
  scale = (Y - X*results.B_draws(:,:,j)')'*(Y - X*results.B_draws(:,:,j)');
  H2i   = [H2i; invwishpdf(results.Sig,scale,size(Y,1))];
end
clear b0 e0 S betam ixx j scale;

% Take mean taking care of possible underflow/overflow with exp
factor = max(H2i);
H2     = exp(H2i-factor);
H2m    = mean(H2);
H2m    = log(H2m)+factor;
% Marginal likelihood.
results.mlik = lik + bp + sp - H1 - H2m;
clear factor H1 H2i factors H2 H2m;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions.

% Function evaluates log-prior distribution VAR coefficients.
function out = multivariatenormal(x,mu,sigma)
k   = size(x,1);
res = x-mu;
isigma  = pinv(sigma);
expterm = -0.5*res'*isigma*res;
constant= -k*log(2*pi)/2-0.5*logdet(sigma);
% Results
out = constant + expterm;

% Function evaluated log likelihood function.
function out = loglik(beta,sigma,y,x)
v = y-x*beta';
T = size(y,1);
N = size(y,2);

isigma = sigma^(-1);
dsigma = logdet(isigma);
sterm  = 0;
for i=1:T
    sterm = sterm+(v(i,:)*isigma*v(i,:)');
end
% Results.
out = (-(T*N)/2)*log(2*pi)+(T/2)*dsigma-0.5*sterm;

% Posterior 
function logpdf = invwishpdf(SIGMA,A,V)
% SIGMA = argument matrix, should be positive definite
% A = p x p symmetric, postitive definite "scale" matrix 
% V = "precision" parameter = "degrees of freeedom"
k = size(SIGMA,1);
logexpterm  = -.5*trace(SIGMA^(-1)*A);
logdetAterm = log(det(A))*(V/2) ;
logdetSterm = log(det(SIGMA))*(-(V+k+1)/2) ;
logtwoterm  = log(2)*((V*k)/2) ;
logpiterm   = log(pi)*(((k-1)*k)/4) ;
sumgamln    = sumgamlnx(k,V);
% Results.
logpdf = logexpterm + logdetSterm +logdetAterm-( logtwoterm + logpiterm + sumgamln  ) ;

% Log-det mattrix.
function out = logdet(x)
a   = chol(x);
out = sum(log(diag(a))*2);

% Aux. functions.
function out = sumgamlnx(b,a)
out = 0;
for i=1:b
    out=out + gammaln((a+1-i)/2);
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
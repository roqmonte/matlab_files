%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description:: Estimation of Structural AB-model VAR, with Long-Run
% restrictions a la Blanchard - Quah (1989):
% (1) y_t = A(L) y_t-1 + u_t <--> A(L)y_t = u_t
% 
% Following BQ, we use B model (A = In) to specify long run restrictions 
% over the IRF.
% - B Model: 
%   A(L)y_t   = u_t             Where u_t   = B*e_t
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Loading data.
clc; clear; close all;
% Seed for the random number generator.
rng('default');

% Working folder
info.ruta = 'C:\Users\Roque Montero\Google Drive\Codigos_Matlab\05 VARS\SVAR_BQ';
cd(info.ruta);
% Loading data.
[~,labels_ini] = xlsread('Data_var','data_m','B2:K2');
data_ini = xlsread('Data_var','data_m','B110:K208');

% Defining endogenous variables.
info.labels_all = labels_ini;
info.endo_names = {'HG1' 'CLP'};
% Define the shocked variable for shock normalization.
info.shock_name = 'HG1';

% Adding constant term, trends and exo variables.
cte    = 1;               % (0) No constant; (1) Constant
trend  = 0;               % (0) No trend; (1) linear trend; (2) linear and quadratic trend.
exo    = [];%data_ini(:,7);   % Exo variables.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Options for the code.
% Set lag order for endogenouse and exogenous variables (if zero, only xt enters to the model)
info.p          = 1;
info.px         = 2;
% Setting dates.
info.dates_ini  = [2009,1,1];       % First observation of the data.
% Settings for impulse responses.
info.do_norm    = 1;                % (1) Normalized shocks; (0) otherwise.
info.norm_fac   = 1;                % Normalization factor (e.g. 10 = 10%).
info.horizon    = 12;               % Horizon of impulse responses.
info.rep        = 10^1;             % Number of bootstrap replications.
info.conf       = [.68 .90 .95];    % Significance levels for error bands.
% Options for plots.
info.widths     = [1 0.7];          % Line widths (zero line, point estim.).
info.fsizes     = [12 10];          % Font sizes (titles, axes).
info.area_color = [0.9 0.9 0.9];    % Color of area for highest sign. level.
info.names      = {'Copper Price' 'USDCLP'};
%info.shock_names= {'Copper price shock'};

% Identification of the model
% Each column of Z00 represents a structural shock. Thus zero entries indicate
% which variables do not have LR impact after the shock.
Z00r= [ NaN   0  ;...
        NaN  NaN ];
  
% Preparing data and model for estimation.
[data,info,Z00,theta,determ,id] = data_make(data_ini,info,cte,trend,exo,Z00r);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model estimation.
% Testing lag lenght of the model.
info.alpha       = 0.05;
info.max_lag     = 4;
lag_test_results = VAR_TestLagLength(data,info,determ);

% Model estimation.
% Plot regression results
VAR_Plot_fit(info.var_results,info,1);
% Computing Hessian matrix at initial values.
H = fdhess('BQ_model',theta,data,info,id,determ);
H0inv = H\eye(size(H));
% Checking the consistency of the Hessian Matrix.
if max(max(isnan(H0inv))) == 1 || max(max(isinf(H0inv))) == 1 || isreal(H0inv) == 0 || isreal(H) == 0
    H = eye(size(theta,1));
else
    [V,Diag] = eig(H0inv);
    Diag     = abs(Diag);
    H        = V*Diag*V';
end;
% Numerical Optimizaci�n.
tol = 1e-08; n_ite = 2000;
[~,thetaf,~,H,~,~,niter] = csminwel('BQ_model',theta,H,[],tol,n_ite,data,info,id,determ);
% Estimation of the structural matrices AB.
[ll,results] = BQ_model(thetaf,data,info,id,determ);
clear Diag V i0 tol n_ite H0inv;

% Computing Impulse responses to the shocks.
[irf,irf_all] = ComputeImpulseResponses(info,results);
% Compuiting confidence bands.
[bands,sig,track]     = ComputeConfidenceBands(data,Z00r,info,determ);
% Plot impulse responses with symmetric and asymmetric bands.
[bands_l,bands_h]     = PlotImpulseResponses(irf,sig,info,3);
[bands_lbt,bands_hbt] = PlotImpulseResponses(irf,bands,info,4);

% Computing Forecast Error Variance Decomposition (FEVD)
FEVD = ComputeFEVD(irf_all,info,5);
% Computing Historical decomposition of the shokcs.
[HDcomp,shocks] = ComputeHDComp(results,info,6);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
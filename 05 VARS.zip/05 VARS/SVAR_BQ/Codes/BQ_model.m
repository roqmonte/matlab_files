function [ll,results] = BQ_model(theta,data,info,id,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Aug/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes likelihood for BQ-VAR model for a given set of
% structural parameters.
% Inputs:
%   theta           : Parameters of the model.
%   data:
%   -.endo          : Data variables in the system.
%   info:
%   -.p             : Lag order.
%   -.var_results   : Structure with results from the reduced VAR model.
%   id              : Matrix containing location of the NaN entries in Z00 matrix.
%   exo             : Matrix with exogenous variables (optional).
%
% Outputs:
%   results:
%   -.C         : Coefficients exogenous variables.
%   -.A         : Coefficients lagged variables.
%   -.F         : Companion form.
%   -.fitted    : Fitted values (T x n matrix).
%   -.resid     : Regression residuals (T x n matrix).
%   -.Sig       : Error covariance from identification.
%   -.Sig_hat   : Error covariance matrix OLS estimator.
%   -.LogL      : Log-likelihood
%   -.aic       : Akaike information criterion.
%   -.sic       : Schwarz information criterion.
%   -.hqc       : Hannan-Quinn information criterion.
%   -.Y         : Dependent variables of the system (lhs variables).
%   -.X         : Independent variables of the system (rhs variables).
%   -.k         : Number of parameters per equation.
%   -.kn        : Total Number parameters of the model.
%   -.ll        : Log-likelihood of the model.
%   -.Bmat      : B matrix of the BQ model.
%   -.Zmat      : Z00 matrix of the BQ model(longrun impacts).
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting info from the code
data= data.endo;
p   = info.p;
n   = size(data,2);
T   = length(data)-p;
Y   = data(1+p:end,:);
if exist('exo','var') == 0
    exo = [];
end

% Building exo variabels
X = [];
i = 1;
while i <= p
    X = [X data(1+p-i:end-i,:)];
    i = i + 1;
end;
X = [X exo(1+p:end,:)];

% Estimation of the reduced form model. Model estimation reduced form.
coef= (X'*X\X'*Y)';
E   = (Y-X*coef');
Sig = E'*E/T;

% Z00 matrix.
Z00 = zeros(n);
nres = size(id,1);
for i0 = 1:nres
    Z00(id(i0,1),id(i0,2)) = theta(i0);
end

% Building B matrix.
aux = eye(n);
for i0 = 1:p
    aux = aux - info.var_results.A(:,:,i0);
end
Bm = aux*Z00;
% Checking B matrix
if min(diag(Bm)) < 0 
    for i0 = 1:n
        if Bm(i0,i0) < 0
            Bm(i0,:) = -1*Bm(i0,:);
        end
    end
end

% Building the likelihood.
Am   = eye(n);
ptA1 =  (T/2) * log((det(Am))^2);
ptB1 = -(T/2) * log((det(Bm))^2);
pf   = -(T/2) * trace(Am'*(Bm')^(-1) * Bm^(-1)*Am * Sig);

% Sign Indetermenmcy
if min(diag(Am^(-1)*Bm)) < 0
    ll = Inf;
    disp('Sign indetermency: inv(A)*B');
else
    ll = -1*(ptA1 + ptB1 + pf);
end;

% Results.
results = info.var_results;
results.Sig_hat = results.Sig;
results.Sig  = (Am^(-1)*Bm)*(Am^(-1)*Bm)';
results.ll   = ll;
results.Bmat = Bm;
results.Zmat = Z00;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
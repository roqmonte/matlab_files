function [irf,BQmod_irf] = ComputeImpulseResponses(info,results)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Aug/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes structural IRF. The code returns an array of 
% dimension (i,j,k) with the response of variable i at horizon j due to 
% an initial shock to variable k.
% Input:
%   info:
%   -.p             : Lag order.
%   -.horizon       : horizon h for impulse response functions.
%   -.do_norm       : (1) Normalized impulse responses; else (0).
%   -.norm_fac      : Normalization factor in percent.
%   -.pos_shock     : Position of the shocked variable.
%   -.dates_xTick   : Dates, var is used to change max horizoon for irf.
%   results:
%   -.A             : Matrix with reduced form parameters.
%   -.Bmat          : B matrix of the model.
%
% Output:
%   irf             : Structural IRF to chosen shock (h+1,n).
%   ABmod_irf       : MA coefficients.
%
% Index:
% 1. Computation of the companion form.
% 2. IRF computation.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Computation of the companion form.
A         = results.A;
Bmat      = results.Bmat;
do_norm   = info.do_norm;
norm_fac  = info.norm_fac;
pos_shock = info.pos_shock;
% Option for IRF.
h = 150;
if info.dates_xTick(end) > h
   h = info.dates_xTick(end) + 10;
end

% Reduce form VAR estimation
p = info.p;
n = size(A,1);
if p == 1
    F = A;
elseif p > 1
    F = [reshape(A,n,n*p); [eye(n*(p-1)) zeros(n*(p-1),n)]];
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. IRF computation.
% Reduced-form impact responses
J = [eye(n) zeros(n,n*(p-1))];
for i = 0:h
    red_irf(:,:,i+1) = J*(F)^(i)*J';
end;

% Orthogonalization
BQ_model = Bmat;
for i=1:h+1
    BQmod_irf(:,:,i) = red_irf(:,:,i)*BQ_model;
end;

% Prepare output
for i0 = 1:n
    irf_all(:,:,i0) = squeeze(BQmod_irf(:,i0,:))';
end;
irf = irf_all(1:info.horizon+1,:,info.pos_shock);

% Normalization
if do_norm
    irf = norm_fac*irf/irf(1,pos_shock);
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
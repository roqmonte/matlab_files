function [FEVD,table,FEVDd] = ComputeFEVD(results,info,print,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 17/Sept/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes Forecast Error Variance Decomposition (FEVD) at the
% posterior median of the reduced form parameters.
% Inside variables "h" control FEVD horizon.
% Input:
%   results:
%   -.F_draws      : Draws Companion form.
%   -.Qh_draws     : Draws from orthogonal matrices.
%   -.A0_draws     : Draws from the structural matrix A0.
%   info:
%   -.p            : Lag order of the VAR.
%   -.rep          : Number of draws from posterior.
%   -.names        : Labels variables in the VAR.
%   -.shock_namess : Labels for shocks.
%   -.nsh          : Number of shocks.
%   -.fsizes       : Font sizes to be used (1 x 2).
%   print          : Do graph and graph id (if print > 0); (0) no graph.
%   vars           : Data selection for charts.
%
% Output:
%   FEVD         : Forecast Error Variance Decomposition (T,n,shock).
%   table        : Table with FEVD (T,n,shock).
%   FEVDd        : Draws FEVD.
%
% Index.
% 1. Computing FEVD
% 2. Printing results
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Computing FEVD
% Getting info
nvars= size(results.Y,2);
nsh  = info.nsh;
p    = info.p;
J    = [eye(nvars) zeros(nvars,nvars*(p-1))];
fsize     = info.fsizes(1);
fsize_alt = info.fsizes(2);

h_wait = waitbar(0,'Computing FEVD from posterior distribution, please wait...');
for jj = 1:info.rep
    % Computing posterior median for draws
    F = results.F_draws(:,:,jj);
    A0inv = (results.Qh_draws(:,:,jj)*results.A0_draws(:,:,jj))^(-1);
    
    % Building IRF.    
    irf_all(:,:,1) = (J*(F^0)*J')*A0inv;
    for h = 1:12
        irf_all(:,:,h+1) = (J*(F^h)*J')*A0inv;
    end

    % Computing RMSE
    h    = 12;
    RMSE = zeros(1+h,nvars);
    aux  = zeros(nvars,nvars);
    for i0 = 1:1+h
        aux = aux + irf_all(:,:,i0)*irf_all(:,:,i0)';
        RMSE(i0,:) = diag(aux)';
    end
    clear aux;

    % Computing contribution to from each structual shock
    num = zeros(1+h,nvars,nvars);
    Iaux = eye(nvars,nvars);
    for i0 = 1:nvars
        temp_ek = Iaux(:,i0);
        for i1 = 1:nvars
            aux     = 0;
            temp_ej = Iaux(:,i1);
            for i2 = 1:1+h
                aux = aux + (temp_ej'*irf_all(:,:,i2)*temp_ek)^(2);
                num(i2,i0,i1) = aux;
            end        
        end
    end

    % Final results
    FEVD2 = zeros(1+h,nvars,nvars);
    for i0 = 1:nvars
        aux = (num(:,:,i0)./repmat(RMSE(:,i0),1,nvars))*100;
        FEVD2(:,:,i0) = aux;
    end
    clear aux num RMSE i0 i1 i2 A0inv F Iaux irf_all temp_ej temp_ek
    % Saving draws and updating waitbar
    FEVD3(:,:,:,jj) = FEVD2;   
    waitbar(jj/info.rep,h_wait);
end
close(h_wait);
for i0 = 1:nvars
   FEVD(:,:,i0) = mean(FEVD3(:,:,i0,:),4);
end
% Checking if model is fully identified or not
if nvars > nsh
    FEVD = [FEVD(:,1:nsh,:) sum(FEVD(:,nsh+1:end,:),2)];
end
FEVDd = FEVD3;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Printing results
% Data selection for charts and tables
if exist('vars','var') == 1
    nvars  = size(vars,2);
else
    vars = 1:nvars;
end

% Print table with results.
part_1= [];
for i0 = 1:nvars
    temp_1 = [[info.names(vars(i0)) info.shock_names]; num2cell([(0:h)' FEVD(:,:,vars(i0))])];
    part_1 = [part_1; temp_1];
    if i0 < nvars
        part_1 = [part_1; repmat({' '},1,size(part_1,2))];
    end
end
table = part_1;
% Do graph.
if exist('print','var') == 1
    if print > 0
        fid = 1;
        fprintf(fid,'***************************************************************************************************\n');
        disp('Forecast Errors Variance Decomposition');
        disp(part_1);
        fprintf(fid,'***************************************************************************************************\n');
        clear  i0 temp_1 part_1;
        % Setup for subplot. Number of variables and graph setup.
        if nvars <= 3
            k1 = 1; k2 = nvars;
        elseif nvars <= 4
            k1 = 2; k2 = 2;
        elseif nvars > 4 && nvars <= 6
            k1 = 3; k2 = 2;
        elseif nvars > 6 && nvars <= 9
            k1 = 3; k2 = 3;
        elseif nvars > 9 && nvars <= 16
            k1 = 4; k2 = 4;
        elseif nvars > 16 && nvars <= 24
            k1 = 4; k2 = 6;
        elseif nvars > 24 && nvars <= 30
            k1 = 5; k2 = 6;
        elseif nvars > 30
            error('Max number of variables reached.');
        end
              
        % Building decomposition for each variable.
        figure(print)
        for i0 = 1:nvars
            subplot(k2,k1,i0)
            bar((0:h)',FEVD(:,:,vars(i0)),'stacked');
            title(info.names(vars(i0)),'FontSize',fsize);
            set(gca,'FontSize',fsize_alt);
            if size(results.Y,2) < 10
                legend1 = legend(info.shock_names);
                set(legend1,'FontSize',fsize_alt-2,'Orientation','vertical','Location','southeast','Box', 'on');
            else
                if i0 == nvars
                    legend1 = legend(info.shock_names);
                    set(legend1,'FontSize',fsize_alt-2,'Position',[0.95 0.59 0.0 0.25],'Orientation','vertical','Box', 'on');
                end
            end
            ylim([1 100]);
            xlim([0 12]);
            set(gca,'XTick',(0:h)');
        end
        axes('Position',[0 0 1 1],'Visible','off');
        text(0.4275,0.975,'Forecast Error Variance Decomposition','FontSize',12','FontWeight','Bold');
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
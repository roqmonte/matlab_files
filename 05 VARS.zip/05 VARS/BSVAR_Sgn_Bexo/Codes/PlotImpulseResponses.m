function [irf_med,bandsl,bandsh] = PlotImpulseResponses(irf,info,fid,shock,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 29/Sept/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes IRF and confidence bands and plot results.
% Inputs:
%   irf             : draws Impulse responses of the structural model.
%   info:
%   -.conf          : Significance levels for confidence bands (1 x c).
%   -.area_color    : Color of area for last significance level (1 x 3).
%   -.widths        : Line widths to be used (1 x 2).
%   -.fsizes        : Font sizes to be used (1 x 2).
%   -.names         : Vector with labels of variables in the system.
%   fid             : Figure number id (optional).
%   shock           : Structural shock for charts
%   vars            : IRF data to structural shocks.
%
% Outputs:
%   irf_med         : Median IRF.
%   bands_l         : Low bands for the IRF.
%   bands_h         : Upper bands for the IRF.
%
% Index:
% 1. Initial Setup.
% 2. Ploting IRF.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Initial Setup.
% Getting info from code
conf        = [(1-info.conf)/2; (1+info.conf)/2];
horizon     = size(irf,1)-1;
nbands      = length(conf);
line_width  = info.widths(1);
line_width_alt = info.widths(2);
fsize       = info.fsizes(1);
fsize_alt   = info.fsizes(2);
names       = info.names;
area_step   = 0.1;
grey        = [0.3,0.3,0.3];

% Shocks selection for charts
if exist('shock','var') == 1
    irf = irf(:,:,shock,:);
end
nshock = size(irf,3);
% Data selection for charts
if exist('vars','var') == 1
    if size(vars,2) == 1
        error('Number of variables must be greater than one.');
    end
    irf = irf(:,vars,:,:);
    names  = names(:,vars);
end
nvars = size(irf,2);

% Number of variables and graph setup.
if nvars <= 3
    k1 = 1; k2 = nvars;
elseif nvars <= 4
    k1 = 2; k2 = 2;
elseif nvars > 4 && nvars <= 6
    k1 = 3; k2 = 2;
elseif nvars > 6 && nvars <= 9
    k1 = 3; k2 = 3;
elseif nvars > 9 && nvars <= 16
    k1 = 4; k2 = 4;
elseif nvars > 16 && nvars <= 24
    k1 = 4; k2 = 6;
elseif nvars > 24 && nvars <= 30
    k1 = 5; k2 = 6;
elseif nvars > 30
    error('Max number of variables reached.');
end

% Plot impulse responses
if exist('fid','var') == 0
    fid = 3;
end

% Computing IRF closer to median.
for i0 = 1:nshock
    % Median IFR for the shock
    irf_med(:,:,i0) = median(irf(:,:,i0,:),4);
end

% Computing bands
for i0 = 1:nshock
    aux = squeeze(irf(:,:,i0,:));
    for i1 = 1:nbands
        bands(:,:,1,i1) = quantile(aux,conf(1,i1),3);
        bands(:,:,2,i1) = quantile(aux,conf(2,i1),3);
    end
    bandsl(i0).bands = bands(:,:,1,:);
    bandsh(i0).bands = bands(:,:,2,:);
    clear aux bands;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Ploting IRF.
for i0 = 1:nshock
    % Name of the graph.
    figure(fid + i0 - 1)
    k = 1;
    for j = 1:nvars
        subplot(k2,k1,k)
        % Area graph.
        area_color = info.area_color;
        % Bands
        bands_l_temp = squeeze(bandsl(i0).bands);
        bands_h_temp = squeeze(bandsh(i0).bands);
        for i = nbands:-1:1
            shadedplot(0:horizon,bands_l_temp(:,j,i)',bands_h_temp(:,j,i)',area_color);
            area_color = area_color-area_step;
            hold on;
        end
        % Zero line.
        h(1) = plot(0:horizon,zeros(1,horizon+1),'-','Color',grey,'LineWidth',line_width_alt);
        % IRF plot model closer to median IRF.
        h(2) = plot(0:horizon,irf_med(:,j,i0)','-b','LineWidth',line_width);

        % Labels.
        title(names(j),'FontSize',fsize);
        if k1 == 1
            if j == nvars 
                xlabel('Periods','FontSize',fsize_alt);
            end
        elseif k1 == 2
            if j == nvars || j == nvars - 1
                xlabel('Periods','FontSize',fsize_alt);
            end
        elseif k1 == 3
            if j == nvars || j == nvars - 1 || j == nvars - 2
                xlabel('Periods','FontSize',fsize_alt);
            end
        else
            if j == nvars || j == nvars - 1 || j == nvars - 2 || j == nvars - 3
                xlabel('Periods','FontSize',fsize_alt);
            end
        end
        set(gca,'FontSize',fsize_alt)
        xlim([0 horizon])
        box off
        k = k + 1;
    end
    clear k j i;
    % Setting the legend of the graphs.
    if length(conf)==1
        legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ' percent confidence bands']);
    elseif length(conf)==2
        legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ' and ',num2str(info.conf(2)*100) ' percent confidence bands']);
    elseif length(conf)==3
        legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ',',num2str(info.conf(2)*100) ' and ',num2str(info.conf(3)*100) ' percent confidence bands']);
    end
    set(legend1,'FontSize',fsize_alt,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function prior = make_prior(data_model,info,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 27/Nov/2018
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Function generates priors for VAR model.
% Inputs:
%   data::
%   -.prior_exo     : Pre sample data exo block.
%   -.prior_endo    : Pre sample data endo block.
%   -.prior_all     : Pre sample data all variables.
%   -.prior_determ  : Pre sample data determ variables.
%   info:
%   -.p             : Lag order.
%   -.prior         : (1) Noninformative Prior; (2) Minnesota prior with dummy variables.
%   -.lambda        : Prior tightness increases with Lmba. 
%       -.lambda(1) : Tightness prior on the AR coefficients.
%       -.lambda(2) : Tightness of prior on higher lags.
%       -.lambda(3) : Tightness of prior constant term and exo variables.
%   -.n_exo         : Number of variables exo block.
%   -.n_endo        : Number of variables endo block.
%   -.rwlist        : Vector, where (1) if prior is RW; (0) if stationary (for MN prior).
%   exo             : Matrix, exogenous variables (optional).
%
% Outputs:
%   prior:
%   -.B0            : Prior for beta.
%   -.H             : Prior for var/cov matrix coefficients.
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Setup of the code.
if exist('exo','var') == 0
    exo = [];
end

% Building data for prior setup.
p      = info.p;
n_exo  = info.n_exo;
n_endo = info.n_endo;
nvar   = n_exo + n_endo;
nexo   = size(exo,2);
% Checking consistency of rwlist and nvar;
if length(info.rwlist) ~= nvar
    error('Check dimension of info.rwlist');
end

% Prior on first lag.
prior_lag = info.rwlist;
B0 = zeros(nvar*p + nexo,nvar);
for i0 = 1:nvar
	B0(i0,i0) = prior_lag(i0);
end

% Prior on sbars for exo block
for i0 = 1:n_exo
    y0 = data_model.prior_exo(2:end,i0);
    x0 = [ones(size(y0,1),1) data_model.prior_exo(1:end-1,i0)];
    b0 = (x0'*x0)^(-1)*x0'*y0;
    sbx1(i0,1) = sqrt(((y0 - x0*b0)'*(y0 - x0*b0)) / (size(y0,1) - 2));
    clear y0 x0 b0;
end

% Prior on sbars for endo block
for i0 = 1:n_endo
    y0 = data_model.prior_endo(2:end,i0);
    x0 = [ones(size(y0,1),1) data_model.prior_endo(1:end-1,i0)];
    b0 = (x0'*x0)^(-1)*x0'*y0;
    sbx2(i0,1) = sqrt(((y0 - x0*b0)'*(y0 - x0*b0)) / (size(y0,1) - 2));
    clear y0 x0 b0;
end

% Prior variance for B0
l1 = info.lambda(1);
l2 = info.lambda(2);
l3 = info.lambda(3);
sbar = [sbx1; sbx2];

% Loop for each equation
aux = [ones(n_exo,1); zeros(n_endo,1)+1e-9];
temp = [];
for i0 = 1:nvar
    ss = sbar(i0);
    temp1= [];
    for i1 = 1:p
        t1 = i1^l2;
        t2 = ((ss./(sbar*t1)).*l1).^2;
        if i0 <= n_exo
            t2 = t2.*aux;
        end
        temp1 = [temp1; t2];
        clear t1 t2;
    end
    % Adding exo variables
    t4 = [temp1; repmat((ss*l3)^2,nexo,1)];
    temp = [temp; t4];
    clear temp1 t4 i1
end

% Results
prior.B0 = B0;
prior.H  = diag(temp);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
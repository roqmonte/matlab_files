function prior = make_prior(data_model,info,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 27/Nov/2018
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Function generates priors for VAR model.
% Inputs:
%   data::
%   -.prior_exo     : Pre sample data exo block.
%   -.prior_endo    : Pre sample data endo block.
%   -.prior_all     : Pre sample data all variables.
%   -.prior_determ  : Pre sample data determ variables.
%   info:
%   -.p             : Lag order.
%   -.prior         : (1) Noninformative Prior; (2) Independent Normal Wishart.
%   -.lambda        : Prior tightness increases with Lmba. 
%       -.lambda(1) : Tightness prior on the AR coefficients.
%       -.lambda(2) : Tightness of prior on higher lags.
%       -.lambda(3) : Tightness of prior constant term and exo variables.
%   -.exo_rest      : Additional restriction to exo block. If empty then block exogeneity applies.
%   -.n_exo         : Number of variables exo block.
%   -.n_endo        : Number of variables endo block.
%   -.rwlist        : Vector, where (1) if prior is RW; (0) if stationary (for MN prior).
%   exo             : Matrix, exogenous variables (optional).
%
% Outputs:
%   prior:
%   -.B0            : Prior for beta.
%   -.H             : Prior for var/cov matrix coefficients.
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Setup of the code.
if exist('exo','var') == 0
    exo = [];
end

% Building data for prior setup.
p      = info.p;
n_exo  = info.n_exo;
n_endo = info.n_endo;
nvar   = n_exo + n_endo;
nexo   = size(exo,2);

if info.prior == 1
    % Priors
    prior.B0 = zeros(nvar*p + nexo,nvar);
    temp     = (nvar*p + nexo)*nvar;
    prior.H  = 1000*eye(temp);
    
elseif info.prior == 2    
    % Prior betas pre-sample data
    bbetas = zeros(n_exo+n_endo,1);
    % Prior on sbars for exo block
    for i0 = 1:n_exo
        y0 = data_model.prior_exo(2:end,i0);
        x0 = [ones(size(y0,1),1) data_model.prior_exo(1:end-1,i0)];
        b0 = (x0'*x0)^(-1)*x0'*y0;
        sbx1(i0,1) = sqrt(((y0 - x0*b0)'*(y0 - x0*b0)) / (size(y0,1) - 2));
        bbetas(i0) = b0(end);
        clear y0 x0 b0;
    end

    % Prior on sbars for endo block
    for i0 = 1:n_endo
        y0 = data_model.prior_endo(2:end,i0);
        x0 = [ones(size(y0,1),1) data_model.prior_endo(1:end-1,i0)];
        b0 = (x0'*x0)^(-1)*x0'*y0;
        sbx2(i0,1) = sqrt(((y0 - x0*b0)'*(y0 - x0*b0)) / (size(y0,1) - 2));
        bbetas(n_exo+i0) = b0(end);
        clear y0 x0 b0;
    end

    % Setting prior for first lag.
    aux = bbetas;
    if isempty(info.rwlist)  == 1
        % Prior from pre-sample data.
        prior_lag = aux;
        info.rwlist = bbetas;
    elseif isempty(info.rwlist)  == 0
        % Prior on first lag.
        prior_lag = info.rwlist;
        % Checking NaN on prior first lag.
        for i0 = 1:nvar
            if isnan(prior_lag(i0))
                prior_lag(i0) = aux(i0);
            end
        end
    end
    % Beta prior.
    B0 = zeros(nvar*p + nexo,nvar);
    for i0 = 1:nvar
        B0(i0,i0) = prior_lag(i0);
    end

    % Checking consistency of rwlist and nvar;
    if length(info.rwlist) ~= nvar
        error('Check dimension of info.rwlist');
    end

    % Prior variance for B0
    l1 = info.lambda(1);
    l2 = info.lambda(2);
    l3 = info.lambda(3);
    sbar = [sbx1; sbx2];

    % Set of restriction and additional restrictions for exo block.
    if isempty(info.exo_rest) == 0
        aux = info.exo_rest + 1e-9;
    else
        aux1 = repmat([ones(n_exo,1); zeros(n_endo,1) + 1e-9],1,n_exo);
        aux2 = ones(n_exo + n_endo,n_endo);
        aux  = [aux1 aux2];
        clear aux1 aux2;
    end
    % Loop for each equation
    temp = [];
    for i0 = 1:nvar
        ss = sbar(i0);
        temp1= [];
        for i1 = 1:p
            t1 = i1^l2;
            t2 = ((ss./(sbar*t1)).*l1).^2;
            t2 = t2.*aux(:,i0);
            temp1 = [temp1; t2];
            clear t1 t2;
        end
        % Adding exo variables
        t4 = [temp1; repmat((ss*l3)^2,nexo,1)];
        temp = [temp; t4];
        clear temp1 t4 i1
    end

    % Results
    prior.B0 = B0;
    prior.H  = diag(temp);
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
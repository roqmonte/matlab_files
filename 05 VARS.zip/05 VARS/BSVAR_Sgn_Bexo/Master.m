%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimate VAR model with block exogeneity (y1_t wrt y2_t).
% Identification is achieved usnig signs and impacts restrictions over the IRF, 
% following  Rubio-Ramirez et al. (2010) and Arias et al. (2014) using
% Gibbs Sampling and an Independent Normal Wishart Prior.
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Loading data.
clc; clear; close all;
% Seed for the random number generator.
rng('default');

% Working folder
info.ruta = 'C:\Users\Roque Montero\Google Drive\Codigos_Matlab\05 VARS\BSVAR_Sgn_Bexo';
cd(info.ruta);
% Loading data.
[~,labels_ini] = xlsread('Data_macro','Data','B1:N1');
data_ini = xlsread('Data_macro','Data','B50:N229');
data_ini = data_ini(2:end,:) - data_ini(1:end-1,:);

% Defining endogenous variables.
info.labels_all = labels_ini;
info.exo_names = {'yus' 'cpius' 'ffrate'};
info.endo_names= {'y' 'IPC'	'tpm' 'RER'};

% Adding constant term, trends and exo variables.
cte    = 1;               % (0) No constant; (1) Constant
trend  = 0;               % (0) No trend; (1) linear trend; (2) linear and quadratic trend.
exo    = [];%data_ini(:,[11,12]);   % Exo variables.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Options for the code.
% Set lag order for endogenouse and exogenous variables (if zero, only xt enters to the model)
info.p          = 2;
info.px         = 0;
% Setting dates.
info.dates_ini  = [2000,1,1];       % First observation of the data.
% Settings for impulse responses.
info.do_norm    = 1;                % (1) Normalized shocks; (0) otherwise.
info.norm_fac   = 1;                % Normalization factor (e.g. 10 = 10%).
info.horizon    = 12;               % Horizon of impulse responses.
info.rep        = 10^3;             % Draws from the posterior.
info.burn       = 100;              % Burning sample.
info.conf       = [.68 .90 .95];    % Significance levels for error bands.
% Options for plots.
info.widths     = [1 0.7];          % Line widths (zero line, point estim.).
info.fsizes     = [12 10];          % Font sizes (titles, axes).
info.area_color = [0.9 0.9 0.9];    % Color of area for highest sign. level.
info.names      = {'US gdp' 'US p' 'fed rate' 'gdp' 'p' 'tpmn' 'RER'};
info.shock_names= {'Demand shock US'};

% Prior setup, Independent Normal wishart.
% Prior Tightness decreases with l(1,3), but increases with l(2).
info.presmaple   = 20;   % Controls sample size of the pre-sample data.
info.lambda(1)   = 0.1;  % Tightness prior on the AR coefficients.
info.lambda(2)   = 0.5;  % Tightness of prior on higher lags.
info.lambda(3)   = 1;    % Tightness of prior constant term and exo variables.

% Defining prior for first lag on VAR coeficients, if empty use pre-sample betas.
% If one element is NaN, then use pre-sample beta on that coefficient.
info.rwlist  = zeros(7,1)+1;

% Identification of the first block of the model.
% Each column represents a structural shock. The sign of the entry determines 
% the sign restriction whereas the magnitude the length of the restriction.
info.sh_signs = [  1;...
                   1;...
                   1;...
                   0;...
                   0;...
                   0;...
                   0];
               
info.sh_zeros = [  0;...
                   0;...
                   0;...
                   0;...
                   0;...
                   0;...
                   0];
               
% Preparing data for estimation.
[data,info,determ] = data_make(data_ini,info,cte,trend,exo);
% Building priors.
prior = make_prior(data,info,determ);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model estimation and Impulse response function.
% Lag length test.
info.alpha = 0.05;
info.max_lag = 6;
exo_test     = VAR_TestBlockExo(data,info,determ);
lag_test     = VAR_TestLagLength(data,info,determ);

% Model estimation and impulse response computation.
results = model_estimation(data,info,prior,determ);
% Plot regression results
VAR_Plot_fit(results,info,1);

% Compute impulse responses and bands
[irf_med,bandsl,bandsh] = PlotImpulseResponses(results.irf,info,3);

% Computing Forecast Error Variance Decomposition (FEVD) at med(models).
FEVD = ComputeFEVD(results,info,20);
% Computing Historical decomposition of the shokcs at med(models).
[HDcomp,~,shocks] = ComputeHDComp(results,info,21);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
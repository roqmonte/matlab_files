function results = model_estimation(data,info,prior,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 26/Feb/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimate SVAR with sign and or zero/impact restrictions.
% Inputs:
%   data:
%   -.all         : All data (both groups).
%   -.endo        : Data model.
%   info:
%   -.p           : Lag order of the VAR.
%   -.prior       : (1) Noninformative Prior; (2) Minnesota prior with dummy variables.
%   -.nsh         : Number of shocks.
%   -.rep         : Number of draws from posterior.
%   -.burn        : Burning sample.
%   -.conf        : Significance levels for error bands.
%   -.horizon     : Horizon impulse response functions.
%   -.sh_signs    : Matriz with sign restrictions.
%   -.sh_zeros    : Matrix with zero/impacts restrictions.
%   -.do_norm     : (1) Normalized impulse responses; (0) otherwise.
%   -.norm_fac    : (1) Normalization factor in percent.
%   prior:
%   -.Ystar       : Data lhs varibable for VAR model with Minnesota prior.
%   -.Xstar       : Data rhs varibable for VAR model with Minnesota prior.
%   exo           : Exogenous variables (optional).
%
% Outputs:
%   results:
%   -.irf          : Draws from Impulse responses of the structural model.
%   -.irf_full     : IRF with extended horizon for FEVD and Hdecomp.
%   -.fitted       : Fitted values
%   -.resid        : Regression residuals
%   -.LogL         : Log-likelihood
%   -.aic          : Akaike information criterion (1 x z+1 vector).
%   -.hqc          : Hannan-Quinn information criterion (1 x z+1 vector).
%   -.sic          : Schwarz information criterion (1 x z+1 vector).
%   -.Y            : Left hand variables.
%   -.X            : Right hand variables.
%   -.Qh_draws     : Draws from orthogonal matrices.
%   -.B_draws      : Draws from the reduced form parameters.
%   -.F_draws      : Draws Companion form.
%   -.C_draws      : Draws parameters exo variables.
%   -.SG_draws     : Draws from Sigama of the reduced form VAR.
%   -.A0_draws     : Draws from the structural matrix A0.
%   -.B            : Median estimates for B.
%   -.A0           : Median estimates for A0.
%   -.Sig          : Median estimates for Sg2.
%   -.data_prior   : Data from priors.
%
% Index:
% 1. Setup of the model.
% 2. Simulations.
% 3. Results.
% 4. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup of the model.
% Data for model.
if exist('exo','var') == 0
    exo = [];
end

% Generating dependent variables.
Y = data.endo(1+info.p:end,:);
% Generating lags of dependent variables.
X = []; i = 1;
while i <= info.p
    X = [X data.endo(1+info.p-i:end-i,:)];
    i = i + 1;
end;
% Adding exogenous variables
X = [X exo(1+info.p:end,:)];

% Variables for model
Ybar  = [Y; prior.Ystar];
Xbar  = [X; prior.Xstar];
Tbar  = size(Xbar,1);

% Compute posterior mean
Bols = ((Xbar'*Xbar)\(Xbar'*Ybar))';

% Compue initial value for Sigma
E    = (Ybar - Xbar*Bols');
Sig  = (E'*E)/Tbar;

% Max horizon for IRF.
hmax = info.horizon;

% Getting info from the code.
nvar  = size(Ybar,2);
k     = size(Xbar,2);
p     = info.p;
nsh   = info.nsh;
draws = info.rep;
burn  = info.burn;

% Genereting matrix concistent with the restrictions.
[Sj,Zj] = gen_matrices(info.sh_zeros,info.sh_signs,info.horizon);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Simulations.
% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');
disp('-Note: Explosive roots are discarded from simulations.');

% Simulations.
record= 0;
ndraw = 1;
J = [eye(nvar) zeros(nvar,nvar*(p-1))];
while record < burn + draws + 1
    % Draw beta
    M = vec(Bols');
    [Vchol,z1] = chol(kron(Sig,(Xbar'*Xbar)\eye(k)));
    if z1 == 0
        beta  = M + (randn(1,nvar*(nvar*p+size(exo,2))) * Vchol)';
        Bdraw = reshape(beta,nvar*p+size(exo,2),nvar)';
        % Draw sigma
        e = Ybar -Xbar*Bdraw';
        scale = e'*e;
        Sig = iwpQ(Tbar,inv(scale));

        % Computing the companion form.
        A = Bdraw(:,1:nvar*p);
        if p == 1
            F = A;
        elseif p > 1
            F = [A; [eye(nvar*(p-1)) zeros(nvar*(p-1),nvar)]];
        end
        clear Sinv R Bvar A;

        % Checking stability of the system.
        if max(abs(eig(F))) < 1
            % Computing Qj matrix (ortogobnal matrix).
            [Qhat,f,A0inv] = Qdraw(F,Sig,Zj,info.horizon,p);
            % Check that the sign restrictions hold otherwise take new draw
            % of the posterior for the parameters of the reduce form VAR.
            S1 = zeros(1,nsh);
            for i1 = 1:nsh
                Si = Sj(i1).S;
                S1(1,i1) = min(Si*f*Qhat(i1,:)');
            end
            % Simulations.
            if min(S1) >= 0
                % Storing the draws after the burning period.
                if record > burn
                    % Update waitbar
                    waitbar(ndraw/draws,h_wait);
                    
                    % IRF for each structural shock identified
                    for i0 = 1:nvar
                        % Computing IRF up to horizon "h".
                        irf_all(1,:,i0,ndraw) = (J*(F^0)*J')*A0inv*Qhat(i0,:)';
                        for h = 1:hmax
                            irf_all(h+1,:,i0,ndraw) = (J*(F^h)*J')*A0inv*Qhat(i0,:)';
                        end
                    end                    
                    % Normalization of IRF.
                    if info.do_norm == 1
                        for i0 = 1:nvar
                            temp = squeeze(irf_all(1:info.horizon,:,i0,ndraw));
                            temp_irf(:,:,i0,ndraw) = info.norm_fac*temp/temp(1,i0);
                            clear temp;
                        end
                        clear i0;
                    end
                    
                    % Storing the draws.
                    Qh_draws(:,:,ndraw)  = Qhat;
                    SG_draws(:,:,ndraw)  = Sig;
                    B_draws(:,:,ndraw)   = Bdraw;
                    A0_draws(:,:,ndraw)  = A0inv^(-1);
                    F_store(:,:,ndraw)   = F;
                    C_store(:,:,ndraw)   = Bdraw(:,nvar*p+1:end);
                    ndraw = ndraw + 1;
                end
                % Moving top next draw if all conditions are satisfied.            
                record = record + 1;
            end
        end
    else
        % New draw for Sigma
        Sig = iwpQ(Tbar,inv(scale));
    end
    clear i0 temp_1 temp_2 Qhat f A0 F Bdraw Sigma i1 Si;
end
close(h_wait);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Impulse response of the model.
% Normalization
if info.do_norm == 1
    results.irf = temp_irf;
else
    results.irf = irf_all(1:info.horizon,:,:,:);
end
results.irf_full = irf_all;

% Fit of the model.
results.fitted    = X*median(B_draws,3)';
results.resid     = Y - results.fitted;
results.Sig       = mean(SG_draws,3);
% Log likelihood
results.LogL      = -Tbar*nvar/2*(1+log(2*pi)) - Tbar/2*log(det(results.Sig));
% Information criteria
results.aic       = -2*results.LogL/Tbar + 2*k/Tbar;
results.sic       = -2*results.LogL/Tbar + k*log(Tbar)/Tbar;
results.hqc       = -2*results.LogL/Tbar + 2*k*log(log(Tbar))/Tbar;
% Data
results.Y         = Y;
results.X         = X;
% Saving draws.
results.Qh_draws  = Qh_draws;
results.B_draws   = B_draws;
results.F_draws   = F_store;
results.C_draws   = C_store;
results.SG_draws  = SG_draws;
results.A0_draws  = A0_draws;
% Median estimates
results.B  = median(B_draws,3);
results.SG = median(SG_draws,3);
results.A0 = median(A0_draws,3);
% Data from priors.
results.data_prior= prior;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions.

% Function generates Matrix Qj for zero/impact restrictions.
function [Qf,f,A0inv] = Qdraw(F,Sigmadraw,Zj,hmax,p)
% Inputs:
% F             : Draw companion form.
% Sigmadraw     : Draw of SIGMA.
% Zj            : Matriz with zero restrictions.
% hmax          : Max. hirizon for irf.
% Outputs:
% Qf            : Matrix Qj for the zero restrictions.
% f             : Intial impact of IRF of the Cholesky model.
% A0inv         : Inverse Matrix A0 of SVAR.
% p             : Lag order of the VAR.

% Getting info form code.
n     = size(Sigmadraw,1);
A0inv = chol(Sigmadraw,'lower');
J     = [eye(n) zeros(n,n*(p-1))];

% Computing IRF at t(0)
f = [];
for i0 = 0:hmax-1
    Ltilde0(:,:,i0+1) = (J*(F^(i0))*J')*A0inv;
    f = [f; Ltilde0(:,:,i0+1)];
end

% Generating qj vectors of Q
Qhat = zeros(n,n);
Qf   = zeros(n,n);
i1 = 1;
while i1 <= n
    % Getting Zi matrix.
    Zi = Zj(i1).Z;
    % Checking zero restrictions.
    temp = max(max(Zi));    
    % -Case (1) Sign restrictions only.
    if temp == 0
        if i1 == 1
            qqj = zeros(n);
        else
            qqj = Qhat(:,1:i1-1)*Qhat(:,1:i1-1)';
        end
        Xhat = randn(n,1);
        Qhat(:,i1) = ((eye(n) - qqj)*Xhat)/norm(((eye(n) - qqj)*Xhat));
        % Storing Qmat.
        Qf(i1,:)   = Qhat(:,i1);
        
    % -Case (2) Sign and Zeros restrictions.
    elseif temp > 0
        if i1 == 1
            qj = [];
        else
            qj = Qhat(:,1:i1-1);
        end
        Rj   = [Zi*f; qj'];
        Nj   = null(Rj);
        Xhat = randn(size(Nj,2),1);
        Qhat(:,i1) = Nj*Xhat/norm(Xhat);
        % Storing Qmat.
        Qf(i1,:)   = Qhat(:,i1);
    end
    
    % Checking the solution of the system.
    if max(isnan(Qhat(:,i1))) == 1
        disp('No solution to the system of equations.') ;
    else
        i1 = i1 + 1;
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
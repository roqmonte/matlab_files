function [Sj,Zj] = gen_matrices(zerosm,signs,hmax)
%-------------------------------------------------------------------------%
% Matlab 8.4
% Autor: Roque Montero
% Date : 25/Feb/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: function creates the Sj and Zj matrices according to 
% Arias et al. (2014).
% Inputs:
%   zeros  : Matrix with impact restrictions.
%   signs  : Matrix with signs restrictions.
%   hmax   : Max. hirizon for irf.
%
% Output:
%   S    : Matrices for sign restrictions.
%   Z    : Matrices for zero restrictions.
%
% Index:
% 1. Matrices.
% 2. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Matrices.
% Max horizon IRF for restriction.
n    = size(zerosm,1);
nsh  = size(zerosm,2);
hmax = hmax*n;

% Matrix S and Z for restrictions for each shock.
for i0 = 1:nsh
    % Checking sign and impact restrictions
    aux = [signs(:,i0) zerosm(:,i0)];
    if max(max(abs(aux))) > 0        
        [Smat,Zmat] = mat_arw(aux,hmax);
    end
       
    % Sign restrictions.
    if max(abs(signs(:,i0))) > 0
        Sj(i0).S = zeromat(Smat,hmax);
    else
        Sj(i0).S = zeromat(0,hmax);
    end
    % Zero restrictions.
    if max(abs(zerosm(:,i0))) > 0
        Zj(i0).Z = zeromat(Zmat,hmax);
    else
        Zj(i0).Z = zeromat(0,hmax);
    end
    clear aux
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Functions.

% Function creates matrices S and Z according to ARW.
function [Smat,Zmat] = mat_arw(res,hmax)
% Inputs:
%   res  : Matrix with restrictions for shock j.
%   hmax : Max. period for restriction.
% Outputs:
%   Smat : S matrix consistent with ARW.
%   Zmat : Z matrix consistent with ARW.
n    = size(res,1);
Smat = [];
Zmat = [];
for i1 = 1:n
    % Mat to store temp results.
    aux_s = [];
    aux_z = [];
    % Sign restrictions
    if abs(res(i1,1)) > 0
        % Matrix with indicate restriction was activated.        
        aux1 = zeros(1,n);
        aux1(1,i1) = res(i1,1)/abs(res(i1,1));

        % Matrix to store results.
        aux2 = zeros(abs(res(i1,1)),hmax);
        jj = 0;
        for i0 = 1:abs(res(i1,1))
           aux2(i0,1+n*jj:n*(jj+1)) = aux1;
           jj = jj + 1;
        end
        % Results.
        aux_s = [aux_s; aux2];
        clear aux1 aux2 jj;
    end
    % Zero/impact restrictions
    if abs(res(i1,2)) > 0
        % Matrix with indicate restriction was activated.        
        aux1 = zeros(1,n);
        aux1(1,i1) = res(i1,2)/abs(res(i1,2));

        % Matrix to store results.
        aux2 = zeros(abs(res(i1,2)),hmax);
        jj = 0;
        for i0 = 1:abs(res(i1,2))
           aux2(i0,1+n*jj:n*(jj+1)) = aux1;
           jj = jj + 1;
        end
        % Results.
        aux_z = [aux_z; aux2];
        clear aux1 aux2 jj;
    end

    % Join restriction over variables.
    id = res(i1,1)*res(i1,2);
    if abs(id) > 0
        mat_aux = repmat(zeros(size(aux_s,1),n),1,res(i1,2));
        col_aux = size(mat_aux,2);
        aux_s   = [mat_aux aux_s(:,1:end-col_aux)];
    end
    
    % Final results
    Smat = [Smat; aux_s];
    Zmat = [Zmat; aux_z];
end

% Function compares cols(A) with alpha, if cols(A) < alpha, function adds
% columns so that cols(A) = alpha.
function results = zeromat(mat,alpha)
% Cheking number of columns
if size(mat,2) == alpha
    results = mat;
% Adding more columns.    
elseif size(mat,2) < alpha
    aux1 = alpha - size(mat,2);
    aux2 = zeros(size(mat,1),aux1);
    results = [mat aux2];    
% Wrong configuration.    
else
    error('Wrong config of shocks.');
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
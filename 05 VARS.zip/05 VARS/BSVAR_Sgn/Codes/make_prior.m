function prior = make_prior(data_model,info,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 03/Sep/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Funtion generates priors for VAR model.
% Inputs:
%   data::
%   -.all           : All data (both groups).
%   -.endo          : Data VAR model.
%   -.prior_endo    : Pre sample data endo variables.
%   -.prior_all     : Pre sample data all variables.
%   -.prior_determ  : Pre sample data determ variables.
%   info:
%   -.p             : Lag order.
%   -.prior         : (1) Noninformative Prior; (2) Minnesota prior with dummy variables.
%   -.lambda        : Prior tightness increases with Lmba. 
%       -.lambda(1) : Overall tightness of prior.
%       -.lambda(2) : Tightness of prior on higher lags.
%       -.lambda(3) : Tightness of prior for cov matrix.
%       -.lambda(4) : Tightness of the prior on constant term.
%       -.lambda(5) : Prior rest of exo variables.
%       -.lambda(6) : Prior sum of coefficients prior.
%       -.lambda(7) : Prior common stochastic trends.
%   -.rwlist        : Vector, where (1) if prior is RW; (0) if stationary (for MN prior).
%   exo             : Matrix, exogenous variables (optional).
%
% Outputs:
%   prior:
%   -.Ystar  : Data lhs varibable for VAR model with Minnesota prior.
%   -.Xstar  : Data rhs varibable for VAR model with Minnesota prior.
%   -.lambda : Prior parameters from grid search over lambda.
%
% Index:
% 1. Building priors.
% 2. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Building priors.
% Setup of the code.
if exist('exo','var') == 0
    exo = [];
end

% Grid search. Parameters for the search for each lambda
rq = [2,2];                                       % [1,1] full search; [1,2] fast search;[2,2] express search.
b11_1 = 0.1; b11_2 = 0.2; bl1_3 = round(2/rq(1)); % Overall tightness of prior.
b12_1 = 1.0; b12_2 = 0.5; bl2_3 = round(2/rq(1)); % Tightness of prior on higher lags.
b13_1 = 0.5; b13_2 = 0.5; bl3_3 = round(2/rq(1)); % Tightness of prior for cov matrix.
b14_1 = 0.1; b14_2 = 0.2; bl4_3 = round(2/rq(2)); % Tightness of the prior on constant term center at 0.
b16_1 = 0.1; b16_2 = 0.2; bl6_3 = round(2/rq(2)); % Prior sum of coefficients prior.
b17_1 = 0.1; b17_2 = 0.2; bl7_3 = round(2/rq(2)); % Prior common stochastic trends.
% Sets serach for prior rest of exo variables.
if size(exo,2) == 1
    a1 = 1; a2 = 1; a3 = 1;
elseif size(exo,2) > 1
    a1 = b14_1; a2 = b14_2; a3 = bl4_3;
end

% Building data for prior setup.
p    = info.p;
nvar = size(data_model.endo,2);

% Noninformative Prior (diffuse prior).
if info.prior == 1
    % Computing posteriors
    prior.Ystar = [];
    prior.Xstar = [];    

% Minnesota prior with dummy variables.
elseif info.prior == 2    
    for i0 = 1:nvar
        Y0 = data_model.prior_endo(2:end,i0);
        X0 = [ones(size(Y0,1),1) data_model.prior_endo(1:end-1,i0)];
        B0 = (X0'*X0)^(-1)*X0'*Y0;
        % Saving priors
        bprior(i0,1) = B0(end);
        sbar(1,i0)   = sqrt(((Y0 - X0*B0)'*(Y0 - X0*B0) / (size(Y0,1) - 2)));
        clear Y0 X0 B0;
    end
    % Data prior and VAR estimation to get sample
    Y0        = data_model.prior_endo;
    res_var = EstimateVAR(data_model.endo,p,exo);

    % Setting prior for first lag.
    aux = bprior;
    if isempty(info.rwlist)  == 1
        prior_lag   = aux;
        info.rwlist = bprior;
    elseif isempty(info.rwlist)  == 0
        prior_lag = info.rwlist;
        % Checking NaN on prior first lag.
        for i0 = 1:nvar
            if isnan(prior_lag(i0))
                prior_lag(i0) = aux(i0);
            end
        end
    end
       
    % Initial check
    if size(exo,2) == 0
        error('BVAR with Minnesota prior must include constant term');
    end
    % Checking consistency of rwlist and nvar;
    if length(info.rwlist) ~= nvar
        error('Check dimension of info.rwlist');
    end    
    warning('off','all')

    % Prior computation
    if isempty(info.lambda) == 0
        % Checking value lambda for number of variables per equation.
        if size(exo,2) == 1
            info.lambda(5) = NaN;
        end
        disp('-Hyper-parameters set by user.');        
        [Ystar,Xstar] = getmnprior(info.lambda,Y0,sbar,p,prior_lag,data_model.prior_determ);
        prior.lambda = info.lambda;
               
    elseif isempty(info.lambda) == 1
        % Grid for lambda.
        disp('-Hyper-parameters set by grid search.');        
        res01 = []; res02 = [];

        % Wait bar.        
        n_tot  = size(b11_1:b11_2:bl1_3,2)*size(b12_1:b12_2:bl2_3,2)*size(b13_1:b13_2:bl3_3,2)*size(b14_1:b14_2:bl4_3,2)*size(a1:a2:a3,2)*size(b16_1:b16_2:bl6_3,2)*size(b17_1:b17_2:bl7_3,2);
        h_wait = waitbar(0,'Selecting hyperparameters for Minnesota prior, please wait...');
        zz     = 0;
        
        % Search
        for l1 = b11_1:b11_2:bl1_3
            for l2 = b12_1:b12_2:bl2_3
                for l3 = b13_1:b13_2:bl3_3
                    for l4 = b14_1:b14_2:bl4_3
                        for l5 = a1:a2:a3
                            for l6 = b16_1:b16_2:bl6_3
                                for l7 = b17_1:b17_2:bl7_3
                                    if size(exo,2) == 1
                                        lambda = [l1; l2; l3; l4; NaN; l6; l7];
                                    elseif size(exo,2) > 1
                                        lambda = [l1; l2; l3; l4; l5; l6; l7];
                                    end
                                    [Ystar,Xstar] = getmnprior(lambda,Y0,sbar,p,prior_lag,data_model.prior_determ);
                                    % Computing Marginal likelihood
                                    marg_like = marglik(Ystar,res_var.Y,Xstar,res_var.X);
                                    res01 = [res01; marg_like];
                                    res02 = [res02; lambda'];
                                    zz = zz + 1;
                                    waitbar(zz/n_tot,h_wait);
                                    clear marg_like lambda;
                                end
                            end
                        end
                    end
                end
            end
        end
        close(h_wait);
        % Computing optimal system.
        [~,id] = max(res01);
        % Building dummy observations.
        lambda_temp = res02(id,:);
        [Ystar,Xstar] = getmnprior(lambda_temp,Y0,sbar,p,prior_lag,data_model.prior_determ);
        display(lambda_temp);
        % Hyperparameters
        prior.lambda = lambda_temp;
        warning('on','all')
        clear l1 l2 l3 l4 l5 zz res01 res02 id;
    end
    
    % Computing posteriors
    prior.Ystar  = Ystar;
    prior.Xstar  = Xstar;
else
    error('Wrong prior selection.');
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions

% Function computes the posterior from the minesota prior.
function [Ystar,Xstar] = getmnprior(lambda,Y0,sbar,p,rwlist,exo)
% builds MN prior dummy obs (see Sims-Zha 98, Del Negro Schorfheide). 
% Note constant term and exo varialbes are ordered last.
% Inputs:
%   lambda  : Hyperparameters for the Minnesota prior.
%   Y0      : Pre-sample data.
%   sbar    : Pre-sample standard deviation residuals.
%   p       : Lag order.
%   rwlist  : Vector row for priors; (1) RW prior; (0) low persistency.
%   exo     : Matrix, exogenous variables pre-sample values
% Outputs:
%   Ystar : Expanded Y variables with dummy observations.
%   Xstar : Expanded X variables with dummy observations.

% Initial setup
Ny   = size(Y0,2);
Nx   = Ny*p+1;
nexo = size(exo,2)-1;
mexo = mean(exo,1);
% Priors.
ybar  = mean(Y0,1);


% Building expanded data set.
Ystar = [diag((1/lambda(1))*((rwlist').*sbar)); zeros(Ny*(p-1),Ny); diag(sbar*lambda(3))];
Xstar = [(1/lambda(1))*kron(diag(1:p)^lambda(2),diag(sbar)) zeros(Ny*p,1); zeros(Ny,Nx)];

% Adding prior for constant terms.
Ystar = [Ystar; zeros(1,Ny)];
Xstar = [Xstar; [zeros(1,Nx-1) (1/lambda(4))]];

% Adding prior rest exo variables.
if isnan(lambda(5)) == 0
    Ystar = [Ystar; zeros(nexo,Ny)];
    Xstar = [Xstar zeros(size(Xstar,1),nexo)];
    Xstar = [Xstar; [zeros(nexo,Nx) (1/lambda(5))*eye(nexo)]];
end

% Adding dummy variables for the sum of coefficients prior.
if isnan(lambda(6)) == 0
    Ystar = [Ystar; (1/lambda(6))*diag(ybar)];
    Xstar = [Xstar; repmat((1/lambda(6))*diag(ybar),1,p) zeros(Ny,nexo+1)];
end
% Adding dummy variables for the common stochastic trends prior.
if isnan(lambda(7)) == 0
    Ystar = [Ystar; (1/lambda(7))*ybar];
    Xstar = [Xstar; repmat((1/lambda(7))*ybar,1,p) (1/lambda(7))*mexo];
end


% Function computes the marginal likelihood.
function minnml = marglik(Ystar,y,Xstar,x)
% Inputs:
%   Ystar : Dummy observations for Y.
%   y : Data Y.
%   Xstar : Dummy observations for X.
%   x : Data X.
% Outputs:
%   minnml : Marginal likelihood.

% Full sample.
Ybar = [Ystar; y];
Xbar = [Xstar; x];
% Info from the code.
Ntstar = size(Ystar,1);
Ntall = size(Ybar,1);
Nx    = size(Xstar,2);
Ny    = size(Ybar,2);
Nt    = size(y,1);

% Computing matrices.
xxxxd = Xstar'*Xstar;
xxxxc = Xbar'*Xbar;
aux1  = (Xstar'*Xstar)\Xstar'*Ystar;
S0    = (Ystar - Xstar*aux1)'*(Ystar - Xstar*aux1);
aux2  = (Xbar'*Xbar)\(Xbar'*Ybar);
Shat  = (Ybar - Xbar*aux2)'*(Ybar - Xbar*aux2);
clear aux1 aux2;
% Computing marginal likelihood.
gamd = 0;
gamc = 0;
for i =1:Ny
    gamd = gamd+gammaln((Ntstar-Nx+1-i)/2);
    gamc = gamc+gammaln((Ntall-Nx+1-i)/2);
end

% Dummy observation
mld = (Ny*(Ntstar-Nx)/2)*log(2)-(Ny/2)*log(det(xxxxd))-(Ntstar-Nx)*0.5*log(det(S0))+gamd;
% Full sample, including dummy observations.
mlc = (Ny*(Ntall-Nx)/2)*log(2)-(Ny/2)*log(det(xxxxc))-(Ntall-Nx)*0.5*log(det(Shat))+gamc;
% Marginal Likelihhod
minnml = -(Ny*Nt/2)*log(2*pi)+mlc-mld;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
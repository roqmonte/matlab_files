function results = EstimateVEC(data,johansen,r,p,mod,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Feb/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Reduced-form VEC estimation by OLS. The code estimates the
% VEC representaion of the model and recovers the VAR model.
% Inputs:
%   data        : Data levels
%   johansen    : Results from Johansen test
%   -.alpha     : Normalized adjustment/loadings coefficients (k,r).
%   -.betas     : Normalized cointegrating vectors (r,k).
%   mod         : Conf. for deterministic terms of the model.
%   r           : Number of cointegrating vectors.
%   p           : Lag order VAR model.
%   exo         : Exogenous variables (optional).
%
% Outputs:
%   results:
%   -.C         : Coefficients exogenous variables.
%   -.A         : Coefficients lagged variables.
%   -.F         : Companion form.
%   -.fitted    : Fitted values (T x n matrix).
%   -.coint     : Cointegration relationships.
%   -.resid     : Regression residuals (T x n matrix).
%   -.Sig       : Error covariance matrix.
%   -.LogL      : Log-likelihood
%   -.aic       : Akaike information criterion.
%   -.sic       : Schwarz information criterion.
%   -.hqc       : Hannan-Quinn information criterion.
%   -.Y         : Dependent variables of the system (lhs variables).
%   -.X         : Independent variables of the system (rhs variables).
%   -.k         : Number of  parameters per equation.
%   -.kn        : Total Number parameters of the model.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting info for estimation.
if exist('exo','var') == 0
    exo = [];
end

% Lag order VEC model
p = p - 1;
% Set up dependent variables
dy = data(2:end,:) - data(1:end-1,:);
Y  = dy(1+p:end,:);
n  = size(dy,2);

% Generating lags of dependent variables for VEC model.
X = [];
i = 1;
while i <= p
    X = [X dy(1+p-i:end-i,:)];
    i = i + 1;
end

% Generating lags of dependent variables for VAR model.
Xm = [];
i = 1;
while i <= p + 1
    Xm = [Xm data(1+(p+1)-i:end-i,:)];
    i = i + 1;
end

% Adding exogenous variables and error corection term
if mod == -1
    % Coint. equ doesn't includes constant term.
    cte = 0;
    temp = data(p+1:end-1,:)*johansen.betas(:,1:r);
    X   = [X  temp exo(1+p+1:end,:)];
else
    % Coint. equ includes constant term.
    cte = 1;
    % Model with restricte constant term
    if mod == 0
        temp = data*johansen.betas(1:n,1:r) + repmat(johansen.betas(end,1:r),size(data,1),1);
        X = [X temp(p+1:end-1,:) exo(1+p+1:end,:)];
        % Adjusting dim of X and exo variable.
        X = X(:,1:n*p+r);
        exo = exo(:,2:end);
        if size(exo,2) == 0
            exo = [];
        end
    % Model with unrestricte constant term
    elseif mod == 1
        temp = data*johansen.betas(1:n,1:r);
        X = [X temp(p+1:end-1,:) exo(1+p+1:end,:)];
    end
end
coint_rel = temp;
clear temp

% Var estimation.
T    = size(Y,1);
coef = (X'*X\X'*Y)';    % OLS equation per equation.
E    = (Y-X*coef');     % Computing residuals.
Sig  = (E'*E)/(T-n);    % Var/cov matrix.

% Total number of parameters
k = sum(sum(coef~=0));

% Get coefficients on exogenous variables
k_x = 0; C = [];
if size(exo,1) > 0
    k_x = size(exo,2);
    C = coef(:,end-k_x+1:end);
end
% Adding constant term to VAR model.
if mod == 0
    C   = [coef(:,p*n+1:p*n+r)*johansen.betas(end,1:r)' C];
    exo = [ones(size(Xm,1)+p+1,1) exo];
end

% Get coefficients for lagged variables.
A   = reshape(coef(:,1:p*n),n,n,p);
if p == 0
   A = zeros(n,n,1); 
end
% Get PHI matrix.
PHI = coef(:,p*n+1:p*n+r)*johansen.betas(1:n,1:r)';

% Recover VAR(p) representation of the model for the levels.
p = p + 1;
Am2 = [];
for i = 1:p
    if i == 1
        Am(:,:,i) = PHI + eye(n) + A(:,:,1);
    elseif i == p
        Am(:,:,i) = -A(:,:,end);
    else
        Am(:,:,i) = A(:,:,i) - A(:,:,i-1);    
    end
    Am2 = [Am2 Am(:,:,i)];
end
% Companion form VAR(p) model.
n = size(Am,1);
if p == 0
    F = [];
elseif p == 1
    F = Am;
elseif p > 1
    F = [reshape(Am,n,n*p); [eye(n*(p-1)) zeros(n*(p-1),n)]];
end

% Results.
results.C       = C;
results.A       = Am;
results.F       = F;
if isempty(exo) == 1
    results.fitted  = Xm*Am2';
else
    results.fitted  = Xm*Am2' + exo(p+1:end,:)*C';
end
results.coint   = coint_rel;
results.resid   = data(p+1:end,:) - results.fitted;
results.Sig     = (results.resid'*results.resid)/(T-n);
% Log likelihood
results.LogL    = -T*n/2*(1+log(2*pi)) - T/2*log(det(Sig));
% Information criteria
results.aic     = log(det(Sig)) + 2*k/T;
results.sic     = log(det(Sig)) + k*log(T)/T;
results.hqc     = log(det(Sig)) + 2*k*log(log(T))/T;
% Data
results.Y       = data(p+1:end,:);
results.X       = Xm;
% Parameters
results.k       = size(Xm,2) + size(exo,2);
results.kn      = results.k*n;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function PT_res = PT_decomp(data,info,results,r)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 02/Aug/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: The code performs the P-T decomposition from Gonzalo and
% Granger (1995).
%
%   X(t) = A1 * ft + A2 Xbar ( P + T )
%
% With ft = alpha_lt * X(t) and Xbar = betas'X(t). The model can be written
% as:
%   X(t) = A1 alpha_lt' X(t) + A2 betas' X(t)
%
% Where:
%   A1 = betas_lt(alpha_tl' betas_lt)^-1
%   A2 = alpha(betas' alpha)^-1
%
% Input:
%   data         : Data all variables of the system.
%   info:
%   -.p          : Lag order of the VAR model.
%   -.mod_type   : Conf. for deterministic terms of the model.
%  results
%   -.alpha      : Normalized adjustment/loadings coefficients (k,r).
%   -.betas      : Normalized cointegrating vectors (r,k).
%   r            : Number of cointegrating vectors.
%
% Output:
%  PT_res
%   -.A1         : Coeff. matrix P component.
%   -.A2         : Coeff. matrix T component.
%   -.ft         : Common factor.
%   -.Xbar       : Ciclical factor.
%   -.P_com      : Permanent component.
%   -.T_com      : Transitory component.
%   -.betas_lt   : Null basis coint vector.
%   -.alpha_lt   : Alpha Lt.
%   -.check      : In checks P-T decomposition.
%
% Index.
% 1. Getting info from core.
% 2. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%% 
% Getting info form code.
p  = info.p - 1;
m  = size(data,2);
H  = info.mod_type;
k  = m - r;

% Getting data ready
YLags = mlag(data,p+1);
LY    = YLags(p+1:end-1,1:m);
temp1 = data(2:end,:) - data(1:end-1,:);
temp2 = mlag(temp1,p);
temp2 = temp2(p+1:end,:);
DY    = temp2(:,1:m);
DLY   = temp2(:,m+1:end);

% Defining conf. of the model
if H == -1
    Z0 = DY;
    Z1 = LY;
    Z2 = DLY;
elseif H == 0
    Z0 = DY;
    Z1 = [LY ones(size(LY,1),1)]; % restricted constant,
    Z2 = DLY;
elseif H == 1
    Z0 = DY;
    Z1 = LY;
    Z2 = [DLY ones(size(DLY,1),1)]; % Unrestricted constant.
end

% Perform the concentrating regressions.
R0 = Z0-Z2*(Z2\Z0); % Z0 on Z2 residuals.
R1 = Z1-Z2*(Z2\Z1); % Z1 on Z2 residuals.

% Compute the product moment matrices of the residuals.
T = size(R0,1);
S00 = (R0'*R0)/T;
S01 = (R0'*R1)/T;
S10 = (R1'*R0)/T;
S11 = (R1'*R1)/T;

% Normalize loadings and eigenvectors
alphaa = results.alpha(:,1:r);
betas  = results.betas(1:m,1:r);

% Working on P-T decomposition from Gonzalo and Granger (1995).
[V2,D2] = eig(S01*(S11\S10),S00);
[lambda2,sortIdx2] = sort(diag(D2),'descend');
% Corresponding eigenvectors.
V2 = V2(:,sortIdx2);
% Normalize the eigenvectors so that M'*S00*M = I.
U2 = V2'*S00*V2;
alphaa_lt = V2./repmat(sqrt(diag(U2))',m,1);
alphaa_lt = alphaa_lt(:,r+1:end);
% Null space for b'.
betas_lt   = null(betas(:,1:r)');

% Building the decomposition
A1 = betas_lt*(alphaa_lt'*betas_lt)^(-1);
A2 = alphaa*(betas'*alphaa)^(-1);

% Building P-T decomposition.
ft   = (alphaa_lt'*data')';
Xbar = (betas'*data')';

% Checking decomposition.
In = A1*alphaa_lt' + A2*betas';

% Saving resuls.
PT_res.A1       = A1;
PT_res.A2       = A2;
PT_res.ft       = ft;
PT_res.Xbar     = Xbar;
PT_res.P_com    = (A1*ft')';
PT_res.T_com    = (A2*Xbar')';
PT_res.betas_lt = betas_lt;
PT_res.alpha_lt = alphaa_lt;
PT_res.check    = In;


%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Functions.

% Functions generatesa matrix of n lags froma matrix.
function mat = mlag(data,p)
T = size(data,1);
N = size(data,2);
NP= N*p;

% Matrix to store results.
mat = NaN(T,N+NP);
mat(:,1:N) = data;

% Filling lags.
z = 1;
for i0 = 1:p
    temp = data(1:end-z,:);
    mat(z+1:end,N*i0+1:N*i0+N) = temp;
    z = z + 1;
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
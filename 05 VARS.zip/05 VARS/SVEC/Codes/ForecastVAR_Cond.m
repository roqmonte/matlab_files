function forecast = ForecastVAR_Cond(results,irf,info,exo,h_const,print,fid)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 24/Nov/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes conditional VAR forecast.
% Inputs:
%   results:
%   -.C           : Coefficients exogenous variables.
%   -.F           : Companion form.
%   -.SG          : Draws from Sigama of the reduced form VAR.
%   -.A0          : Draws from the structural matrix A0.
%   -.Y           : Left hand variables.
%   -.X           : Right hand variables.
%   irf           : IRF
%   info:
%   -.p           : Lag order.
%   -.names       : Labels with variable names (1 x n).
%   -.fsizes      : Font sizes to be used (1 x 2).
%   -.dates_ini   : Setting for dates: (year,month,freq).
%                   Where, freq: (1) monthly;(2) quaterly data.
%   -.dates_xTick : Xtick for dates.
%   -.widths      : vector with line widths.
%   -.fsizes      : vector with font sizes.
%   exo           : Exogenous variables.
%   h_const       : Matrix with constrained paths (p const x N); col(0) no restrictions.
%   print         : (1) print charts.
%   fid           : Figure number for plots.
%
% Outputs:
%   forecast:
%   -.dataf     : Matrix with data and forecast.
%   -.VARf      : Matrix with forecast only.
%
% Index:
% 2. Forecast.
% 3. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting info for estimation.
if exist('exo','var') == 0
    exo = [];
end
fsize      = info.fsizes(1);
fsize_alt  = info.fsizes(2);
% Checking dim of exo and h.
if size(exo,1) > 1
    if size(exo,1) ~= size(h_const,1)
       error('Dim for exo variables not consistent with forecast horizon.');
    end
end

% Model selection with and without block exogeneity.
if info.block == 0    
    C = results.C;
elseif info.block == 1
    C = [results.C_1; results.C_2];
end
F = results.F;
A0inv = chol(results.Sig,'lower');

% Info fom code.
p = info.p;
N = size(results.Y,2);
h = size(h_const,1);
% Reshape IRF
for i0 = 1:N
    irf_all(:,:,i0) = squeeze(irf(:,i0,:))';
end    

% Setp up for the restriction.
rest_per = size(h_const,1);
id_rest  = double(any(h_const)).*(1:N);
id_rest  = id_rest((id_rest>0));

% Condtional forecast.
yf = yfore_cond(irf_all,rest_per,id_rest,h_const,results.Y,exo,p,F,C,A0inv);
% Forecast
forecast.dataf = [NaN(info.dates_xTick(end)-size(results.Y,1),N); [results.Y; yf]];
forecast.VARf  = yf;
Tf             = size(forecast.dataf,1);

% Do charts
if exist('print','var')
    if print == 1       
        if exist('fid','var') == 0
            fid = 1;
        end;
        % Do charts
        % Setup for charts
        line_width= info.widths(1);
        fsize     = info.fsizes(1);
        fsize_alt = info.fsizes(2);
        names     = info.names;
        if info.dates_ini(end) == 1
            freq = 'm';
        elseif info.dates_ini(end) == 2
            freq = 'q';
        end
        [xTick,xTickLabel] = calendar(info.dates_ini(1),info.dates_ini(2),Tf,freq);

        % Number of variables and graph setup.
        aux = N;
        if aux <= 3
            k1 = 1; k2 = aux;
        elseif aux <= 4
            k1 = 2; k2 = 2;
        elseif aux > 4 && aux <= 6
            k1 = 3; k2 = 2;
        elseif aux > 6 && aux <= 9
            k1 = 3; k2 = 3;
        elseif aux > 9 && aux <= 16
            k1 = 4; k2 = 4;
        elseif aux > 16
            error('Max number of variables reached.');
        end

        % Building Chart
        figure(fid);
        k = 1;
        for j = 1:N
            subplot(k2,k1,k);
            plot(forecast.dataf(:,j),'-r','LineWidth',line_width);
            hold on
            plot([forecast.dataf(1:end-h,j); NaN(h,1)],'-b','LineWidth',line_width);
            title(names(j),'FontSize',fsize);
            set(gca,'FontSize',fsize_alt);
            % Limits for charts
            set(gca,'xTick',xTick);
            set(gca,'xTickLabel',xTickLabel);
            xlim([xTick(round(size(xTick,1)/2)) xTick(end)]);
            k = k + 1;
        end;
        legend1 = legend('forecast','Data');
        set(legend1,'FontSize',fsize_alt-2,'Orientation','horizontal',...
        'Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
        clear k j fid1;
    end
end
    
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions.
% Function estimates conditionla forecast and matrix r, R.
function yf = yfore_cond(irf,h,id,h_const,Y,exo,p,F,C,A0inv)
% Imputs.
%   irf     : Structural Impulse response from VAR model.
%   h       : Restricted horizon.
%   id      : Vector that identifies restrcited variables.
%   h_const : Matrix with constrained paths (p const x N); col(0) no restrictions.
%   Y       : Dependent variables.
%   exo     : Exogenous variables.
%   p       : Lag order of the VAR.
%   F       : Companion form.
%   C       : Parameters exo variables.
%   A0inv   : Invesre of structural matrix A0.
% Outputs:
%   yf      : Conditional forecast.

% Number of variables 
N = size(irf,2);

% Unconditional forecast.
y_fore = Y(end-p-12:end,:);
for j0 = 1:h
    Ttemp = size(y_fore,1);
    temp1 = [];
    for i0 = Ttemp:-1:Ttemp-p+1
        temp1 = [temp1; y_fore(i0,:)'];
    end
    % Forecast 
    if isempty(exo) == 1
        aux = ([eye(N);zeros(N*(p-1),N)])'*F*temp1;
    else
        aux = ([eye(N);zeros(N*(p-1),N)])'*F*temp1 + C*exo(j0,:)';
    end
    yf_ini(j0,:)  = aux';
    % Adding forecast to data.
    y_fore = [y_fore; yf_ini(j0,:)];
    clear temp1 aux;
end
clear Ttemp y_fore j0;

% Bulding R matrix
IRF_temp = irf(1:h,:,:,1);
R = [];
for i0 = 1:size(id,2)
    IRF_temp2 = squeeze(IRF_temp(:,id(i0),:));
    R1 = IRF_temp2;
    for i1 = 1:h-1
        temp = [zeros(i1,N); IRF_temp2(1:end-i1,:)];
        R1   = [R1 temp];
    end
    R = [R; R1];
    clear i1 temp R1;
end
clear i0 IRF_temp;

% Bulding r matrix
r = vec(h_const(:,id) - yf_ini(:,id));
% Restricted structural shocks
ehat = R'*(R*R')^(-1)*r;
ehat = reshape(ehat,N,h)';

% Conditionl forecast
y_fore = Y(end-p-12:end,:);
for j0 = 1:h
    Ttemp = size(y_fore,1);
    temp1 = [];
    for i0 = Ttemp:-1:Ttemp-p+1
        temp1 = [temp1; y_fore(i0,:)'];
    end
    % Forecast 
    if isempty(exo) == 1
        aux = ([eye(N);zeros(N*(p-1),N)])'*F*temp1;
    else
        aux = ([eye(N);zeros(N*(p-1),N)])'*F*temp1 + C*exo(j0,:)';
    end
    yf(j0,:)  = aux' + ehat(j0,:)*A0inv';
    % Adding forecast to data.
    y_fore = [y_fore; yf(j0,:)];
    clear temp1 aux;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
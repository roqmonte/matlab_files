function results = johansen(data,info)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 22/Jul/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: The code estimate the rank(PHI), and the cointegrating vectors. 
% using Johansen's procedure. Note, c_sja(), c_sjt() provide critical values 
% generated using a method of MacKinnon (1994, 1996). Critical values are 
% available for n<=12 and -1 <= p <= 1, zeros are returned for other cases.
% Input:
%   data         : Data all variables of the system.
%   info:
%   -.p          : Lag order of the VAR model.
%   -.mod_type   : Conf. for deterministic terms of the model.
%   -.endo_names : Vector with labels for variables of the system (1 x n).
%
% Output:
%  results
%   -.eig      : Eigenvalues (m,1).
%   -.alpha    : Normalized adjustment/loadings coefficients.
%   -.betas    : Normalized cointegrating vectors.
%   -.lr1      : Likelihood ratio trace statistic, for r=0 to m-1 (m,1).
%   -.lr2      : Maximum eigenvalue statistic, for r=0 to m-1 (m,1).
%   -.cvt      : CV trace statistic at [90% 95% 99%] sig. levels.
%   -.cvm      : CV max eigen value statistic at [90% 95% 99%] sig. levels.
%
% Index.
% 1. Getting info from core.
% 2. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%% 
% Getting info form code.
p  = info.p;
m  = size(data,2);
H  = info.mod_type;

% Getting data ready
YLags = mlag(data,p+1);
LY    = YLags(p+1:end-1,1:m);
temp1 = data(2:end,:) - data(1:end-1,:);
temp2 = mlag(temp1,p);
temp2 = temp2(p+1:end,:);
DY    = temp2(:,1:m);
DLY   = temp2(:,m+1:end);

% Defining conf. of the model
if H == -1
    Z0 = DY;
    Z1 = LY;
    Z2 = DLY;
elseif H == 0
    Z0 = DY;
    Z1 = [LY ones(size(LY,1),1)]; % restricted constant,
    Z2 = DLY;
elseif H == 1
    Z0 = DY;
    Z1 = LY;
    Z2 = [DLY ones(size(DLY,1),1)]; % Unrestricted constant.
end

% Perform the concentrating regressions.
R0 = Z0-Z2*(Z2\Z0); % Z0 on Z2 residuals.
R1 = Z1-Z2*(Z2\Z1); % Z1 on Z2 residuals.

% Compute the product moment matrices of the residuals.
T = size(R0,1);
S00 = (R0'*R0)/T;
S01 = (R0'*R1)/T;
S10 = (R1'*R0)/T;
S11 = (R1'*R1)/T;

% Estimate the eigenvectors and eigenvalues of C = A*B'.
[V,D] = eig(S10*(S00\S01),S11);
[lambda,sortIdx] = sort(diag(D),'descend');
% Corresponding eigenvectors.
V = V(:,sortIdx);

% Normalize the eigenvectors so that V'*S11*V = I, as in (2).
U = V'*S11*V; % V diagonalizes S11.
betas = V./repmat(sqrt(diag(U))',size(U,1),1);
% Adjustment coefficients/loadings coeff. (alpha)
alphaa = S01*betas;

% Matrix to store results.
lr1 = zeros(m,1);
lr2 = zeros(m,1);
cvm = zeros(m,3);
cvt = zeros(m,3);

% Chosing conf. for critical values.
if H == -1
    mod_type = 1;
elseif H == 0
    mod_type = 2;
    lambda = lambda(1:end-1);
    betas = betas(:,1:end-1);
elseif H == 1
    mod_type = 3;
end
% Loading critical values.
sigLevels = [0.001 (0.005:0.005:0.10) (0.125:0.025:0.20) ...
                   (0.80:0.025:0.875) (0.90:0.005:0.995) 0.999];
load Data_CV_johansen JCV
c_sjt = JCV(:,[1 2 3],mod_type,1); % Trace test CVs.
c_sja = JCV(:,[1 2 3],mod_type,2); % Max eig. CVs.

% Compute the trace and max eigenvalue statistics
iota = ones(m,1);
t    = size(R0,1);
for i = 1:m
    % Trace test.
    tmp = trimr(log(iota-lambda),i-1,0);
    lr1(i,1) = -t*sum(tmp);
    cvt(i,:) = c_sjt(m-i+1,:);
    % Max eig. test.
    lr2(i,1) = -t*log(1-lambda(i,1));
    cvm(i,:) = c_sja(m-i+1,:);
end

% Saving results.
results.eig   = lambda;
results.alpha = alphaa;
results.betas = betas;
results.lr1   = lr1;
results.lr2   = lr2;
results.cvt   = cvt;
results.cvm   = cvm;
% Printing table with results.
print_res(results,info);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Functions.

% Funtion do table.
function Estimation_results = print_res(results,info)
% Building table
lab = [];
r = size(results.betas,2);
for i0 = 1:r
    lab2 = {['r',num2str(i0)]};
    lab = [lab lab2];
end
% Cointegrating vectors
labels = ['betas' info.names];
if info.mod_type == 0
    labels = [labels 'C'];
    info.names = [info.names 'C'];
end
temp_1 = [lab' num2cell(results.betas')];
part_1a = [labels; temp_1];
% Adjustment/loadings coefficitens.
for i0 = 1:r
    lab_a(1,i0) = strcat('D(',info.names(i0),')');
end
labels = ['alpha'; lab_a'];
part_1b = [labels [info.names; num2cell(results.alpha)]];
part_1  = repmat({' '},size(part_1a,1)+size(part_1b,1)+1,size(part_1a,2)+size(part_1b,2));
part_1(1:size(part_1a,1),1:size(part_1a,2)) = part_1a;
part_1(size(part_1a,1)+2:size(part_1a,1)+size(part_1b,1)+1,1:size(part_1b,2)) = part_1b;

% Trace stat
temp_2 = {'# CE(s)' 'Eigenvalue' 'Trace stat' '90%' '95%' '99%'};
temp_3 = [num2cell(0:r-1)' num2cell(results.eig) num2cell(results.lr1) num2cell(results.cvt)];
part_2 = [{' ' ' ' ' ' ' ' ' ' ' '}; temp_2; temp_3];
% M.eig stat
temp_4 = {'# CE(s)' 'Eigenvalue' 'M.eig stat' '90%' '95%' '99%'};
temp_5 = [num2cell(0:r-1)' num2cell(results.eig) num2cell(results.lr2) num2cell(results.cvm)];
part_3 = [{' ' ' ' ' ' ' ' ' ' ' '}; temp_4; temp_5];
part_4 = [part_2;part_3];
% Print results.
aux = repmat({' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' '},size(part_1,1)+size(part_2,1)+size(part_3,1)+1,1);
aux(1:size(part_1,1),1:size(part_1,2)) = part_1;
aux(size(part_1,1)+1:size(part_1,1)+size(part_4,1),1:size(part_4,2)) = part_4;
% Final table
Estimation_results = aux(:,1:max([size(temp_1,2) size(temp_4,2)]));
print = 1;
if print == 1
    fid = 1;
    fprintf(fid,'************************************************************************************\n');
    display(Estimation_results);
    fprintf(fid,'************************************************************************************\n');
end


% Functions generatesa matrix of n lags froma matrix.
function mat = mlag(data,p)
T = size(data,1);
N = size(data,2);
NP= N*p;

% Matrix to store results.
mat = NaN(T,N+NP);
mat(:,1:N) = data;

% Filling lags.
z = 1;
for i0 = 1:p
    temp = data(1:end-z,:);
    mat(z+1:end,N*i0+1:N*i0+N) = temp;
    z = z + 1;
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
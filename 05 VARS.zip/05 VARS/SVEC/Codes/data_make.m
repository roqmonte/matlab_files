function [data,info,determ] = data_make(data_ini,info)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 22/Jul/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Generates data for VEC model.
% Input:
%   data_ini        : Data all variables of the system.
%   info:
%   -.mod_type      : Conf. for deterministic terms of the model.
%   -.labels_all    : Vector with all labels.
%   -.endo_names    : Vector with labels for variables of the system (1 x n).
%   -.names         : Labels variables in the VAR.
%   -.shock_name    : Shocked equation. 
%   -.shock_names   : Shock labels.
%   -.dates_ini     : Vector with info for dates: [year,month,freq].
%
% Output:
%   data:
%   -.all           : Data all variables.
%   -.endo          : Data endogenous variables of the model.
%   info:
%   -.pos_shock     : Possition of the shocked variable.
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%   determ          : Constant term, trends and exo variables for VAR.
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Building variables.
% Getting info from code.
var_names  = info.labels_all;
endo_names = info.endo_names;
n_endo     = length(endo_names);

% Preparing data for the model.
% Locate positions of variables.
for i=1:n_endo
    pos_endo(i) = loc(char(var_names),char(endo_names(i)));
end

% Results.
data.endo   = data_ini(:,pos_endo);
data.all    = data_ini(:,pos_endo);
% Labels for variables.
if isfield(info,'names') == 0
    info.names = var_names(pos_endo);
end
% Labels for shocks.
aux_t1 = {'Shock '}; aux_t2 = {};
for i0 = 1:n_endo
    aux_t2 = [aux_t2 strcat(aux_t1,num2str(i0))];
end
% Checking consistency for shocks labels
if isfield(info,'shock_names') == 0
    info.shock_names = aux_t2;
else
    if size(info.shock_names,2) < n_endo
        info.shock_names = [info.shock_names aux_t2(:,size(info.shock_names,2)+1:end)];
    end
end
clear aux_t1 aux_t2 i0;

% Locate shocked variable
info.pos_shock = loc(char(info.endo_names),info.shock_name);
% Generating dates.
T = length(data_ini);
if info.dates_ini(end) == 1
	freq = 'm';
elseif info.dates_ini(end) == 2
	freq = 'q';
end
[time1,time2] = calendar(info.dates_ini(1),info.dates_ini(2),T,freq);
info.dates_xTick = time1;
info.dates_label = time2;

% Building exo variables.
% Constant term
if info.mod_type == 1;
    determ = ones(size(data_ini,1),1);    
else
    determ = [];
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
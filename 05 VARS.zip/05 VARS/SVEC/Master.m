%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description:: Estimation of a vector error correction model (VEC) using a
% two step procedure. The model has a VAR(p) representation:
%
% (1) y_t = A1 y_t-1 + ... + A_1p y1_t-p + e_t.
%
% If there are cointegrating relationships between the variables of the model,
% then we can write the VEC(p-1) representation of the model as;
%
% (1) dy_t = PHI y_t-1 + A_11 dy_t-1 + ... + A_1p-1 dy1_t-p + u_t,
%
% Here PHI = ab', contains the loadings (a) and cointegrating vectors (b). 
% The Johansen procedure is used to estimate the cointegration vectors, and
% then the VEC is estimated by OLS (two step procedure). Finally, all
% statistics (IRF, FEVD, etc) are derived from the VAR representation.
% The model allows for deterministic terms, in particular there are three
% versions of the model that defines the dinamics for the levels of the variables: 
% [a] centered around 0; [b] centered around non-zero mean; [c] drift in data.
%
% Model B (A = In) is used to identify the structural shocks.
% - B Model: 
%   A(L)y_t   = u_t             Where u_t   = B*e_t
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Loading data.
clc; clear; close all;
% Seed for the random number generator.
rng('default');

% Working folder
info.ruta = 'C:\Users\Roque Montero\Google Drive\Codigos_Matlab\05 VARS\SVEC';
cd(info.ruta);
% Loading data.
[~,labels_ini] = xlsread('Data_var','data_m','V2:AE2');
data_ini = xlsread('Data_var','data_m','V3:AE214');

% Defining endogenous variables.
info.labels_all = labels_ini;
info.endo_names= {'NEER' 'CLP'};
% Define the shocked variable.
info.shock_name = 'CLP';

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Options for the code.
% Lag order endogenouse variables in VEC(p-1) representation of the model.
info.p          = 2;
% Setting dates.
info.dates_ini  = [2000,2,1];       % First observation of the data.
% Settings for impulse responses.
info.do_norm    = 1;                % (1) Normalized shocks; (0) otherwise.
info.norm_fac   = 1;                % Normalization factor (e.g. 10 = 10%).
info.horizon    = 12;               % Horizon of impulse responses.
info.rep        = 10^1;             % Number of bootstrap replications.
info.conf       = [.68 .90 .95];    % Significance levels for error bands.
% Options for plots.
info.widths     = [1 0.7];          % Line widths (zero line, point estim.).
info.fsizes     = [12 10];          % Font sizes (titles, axes).
info.area_color = [0.9 0.9 0.9];    % Color of area for highest sign. level.
info.names      = {'NEER' 'USDCLP'};
info.shock_names= {'CLP shock'};

% Identification of the model
% Each column of B represents the contemporaneous impact of transitory shocks, 
% where NaN entries indicate free parameters and zero entries represent 
% restriction on the response of variables to the transitory shocks.
Br= [ NaN  NaN  NaN;...
      NaN  NaN   0;...
      NaN  NaN  NaN];

% Model type: 
% [-1], No intercepts/trends in cointegrated series (no trend).
% [ 0], Intercepts only in the cointegrated series (non-zero mean).
% [ 1], Intercepts in the cointegrated series and deterministic linear
% trends in the data.
info.mod_type = 1;
  
% Preparing data and model for estimation.
[data,info,determ] = data_make(data_ini,info);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model estimation.
% Testing lag lenght of the model.
info.alpha       = 0.05;
info.max_lag     = 12;
lag_test_results = VAR_TestLagLength(data,info,determ);

% Johansen test for # and parameters of cointegrating vectors.
res_johansen = johansen(data.endo,info);

% Perform P-T decomposition.
PT_res = PT_decomp(data.endo,info,res_johansen,1);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
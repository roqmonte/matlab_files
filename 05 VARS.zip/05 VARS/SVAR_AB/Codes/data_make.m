function [data,info,A,B,theta,determ,id1,id2] = data_make(data_ini,info,cte,trend,exo,Ar,Br)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 31/Aug/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Generates data for AB-VAR model and initial values for
% parameter estimation.
% Input:
%   data_ini        : Data all variables of the system.
%   info:
%   -.px            : Lag order exo variables.
%   -.labels_all    : Vector with all labels.
%   -.endo_names    : Vector with labels for variables of the system (1 x n).
%   -.names         : Labels variables in the VAR.
%   -.shock_name    : Shocked equation. 
%   -.shock_names   : Shock labels.
%   -.p             : Lag order.
%   -.dates_ini     : Vector with info for dates: [year,month,freq].
%   cte             : (0) No constant; (1) Constant (default).
%   trend           : (0) No trend (default); (1) linear trend; (2) quadratic trend.
%   exo             : Exogenous variables of the model.
%   Ar              : Matrix with restrictions for A matrix.
%   Br              : Matrix with restrictions for B matrix.
%
% Output:
%   data:
%   -.all           : Data all variables.
%   -.endo          : Data endogenous variables of the model.
%   info:
%   -.pos_shock     : Possition of the shocked variable.
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%   -.var_results   : Structure with results from the reduced VAR model.
%   -.determ_cte    : Contant term.
%   -.determ_trend  : Linear trend.
%   -.determ_trend2 : Quadratic term.
%   -.determ_exo    : Exogebous variable.
%   -.px            : Lag order exo variables.
%   A               : Initial values for A matrix.
%   B               : Initial values for B matrix.
%   theta           : Vector with initial values for estimation.
%   determ          : Constant term, trends and exo variables for VAR.
%   id1             : Matrix containing location of NaN entries in Ar.
%   id2             : Matrix containing location of NaN entries in Br.
%
% Index:
% 1. Building variables.
% 2. Building parameters.
% 3. Checking code configuration.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Building variables.
% Checking exo variables
if exist('exo','var') == 0
    exo = [];
    px = 0;
else
    px = info.px*(1-isempty(exo));
end
% Getting info from code.
var_names  = info.labels_all;
endo_names = info.endo_names;
n_endo     = length(endo_names);
T          = length(data_ini);

% Preparing data for the model.
% Locate positions of variables.
for i=1:n_endo
    pos_endo(i) = loc(char(var_names),char(endo_names(i)));
end

% Results.
data.endo   = data_ini(1+px:end,pos_endo);
data.all    = data_ini(1+px:end,pos_endo);
% Labels for variables.
if isfield(info,'names') == 0
    info.names = var_names(pos_endo);
end
% Labels for shocks.
aux_t1 = {'Shock '}; aux_t2 = {};
for i0 = 1:n_endo
    aux_t2 = [aux_t2 strcat(aux_t1,num2str(i0))];
end
% Checking consistency for shocks labels
if isfield(info,'shock_names') == 0
    info.shock_names = aux_t2;
else
    if size(info.shock_names,2) < n_endo
        info.shock_names = [info.shock_names aux_t2(:,size(info.shock_names,2)+1:end)];
    end
end
clear aux_t1 aux_t2 i0;

% Locate shocked variable
info.pos_shock = loc(char(info.endo_names),info.shock_name);
% Generating dates.
T = length(data_ini);
if info.dates_ini(end) == 1
	freq = 'm';
elseif info.dates_ini(end) == 2
	freq = 'q';
end
[time1,time2] = calendar(info.dates_ini(1),info.dates_ini(2),T,freq);
info.dates_xTick = time1;
info.dates_label = time2;
info.px    = px;

% Building exo variables.
% Constant term
if cte == 0
    info.determ_cte = [];
elseif cte == 1
    info.determ_cte = ones(size(data_ini,1),1);    
else
   error('Check cte variable'); 
end
% Trends
if trend == 0
    info.determ_trend = [];
    info.determ_trend2= [];
elseif trend == 1
    info.determ_trend = (1:size(data_ini,1))';
    info.determ_trend2= [];
elseif trend == 2
    info.determ_trend = (1:size(data_ini,1))';
    info.determ_trend2= ((1:size(data_ini,1)).^(2))';
else
   error('Check trend variable'); 
end
% Exo variables.
if size(exo,2) == 0 
    info.determ_exo = [];
elseif size(exo,2) > 0
    exo2 = LagN(exo,px);
    info.determ_exo = exo2;
end
% Deterministic variables.
determ = [info.determ_cte(1+px:end) info.determ_trend(1+px:end) info.determ_trend2(1+px:end) info.determ_exo];

% VAR estimation.
info.var_results = EstimateVAR(data.endo,info.p,determ);

% Adding names of the variables in the results for VAR.
info.var_results.names = info.names;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Building parameters.
% Number of variables.
nvar = size(info.var_results.Sig,2);

% Matrix A and theta associated to free elements of A.
if Ar == eye(n_endo)
    A     = Ar;
    theta = [];
    id1   = [];
else
    % Building A matrix according to Ar matrix.
    [row,col]   = find(isnan(Ar));
    id1         = [row col];
    A           = Ar(:);
    % Initial values for Ar.    
    A_2 = vec(corr(info.var_results.resid));
    for i0 = 1:nvar^2
        if isnan(A(i0))
            A(i0) = A_2(i0);
        end
    end        
    % Matrix A and theta associated to free elements of Ar.
    A = reshape(A,nvar,nvar);
    for i0 = 1:size(id1,1)
        theta(i0,1) = A(id1(i0,1),id1(i0,2));
    end    
end

% Building B matrix according to Br matrix.
if Br == eye(n_endo)
    B   = Br;
    id2 = [];
else
    % Building second part of theta vector.
    [row,col] = find(isnan(Br));
    id2 = [row col];
    B   = Br(:);
    % Initial values for Br
    B_2 = abs(vec(info.var_results.A(:,:,1)));
    for i0 = 1:nvar^2
        if isnan(B(i0))
            B(i0) = B_2(i0);
        end
    end
    % Matrix B and theta associated to free elements of Br.
    B = reshape(B,nvar,nvar);
    for i0 = 1:size(id2,1)
        theta_b(i0,1) = B(id2(i0,1),id2(i0,2));
    end
    theta = [theta; theta_b];
end
clear row col i0 i;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Checking code configuration.
% Dim of A and B mmust be consistence
if (size(Ar,1) ~= size(Br,1)) || (size(Ar,2) ~= size(Br,2))
    error('Dimension of A and B are not consistent.');
end

% Checking local identification, Rothenberg's (1971).
% For the system.
RT_cond = nvar*(nvar+1)/2;          % # Parameters to estimate in identified model
n_rest  = size(id1,1)+size(id2,1);  % # Parameters in the model.
if n_rest == RT_cond
    disp('-The model is locally identified according to Rothenbergs (1971) condition (#rest = n*(n-1)/2).');
elseif n_rest < RT_cond
    disp('-The model is over identified (#rest > n*(n-1)/2).');
else
    disp('-The model is not locally identified according to Rothenbergs (1971) condition (#rest = n*(n-1)/2).');
end
pause(1);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
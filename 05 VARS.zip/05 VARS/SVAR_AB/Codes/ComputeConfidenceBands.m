function [bands,sig] = ComputeConfidenceBands(data,Ar,Br,info,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 12/Oct/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes bootstrapped confidence bands for impulse responses.
% Input:
%   data:
%   -.endo      : Data endogenous variables.
%   Ar          : Matrix with restrictions for A matrix.
%   Br          : Matrix with restrictions for B matrix.
%   info:
%   -.p         : Lag order.
%   -.horizon   : Horizon for impulse response functions.
%   -.rep       : Number of Bootstrap replications.
%   -.conf      : Confidence levels for error bands.
%   -.do_norm   : (1) Normalized impulse responses; else (0).
%   -.norm_fac  : Normalization factor in percent.
%   exo         : Exogenous variables (optional).
%
% Output:
%   bands       : Lower (1st) and upper (2nd) bands (n x h+1 x 2 x c).
%   sig         : IRF standard deviations (n x h+1)
%
% Index:
% 1. VAR estimation.
% 2. Boostraps.
% 3. Results.
% 4. Functions
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. VAR estimation.
if exist('exo','var') == 0
    exo = [];
end
rVAR = EstimateVAR(data.endo,info.p,exo);

% Inputs for the code.
A    = rVAR.A;
C    = rVAR.C;
n    = size(A,1);
resid= rVAR.resid;
T    = length(data.endo);
p    = info.p;
rep  = info.rep;
conf = info.conf;
c    = length(conf);

% Allocate memory for simulated data.
for k=1:rep
    boot_data(k).endo = zeros(T,n);
end;
% Generate bootstrap indices
[~,index] = bootstrp(rep,[],resid);
% Put waitbar
h_wait = waitbar(0,'Generating bootstrap samples, please wait...');
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Boostraps.
% Generate bootstrap samples
for k = 1:rep
    waitbar(k/rep,h_wait)
    for i = 1:T
        if i <= p
            % Use pre-sample values here
            boot_data(k).endo(i,:) = data.endo(i,:);
        else
            % Exogenous variables
            if size(exo,2) > 0
                boot_data(k).endo(i,:) = exo(i,:)*C';
            end;
            % Autoregressive parts
            for j = 1:p
                boot_data(k).endo(i,:) = boot_data(k).endo(i,:) + ...
                                         boot_data(k).endo(i-j,:)*A(:,:,j)';
            end;
            % Stochastics
            boot_data(k).endo(i,:) = boot_data(k).endo(i,:) + resid(index(i-p,k),:);
        end;
    end;
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Close waitbar
close(h_wait)
% Put waitbar
h_wait = waitbar(0,'Bootstrapping impulse responses, please wait...');
% Generate bootstrap impulse responses
for k = 1:rep
    waitbar(k/rep,h_wait)
    % Estimation reduced form model.
    var_results = EstimateVAR(boot_data(k).endo,info.p,exo);
    % Model setup.
    [theta,id1,id2]  = gen_var(Ar,Br,var_results);
    info.var_results = var_results;
    % Computing Hessian matrix at initial values.
    H     = fdhess('AB_model',theta,boot_data(k),info,id1,id2,exo);
    H0inv = H\eye(size(H));
    % Checking the consistency of the Hessian Matrix.
    if max(max(isnan(H0inv))) == 1 || max(max(isinf(H0inv))) == 1 || isreal(H0inv) == 0 || isreal(H) == 0
        H = eye(size(theta,1));
    else
        [V,Diag] = eig(H0inv);
        Diag     = abs(Diag);
        H        = V*Diag*V';
    end;
    % Numerical Optimizaci�n.
    tol = 1e-08; n_ite = 2000;
    [~,thetaf,~,~,~,~,~] = csminwel('AB_model',theta,H,[],tol,n_ite,boot_data(k),info,id1,id2,exo);
    % Estimation of the structural matrices AB.
    [~,results] = AB_model(thetaf,boot_data(k),info,id1,id2,exo);
    clear Diag V i0 tol n_ite H0inv;    
    % Computing IRF for simulated data.
    boot_irf(:,:,k) = ComputeImpulseResponses(info,results);
    clear results;
end;
% Close waitbar
close(h_wait)

% Sort impulse responses (sort at each t)
sort_irf = sort(boot_irf,3);
% Compute lower and upper bands.
for i = 1:c
    bands(:,:,1,i) = sort_irf(:,:,ceil((1-(1+conf(i))/2)*rep));
    bands(:,:,2,i) = sort_irf(:,:,ceil((1+conf(i))/2*rep));
end;
% Provide standard deviations
sig = std(boot_irf,0,3);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions

% The function generates the initial values for the model estimation.
function [theta,id1,id2] = gen_var(Ar,Br,var_res)
% Inputs:
%   -.Ar    : Matrix with NaN entries for A.
%   -.Br    : Matrix with NaN entries for B.
%   var_res:
%   -.Sig   : Var/cov matrix for B matrix.
%   -.A1    : First lags of VAR for A matrix.
% Outputs:
%   thera   : Vector with initial values for the partameters of the model.
%   id1     : Matrix containing location of the NaN entries in B matrix.
%   id2     : Matrix containing location of the NaN entries in A matrix.

% Number of variables.
nvar   = size(var_res.Sig,2);

% Matrix A and theta associated to free elements of A.
if Ar == eye(nvar)
    A     = Ar;
    theta = [];
    id1   = [];
else
    % Building A matrix according to Ar matrix.
    [row,col]   = find(isnan(Ar));
    id1         = [row col];
    A           = Ar(:);
    % Initial values for Ar.
    A_2 = vec(var_res.Sig);
    for i0 = 1:nvar^2
        if isnan(A(i0))
            A(i0) = A_2(i0);
        end
    end        
    % Matrix A and theta associated to free elements of Ar.
    A = reshape(A,nvar,nvar);
    for i0 = 1:size(id1,1)
        theta(i0,1) = A(id1(i0,1),id1(i0,2));
    end    
end

% Building B matrix according to Br matrix.
if Br == eye(nvar)
    B   = Br;
    id2 = [];
else
    % Building second part of theta vector.
    [row,col] = find(isnan(Br));
    id2 = [row col];
    B   = Br(:);
    % Initial values for Br
    B_2 = abs(vec(var_res.A(:,:,1)));
    for i0 = 1:nvar^2
        if isnan(B(i0))
            B(i0) = B_2(i0);
        end
    end
    % Matrix B and theta associated to free elements of Br.
    B = reshape(B,nvar,nvar);
    for i0 = 1:size(id2,1)
        theta_b(i0,1) = B(id2(i0,1),id2(i0,2));
    end
    theta = [theta; theta_b];
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
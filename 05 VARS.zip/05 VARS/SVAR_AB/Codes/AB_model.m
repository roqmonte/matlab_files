function [ll,results] = AB_model(theta,data,info,id1,id2,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 24/Feb/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes likelihood for AB-VAR model for a given set of
% structural parameters.
% Inputs:
%   theta           : Parameters of the model.
%   data:
%   -.endo          : Data variables in the system.
%   info:
%   -.p             : Lag order.
%   -.var_results   : Structure with results from the reduced VAR model.
%   id1             : Matrix containing location of the NaN entries in A matrix.
%   id2             : Matrix containing location of the NaN entries in B matrix.
%   exo             : Matrix with exogenous variables (optional).
%
% Outputs:
%   results:
%   -.C         : Coefficients exogenous variables.
%   -.A         : Coefficients lagged variables.
%   -.F         : Companion form.
%   -.fitted    : Fitted values (T x n matrix).
%   -.resid     : Regression residuals (T x n matrix).
%   -.Sig       : Error covariance from identification.
%   -.Sig_hat   : Error covariance matrix OLS estimator.
%   -.Sig_check : Difference between Sg2 and Sg2_hat.
%   -.LogL      : Log-likelihood
%   -.aic       : Akaike information criterion.
%   -.sic       : Schwarz information criterion.
%   -.hqc       : Hannan-Quinn information criterion.
%   -.Y         : Dependent variables of the system (lhs variables).
%   -.X         : Independent variables of the system (rhs variables).
%   -.k         : Number of parameters per equation.
%   -.kn        : Total Number parameters of the model.
%   -.ll        : Log-likelihood of the model.
%   -.Amat      : A matrix of the AB model.
%   -.Bmat      : B matrix of the AB model.
%   -.LRtest    : LL ratio for overidentifying restrictions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting info from the code
data= data.endo;
p   = info.p;
n   = size(data,2);
T   = length(data)-p;
Y   = data(1+p:end,:);
if exist('exo','var') == 0
    exo = [];
end

% Building exo variabels
X = [];
i = 1;
while i <= p
    X = [X data(1+p-i:end-i,:)];
    i = i + 1;
end;
X = [X exo(1+p:end,:)];

% Estimation of the reduced form model. Model estimation reduced form.
Sig = info.var_results.Sig;

% Generating A and B matrices.
% A matrix.
if size(id1,1) == 0
    A_theta = eye(n);
    Am      = A_theta;
    nres_a  = 0;
else
    Am = eye(n);
    % Off-diagonal elements according to theta and id variable.
    nres_a = size(id1,1);
    A_theta = theta(1:nres_a);
    for i0 = 1:nres_a
        Am(id1(i0,1),id1(i0,2)) = A_theta(i0);
    end
end

% B matrix.
if size(id2,1) == 0
    B_theta = eye(n);
    Bm = B_theta;
else
    % Off-diagonal elements according to theta and id variable.
    Bm = eye(n);
    nres_b = size(id2,1);
    B_theta = theta(nres_a+1:end);
    for i0 = 1:nres_b
        Bm(id2(i0,1),id2(i0,2)) = B_theta(i0);
    end
end

% Building the likelihood.
ptA1 =  (T/2) * log((det(Am))^2);
ptB1 = -(T/2) * log((det(Bm))^2);
pf   = -(T/2) * trace(Am'*Bm^(-1)' * Bm^(-1)*Am * Sig);
% Log-likelihood of the model.
ll   = -1*(ptA1 + ptB1 + pf);
% Results.
results           = info.var_results;
results.Sig_hat   = Sig;
results.Sig       = (Am^(-1)*Bm)*(Bm'*Am^(-1)');
results.Sig_check = vec(results.Sig_hat - results.Sig);
results.ll        = ll;
results.Amat      = Am;
results.Bmat      = Bm;
% Test for overidentified restrictions
nr = n*(n+1)/2 - (size(id1,1) + size(id2,1));
if nr > 0 
	LRtest = T*(log(det(results.Sig)) - log(det(results.Sig_hat)));
    results.LRtest = [LRtest 1-chi2cdf(LRtest,nr)];
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
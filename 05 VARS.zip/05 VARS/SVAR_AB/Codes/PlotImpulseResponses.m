function [bands_l,bands_h] = PlotImpulseResponses(irf,var_in,info,fid)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 12/Oct/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Plots impulse responses.
% Input:
%   irf             : Impulse responses (n x h+1 array).
%   var_in          : variable inputs; bands or sig.
%   info:
%   -.conf          : Significance levels for confidence bands (1 x c).
%   -.area_color    : Color of area for last significance level (1 x 3).
%   -.widths        : Line widths to be used (1 x 2).
%   -.fsizes        : Font sizes to be used (1 x 2).
%   -.names         : Labels with variable names (1 x n).
%   fid             : Figure id identifier (optional).
%
% Outputs:
%   bands_l         : Low bands for the IRF.
%   bands_h         : Upper bands for the IRF.
%
% Index:
% 1. Initial Setup.
% 2. Ploting IRF.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Initial Setup.
% Getting infor from the code
nvars           = size(irf,2);
horizon         = size(irf,1)-1;
conf            = info.conf;
nbands          = length(conf);
line_width      = info.widths(1);
line_width_alt  = info.widths(2);
fsize           = info.fsizes(1);
fsize_alt       = info.fsizes(2);
names           = info.names;
area_step       = 0.1;
grey            = [0.3,0.3,0.3];

% Number of variables and graph setup.
if nvars <= 3
    k1 = 1; k2 = nvars;
elseif nvars <= 4
    k1 = 2; k2 = 2;
elseif nvars > 4 && nvars <= 6
    k1 = 3; k2 = 2;
elseif nvars > 6 && nvars <= 9
    k1 = 3; k2 = 3;
elseif nvars > 9 && nvars <= 16
    k1 = 4; k2 = 4;
elseif nvars > 16
    error('Max number of variables reached.');
end

% Plot impulse responses
if exist('fid','var') == 0
    fid = 3;
end;

% Use asymmetric or symmetric bands
% Asymmetric bands.
if size(var_in,3) > 1
    bands_l = squeeze(var_in(:,:,1,:));
    bands_h = squeeze(var_in(:,:,2,:));
% Symmetric bands
else
    bands_l = zeros(horizon+1,nvars,nbands);
    bands_h = zeros(horizon+1,nvars,nbands);
    for i = 1:nbands
        p_level = (1+info.conf(i))/2;
        band_width = norminv(p_level,0,1);
        bands_l(:,:,i) = irf - band_width*var_in;
        bands_h(:,:,i) = irf + band_width*var_in;
    end;
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Ploting IRF.
figure(fid)
k = 1;
T_aux = [0:horizon];
for j = 1:nvars
    subplot(k2,k1,k)
    % Area graph.
    area_color = info.area_color;
    for i = nbands:-1:1
        shadedplot(T_aux,bands_l(:,j,i)',bands_h(:,j,i)',area_color);
        area_color = area_color-area_step;
        hold on;
    end;
    % Zero line.
    h(1) = plot(T_aux,zeros(1,horizon+1),'-','Color',grey,'LineWidth',line_width_alt);
    % IRF plot.
    h(2) = plot(T_aux,irf(:,j)','-b','LineWidth',line_width);
    % Labels.
    title(names(j),'FontSize',fsize);
    if k1 == 1
        if j == nvars 
            xlabel('Periods','FontSize',fsize_alt);
        end
    elseif k1 == 2
        if j == nvars || j == nvars - 1
            xlabel('Periods','FontSize',fsize_alt);
        end
    elseif k1 == 3
        if j == nvars || j == nvars - 1 || j == nvars - 2
            xlabel('Periods','FontSize',fsize_alt);
        end
    else
        if j == nvars || j == nvars - 1 || j == nvars - 2 || j == nvars - 3
            xlabel('Periods','FontSize',fsize_alt);
        end
    end
    set(gca,'FontSize',fsize_alt);
    xlim([0 horizon]);
    box off
    k = k + 1;
end;
clear k j i;

% Setting the legend of the graphs.
if length(conf)==1
    legend1 = legend(h(2),['Impulse responses with ',num2str(conf*100) ' percent confidence bands']);
elseif length(conf)==2
    legend1 = legend(h(2),['Impulse responses with ',num2str(conf(1)*100) ' and ',num2str(conf(2)*100) ' percent confidence bands']);
elseif length(conf)==3
    legend1 = legend(h(2),['Impulse responses with ',num2str(conf(1)*100) ', ',num2str(conf(2)*100) ' and ',num2str(conf(3)*100) ' percent confidence bands']);
end;
set(legend1,'FontSize',fsize_alt,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function results = model_estimation(data,info,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 25/Dec/2018
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimate TVPVAR model with Gibbs Sampling.
% State-space representation of the model:
%
% Observation Equation : Y(t) = H*B(t) + e(t)
% Transition Equation  : B(t) = mu + F*B(t-1) + v(t)
%
% Where: var(et) = R and var(vt) = Q. Note that F is an a identity matrix 
% and mu is equal to zero.
%
% Inputs:
%   data:
%   -.all         : All data.
%   -.endo        : Data VAR.
%   info:
%   -.p           : Lag order of the VAR.
%   -.rep         : Number of draws from posterior.
%   -.burn        : Burning sample.
%   -.presmaple   : Presample data for prior.
%   -.Q0_Tau      : Controls uncertainty around first state.
%   -.horizon     : Horizon impulse response functions.
%   -.do_norm     : (1) Normalized impulse responses; (0) otherwise.
%   -.norm_fac    : (1) Normalization factor in percent.
%   -.exo_rest    : Additional restriction to exo block. If empty then block exogeneity applies.
%   exo           : Exogenous variables (optional).
%
% Outputs:
%   results:
%   -.irf          : Draws from Impulse responses of the structural model: horizon, variable, shock, simulation, time.
%   -.irf_full     : IRF with extended horizon for FEVD and Hdecomp: horizon, variable, shock, simulation, time.
%   -.fitted       : Fitted values
%   -.resid        : Regression residuals
%   -.Y            : Left hand variables.
%   -.X            : Right hand variables.
%   -.B_draws      : Draws from the reduced form parameters.
%   -.R_draws      : Draws R matrix var/cov observaion equation.
%   -.Q_draws      : Draws Q matrix var.cov state equation.
%   -.A0_draws     : Draws from the structural matrix A0.
%   -.A0           : Median estimates for A0.
%   -.Sig          : Median estimates for Sg2, observation equation.
%   -.Sig_vb       : Median estimates for Sg2, state equation.
%   -.Betas_tvp    : TVP betas.
%   -.Fcomp_tvp    : TVP companion form
%   -.C_tvp        : TVP exogenous regressors.
%   -.prior        : Data from priors.
%
% Index:
% 1. Setup of the model.
% 2. Simulations.
% 3. Results.
% 4. Finctions
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup of the model.
% Data for model.
if exist('exo','var') == 0
    exo = [];
end

% Generating dependent variables.
datax = [data.prior_all; data.all];
Y = datax(1+info.p:end,:);
% Generating lags of dependent variables.
X = []; i = 1;
while i <= info.p    
    X = [X datax(1+info.p-i:end-i,:)];
    i = i + 1;
end;
% Adding exogenous variables
datadet = [data.prior_determ; exo];
X = [X datadet(1+info.p:end,:)];
clear datax datadet;
  
% Pre-sample data for prior.
T0 = info.presample;
y0 = Y(1:T0,:);
x0 = X(1:T0,:);
b0 = (x0'*x0)^(-1)*x0'*y0;
e0 = y0-x0*b0;
% Setting Priors with pre-sample data.
sigma0= (e0'*e0)/T0;        % Initial R draw.
V0    = kron(sigma0,(x0'*x0)^(-1));
Q0    = V0*T0*info.Q0_Tau;  % Prior variance transition equation error; initial Q draw.
R0    = zeros(size(Y,2));   % Prior variance observation equation error.
P00   = V0;                 % Variance of the intial state vector: p[t-1/t-1]
beta0 = vec(b0)';           % Intial state vector b[t-1/t-1]
clear V0 y0 x0 e0;

% Set of restriction and additional restrictions for exo block.
if isempty(info.exo_rest) == 0
    % Selection matrix
    aux_r = ones(size(b0,1),size(b0,2));
    aux_0 = repmat(info.exo_rest,1,info.p)';   
    aux_r(1:info.p*size(Y,2),:) = aux_0;
    id  = vec(aux_r)'.*(1:size(beta0,2));
    % Formating variables.
    idx1 = find(id>0);
    idx2 = vec(aux_r)';
    
    % New priors.
    Q0    = Q0(idx1,idx1);
    P00   = P00(idx1,idx1);
    
    beta0 = beta0(idx1);
    clear aux_0 aux_r id;
end

% Initialise Gibbs Sampling
Q = Q0;
R = sigma0;
% Data for model estimation.
Ybar  = Y(T0+1:end,:);
Xbar  = X(T0+1:end,:);
Tbar  = size(Xbar,1);

% Getting info from the code.
nvar  = size(Ybar,2);
nexo  = size(exo,2);
kb    = size(beta0,2);
p     = info.p;
draws = info.rep;
burn  = info.burn;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Simulations.
% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');
disp('-Note: Explosive roots are discarded from simulations.');

% Matrix to store results: betas, R matrix and Q matrix.
out1 = zeros(Tbar,size(vec(b0),1),info.rep);
out2 = zeros(nvar,nvar,info.rep);
out3 = zeros(kb,kb,info.rep);

% Simulations.
record  = 0;
ndraw   = 1;
while record < burn + draws + 1    
    % Set up matrices for the Kalman Filter
    ns = size(beta0,2);
    F  = eye(ns); % FIX
    mu = 0;       % FIX
    % Matrix to store the filtered state variable and its variance
    beta_tt = [];
    ptt     = zeros(Tbar,ns,ns);
    
    % Initial states, from pre-sample data
    beta11 = beta0;
    p11    = P00;
    % Kalman Filter
    for i=1:Tbar        
        % Prediction
        x = kron(eye(nvar),Xbar(i,:));
        beta10 = mu + beta11*F';
        p10    = F*p11*F' + Q;
        
        % Restrictions state equation.
        if isempty(info.exo_rest) == 0
            temp = zeros(1,size(idx2,2));
            temp(1,idx1) = beta10;
            beta10 = temp;        
            % Fit 
            yhat   = (x*(beta10)')';
            % Removing extra zeros.
            beta10 = beta10(idx1);

            eta    = Ybar(i,:) - yhat;
            
            % Removing cols from x.
            xx = x(:,idx1);
            x  = xx;
            
            feta   = (x*p10*x') + R;
            % Kalman gain and updating.
            K      = (p10*x')*(feta)^(-1);
            beta11 = (beta10' + K*eta')';
            p11    = p10 - K*(x*p10);
            clear temp xx;
            
        % No Restrictions state equation.
        else
            % Fit 
            yhat   = (x*(beta10)')';
            
            eta    = Ybar(i,:) - yhat;
            feta   = (x*p10*x') + R;
            % Kalman gain and updating.
            K      = (p10*x')*(feta)^(-1);
            beta11 = (beta10' + K*eta')';
            p11    = p10 - K*(x*p10);            
        end        
        
        % Saving updates.
        ptt(i,:,:) = p11;
        beta_tt    = [beta_tt;beta11];
    end

    
    % Backward recursion from Kalman Filter to compute mean and variance of the 
    % distribution of the state vector.
    
    % Check stable draws
    scheck = -1;
    while scheck < 0;
        % Matrix to store draws from posterior distirbutions.
        beta2 = zeros(Tbar,ns);
        wa    = randn(Tbar,ns);
        error = zeros(Tbar,nvar);

        % First iteration, period T.
        i  = Tbar;
        p00= squeeze(ptt(i,:,:)); 
        % Draw for beta ~ N(beta_tt,ptt)
        beta2(i,:) = beta_tt(i:i,:) + (wa(i:i,:)*chol(p00));
        % Var residuals
        % Restrictions state equation.
        if isempty(info.exo_rest) == 0
            temp = zeros(1,size(idx2,2));
            temp(1,idx1) = beta2(i:i,:);
            error(i,:) = Ybar(i,:) - Xbar(i,:)*reshape(temp,nvar*p+nexo,nvar);
            clear temp;
        else
            error(i,:) = Ybar(i,:) - Xbar(i,:)*reshape(beta2(i:i,:),nvar*p+nexo,nvar);
        end

        % Rest of backward iterations, from t-1..to .1
        i = Tbar-1;
        while i >= 1;
            pt = squeeze(ptt(i,:,:));
            % Update the filtered beta for information contained in beta[t+1], i.e. beta2(i+1:i+1,:) eq 8.16 pp193 in Kim Nelson
            bm = beta_tt(i:i,:) + (pt*F'*(F*pt*F'+Q)^(-1)*(beta2(i+1:i+1,:) - beta_tt(i,:)*F')')';
            % Update covariance of beta
            pm = pt - pt*F'*(F*pt*F' + Q)^(-1)*F*pt;
            
            % Checking pm matrix in burning sample and estimation smaple.
            chol_check = - 1;
            while chol_check < 0
                [~,temp] = chol(pm);
                if temp > 0 
                    pm = eye(size(beta0,2))*0.000001+pm;
                else
                    chol_check = 1;
                end
                clear temp
            end
            clear chol_check 
            
            % Draw for beta in period t from N(bm,pm)eq 8.17 pp193 in Kim Nelson
            beta2(i:i,:) = bm + (wa(i:i,:)*chol(pm));  
            % VAR residuals
            % Restrictions state equation.
            if isempty(info.exo_rest) == 0
                temp = zeros(1,size(idx2,2));
                temp(1,idx1) = beta2(i:i,:);
                error(i,:) = Ybar(i,:) - Xbar(i,:)*reshape(temp,nvar*p+nexo,nvar);
            else
                temp = beta2(i:i,:);
                error(i,:) = Ybar(i,:) - Xbar(i,:)*reshape(temp,nvar*p+nexo,nvar);
            end
            
            % Checking roots.
            % Getting companion form of the model.
            [~,temp] = F_comp(temp,nvar,p,nexo);            
            if temp == -1
                i = 0;
                clear pt bm pm beta2 wa p00;
            else
                i = i - 1;
                % Terminal condition
                if i == 0
                   scheck = 1; 
                end
            end
            clear temp;
        end
    end
    clear scheck;
    
    % Conditional on state variable, sample Q from IW distribution..
    errorq = diff(beta2);
    scaleQ = (errorq'*errorq) + Q0;
    Q      = iwpQ(Tbar+T0,scaleQ^(-1));

    % Conditional on state variable and Q, sample R IW distribution.
    scaleR = (error'*error);
    R      = iwpQ(Tbar,scaleR^(-1)) + R0;

    % Storing draws after the burning period.
    if record > burn
        % Update waitbar
        waitbar(ndraw/draws,h_wait);
        if isempty(info.exo_rest) == 0
            temp = zeros(Tbar,size(idx2,2));
            temp(:,idx1) = beta2(:,:);
            out1(:,:,ndraw) = temp;
            clear temp;
        else
            out1(:,:,ndraw) = beta2;
        end
        out2(:,:,ndraw) = R;
        out3(:,:,ndraw) = Q;
        % Saving cholesky decomposition.
        A0_draws(:,:,ndraw)  = (chol(R,'lower'))^(-1);
        ndraw = ndraw + 1;
    end

    % Moving top next draw if all conditions are satisfied.            
    record = record + 1;

    % Cleaning memory.
    clear errorq scaleQ scaleR Fcomp;
end
close(h_wait);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Waitbar for in-sample fit and irf.
h_wait = waitbar(0,'Computing in-sample fit and TV-IRF for structural shocks...');
% Building results from simulations.
hmax = info.horizon;
J    = [eye(nvar) zeros(nvar,nvar*(p-1))];
for i = 1:Tbar;
    % Betas, draws from posterior.
    temp = median(out1(i,:,:),3);
    % Building beta matrix
    betas_tvp(:,:,i) = reshape(temp,nvar*p+nexo,nvar)';
    % Saving betas from deterministic variables.
    C_tvp(:,:,i) = betas_tvp(:,nvar*p+1:end,i);
    % Companion form of the model
    F_tvp(:,:,i) = F_comp(median(out1(i,:,:),3),nvar,p,nexo);
    % In sample fit of the model.
    fitted(i,:) = Xbar(i,:)*betas_tvp(:,:,i)';
    clear temp
    
    % Do impulse response of the model with recursive identification.
    for ndraw = 1:size(out1,3)    
        % Recursive idenitfication scheme.
        irf_all = recursive(A0_draws(:,:,ndraw),out1(i,:,ndraw),nvar,p,nexo,J,hmax);
        
        % Normalization of IRF.
        if info.do_norm == 1
            for i0 = 1:nvar
                temp = squeeze(irf_all(1:info.horizon,:,i0));
                temp_irf = info.norm_fac*temp/temp(1,i0);
                temp_irf2(:,:,i0,ndraw,i) = temp_irf;
                clear temp;
            end
        end
        % Storing IRF (horizon, variable, shock, simulation, time).    
        irf_all2(:,:,:,ndraw,i) = irf_all;
    end
    clear temp_irf irf_all;
    % Waitbar.
    waitbar(i/Tbar,h_wait);
end
close(h_wait);

% Impulse response of the model.
% Normalization
if info.do_norm == 1
    results.irf = temp_irf2;
else
    results.irf = irf_all2(1:info.horizon,:,:,:,:);
end
results.irf_full = irf_all2;

% Data
results.Y         = Ybar;
results.X         = Xbar;
% Fit of the model.
results.fitted    = fitted;
results.resid     = Ybar - results.fitted;
% Saving draws.
results.B_draws   = out1;
results.R_draws   = out2;
results.Q_draws   = out3;
results.A0_draws  = A0_draws;
% Median estimates
results.Sig       = median(out2,3);
results.Sig_vb    = median(out3,3);
results.A0        = median(A0_draws,3);
% Saving TVP
results.Betas_tvp = betas_tvp;
results.Fcomp_tvp = F_tvp;
results.C_tvp     = C_tvp;
% Priors.
results.prior_Q0    = Q0;
results.prior_P00   = P00;
results.prior_beta0 = beta0;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Function.
% Computing the companion form.
function [F,check] = F_comp(Bdraw,nvar,p,nexo)
% Inputs:
% Bdraw  : Draw from beta.
% nvar   : Number of endogenous variables.
% p      : Lag order.
% nexo   : Number of deterministic and exogenous variables.
% Building B matrix.
Bdraw = reshape(Bdraw,nvar*p+nexo,nvar)';
% Getting companion form.
A = Bdraw(:,1:nvar*p);
if p == 1
    F = A;
elseif p > 1
    F = [A; [eye(nvar*(p-1)) zeros(nvar*(p-1),nvar)]];
end
temp = max(abs(eig(F)));
if temp < 1
    check = 1;
else
    check = -1;
end

% Identification structural shocks using a recursive identification scheme.
function irf_all = recursive(A0_draws,out1,nvar,p,nexo,J,hmax)
% A0_draws  : Draws form A0 matrix.
% out1      : Matrix with Betas draws.
% nvar      : Number of endogenous variables.
% p         : Lag order.
% nexo      : Number of deterministic and exogenous variables.
% J         : Selection matrix for IRF.
% hmax      : Max. horizon for IRF.

%Cholesky decomposition.
A0inv = A0_draws^(-1);
% Companion form of the model.
F_temp = F_comp(out1,nvar,p,nexo);

% IRF for each structural shock.
irf_all_temp(:,:,1) = (J*(F_temp^0)*J')*A0inv;
for h = 1:hmax
    irf_all_temp(:,:,h+1) = (J*(F_temp^h)*J')*A0inv;
end

% Bulding IRF.
for i0 = 1:nvar
    irf_all(:,:,i0) = squeeze(irf_all_temp(:,i0,:))';
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
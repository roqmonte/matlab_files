function forecast = ForecastVAR(results,info,exo,h,sim,density,pfid,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 05/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes VAR forecast.
% Inputs:
%   results:
%   -.B_draws     : Draws from the reduced form parameters.
%   -.R_draws     : Draws R matrix var/cov observaion equation.
%   -.Y           : Left hand variables.
%   -.X           : Right hand variables.
%   info:
%   -.p           : Lag order.
%   -.rep         : Draws from the posterior.
%   -.names       : Labels with variable names (1 x n).
%   -.fsizes      : Font sizes to be used (1 x 2).
%   -.dates_ini   : Setting for dates: (year,month,freq).
%                   Where, freq: (1) monthly;(2) quaterly data.
%   -.dates_xTick : Xtick for dates.
%   exo           : Exogenous variables.
%   h             : Forecast horizon.
%   sim           : Simulations residuals per draw of the posterior.
%   density       : Quantiles for the fan chart, default: [90 80 60 40 20]
%   pfid          : (>0) print charts and figure number for plots.
%   vars          : Data selection for charts
%
% Outputs:
%   forecast:
%   -.dataf     : Matrix with data and forecast (median forecast).
%   -.draws     : Matrix to store draws for forecast.
%   -.median    : Median forecast.
%   -.density   : Density forecast.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Forecast.
% Getting info for estimation.
if exist('exo','var') == 0
    exo = [];
end
% Checking dim of exo and h.
if size(exo,1) > 1
    if size(exo,1) ~= h
       error('Dim for exo variables not consistent with forecast horizon.');
    end
end
% Checking quantiles for density forecast.
if exist('density','var') == 0 || size(density,1) == 0
    quantiles = [5 10 20 30 40 50 60 70 80 90 95];
else
    ql = (100-density)/2;
    qm = 50;
    qu = 100-ql(end:-1:1);
    quantiles = [ql qm qu];
    clear ql qm qu;
end

% Lag order of the model.
p = info.p;

% Building data for forecast
n  = size(results.Y,2);
yf = zeros(h,n,info.rep*sim);
ns = info.rep*sim;
nexo = size(results.X,2) - n*p;

% Posterior estimates parameters.
ids = 1;
h_wait = waitbar(0,'Computing density forecast, please wait...');
for i =1:info.rep   
    % Building companion form and residuals.
    Bdraw = reshape(results.B_draws(end,:,i),n*p+nexo,n)';
    % Getting companion form.
    A = Bdraw(:,1:n*p);
    if p == 1
        F = A;
    elseif p > 1
        F = [A; [eye(n*(p-1)) zeros(n*(p-1),n)]];
    end
    clear A;
    C = Bdraw(:,n*p+1:end);
    SG= results.R_draws(:,:,i);
    
    % Forecasting model
    for z0 = 1:sim
        % Data Model
        y_fore = results.Y(end-p-12:end,:);

        % Draws residuals
        e_draws = chol(SG,'lower')*randn(h,n)';
        for j0 = 1:h
            T = size(y_fore,1);
            temp1 = [];
            for i0 = T:-1:T-p+1
                temp1 = [temp1; y_fore(i0,:)'];
            end
            % Forecast 
            aux = ([eye(n);zeros(n*(p-1),n)])'*F*temp1 + C*exo(j0,:)';
            yf(j0,:,ids)  = aux' + e_draws(:,j0)';
            % Adding forecast to data.
            y_fore = [y_fore; yf(j0,:,ids)];
            clear temp1 aux;
        end
        % Next simulation.
        waitbar(ids/ns,h_wait);
        ids = ids + 1;       
        clear i0 j0 e_draws y_fore T;
    end
    clear F C SG z0;
end
close(h_wait);
clear ids i;

% Forecast
forecast.draws = yf;
forecast.median= median(yf,3);
forecast.dataf = results.Y;

% Data selection for charts
if exist('vars','var') == 0
    vars = 1:n;
else
    vars = sort(vars);
end

% Fanchart.
if exist('pfid','var') == 1
    figure(pfid)
    % Number of variables and graph setup.
    aux = size(vars,2);
    if aux <= 3
        k1 = 1; k2 = aux;
    elseif aux <= 4
        k1 = 2; k2 = 2;
    elseif aux > 4 && aux <= 6
        k1 = 3; k2 = 2;
    elseif aux > 6 && aux <= 9
        k1 = 3; k2 = 3;
    elseif aux > 9 && aux <= 16
        k1 = 4; k2 = 4;
    elseif aux > 16 && aux <= 24
        k1 = 4; k2 = 6;
    elseif aux > 24 && aux <= 30
        k1 = 5; k2 = 6;
    elseif aux > 30
        error('Max number of variables reached.');
    end
else
    pfid = 0;
end
% Density forecats and charts.
j = 1;
for i0 = 1:n
    % Chart
    if max(vars == i0) == 1
        if pfid > 0
            subplot(k1,k2,j);
        end
        % Densiy forecast and var. selection for charts
        df = FanChart(squeeze(yf(:,i0,:)),forecast.dataf(:,i0),info,quantiles,info.names(i0),pfid);
        j = j + 1;        
    else
        df = FanChart(squeeze(yf(:,i0,:)),forecast.dataf(:,i0),info,quantiles,info.names(i0),0);
    end
    % Savong output
    forecast.density(:,:,i0) = df(end-h+1:end,:);
end

% Building data plus forecast (median)
forecast.dataf = [forecast.dataf; squeeze(forecast.density(:,(size(df,2)-1)/2+1,:))];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description:: Time varying parameter VAR model. Current model allows for 
% recursive identification of the structural shocks. 
% Note, first variable is the most exogenous of the system.
% State-space representation of the model:
%
% Observation Equation : Y(t) = H*B(t) + e(t)
% Transition Equation  : B(t) = mu + F*B(t-1) + v(t)
%
% Where: var(et) = R and var(vt) = Q. Note that F is an a identity matrix 
% and mu is equal to zero.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Loading data.
clc; clear; close all;
% Seed for the random number generator.
rng('default');

% Working folder
info.ruta = 'C:\Users\Roque Montero\Google Drive\Codigos_Matlab\05 VARS\TVPVAR';
cd(info.ruta);
% Loading data.
[~,labels_ini] = xlsread('usdata','Sheet1','A1:C1');
data_ini = xlsread('usdata','Sheet1','A2:C227');
data_ini = (data_ini(2:end,:) - data_ini(1:end-1,:))/100;

% Defining endogenous variables.
info.labels_all = labels_ini;
info.endo_names= {'y' 'p' 'tpm'};

% Adding constant term, trends and exo variables.
cte    = 1;               % (0) No constant; (1) Constant
trend  = 0;               % (0) No trend; (1) linear trend; (2) linear and quadratic trend.
exo    = [];%data_ini(:,9);   % Exo variables.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------
% 2. Options for the code.
% Set lag order for endogenouse and exogenous variables (if zero, only xt enters to the model)
info.p          = 2;
info.px         = 0;
% Setting dates.
info.dates_ini  = [1954,1,2];       % First observation of the data.
% Settings for prior.
info.presample  = 40;               % Controls sample size of the pre-sample data, if 0 then use 15% of data.
info.Q0_Tau     = 0.01;             % Adjust prior of the variance of the state equation.
% Settings for impulse responses.
info.do_norm    = 1;                % (1) Normalized shocks; (0) otherwise.
info.norm_fac   = 1;                % Normalization factor (e.g. 10 = 10%).
info.horizon    = 12;               % Horizon of impulse responses.
info.rep        = 1000;             % Draws from the posterior.
info.burn       = 109000/100;       % Burning sample.
info.conf       = [.68 .90 .95];    % Significance levels for error bands.
% Options for plots.
info.widths     = [1 0.7];          % Line widths (zero line, point estim.).
info.fsizes     = [14 10];          % Font sizes (titles, axes).
info.area_color = [0.9 0.9 0.9];    % Color of area for highest sign. level.
info.names      = {'GDP' 'IPC' 'tpmn'};
%info.shock_names= {'US GDP shocks'};

% Adding additional restrictions to lag estructure of the model, if empty 
% then no restrictions. If not, then unit entries indicate no restriction,
% and zero entries indicate tight prior around zero.
% Note, the matrix represents lag reduced form model. (eq,nvars).
% info.exo_rest = ones(3,3);
% info.exo_rest(1,2) = 0;
% info.exo_rest(1,3) = 0;
info.exo_rest = [];

% Preparing data for estimation.
[data,info,determ] = data_make(data_ini,info,cte,trend,exo);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model estimation.
% Testing lag lenght of the model.
info.alpha       = 0.05;
info.max_lag     = 4;
lag_test_results = VAR_TestLagLength(data,info,determ);

% Model and IRF estimation
results = model_estimation(data,info,determ);
% Plot regression results
VAR_Plot_fit(results,info,1);

% Model VAR forecast, based on betas T|T.
forecast_h  = 8;
determ_fore = ones(forecast_h,1);
fore_sim    = 1;
density     = [90 80 60 40 20];
VARfore     = ForecastVAR(results,info,determ_fore,forecast_h,fore_sim,density,3);

% Computes impulse responses and bands for IRF T|T.
[irf_med,bandsl,bandsh] = PlotImpulseResponses(results.irf,info,5);

% Computes impulse responses using TVP VAR for one structural shock.
irf_med_tvp = PlotImpulseResponses_tvp(results.irf,info,15,3);

% Computing Forecast Error Variance Decomposition (FEVD T|T)
FEVD = ComputeFEVD(results,info,20);
% Computing TV Forecast Error Variance Decomposition at "h" horizon.
FEVD_tvp = ComputeFEVD_tvp(results,info,21,4);

% Computing Historical decomposition of the shokcs.
[HDcomp,~,shocks] = ComputeHDComp(results,info,22);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
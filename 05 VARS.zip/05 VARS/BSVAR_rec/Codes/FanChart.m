function mat_quant = FanChart(fore,hist,info,quantiles,name,pfid)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Marco Buchmann (mb-econ.net), ECB / Frankfurt University
% Date: January 2010
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: This function generates a fan chart. A fan chart aims to 
% visualize the uncertainty that surrounds a sequence of point forecasts.
% Inputs:
%   fore          : Density forecasts D along the horizon 1:H (HxD matrix).
%   hist          : Vector of historical data (Tx1 vector).
%   datesf        : Vectos with dates.
%   quantiles     : Quantiles for the fan chart, default: [90 80 60 40 20]
%   info:
%   -.dates_ini   : Setting for dates: (year,month,freq).
%                   Where, freq: (1) monthly;(2) quaterly data.
%   -.dates_xTick : Xtick for dates.
%   -.fsizes      : Font sizes to be used (1 x 2).
%   name          : Label for variable.
%   pfid          : (>0) print charts and figure number for plots.
% Output:
%   matm          : Density forecast.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Check input
if nargin < 2
    error('Not enough input arguments')
end
fsize     = info.fsizes(1);
fsize_alt = info.fsizes(2);

% Parameters
H = size(fore,1);
T = size(hist,1);

% Set relevant quantiles (in percent)
num_quant = size(quantiles,2);

% Compute quantiles
mat_quant = NaN(H,num_quant);
for h=1:H % loop over horizon
    for q = 1:num_quant % loop over quantiles
        mat_quant(h,q) = quantile(fore(h,:),quantiles(1,q)/100);
    end
end

% Add hist. observations to the plot matrix
%addv = [10^(-46) 10^(-47) 10^(-48) 10^(-49) 10^(-50) 0 10^(-50) 10^(-49) 10^(-48) 10^(-47) 10^(-46)];
temp = -46-(1*(num_quant-1)/2-1);
addv = [10.^(-46:-1:temp) 0 10.^(temp:1:(temp+(num_quant-1)/2-1))];
hm = hist;
for i = 1:num_quant-1
    hm = [hm hist]; %#ok<AGROW>
end
mat_quant = [hm;mat_quant];
for t = 1:T
   mat_quant(t,:) = mat_quant(t,:) + addv; 
end

% Prepare plot matrix for its use with the area function
matm = mat_quant;
for i = 2:size(matm,2)
    matm(:,i) = matm(:,i) - mat_quant(:,i-1);
end
matm = [repmat((NaN(info.dates_xTick(end)-size(hist,1),1)),1,size(matm,2)); matm];
mat_quant = [repmat((NaN(info.dates_xTick(end)-size(hist,1),1)),1,size(matm,2)); mat_quant];
clear temp

% Do charts
if pfid > 0
    % Setup for charts
    if info.dates_ini(end) == 1
        freq = 'm';
    elseif info.dates_ini(end) == 2
        freq = 'q';
    end
    Tf   = size(matm,1);
    samp = round(Tf*0.25);
    [~,xTickLabel_2,dates_all] = calendar(info.dates_ini(1),info.dates_ini(2),Tf,freq);
    temp_1 = fix(dates_all(end-samp));
    temp_2 = round((dates_all(end-samp) - fix(dates_all(end-samp)))*100);
    [xTick,xTickLabel] = calendar(temp_1,temp_2,samp+1,freq);       
    
    if sum(((abs(matm(end,2:end))>1.0e-6))) > 0
        % Generate plot
        h = area(matm(end-samp:end,:));
        % Color setup for fanchart.
        r = 1; g = 0; b = 0.1; 
        delta_color = 0.15;
        % Looping over quantiles.
        set(h,'LineStyle','none')
        set(h(1),'FaceColor',[1 1 1]) % white
        for i0 = 2:(num_quant-1)/2
            set(h(i0),'FaceColor',[r g b]); r = r - delta_color;
        end
        set(h((num_quant-1)/2+1),'FaceColor',[r g b]);
        for i0 = (num_quant-1)/2+2:num_quant
            set(h(i0),'FaceColor',[r g b]); r = r + delta_color;
        end
        hold on
    end        
        
    % Median forecast in black
    plot(mat_quant(end-samp:end,(num_quant-1)/2+1),'-k');    
    if min(min(mat_quant)) < 0
        hold on
        plot(zeros(size(mat_quant(end-samp:end,(num_quant-1)/2+1),1),1),'-k');
    end

    % Title chart.
    title(strcat('Density forecast-',name),'FontSize',fsize);
    set(gca,'FontSize',fsize_alt);
    
    % Limits for charts
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel',xTickLabel);
    xlim([xTick(1)*0 xTick(end)]);
    ylim([min(min(mat_quant(end-samp:end,:))) max(max(mat_quant(end-samp:end,:)))]);
    box on;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
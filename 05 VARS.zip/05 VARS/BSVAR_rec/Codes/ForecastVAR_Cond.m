function forecast = ForecastVAR_Cond(results,info,exo,h_const,density,pfid,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 24/Nov/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes conditional VAR forecast.
% Inputs:
%   results:
%   -.F_draws    : Draws Companion form.
%   -.C_draws    : Draws parameters exo variables.
%   -.SG_draws   : Draws from Sigama of the reduced form VAR.
%   -.A0_draws   : Draws from the structural matrix A0.
%   -.Y          : Left hand variables.
%   -.X          : Right hand variables.
%   -.irf_full   : IRF.
%   -.data_prior : Data from priors.
%   info:
%   -.p          : Lag order.
%   -.rep        : Number of draws from posterior.
%   -.burn       : Burning sample.
%   -.names      : Labels with variable names (1 x n).
%   -.fsizes     : Font sizes to be used (1 x 2).
%   -.dates_ini  : Setting for dates: (year,month,freq).
%                  Where, freq: (1) monthly;(2) quaterly data.
%   -.dates_xTick: Xtick for dates.
%   exo          : Exogenous variables.
%   h_const      : Matrix with constrained paths (p const x N); col(0) no restrictions.
%   density      : Quantiles for the fan chart, default: [90 80 60 40 20]
%   pfid         : (>0) print charts and figure number for plots.
%   vars          : Data selection for charts
%
% Outputs:
%   forecast:
%   -.dataf     : Matrix with data and forecast (median forecast).
%   -.draws     : Matrix to store draws for forecast.
%   -.median    : Median forecast.
%   -.density   : Density forecast.
%
% Index:
% 1. Setup of the model.
% 2. Density forecast.
% 3. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup of the model.
% Getting info for estimation.
if exist('exo','var') == 0
    exo = [];
end
% Checking dim of exo and h.
if size(exo,1) > 1
    if size(exo,1) ~= size(h_const,1)
       error('Dim for exo variables not consistent with forecast horizon.');
    end
end
% Checking quantiles for density forecast.
if exist('density','var') == 0 || size(density,1) == 0
    quantiles = [5 10 20 30 40 50 60 70 80 90 95];
else
    ql = (100-density)/2;
    qm = 50;
    qu = 100-ql(end:-1:1);
    quantiles = [ql qm qu];
    clear ql qm qu;
end

% Info fom code.
p = info.p;
N = size(results.Y,2);
k = size(results.X,2);
draws = info.rep;
burn  = info.burn;

% Setp up for the restriction.
rest_per = size(h_const,1);
id_rest  = double(any(h_const)).*(1:N);
id_rest  = id_rest((id_rest>0));

% Initialization for simulations.
F     = results.F_draws(:,:,1);
C     = results.C_draws(:,:,1);
A0inv = results.A0_draws(:,:,1)^(-1);
% Condtional forecast.
yf = yfore_cond(results.irf_full,rest_per,id_rest,h_const,results.Y,exo,p,F,C,A0inv);
clear F C A0inv;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Density forecast.
% Put waitbar
h_wait = waitbar(0,'Computing conditional forecast, please wait...');
disp('-Note: Explosive roots are discarded from simulations.');

% Simulations.
record= 0;
ndraw = 1;
J = [eye(N) zeros(N,N*(p-1))];
yf_temp = yf;
while record < burn + draws + 1
    % Building expanded data set.step 1 DRAW VAR parameters
    data = [results.Y; yf_temp];
    % Generating dependent variables.
    Y = data(1+p:end,:);      
    % Generating lags of dependent variables.
    X = []; i = 1;
    while i <= p
        X = [X data(1+p-i:end-i,:)];
        i = i + 1;
    end;
    % Adding exogenous variables
    X = [X [results.X(1+p:end,N*p+1:end);exo]];
    % Variables for model
    Ybar  = [results.data_prior.Ystar; Y];
    Xbar  = [results.data_prior.Xstar; X];
    Tbar  = size(Xbar,1);
    % Conditional mean and conditional variance
    Bols = ((Xbar'*Xbar)\(Xbar'*Ybar))';
    E    = (Ybar - Xbar*Bols');
    Sig  = (E'*E)/Tbar;
    
    % Draw VAR parameters
    M = vec(Bols');
    [Vchol,z1] = chol(kron(Sig,(Xbar'*Xbar)\eye(k)));
    if z1 == 0
        beta  = M + (randn(1,N*(N*p+size(exo,2))) * Vchol)';
        Bdraw = reshape(beta,N*p+size(exo,2),N)';
        % Draw sigma
        e = Ybar -Xbar*Bdraw';
        Sig = iwpQ(Tbar,inv(e'*e));
        clear data Y X Ybar Xbar Tbar Bols E M V beta e i;

        % Computing the companion form.
        A = Bdraw(:,1:N*p);
        C = Bdraw(:,N*p+1:end);
        if p == 1
            F = A;
        elseif p > 1
            F = [A; [eye(N*(p-1)) zeros(N*(p-1),N)]];
        end

        % Checking stability of the system.
        if max(abs(eig(F))) < 1
            % Computing Cholesky for Signa
            A0inv = chol(Sig,'lower');
            % Storing the draws after the burning period.
            if record > burn
                % Update waitbar
                waitbar(ndraw/draws,h_wait);
                % IRF for each structural shock identified
                irf_all_temp(:,:,1) = (J*(F^0)*J')*A0inv;
                for h = 1:rest_per
                    irf_all_temp(:,:,h+1) = (J*(F^h)*J')*A0inv;
                end
                % Bulding IRF.
                for i0 = 1:N
                    irf_all(:,:,i0) = squeeze(irf_all_temp(:,i0,:))';
                end              
                % Conditional forecast.
                [~,yf_draw(:,:,ndraw)] = yfore_cond(irf_all,rest_per,id_rest,h_const,results.Y,exo,p,F,C,A0inv);
                % Checking draws
                if max(max(isnan(yf_draw(:,:,ndraw)))) == 1
                    yf_temp = yf_draw(:,:,ndraw-1);
                else
                    yf_temp = yf_draw(:,:,ndraw);
                    ndraw = ndraw + 1; 
                end
                clear irf_all_temp;
            end
            % Moving top next draw if all conditions are satisfied.
            record = record + 1;
        end
    else
        % New draw for Sigma
        Sig = iwpQ(Tbar,inv(e'*e)); 
    end
    clear Bdraw A C F Sig A0inv h i0;
end
close(h_wait);

% Forecast
forecast.draws = yf;
forecast.median= median(yf,3);
forecast.dataf = results.Y;

% Data selection for charts
if exist('vars','var') == 0
    vars = 1:N;
else
    vars = sort(vars);
end

% Fanchart.
if exist('pfid','var') == 1
    figure(pfid)
    % Number of variables and graph setup.
    aux = size(vars,2);
    if aux <= 3
        k1 = 1; k2 = aux;
    elseif aux <= 4
        k1 = 2; k2 = 2;
    elseif aux > 4 && aux <= 6
        k1 = 3; k2 = 2;
    elseif aux > 6 && aux <= 9
        k1 = 3; k2 = 3;
    elseif aux > 9 && aux <= 16
        k1 = 4; k2 = 4;        
    elseif aux > 16 && aux <= 24
        k1 = 4; k2 = 6;
    elseif aux > 24 && aux <= 30
        k1 = 5; k2 = 6;
    elseif aux > 30
        error('Max number of variables reached.');
    end
    
else
    pfid = 0;
end

% Density forecats and charts.
j = 1;
for i0 = 1:N
    % Chart
    if max(vars == i0) == 1
        if pfid > 0
            subplot(k1,k2,j);
        end
        % Densiy forecast and var. selection for charts
        df = FanChart(squeeze(yf_draw(:,i0,:)),forecast.dataf(:,i0),info,quantiles,info.names(i0),pfid);
        j = j + 1;        
    else
        df = FanChart(squeeze(yf(:,i0,:)),forecast.dataf(:,i0),info,quantiles,info.names(i0),0);
    end
    % Saving output
    forecast.density(:,:,i0) = df(end-rest_per+1:end,:);
end

% Building data plus forecast (median)
forecast.dataf = [forecast.dataf; squeeze(forecast.density(:,(size(df,2)-1)/2+1,:))];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions.
% Function estimates conditionla forecast and matrix r, R.
function [yf,yf_draw] = yfore_cond(irf,h,id,h_const,Y,exo,p,F,C,A0inv)
% Imputs.
%   irf     : Structural Impulse response from VAR model.
%   h       : Restricted horizon.
%   id      : Vector that identifies restrcited variables.
%   h_const : Matrix with constrained paths (p const x N); col(0) no restrictions.
%   Y       : Dependent variables.
%   exo     : Exogenous variables.
%   p       : Lag order of the VAR.
%   F       : Companion form.
%   C       : Parameters exo variables.
%   A0inv   : Invesre of structural matrix A0.
% Outputs:
%   yf      : Conditional forecast.
%   yf_draw : Draw conditional forecast.

% Number of variables 
N = size(irf,2);

% Unconditional forecast.
y_fore = Y(end-p-12:end,:);
for j0 = 1:h
    Ttemp = size(y_fore,1);
    temp1 = [];
    for i0 = Ttemp:-1:Ttemp-p+1
        temp1 = [temp1; y_fore(i0,:)'];
    end
    % Forecast 
    aux = ([eye(N);zeros(N*(p-1),N)])'*F*temp1 + C*exo(j0,:)';
    yf_ini(j0,:)  = aux';
    % Adding forecast to data.
    y_fore = [y_fore; yf_ini(j0,:)];
    clear temp1 aux;
end
clear Ttemp y_fore j0;

% Bulding R matrix
IRF_temp = irf(1:h,:,:,1);
R = [];
for i0 = 1:size(id,2)
    IRF_temp2 = squeeze(IRF_temp(:,id(i0),:));
    R1 = IRF_temp2;
    for i1 = 1:h-1
        temp = [zeros(i1,N); IRF_temp2(1:end-i1,:)];
        R1   = [R1 temp];
    end
    R = [R; R1];
    clear i1 temp R1;
end
clear i0 IRF_temp;

% Bulding r matrix
r = vec(h_const(:,id) - yf_ini(:,id));
% Restricted structural shocks
ehat = R'*(R*R')^(-1)*r;
ehat = reshape(ehat,N,h)';

% Conditionl forecast
y_fore = Y(end-p-12:end,:);
for j0 = 1:h
    Ttemp = size(y_fore,1);
    temp1 = [];
    for i0 = Ttemp:-1:Ttemp-p+1
        temp1 = [temp1; y_fore(i0,:)'];
    end
    % Forecast 
    aux = ([eye(N);zeros(N*(p-1),N)])'*F*temp1 + C*exo(j0,:)';
    yf(j0,:)  = aux' + ehat(j0,:)*A0inv';
    % Adding forecast to data.
    y_fore = [y_fore; yf(j0,:)];
    clear temp1 aux;
end

% Draws from the posterios of the restricted structural shocks.
% Posterior mean for restricted structural shocks.
MBAR = R'*pinv(R*R')*r;
% Posterior variance for restricted structural shocks.
VBAR = R'*(R*R')^(-1)*R;
VBAR= eye(size(VBAR,2)) - VBAR;
% Draw structural shocks from N(MBAR,VBAR).
edraw = MBAR + (randn(1,size(MBAR,1))*real(sqrtm(VBAR)))';
edraw = reshape(edraw,N,h)';
% Conditional forecast using new draw of shocks
y_fore = Y(end-p-12:end,:);
for j0 = 1:h
    Ttemp = size(y_fore,1);
    temp1 = [];
    for i0 = Ttemp:-1:Ttemp-p+1
        temp1 = [temp1; y_fore(i0,:)'];
    end
    % Forecast 
    aux = ([eye(N);zeros(N*(p-1),N)])'*F*temp1 + C*exo(j0,:)';
    yf_draw(j0,:)  = aux' + edraw(j0,:)*A0inv';

    % Adding forecast to data.
    y_fore = [y_fore; yf_draw(j0,:)];
    clear temp1 aux;
end
clear Ttemp j0 y_fore i0;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [HD,HDsim,eps] = ComputeHDComp(results,info,print,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 17/Sept/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes historical Decomposition of the shocks at the
% posterior median of the reduced form parameters.
% Input:
%   results:
%   -.resid         : Regression residuals (T x n matrix).
%   -.Y             : Endogenous variables.
%   -.X             : Exogenous variables.
%   -.A0_draws      : Draws from the structural matrix A0.
%   -.F_draws       : Draws Companion form.
%   -.C_draws       : Draws parameters exo variables.
%   -.B_draws       : Draws from the reduced form parameters.
%   -.irf_full      : Impulse response functions from the model.
%   info:
%   -.names         : Vector with labels for variables.
%   -.shock_names   : Shock labels.
%   -.fsizes        : Font sizes to be used (1 x 2).
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%   -.p             : Lag order.
%   -.rep           : Number of draws from posterior.
%   -.determ_cte    : Contant term.
%   -.determ_trend  : Linear trend.
%   -.determ_trend2 : Quadratic term.
%   -.determ_exo    : Exogebous variable.
%   print           : Do graph and graph id (if print > 0); (0) no graph.
%   vars            : Data selection for charts
%
% Output:
%   HD              : Historical decomposition of shocks (T,n,shock).
%   -.shock         : Contribution of each shock.
%   -.init          : Contribution initial conditions.
%   -.const         : Contribution contant terms.
%   -.trend         : Contribution linear trends.
%   -.trend2        : Contribution quadratic trends
%   -.exo           : Contribution exogenous variables.
%   -.endo          : Sum of contributions (original data).
%   -.data          : Data VAR model.
%   HDsim           : Structure with HDcomp simulations
%   eps             : Structural shocks
%
% Index.
% 1. Computing Historical decomposition.
% 2. Graph.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Computing Historical decomposition.
% Standard option for draws.
nvar    = size(results.Y,2);              % Number of endogenous variables
nvar_ex = size(info.determ_exo,2);        % Number of exogenous (excluding constant and trend)
nvarXeq = nvar*info.p;                    % Number of lagged endogenous per equation
nlag    = info.p;                         % Number of lags 
nlag_ex = 0;                              % Number of lags of the exogenous 
Y       = results.Y;                      % Left-hand side
X       = results.X(:,1:nvarXeq);         % Right-hand side (no exogenous)
nobs    = length(results.Y);              % Number of observations
const   = size(info.determ_cte,2);        % Constant and/or trends
deter   = size(info.determ_trend,2);      % Linear trends.
deter2  = size(info.determ_trend2,2);     % Quadratic trends.
HDsim.shock = zeros(nobs,nvar,nvar,info.rep);
fsize     = info.fsizes(1);
fsize_alt = info.fsizes(2);

h_wait = waitbar(0,'Computing Hist. decomp of the shocks, please wait...');
for jj = 1:info.rep
    % Parameter estimates.
    % Decomposition at the posterior mean of the reduced form parameters.
    A0inv  = chol(results.SG_draws(:,:,jj),'lower');
    resid  = results.Y - results.X*results.B_draws(:,:,jj)';   
    eps    = resid*(A0inv')^(-1);
    epsx(:,:,jj) = eps;
    Fcomp  = results.F_draws(:,:,jj);
    % Parameters for deterministic and exo variables.
    F = results.C_draws(:,:,jj);

    % Contribution of each shock
    Ainv = zeros(nvarXeq,nvar);
    Ainv(1:nvar,:) = A0inv;
    Icomp = [eye(nvar) zeros(nvar,(nlag-1)*nvar)];
    HDshock_big = zeros(nlag*nvar,nobs+1,nvar);
    HDshock = zeros(nobs,nvar,nvar);
    for j = 1:nvar
        % Matrix of shocks conformable with companion
        eps_big = zeros(nvar,nobs+1);
        eps_big(j,2:end) = eps(:,j);
        for i = 2:nobs+1
            HDshock_big(:,i,j) = Ainv*eps_big(:,i) + Fcomp*HDshock_big(:,i-1,j);
            HDshock(i-1,:,j) = (Icomp*HDshock_big(:,i,j))';
        end
    end    

    % Initial value
    HDinit_big = zeros(nlag*nvar,nobs+1);
    HDinit = zeros(nobs,nvar);
    HDinit_big(:,1) = X(1,:)';
    HDinit(1,:)= Icomp*HDinit_big(:,1);
    for i = 2:nobs+1
        HDinit_big(:,i) = Fcomp*HDinit_big(:,i-1);
        HDinit(i-1,:) = Icomp*HDinit_big(:,i);
    end    

    % Constant
    HDconst_big = zeros(nlag*nvar,nobs+1);
    HDconst = zeros(nobs,nvar);
    CC = zeros(nlag*nvar,1);
    if const == 1
        CC(1:nvar,:) = F(:,1);
        for i = 2:nobs+1
            HDconst_big(:,i) = CC + Fcomp*HDconst_big(:,i-1);
            HDconst(i-1,:) = Icomp*HDconst_big(:,i);
        end
    end    

    % Linear trend
    HDtrend_big = zeros(nlag*nvar,nobs+1);
    HDtrend = zeros(nobs,nvar);
    TT = zeros(nlag*nvar,1);
    if deter == 1
        TT(1:nvar,:) = F(:,2);
        id = results.X(:,nvarXeq+const+1);
        for i = 2:nobs+1
            HDtrend_big(:,i) = TT*id(i-1) + Fcomp*HDtrend_big(:,i-1);
            HDtrend(i-1,:) = Icomp*HDtrend_big(:,i);
        end
    end    

    % Quadratic trend
    HDtrend2_big = zeros(nlag*nvar, nobs+1);
    HDtrend2 = zeros(nobs,nvar);
    TT2 = zeros(nlag*nvar,1);
    if deter2 == 1
        TT2(1:nvar,:) = F(:,3);
        id = results.X(:,nvarXeq+const+2);
        for i = 2:nobs+1
            HDtrend2_big(:,i) = TT2*id(i-1) + Fcomp*HDtrend2_big(:,i-1);
            HDtrend2(i-1,:) = Icomp*HDtrend2_big(:,i);
        end
    end

    % Exogenous
    HDexo_big = zeros(nlag*nvar,nobs+1);
    HDexo = zeros(nobs,nvar);
    EXO = zeros(nlag*nvar,nvar_ex*(nlag_ex+1));
    if nvar_ex > 0
        VARexo = info.determ_exo(1+nlag:end,:);
        EXO(1:nvar,:) = F(:,const+deter+deter2+1:end);
        for i = 2:nobs+1
            HDexo_big(:,i) = EXO*VARexo(i-1,:)' + Fcomp*HDexo_big(:,i-1);
            HDexo(i-1,:) = Icomp*HDexo_big(:,i);
        end
    end

    % Cleaning memory
    clear B_big Icomp HDshock_big j i HDinit_big HDconst_big HDtrend_big HDtrend2_big HDexo_big

    % All decompositions must add up to the original data
    HDshock_temp = HDshock;
    HDendo = HDinit + HDconst + HDtrend + HDtrend2 + HDexo + sum(HDshock_temp,3);

    % Save and reshape all HDs
    for i = 1:nvar
        HDsim.shock(:,:,i,jj) = squeeze(HDshock_temp(:,i,:));
    end

    % Saving draws and updating waitbar
    HDsim.init(:,:,jj)   = HDinit;
    HDsim.const(:,:,jj)  = HDconst;
    HDsim.trend(:,:,jj)  = HDtrend;
    HDsim.trend2(:,:,jj) = HDtrend2;
    HDsim.exo(:,:,jj)    = HDexo;
    HDsim.endo(:,:,jj)   = HDendo;
    waitbar(jj/info.rep,h_wait);
    clear HDinit HDconst HDtrend HDtrend2 HDexo HDendo A0inv A0mat Ainv CC eps eps_big F Fcomp HDshock HDshock_temp TT TT2 EXO i
end
close(h_wait);

% Median HDcomp.
for i0 = 1:nvar
   HD.shock(:,:,i0) = median(HDsim.shock(:,:,i0,:),4);
end
HD.init  = median(HDsim.init,3);
HD.const = median(HDsim.const,3);
HD.trend = median(HDsim.trend,3);
HD.trend2= median(HDsim.trend2,3);
HD.exo   = median(HDsim.exo,3);
HD.endo  = median(HDsim.endo,3);
HD.data  = Y;
eps = median(epsx,3);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Graph.
if exist('print','var') == 1
    hdcomp = HD.shock;
    if print > 0
        % Var names.
        names_var = info.names;
        xTick     = info.dates_xTick;
        xTickLabel= info.dates_label;
        
        % Data selection for charts and tables
        if exist('vars','var') == 1
            nvar  = size(vars,2);
        else
            vars = 1:nvar;
        end
        
        % Number of variables and graph setup.
        if nvar <= 3
            k1 = 1; k2 = nvar;
        elseif nvar <= 4
            k1 = 2; k2 = 2;
        elseif nvar > 4 && nvar <= 6
            k1 = 3; k2 = 2;
        elseif nvar > 6 && nvar <= 9
            k1 = 3; k2 = 3;
        elseif nvar > 9 && nvar <= 16
            k1 = 4; k2 = 4;
        elseif nvar > 16 && nvar <= 24
            k1 = 4; k2 = 6;
        elseif nvar > 24 && nvar <= 30
            k1 = 5; k2 = 6;
        elseif nvar > 30
            error('Max number of variables reached.');
        end
        
        % Building decomposition for each shock.
        figure(print)
        for i0 = 1:nvar
            subplot(k2,k1,i0)
            % Data for plot.
            aux_0 = [NaN(info.dates_xTick(end)-nobs,1); sum(hdcomp(:,:,vars(i0)),2)];
            aux_1 = [NaN(info.dates_xTick(end)-nobs,size(results.Y,2)); hdcomp(:,:,vars(i0))];
            % Doing the plots.
            bar(aux_1);
            hold on
            plot(aux_0,'LineWidth',1,'Color','k');
            title(names_var(vars(i0)),'FontSize',fsize);
            set(gca,'FontSize',fsize_alt);
            if size(results.Y,2) < 10
                legend1 = legend(info.shock_names);
                set(legend1,'FontSize',fsize_alt-2,'Orientation','vertical','Location','southeast','Box', 'on');
            else
                if i0 == nvar
                    legend1 = legend(info.shock_names);
                    set(legend1,'FontSize',fsize_alt-2,'Position',[0.95 0.59 0.0 0.25],'Orientation','vertical','Box', 'on');
                end
            end
            xlim([xTick(1) xTick(end)]);
            set(gca,'XTick',xTick);
            set(gca,'XTickLabel',xTickLabel);
            clear aux_1 aux_2;
        end
        axes('Position',[0 0 1 1],'Visible','off');
        text(0.4275,0.975,'Historical Decomposition of the Shocks','FontSize',12','FontWeight','Bold');
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
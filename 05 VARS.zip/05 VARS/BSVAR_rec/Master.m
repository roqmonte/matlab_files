%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description:: Recursive VAR model estimation, Sims 1980.
% The estimation is done by Gibbs Sampling, the reduced-form model is:
% (1) y_t = C_1 x_t + A_11 y_t-1 + ... + A_1p y1_t-p + e_t,
%
% Note, the first variable is the most exogenous of the system.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Loading data.
clc; clear; close all;
% Seed for the random number generator.
rng('default');

% Working folder
info.ruta = 'C:\Users\Roque Montero\Google Drive\Codigos_Matlab\05 VARS\BSVAR_rec';
cd(info.ruta);
% Loading data.
[~,labels_ini] = xlsread('Data_macro','Data','B1:N1');
data_ini = xlsread('Data_macro','Data','B50:N229');

% Defining endogenous variables.
info.labels_all = labels_ini;
info.endo_names= {'yx' 'y' 'p' 'tpm' 'tcr'};

% Adding constant term, trends and exo variables.
cte    = 1;               % (0) No constant; (1) Constant
trend  = 0;               % (0) No trend; (1) linear trend; (2) linear and quadratic trend.
exo    = [];%data_ini(:,9);   % Exo variables.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------
% 2. Options for the code.
% Set lag order for endogenouse and exogenous variables (if zero, only xt enters to the model)
info.p          = 2;
info.px         = 0;
% Setting dates.
info.dates_ini  = [2000,1,2];       % First observation of the data.
% Settings for impulse responses.
info.do_norm    = 1;                % (1) Normalized shocks; (0) otherwise.
info.norm_fac   = 1;                % Normalization factor (e.g. 10 = 10%).
info.horizon    = 12;               % Horizon of impulse responses.
info.rep        = 10^3;             % Draws from the posterior.
info.burn       = 100;              % Burning sample.
info.conf       = [.68 .90 .95];    % Significance levels for error bands.
% Options for plots.
info.widths     = [1 0.7];          % Line widths (zero line, point estim.).
info.fsizes     = [14 10];          % Font sizes (titles, axes).
info.area_color = [0.9 0.9 0.9];    % Color of area for highest sign. level.
info.names      = {'US GDP' 'GDP' 'IPC' 'tpmn' 'RER'};
%info.shock_names= {'US GDP shocks'};

% Prior setup: (1) Noninformative Prior; (2) Minnesota prior with dummy variables.
info.prior       = 2;
info.presmaple   = 20;   % Controls sample size of the pre-sample data.
% Prior configuration for dummy variables, if empty grid search over lambda.
% Prior Tightness decreases with l(1,3,4,5,6,7), but increases with l(2).
info.lambda(1)   = 0.2;  % Overall tightness of prior for lags.
info.lambda(2)   = 1;    % Tightness of prior on higher lags.
info.lambda(3)   = 1;    % Tightness of prior for cov matrix.
info.lambda(4)   = 1;    % Tightness of the prior on constant term center at 0.
info.lambda(5)   = 1;    % Prior rest of exo variables center at 0.
info.lambda(6)   = 2;    % Prior sum of coefficients prior.
info.lambda(7)   = 2;    % Prior common stochastic trends.
%info.lambda      = [];

% Defining prior for first lag on VAR coeficients, if empty use pre-sample betas.
% If one element is NaN, then use pre-sample beta on that coefficient.
info.rwlist  = [1; 1; 1; 1; 1];
             
% Preparing data for estimation.
[data,info,determ] = data_make(data_ini,info,cte,trend,exo);
% Building priors.
prior = make_prior(data,info,determ);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model estimation.
% Testing lag lenght of the model.
info.alpha       = 0.05;
info.max_lag     = 4;
lag_test_results = VAR_TestLagLength(data,info,determ);

% Model estimation.
results = model_estimation(data,info,prior,determ);
% Plot regression results
VAR_Plot_fit(results,info,1);

% Model VAR forecast.
forecast_h  = 3;
determ_fore = ones(forecast_h,1);
fore_sim    = 1;
density     = [90 80 60 40 20];
VARfore     = ForecastVAR(results,info,determ_fore,forecast_h,fore_sim,density,3);
% Conditional forecast.
forecast_h  = 3;
determ_fore = ones(forecast_h,1);
h_const     = [zeros(3,3) 3.5*ones(3,1) 5*ones(3,1)];
density     = [90 80 60 40 20];
VARforec    = ForecastVAR_Cond(results,info,determ_fore,h_const,density,4);

% Compute impulse responses and bands
[irf_med,bandsl,bandsh] = PlotImpulseResponses(results.irf,info,5);

% Computing Forecast Error Variance Decomposition (FEVD)
FEVD = ComputeFEVD(results,info,20);
% Computing Historical decomposition of the shokcs.
[HDcomp,~,shocks] = ComputeHDComp(results,info,21);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
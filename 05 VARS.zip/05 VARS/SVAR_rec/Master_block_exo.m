%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of the Recursive VAR model (Sims 1980) with block
% exogeneity. The estimation is done by maximun likelihood. The reduced-form
% model is:
% (1) y1_t = C_1 x_t + A_11 y1_t-1 + ... + A_1p y1_t-p + e_1t,
% (2) y2_t = C_2 x_t + B_11 y1_t-1 + ... + B_1p y1_t-p
%                    + B_21 y2_t-1 + ... + B_2p y2_t-p + e_2t,
%
% Where cov([e_1t; e_2t]) = [Sig_11 Sig_12; Sig_21 Sig_22].
% The group of variables y1_t is block exogenous wrt y2_t variables.
% In this model the first variable is the most exogenous to the system.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Loading data.
clc; clear; close all;
% Seed for the random number generator.
rng('default');

% Working folder
info.ruta = 'C:\Users\Roque Montero\Google Drive\Codigos_Matlab\05 VARS\SVAR_rec';
cd(info.ruta);
% Loading data.
[~,labels_ini] = xlsread('Data_var','data_m','B2:K2');
data_ini = xlsread('Data_var','data_m','B110:K208');

% Defining endogenous and exogenous blocks.
info.labels_all = labels_ini;
info.exo_names  = {'CL1' };%'SPX'
info.endo_names = {'HG1' 'CLP'};
% Define the shocked variable for shock normalization.
info.shock_name = 'HG1';

% Adding constant term, trends and exo variables.
cte    = 1;               % (0) No constant; (1) Constant
trend  = 0;               % (0) No trend; (1) linear trend; (2) linear and quadratic trend.
exo    = [];%data_ini(:,7);   % Exo variables.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Options for the code.
% Set lag order for endogenouse and exogenous variables (if zero, only xt enters to the model)
info.p          = 2;
info.px         = 0;
% Setting dates.
info.dates_ini  = [2009,1,1];       % First observation of the data.
% Settings for impulse responses.
info.do_norm    = 1;                % (1) Normalized shocks; (0) otherwise.
info.norm_fac   = 1;                % Normalization factor (e.g. 10 = 10%).
info.horizon    = 12;               % Horizon of impulse responses.
info.rep        = 10^3;             % Number of bootstrap replications.
info.conf       = [.68 .90 .95];    % Significance levels for error bands.
% Options for plots.
info.widths     = [1 0.7];          % Line widths (zero line, point estim.).
info.fsizes     = [12 10];          % Font sizes (titles, axes).
info.area_color = [0.9 0.9 0.9];    % Color of area for highest sign. level.
info.names      = {'WTI oil' 'Copper Price' 'USDCLP'};
%info.shock_names= {'Copper price shock'};

% Preparing data for estimation.
[data,info,determ] = data_make(data_ini,info,cte,trend,exo);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model estimation.
% Testing block exogeneity and lag lenght.
info.alpha   = 0.05;
info.max_lag = 4;
exo_test     = VAR_TestBlockExo(data,info,determ);
lag_test     = VAR_TestLagLength(data,info,determ);

% Model estimation.
results = EstimateBlockVAR(data,info.p,determ);
% Plot regression results
VAR_Plot_fit(results,info,1);

% Compute impulse responses (point estimates)
[irf,irf_all] = ComputeImpulseResponses(results,info);
% Compute generalize impulse responses.
[girf,girf_all] = ComputeGIRF(results,info);
% Compute confidence bands for impulse responses
[bands,sig,bands_girf,sig_girf] = ComputeConfidenceBands(results,info,data,determ);

% Model VAR forecast.
forecast_h  = 6;
determ_fore = ones(6,1);
VARfore = ForecastVAR(results,info,determ_fore,forecast_h,1,3);
% Conditional forecast.
forecast_h  = 3;
determ_fore = ones(forecast_h,1);
h_const     = [zeros(3,1) 3.5*ones(3,1) 5*ones(3,1)];
forecast    = ForecastVAR_Cond(results,irf_all,info,determ_fore,h_const,1,4);

% Plot impulse responses with symmetric and asymmetric bands
[bands_l,bands_h]     = PlotImpulseResponses(irf,sig,info,5);
[bands_lbt,bands_hbt] = PlotImpulseResponses(irf,bands,info,6);

% Computing Forecast Error Variance Decomposition (FEVD)
FEVD = ComputeFEVD(irf_all,info,7);
% Computing Historical decomposition of the shokcs.
[HDcomp,shocks] = ComputeHDComp(results,info,8);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [bands,sig,bands_girf,sig_girf] = ComputeConfidenceBands(input,info,data,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 12/Oct/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes bootstrapped or asymtotic confidence bands for 
% impulse responses of VAR (with and without block exogeneity).
% Input:
%   input:
%   -.A_1       : Lag matrices for exo block.
%   -.B_1       : Lag mats. endo block (exo vars; n2 x n1 x p).
%   -.B_2       : Lag mats. endo block (end vars; n2 x n2 x p).
%   -.C_1       : Coefficients exogenous variables for y1t.
%   -.C_2       : Coefficients exogenous variables for y2t.
%   -.resid     : Regression residuals (T x n matrix).
%   -.Sig       : Matrix, error covariance matrix.
%   info:
%   -.p         : Lag order.
%   -.rep       : Number of Bootstrap replications.
%   -.conf      : Confidence levels for error bands.
%   -.block     : (0) VAR; (1) VAR with block exogeneity.
%   data:
%   -.exo       : Data exo block (y_1t).
%   -.endo      : Data endo block (y_2t).
%   exo         : Exogenous variables (optional).
%
% Output:
%   bands       : Lower (1st) and upper (2nd) bands (n x h+1 x 2 x c).
%   sig         : IRF standard deviations (n x h+1).
%   bands_girf  : Lower (1st) and upper (2nd) bands (n x h+1 x 2 x c) for GIRF.
%   sig_girf    : IRF standard deviations (n x h+1) for GIRF.
%
% Index:
% 1. Setup.
% 2. Simple VAR model.
% 3. VAR model with block exogeneity.
% 4. Results.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup.
endo_data = data.endo;
T         = length(endo_data);
p         = info.p;
resid     = input.resid;
rep       = info.rep;
conf      = info.conf;
c         = length(conf);  

% VAR model.
if info.block == 0
    A = input.A;
    C = input.C;
    % Allocate memory for simulated data.
    nvar = size(data.endo,2);
    for k = 1:rep
        boot_data(k).endo = zeros(T,nvar);
    end
end
% VAR model with block exogeneity.
if info.block == 1
    exo_data = data.exo;
    A_1 = input.A_1;
    B_1 = input.B_1;
    B_2 = input.B_2;
    C_1 = input.C_1;
    C_2 = input.C_2;
    n_1 = size(A_1,1);
    n_2 = size(B_1,1);
    % Allocate memory for simulated data.
    for k= 1:rep
        boot_data(k).exo = zeros(T,n_1);
        boot_data(k).endo= zeros(T,n_2);
    end
end
% Generate bootstrap indices
[~,index] = bootstrp(rep,[],resid);
% Put waitbar
h_wait = waitbar(0,'Generating bootstrap samples, please wait...');
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Simple VAR model.
if info.block == 0
    % Generate bootstrap samples
    for k = 1:rep
        waitbar(k/rep,h_wait)
        for i = 1:T
            if i <= p
                % Use pre-sample values here
                boot_data(k).endo(i,:) = endo_data(i,:);
            else
                % Exogenous variables
                if size(exo,2) >0
                    boot_data(k).endo(i,:) = exo(i,:)*C';
                end
                % Autoregressive parts
                for j = 1:p
                    boot_data(k).endo(i,:) = boot_data(k).endo(i,:) + boot_data(k).endo(i-j,:)*A(:,:,j)';
                end
                % Stochastics
                boot_data(k).endo(i,:)= boot_data(k).endo(i,:) + resid(index(i-p,k),:);
            end
        end
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. VAR model with block exogeneity.
if info.block == 1
    % Generate bootstrap samples
    for k = 1:rep
        waitbar(k/rep,h_wait)
        for i = 1:T
            if i <= p
                % Use pre-sample values here
                boot_data(k).exo(i,:)  = exo_data(i,:);
                boot_data(k).endo(i,:) = endo_data(i,:);
            else
                % Exogenous variables
                if size(exo,2) > 0
                    boot_data(k).exo(i,:)  = exo(i,:)*C_1';
                    boot_data(k).endo(i,:) = exo(i,:)*C_2';
                end
                % Autoregressive parts
                for j = 1:p
                    boot_data(k).exo(i,:) = boot_data(k).exo(i,:) + ...
                                            boot_data(k).exo(i-j,:)*A_1(:,:,j)';
                    boot_data(k).endo(i,:)= boot_data(k).endo(i,:) + ...
                                            boot_data(k).exo(i-j,:)*B_1(:,:,j)' + ...
                                            boot_data(k).endo(i-j,:)*B_2(:,:,j)';
                end
                % Stochastics
                boot_data(k).exo(i,:) =  boot_data(k).exo(i,:) + ...
                                         resid(index(i-p,k),1:n_1);
                boot_data(k).endo(i,:) = boot_data(k).endo(i,:) + ...
                                         resid(index(i-p,k),n_1+1:end);
            end
        end
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Results.
% Close waitbar
close(h_wait)
% Put waitbar
h_wait = waitbar(0,'Bootstrapping impulse responses, please wait...');

% Generate bootstrap impulse responses
for k = 1:rep
    waitbar(k/rep,h_wait)
    % Data for the type of model.
    if info.block == 0
        boot_data(k).all = boot_data(k).endo;
    elseif info.block == 1
        boot_data(k).all = [boot_data(k).exo boot_data(k).endo];
    end
    % Model estimation for each case.
    if nargin == 3
        if info.block == 0
            results = EstimateVAR(boot_data(k).all,p);
        elseif info.block == 1
            results = EstimateBlockVAR(boot_data(k),p);
        end
    elseif nargin == 4
        if info.block == 0
            results = EstimateVAR(boot_data(k).all,p,exo);
        elseif info.block == 1
            results = EstimateBlockVAR(boot_data(k),p,exo);
        end
    end
    % Computing IRF for simulated data.
    boot_irf(:,:,k) = ComputeImpulseResponses(results,info);
    if nargout > 2
        boot_irf_girf(:,:,k) = ComputeGIRF(results,info);
    end
     clear results;
end
% Close waitbar
close(h_wait)

% Genereting bootstrap confidence bands (Sort IRF at each t)
sort_irf = sort(boot_irf,3); 
if nargout > 2
    sort_irf_girf = sort(boot_irf_girf,3);
end

% Compute lower and upper bands.
for i = 1:c
    bands(:,:,1,i) = sort_irf(:,:,ceil((1-(1+conf(i))/2)*rep));
    bands(:,:,2,i) = sort_irf(:,:,ceil((1+conf(i))/2*rep));
    if nargout > 2
        bands_girf(:,:,1,i) = sort_irf_girf(:,:,ceil((1-(1+conf(i))/2)*rep));
        bands_girf(:,:,2,i) = sort_irf_girf(:,:,ceil((1+conf(i))/2*rep));
    end
end
% Genereting asymptotic confidence bands
sig = std(boot_irf,0,3);
if nargout > 2
    sig_girf = std(boot_irf_girf,0,3);   
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [FEVD,table] = ComputeFEVD(irf_all,info,print)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 12/Oct/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes Forecast Error Variance Decomposition (FEVD).
% Input:
%   irf_all        : Impulse responses functions system (h,vars,shock).
%   info:
%   -.names        : Labels variables in the VAR.
%   -.shock_names  : Shock labels.
%   -.fsizes       : Font sizes to be used (1 x 2).
%   print          : Do graph and graph id (if print > 0); (0) no graph.
%
% Output:
%   FEVD           : Forecast Error Variance Decomposition (T,n,shock).
%   table          : Table with FEVD (T,n,shock).
%
% Index.
% 1. Computing FEVD
% 2. Printing results
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Computing FEVD
% Getting infor for the code.
nvars = size(irf_all,2);
h     = 12;
fsize      = info.fsizes(1);
fsize_alt  = info.fsizes(2);

% Computing RMSE
RMSE = zeros(1+h,nvars);
aux  = zeros(nvars,nvars);
for i0 = 1:1+h
    aux = aux + irf_all(:,:,i0)*irf_all(:,:,i0)';
    RMSE(i0,:) = diag(aux)';
end
clear aux;

% Computing contribution to from each structual shock
num = zeros(1+h,nvars,nvars);
Iaux = eye(nvars,nvars);
for i0 = 1:nvars
    temp_ek = Iaux(:,i0);
    for i1 = 1:nvars
        aux     = 0;
        temp_ej = Iaux(:,i1);
        for i2 = 1:1+h
            aux = aux + (temp_ej'*irf_all(:,:,i2)*temp_ek)^(2);
            num(i2,i0,i1) = aux;
        end        
    end
end

% Final results
FEVD = zeros(1+h,nvars,nvars);
for i0 = 1:nvars
    aux = (num(:,:,i0)./repmat(RMSE(:,i0),1,nvars))*100;
    FEVD(:,:,i0) = aux;
end
clear aux num RMSE i0 i1 i2;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Printing results
% Print table with results.
part_1= [];
for i0 = 1:nvars
    temp_1 = [[info.names(i0) info.shock_names]; num2cell([(0:h)' FEVD(:,:,i0)])];
    part_1 = [part_1; temp_1];
    if i0 < nvars
        part_1 = [part_1; repmat({' '},1,nvars+1)];
    end
end
table = part_1;
% Do graph.
if exist('print','var') == 1
    if print > 0
        fid = 1;
        fprintf(fid,'***************************************************************************************************\n');
        disp('Forecast Errors Variance Decomposition');
        disp(table);
        fprintf(fid,'***************************************************************************************************\n');
        clear  i0 temp_1 part_1;

        % Setup for subplot. Number of variables and graph setup.
        if nvars <= 3
            k1 = 1; k2 = nvars;
        elseif nvars <= 4
            k1 = 2; k2 = 2;
        elseif nvars > 4 && nvars <= 6
            k1 = 3; k2 = 2;
        elseif nvars > 6 && nvars <= 9
            k1 = 3; k2 = 3;
        elseif nvars > 9 && nvars <= 16
            k1 = 4; k2 = 4;
        elseif nvars > 16
            error('Max number of variables reached.');
        end
              
        % Building decomposition for each variable.
        figure(print)
        for i0 = 1:nvars
            subplot(k2,k1,i0)
            bar((0:h)',FEVD(:,:,i0),'stacked');
            title(info.names(i0),'FontSize',fsize);
            set(gca,'FontSize',fsize_alt);
            legend1 = legend(info.shock_names);
            set(legend1,'FontSize',fsize_alt-2,'Orientation','vertical','Location','southeast','Box', 'on');
            ylim([1 100]);
            xlim([0 12]);
            set(gca,'XTick',(0:h)');
        end
        axes('Position',[0 0 1 1],'Visible','off');
        text(0.4275,0.975,'Forecast Error Variance Decomposition','FontSize',12','FontWeight','Bold');
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
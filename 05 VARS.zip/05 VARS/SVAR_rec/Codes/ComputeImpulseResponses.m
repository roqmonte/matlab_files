function [irf,chol_irf] = ComputeImpulseResponses(input,info)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 01/Feb/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes structural IRF for VAR model (with/without block 
% exogeneity) using a recursive identification scheme. Returns an array of 
% dimension (i,j,k) with the response of variable i at horizon j due to an 
% initial shock to variable k.
% Input:
%   input:
%   -.A_1         : Lag matrices for exo block.
%   -.B_1         : Lag mats. endo block (exo vars; n2 x n1 x p).
%   -.B_2         : Lag mats. endo block (end vars; n2 x n2 x p).
%   -.Sig         : Matrix, error covariance matrix.
%   info:
%   -.p           : Lag order p.
%   -.horizon     : Horizon impulse response functions.
%   -.do_norm     : (1) Normalized impulse responses; (0) otherwise.
%   -.norm_fac    : (1) Normalization factor in percent.
%   -.pos_shock   : Position of the shocked variables.
%   -.block       : (0) VAR; (1) VAR with block exogeneity.
%   -.dates_xTick : Dates, var is used to change max horizoon for irf.
%
% Output:
%   irf         : Structural IRF to chosen shock (n x h+1).
%   chol_irf    : MA coefficients.
%
% Index:
% 1. Computation of the companion form.
% 2. IRF computation.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Computation of the companion form.
% Getting info.
Sig         = input.Sig;
do_norm     = info.do_norm;
norm_fac    = info.norm_fac;
pos_shock   = info.pos_shock;
p           = info.p;
% Option for IRF.
h = 150;
if info.dates_xTick(end) > h
   h = info.dates_xTick(end) + 10;
end

% VAR model.
if info.block == 0
    % Companion form VAR(p) model.
    n = size(input.A,1);
    if p == 1
        F = input.A;
    elseif p > 1
        F = [reshape(input.A,n,n*p); [eye(n*(p-1)) zeros(n*(p-1),n)]];
    end
end

% VAR model with block exogeneity.
if info.block == 1
    % Companion form VAR(p) model.
    n_1 = size(input.A_1,1);
    n_2 = size(input.B_1,1);
    n = n_1 + n_2;
    if p == 1
        F1 = [input.A_1(:,:,1) zeros(n_1,n_2)];
        F2 = [input.B_1(:,:,1) input.B_2(:,:,1)];
        F  = [F1; F2];
    elseif p > 1
        F1 = [];
        F2 = [];
        for i = 1:p
            F1 = [F1 input.A_1(:,:,i) zeros(n_1,n_2)];
            F2 = [F2 input.B_1(:,:,i) input.B_2(:,:,i)];
        end
        F3 = [F1; F2];
        F  = [F3; [eye(n*(p-1)) zeros(n*(p-1),n)]];
    end
    clear i F1 F2 F3;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. IRF computation.
% Reduced-form impact responses
J = [eye(n) zeros(n,n*(p-1))];
red_irf = zeros(n,n,h+1);
for i = 0:h
    red_irf(:,:,i+1) = J*(F)^(i)*J';
end

% Orthogonalization
chol_irf = zeros(n,n,h+1);
cho_fac  = chol(Sig,'lower');
A0inv    = cho_fac;
for i=1:h+1
    chol_irf(:,:,i) = red_irf(:,:,i)*A0inv;
end

% Prepare output
for i0 = 1:n
    irf_all(:,:,i0) = squeeze(chol_irf(:,i0,:))';
end
irf = irf_all(1:info.horizon+1,:,info.pos_shock);

% Normalization
if do_norm == 1
    irf = norm_fac*irf/irf(1,pos_shock);
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
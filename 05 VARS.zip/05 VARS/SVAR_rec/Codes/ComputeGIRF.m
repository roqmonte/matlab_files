function [girf,girf_all,FEVD,table,spillovers] = ComputeGIRF(input,info,print,spillh)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 23/Sept/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes Generalzed IRF for VAR model (with/without block 
% exogeneity) following Pesaran and Shin (1998). Returns an array of 
% dimension (i,j,k) with the response of variable i at horizon j due to an 
% initial shock to variable k.
% Input:
%   input:
%   -.A_1         : Lag matrices for exo block.
%   -.B_1         : Lag mats. endo block (exo vars; n2 x n1 x p).
%   -.B_2         : Lag mats. endo block (end vars; n2 x n2 x p).
%   -.Sig         : Matrix, error covariance matrix.
%   info:
%   -.p           : Lag order p.
%   -.names       : Labels variables in the VAR.
%   -.fsizes      : Font sizes to be used (1 x 2).
%   -.horizon     : Horizon impulse response functions.
%   -.do_norm     : (1) Normalized impulse responses; (0) otherwise.
%   -.norm_fac    : (1) Normalization factor in percent.
%   -.pos_shock   : Position of the shocked variables.
%   -.block       : (0) VAR; (1) VAR with block exogeneity.
%   -.dates_xTick : Dates, var is used to change max horizoon for irf.
%   print         : Do graph and graph id (if print > 0); (0) no graph.
%   spillh        : Horizon for the spillover analysis, (default 5).
%
% Output:
%   girf        : Structural IRF to chosen shock (n x h+1).
%   girf_MA     : MA coefficients.
%   FEVD        : Forecast error variance decomposition.
%   table       : Table with FEVD (T,n,shock).
%   spillovers:
%   -.total     : Total net volatility spillover.
%   -.rec       : Volatility spillovers received by market i from all other markets j
%   -.tra       : Volatility spillovers transmited by market i to all other markets j
%   -.net       : Net spillovers.
%   -.atri      : Contribution to volatility spillovers for each variable.
%
% Index:
% 1. Computation of the companion form.
% 2. IRF computation.
% 3. FEVD computation.
% 4. Spillovers.
% 5. Printing results.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Computation of the companion form.
% Getting info.
Sig         = input.Sig;
do_norm     = info.do_norm;
norm_fac    = info.norm_fac;
pos_shock   = info.pos_shock;
p           = info.p;
fsize      = info.fsizes(1);
fsize_alt  = info.fsizes(2);
% Option for IRF.
h = 150;
if info.dates_xTick(end) > h
   h = info.dates_xTick(end) + 10;
end

% VAR model.
if info.block == 0
    % Companion form VAR(p) model.
    n = size(input.A,1);
    if p == 1
        F = input.A;
    elseif p > 1
        F = [reshape(input.A,n,n*p); [eye(n*(p-1)) zeros(n*(p-1),n)]];
    end
end

% VAR model with block exogeneity.
if info.block == 1
    % Companion form VAR(p) model.
    n_1 = size(input.A_1,1);
    n_2 = size(input.B_1,1);
    n = n_1 + n_2;
    if p == 1
        F1 = [input.A_1(:,:,1) zeros(n_1,n_2)];
        F2 = [input.B_1(:,:,1) input.B_2(:,:,1)];
        F  = [F1; F2];
    elseif p > 1
        F1 = [];
        F2 = [];
        for i = 1:p
            F1 = [F1 input.A_1(:,:,i) zeros(n_1,n_2)];
            F2 = [F2 input.B_1(:,:,i) input.B_2(:,:,i)];
        end
        F3 = [F1; F2];
        F  = [F3; [eye(n*(p-1)) zeros(n*(p-1),n)]];
    end
    clear i F1 F2 F3;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. IRF computation.
% Reduced-form impact responses
J = [eye(n) zeros(n,n*(p-1))];
red_irf = zeros(n,n,h+1);
for i = 0:h
    red_irf(:,:,i+1) = J*(F)^(i)*J';
end

% Generalized impulse response function
girf_all = zeros(n,n,h+1);
aux = repmat(diag(Sig).^(-1/2)',n,1);
for i=1:h+1
    girf_all(:,:,i) = aux.*(red_irf(:,:,i)*Sig);
end
clear aux i;

% Prepare output
for i0 = 1:n
    temp_irf(:,:,i0) = squeeze(girf_all(:,i0,:))';
end
girf = temp_irf(1:info.horizon+1,:,info.pos_shock);

% Normalization
if do_norm == 1
    girf = norm_fac*girf/girf(1,pos_shock);
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. FEVD computation
hor = 13;
g_temp = red_irf(:,:,1:hor);
% Loop.
In = eye(n);
for ei = 1:n
   eii =  In(:,ei);
   for ej = 1:n
       ejj = In(:,ej);
       aux1 = 0;
       aux2 = 0;
       for i0 = 1:hor
          % Numerator
          aux1 = aux1 + (eii'*(g_temp(:,:,i0)*Sig)*ejj)^2;
          num(ej,ei,i0) = Sig(ej,ej)^(-1)*aux1;
          % Denomitatonr
          aux2 = aux2 + eii'*(g_temp(:,:,i0)*Sig*g_temp(:,:,i0)'*eii);
          den(i0,ei) = aux2;
       end       
   end
end
clear aux1 aux2 h
% Final results
FEVD = zeros(hor,n,n);
for i0 = 1:n
    for i1 = 1:hor
        FEVD(i1,:,i0) = num(:,i0,i1) ./ den(i1,i0);
    end
end
FEVD= FEVD*100;
clear i0 num den;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Spillovers.
% Checking horizon.
if exist('spillh','var') == 0
    spillh = 5;
end
id_aux = reshape(ones(n)-eye(n),1,n*n);

% Normalization
fdn = FEVD./repmat(sum(FEVD,2),1,n);
% Total spillovers.
spill_tot = (id_aux*reshape(squeeze(fdn(spillh,:,:)),1,n*n)')/n*100;
% Directional spillovers
for i1 = 1:n
    % Volatility spillovers received by market i from all other markets j
    ei     = ones(1,n);
    ei(i1) = 0;
    spill_rec(1,i1) = sum(ei.*fdn(spillh,:,i1))/n*100;
    
    % Volatility spillovers transmited by market i to all other markets j
    ej     = ones(1,n);
    ej(i1) = 0;
    spill_tra(1,i1) = sum(ej*squeeze(fdn(spillh,i1,:)))/n*100;
    
    % Aditional results
    xrq(i1,:) = [fdn(spillh,:,i1) squeeze(fdn(spillh,i1,:))'];

end    
% Net spillovers
spill_net(1,:) = spill_tra(1,:) - spill_rec(1,:);
clear ei ej;

% Savinf results
spillovers.total = spill_tot;
spillovers.rec   = spill_rec;
spillovers.tra   = spill_tra;
spillovers.net   = spill_net;
spillovers.atri  = xrq;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 5. Printing results
% Print table with results.
part_1= [];
for i0 = 1:n
    temp_1 = [[info.names(i0) info.names]; num2cell([(0:hor-1)' FEVD(:,:,i0)])];
    part_1 = [part_1; temp_1];
    if i0 < n
        part_1 = [part_1; repmat({' '},1,n+1)];
    end
end
table = part_1;

% Do graph.
if exist('print','var') == 1
    if print > 0
        fid = 1;
        fprintf(fid,'***************************************************************************************************\n');
        disp('Forecast Errors Variance Decomposition based on the Generalized Impulse Response');
        disp(table);
        fprintf(fid,'***************************************************************************************************\n');
        clear  i0 temp_1 part_1;

        % Setup for subplot. Number of variables and graph setup.
        if n <= 3
            k1 = 1; k2 = n;
        elseif n <= 4
            k1 = 2; k2 = 2;
        elseif n > 4 && n <= 6
            k1 = 3; k2 = 2;
        elseif n > 6 && n <= 9
            k1 = 3; k2 = 3;
        elseif n > 9 && n <= 16
            k1 = 4; k2 = 4;
        elseif n > 16
            error('Max number of variables reached.');
        end
              
        % Building decomposition for each variable.
        figure(print)
        for i0 = 1:n
            subplot(k2,k1,i0)
            bar((0:hor-1)',FEVD(:,:,i0),'stacked');
            title(info.names(i0),'FontSize',fsize);
            set(gca,'FontSize',fsize_alt);
            legend1 = legend(info.names);
            set(legend1,'FontSize',fsize_alt-2,'Orientation','vertical','Location','southeast','Box', 'on');
            xlim([0 hor-1]);
            set(gca,'XTick',(0:hor-1)');
        end
        axes('Position',[0 0 1 1],'Visible','off');
        text(0.4275,0.975,'Forecast Error Variance Decomposition','FontSize',12','FontWeight','Bold');
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function forecast = ForecastVAR(results,info,exo,h,print,fid)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 22/Sept/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes VAR forecast.
% Inputs:
%   results:
%   -.C           : Coefficients exogenous variables.
%   -.F           : Companion form.
%   -.Y           : Dependent variables of the system (lhs variables).
%   info:
%   -.p           : Lag order.
%   -.names       : Labels with variable names (1 x n).
%   -.dates_ini   : Setting for dates: (year,month,freq).
%                   Where, freq: (1) monthly;(2) quaterly data.
%   -.dates_xTick : Xtick for dates.
%   -.widths      : vector with line widths.
%   -.fsizes      : vector with font sizes.
%   exo           : Exogenous variables.
%   h             : Forecast horizon.
%   print         : (1) print charts.
%   fid           : Figure number for plots.
%
% Outputs:
%   forecast:
%   -.dataf     : Matrix with data and forecast.
%   -.VARf      : Matrix with forecast only.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting info for estimation.
if exist('exo','var') == 0
    exo = [];
end
% Checking dim of exo and h.
if size(exo,1) > 1
    if size(exo,1) ~= h
       error('Dim for exo variables not consistent with forecast horizon.');
    end
end

% Lag order of the model.
p = info.p;
% Companion form nodel.
F = results.F;

% Model selection with and without block exogeneity.
if info.block == 0    
    C = results.C;
elseif info.block == 1
    C = [results.C_1; results.C_2];
end

% Building data for forecast
y_fore = results.Y(end-p-12:end,:);
n = size(y_fore,2);
yf = zeros(h,n);
% Forecasting model
for j0 = 1:h
    T = size(y_fore,1);
    temp1 = [];
    for i0 = T:-1:T-p+1
        temp1 = [temp1; y_fore(i0,:)'];
    end
    % Forecast 
    aux = ([eye(n);zeros(n*(p-1),n)])'*F*temp1 + C*exo(j0,:)';
    yf(j0,:)  = aux';
    y_fore = [y_fore; aux'];
    clear temp1 i0 aux;
end
clear j0;
% Forecast
forecast.dataf = [NaN(info.dates_xTick(end)-size(results.Y,1),n); [results.Y; yf]];
forecast.VARf  = yf;
Tf             = size(forecast.dataf,1);

% Do charts
if exist('print','var')
    if print == 1       
        if exist('fid','var') == 0
            fid = 1;
        end;
        % Setup for charts
        line_width= info.widths(1);
        fsize     = info.fsizes(1);
        fsize_alt = info.fsizes(2);
        names     = info.names;
        if info.dates_ini(end) == 1
            freq = 'm';
        elseif info.dates_ini(end) == 2
            freq = 'q';
        end
        [xTick,xTickLabel] = calendar(info.dates_ini(1),info.dates_ini(2),Tf,freq);
        
        % Number of variables and graph setup.
        aux = n;
        if aux <= 3
            k1 = 1; k2 = aux;
        elseif aux <= 4
            k1 = 2; k2 = 2;
        elseif aux > 4 && aux <= 6
            k1 = 3; k2 = 2;
        elseif aux > 6 && aux <= 9
            k1 = 3; k2 = 3;
        elseif aux > 9 && aux <= 16
            k1 = 4; k2 = 4;
        elseif aux > 16
            error('Max number of variables reached.');
        end

        % Building Chart
        figure(fid);
        k = 1;
        for j = 1:n
            subplot(k2,k1,k);
            plot(forecast.dataf(:,j),'-r','LineWidth',line_width);
            hold on
            plot([forecast.dataf(1:end-h,j); NaN(h,1)],'-b','LineWidth',line_width);
            title(names(j),'FontSize',fsize);
            set(gca,'FontSize',fsize_alt);
            % Limits for charts
            set(gca,'xTick',xTick);
            set(gca,'xTickLabel',xTickLabel);
            xlim([xTick(round(size(xTick,1)/2)) xTick(end)]);
            k = k + 1;
        end;
        legend1 = legend('forecast','Data');
        set(legend1,'FontSize',fsize_alt-2,'Orientation','horizontal',...
        'Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
        clear k j fid1;
    end    
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
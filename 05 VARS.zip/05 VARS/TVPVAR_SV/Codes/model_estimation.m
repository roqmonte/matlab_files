function results = model_estimation(data,info,prior,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 6/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimate TVPVAR model with Gibbs Sampling.
% State-space representation of the model:
%
% Observation Equation : Y(t) = H*B(t) + A(t)^(-1)*SIGMA(t)*e(t)
% Transition Equation  : B(t) = B(t-1) + v(t)
%                        A(t) = A(t-1) + w(t)
%                        H(t) = H(t-1) + n(t) ; H(t) = diag(log(sg2)))
%
% Where: var(et) = I, var(vt) = Q, var(wt) = S, var(nt) = W.
% Note that H(t) is xi-square(1), we approximate H(t) by a mixture of
% normal distirbutions, With H = log(diag(chol(Omega))).
%
% Inputs:
%   data:
%   -.all         : All data.
%   -.endo        : Data VAR.
%   info:
%   -.p           : Lag order of the VAR.
%   -.rep         : Number of draws from posterior.
%   -.burn        : Burning sample.
%   -.presmaple   : Presample data for prior.
%   -.thin        : Thinning parameter; set=1 to use all draws.
%   -.kQ          : Scale parameter for Q matrix.
%   -.kS          : Scale parameter for S matrices.
%   -.kW          : Scale parameter for W matrix.
%   -.horizon     : Horizon impulse response functions.
%   -.do_norm     : (1) Normalized impulse responses; (0) otherwise.
%   -.norm_fac    : (1) Normalization factor in percent.
%   -.exo_rest    : Additional restriction to exo block. If empty then block exogeneity applies.
%   prior:
%   -.Aind        : Indicators variables for aij elements of A matrix.
%   -.TS          : Degrees of freedom for S.
%   -.Bpr         : Prior for B.
%   -.VBpr        : Prior for cov(B).
%   -.Qpr         : Prior for Q matrix.
%   -.Apr         : Prior for A elements of A mtrix.
%   -.VApr        : Prior for cov(A(t))elements of A mtrix.
%   -.HApr        : Prior for H(t).
%   -.VHApr       : Prior for cov H(t).
%   exo           : Exogenous variables (optional).
%
% Outputs:
%   results:
%   -.irf          : Draws from Impulse responses of the structural model: horizon, variable, shock, simulation, time.
%   -.irf_full     : IRF with extended horizon for FEVD and Hdecomp: horizon, variable, shock, simulation, time.
%   -.fitted       : Fitted values
%   -.resid        : Regression residuals
%   -.Y            : Left hand variables.
%   -.X            : Right hand variables.
%   -.A0           : Median estimates for A0.
%   -.Sig_vb       : Median estimates for Sg2, state equation.
%   -.Sig_tvp      : TVP variance/covariance of the reduced residuals.
%   -.Betas_tvp    : TVP betas.
%   -.Fcomp_tvp    : TVP companion form
%   -.C_tvp        : TVP exogenous regressors.
%   -.B_draws      : Draws from the reduced form parameters.
%   -.R_draws      : Draws R matrix var/cov observaion equation.
%   -.Q_draws      : Draws Q matrix var.cov state equation.
%   -.A0_draws     : Draws from the structural matrix A0.
%   -.A_draws      : Draws for A(t) coefficients,
%   -.S_draws      : Draws cov matrix of A(t).
%   -.H_draws      : Draws H(t) matrix.
%   -.W_draws      : Draws for cov matrix of H(t).
%   -.Sg2_draws    : Draws time varing Sg2(t).

%   -.prior        : Data from priors.
%
% Index:
% 1. Setup of the model.
% 2. Gibss sample Initialisation
% 3. Simulations.
% 4. Results.
% 5. Finctions
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup of the model.
% Data for model.
if exist('exo','var') == 0
    exo = [];
end
% Info from code.
p     = info.p;
draws = info.rep+1;
burn  = info.burn;
nexo  = size(exo,2);

% Generating dependent variables.
datax = [data.prior_all; data.all];
Y = datax(1+info.p:end,:);
% Generating lags of dependent variables.
X = []; i = 1;
while i <= p    
    X = [X datax(1+info.p-i:end-i,:)];
    i = i + 1;
end;
% Adding exogenous variables
datadet = [data.prior_determ; exo];
X = [X datadet(1+info.p:end,:)];
clear datax datadet;
  
% Pre-sample data for prior.
T0   = info.presample - info.p;
TW   = size(Y,2) + 1;
kQ   = info.kQ;
kS   = info.kS;
kW   = info.kW;
Aind = prior.Aind;
TS   = prior.TS;
Bpr  = prior.Bpr;
VBpr = prior.VBpr;
Qpr  = prior.Qpr;
Apr  = prior.Apr;
VApr = prior.VApr;
Hpr  = prior.Hpr;
VHpr = prior.VHpr;
% Intial state vector b[t-1/t-1]
beta0 = vec(Bpr)';

% Set of restriction and additional restrictions for exo block.
if isempty(info.exo_rest) == 0
    % Selection matrix
    aux_r = ones(size(Bpr,1),size(Bpr,2));
    aux_0 = repmat(info.exo_rest,1,info.p)';   
    aux_r(1:info.p*size(Y,2),:) = aux_0;
    id  = vec(aux_r)'.*(1:size(beta0,2));
    % Formating variables.
    idx1 = find(id>0);
    idx2 = vec(aux_r)';
    
    % New priors.
    Qpr    = Qpr(idx1,idx1);
    VBpr   = VBpr(idx1,idx1);
    
    beta0 = beta0(idx1);
    clear aux_0 aux_r id;
else
    idx1 = [];
    idx2 = [];
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Gibss sample Initialisation

% Data for model estimation.
Ybar  = Y(T0+1:end,:);
Xbar  = X(T0+1:end,:);
Tbar  = size(Xbar,1);
ny    = size(Ybar,2);
% Number of states and lower-triangular elements
ns    = size(Xbar,2)*ny;
nA    = ny*(ny-1)/2;

% Gibss sample Initialisation
% Initialise Q
covB = T0*VBpr*kQ^2;
Q    = iwishrnd(covB,T0);
VBpr = 4*VBpr;

% Initialise S
z1 = 1; z2 = 1; S  = [];
for i0 = 1:nA-1
    i1 = i0 + 1;
    eval(['covS' num2str(i1) ' = TS(i0)*VApr(z1:z2,z1:z2)*kS^2;']);
    eval(['S_temp = iwishrnd(covS' num2str(i1) ',TS(i0));']);
    eval(['S' num2str(i1) '= S_temp;']);
    z1 = z1*2;
    z2 = z2*2 + 1;
    % Initialise S
    S  = blkdiag(S,S_temp);    
end
clear S_temp i0 i1 z1 z2;

% Initialise W
covW = TW*VHpr*kW^2;
W    = iwishrnd(covW,TW);

% Initialise H and Sigma(t)
H    = NaN(Tbar,ny);
Sig  = NaN(ny-1,ny-1,Tbar);
H(1,:)      = mvnrnd(Hpr,VHpr,1);
Sig(:,:,1)  = diag(exp(2*H(1,TS(1):TS(end))));
for t = 2:Tbar
    H(t,:)      = mvnrnd(H(t-1,:),W,1);
    Sig(:,:,t)  = diag(exp(2*H(t,TS(1):TS(end))));
end

% initialise A
A    = NaN(Tbar,nA);
A(1,:) = mvnrnd(Apr,4*VApr,1);
for t = 2:Tbar
    A(t,:) = mvnrnd(A(t-1,:),S,1);
end

% Matrix to store draws.
B_s  = zeros(Tbar,ns,draws);
A_s  = zeros(Tbar,nA,draws);
H_s  = zeros(Tbar,ny,draws);
Q_s  = zeros(ns,ns,draws);
% Matrix for S
for i0 = 1:nA-1
    i1 = i0 + 1;
    eval(['S' num2str(i1) '_s = zeros(i0,i0,draws+1);']);
end
W_s  = zeros(ny,ny,draws);

% Initialise.
A_s(:,:,1) = A;
H_s(:,:,1) = H;
Q_s(:,:,1) = Q;
% Matrix for S
for i0 = 1:nA-1
    i1 = i0 + 1;
    eval(['S' num2str(i1) '_s(:,:,1) = S' num2str(i1) ';']);
end
S_s(:,:,1) = S;
W_s(:,:,1) = W;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Simulations.

% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');
%disp('-Note: Explosive roots are discarded from simulations.');
record  = 0;
ndraw   = 1;
while record < burn + draws + 1
    
    % Stage 1: Draw beta(t) and Q
    % Omega(t) = A(t)^-1 * H(t)*H(t)' * (A(t)')^-1;
    Omega = NaN(ny,ny,Tbar);
    Alt   = kron(ones(Tbar,1),eye(ny));   
    for t = 1:Tbar
        z1 = 1; j1 = 1; j2 = 1;
        for i0 = 2:ny
            Alt((t-1)*ny+i0,1:z1) = -A(t,j1:j2);            
            z1 = z1 + 1;
            j1 = j1*2;
            j2 = j2*2 + 1;
        end
        Omega(:,:,t) = Alt((t-1)*ny+1:t*ny,:) \ diag(exp(2*H(t,:))) ...
                       / Alt((t-1)*ny+1:t*ny,:)';
                   
    end
    [B,resB] = KalmanCarterKohn_b(beta0,VBpr,Ybar,Xbar,Q,Omega,info.exo_rest,idx1,idx2,nexo,p);
    clear t z1 j1 j2;
    
    % Stage 2: Draw A(t).
    % Rregressors for A(t)
    XA  = zeros(Tbar,nA,size(TS,2));
    % Measurement error for A(t)
    Sig = zeros(nA-1,nA-1,Tbar);
    for t = 1:Tbar
        j1 = 1; j2 = 1;
        for i0 = TS(1):TS(end)
            XA(t,j1:j2,TS(i0-1)-1) = resB(t,1:j1);    
            j1 = j1 + 1;
            j2 = j1 + 1;
        end
        Sig(:,:,t) = diag(exp(2*H(t,TS(1):TS(end))));
    end
    [A,resA] = KalmanCarterKohn_sv(resB(:,2:end),XA,Apr,4*VApr,Sig,S); % change 3 by end
    
    % Stage 3: Draw H(t)
    % Sample S from a 7-point discrete density (see Kim et al., 1998)
    [s,v2j,yss_mj] = KF_KimShephardChib(A,Tbar,ny,resB,H);    
    % Get draw for Sigmas2
    covH = zeros(ny,ny,Tbar);
    for t = 1:Tbar
        covH(:,:,t) = diag(v2j(s(t,:)));
    end
    H = KalmanCarterKohn_sv(yss_mj,ones(Tbar,1)*2,Hpr,VHpr,covH,W);
    clear t z1 j1 j2;    
    
    % Step 4: Sample Q from the IW distribution (given beta draws)
    errorB = diff(B);
    scaleQ = errorB'*errorB + Qpr;
    Q      = iwishrnd(scaleQ,Tbar-1+T0);  
    
    % Step 5: Draw S, the covariance of A(t), from inverse Wishart
    errorA = diff(A);
    sqerrA = errorA'*errorA;    
    % Do draw of S
    z1 = 1; z2 = 1; S  = [];
    for i0 = 1:nA-1
        i1 = i0 + 1;
        eval(['scale' num2str(i1) ' = sqerrA(z1:z2,z1:z2) + covS' num2str(i1) ';']);
        eval(['S' num2str(i1) ' = iwishrnd(scale' num2str(i1) ',Tbar-1+TS(i0));']);
        eval(['S_temp = S' num2str(i1) ';']);
        z1 = z1*2;
        z2 = z2*2 + 1;
        % Initialise S
        S  = blkdiag(S,S_temp);
    end
    clear S_temp i0 i1 z1 z2;
            
    % Step 6: Draw W, the covariance of H(t), from inverse Wishart
    errorH = diff(H);
    scaleW = errorH'*errorH + TW*VHpr*kW^2;
    W      = iwishrnd(scaleW,Tbar-1+TW);
    
    % Storing draws after the burning period.
    if record > burn
        % Update waitbar
        waitbar(ndraw/draws,h_wait);
        % Draws of B(t)
        if isempty(info.exo_rest) == 0
            temp = zeros(Tbar,size(idx2,2));
            temp(:,idx1) = B(:,:);
            out1(:,:,ndraw) = temp;
            clear temp;
        else
            out1(:,:,ndraw) = B;
        end
        % Draws of R(t).
        out2(:,:,:,ndraw) = Omega;       
        % Draws of Q from IW
        out3(:,:,ndraw) = Q;
        % Draws of A(t).
        A_draws(:,:,ndraw) = A;
        % Draws of S.
        S_draws(:,:,ndraw) = S;
        % draws of H(t).
        H_s(:,:,ndraw)   = H;
       % draws of W from IW
        W_s(:,:,ndraw)   = W;
        
        ndraw = ndraw + 1;
    end

    % Moving top next draw if all conditions are satisfied.            
    record = record + 1;

    % Cleaning memory.
    clear errorq scaleQ scaleR Fcomp;
end
close(h_wait);
clear i f ii j ndraw z3 ys yss

% Adjust out1 and out2 dimension to make draws consistent
out1 = out1(:,:,2:end);
out2 = out2(:,:,:,2:end);

% Do Thinning
if info.thin > 1
    thin = info.thin;
    out1 = out1(:,:,1:thin:end);
    out2 = out2(:,:,:,1:thin:end);
    out3 = out3(:,:,1:thin:end);
    A_draws = A_draws(:,:,1:thin:end);
    S_draws = S_draws(:,:,1:thin:end);
    H_s = H_s(:,:,1:thin:end);
    W_s = W_s(:,:,1:thin:end);
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Waitbar for in-sample fit and irf.
h_wait = waitbar(0,'Computing in-sample fit and TV-IRF for structural shocks...');
% Building results from simulations.
nvar = ny;
hmax = info.horizon;
J    = [eye(nvar) zeros(nvar,nvar*(p-1))];
for i = 1:Tbar;
    % Betas, draws from posterior.
    temp = median(out1(i,:,:),3);
    % Building beta matrix
    betas_tvp(:,:,i) = reshape(temp,nvar*p+nexo,nvar)';
    % Saving betas from deterministic variables.
    C_tvp(:,:,i) = betas_tvp(:,nvar*p+1:end,i);
    % Companion form of the model
    F_tvp(:,:,i) = F_comp(median(out1(i,:,:),3),nvar,p,nexo);
    % Covariance matrix residual of the model.
    R_tvp(:,:,i) = median(out2(:,:,i,:),4);
    
    % In sample fit of the model.
    fitted(i,:) = Xbar(i,:)*betas_tvp(:,:,i)';
    clear temp
    
    % Do impulse response of the model with recursive identification.
    for ndraw = 1:size(out1,3)        
        % Get A0_draws
        temp = out2(:,:,i,ndraw);
        % Saving Sg2(t) draws
        Sg2_draws(i,:,ndraw) = diag(chol(temp)')';
        % Draws structural parameters.
        A0_draws(:,:,i,ndraw) = (chol(temp,'lower'))^(-1);
        
        % Recursive idenitfication scheme.
        irf_all = recursive(A0_draws(:,:,i,ndraw),out1(i,:,ndraw),nvar,p,nexo,J,hmax);
        clear aux
        % Normalization of IRF.
        if info.do_norm == 1
            for i0 = 1:nvar
                temp = squeeze(irf_all(1:info.horizon,:,i0));
                temp_irf = info.norm_fac*temp/temp(1,i0);
                temp_irf2(:,:,i0,ndraw,i) = temp_irf;
                clear temp;
            end
        end
        % Storing IRF (horizon, variable, shock, simulation, time).    
        irf_all2(:,:,:,ndraw,i) = irf_all;
    end
    clear temp_irf irf_all;
    % Waitbar.
    waitbar(i/Tbar,h_wait);
end
close(h_wait);

% Impulse response of the model.
% Normalization
if info.do_norm == 1
    results.irf = temp_irf2;
else
    results.irf = irf_all2(1:info.horizon,:,:,:,:);
end
results.irf_full = irf_all2;

% Data
results.Y         = Ybar;
results.X         = Xbar;
% Fit of the model.
results.fitted    = fitted;
results.resid     = Ybar - results.fitted;
% Saving draws.
results.B_draws   = out1;
results.R_draws   = out2;
results.Q_draws   = out3;
results.A0_draws  = A0_draws;
results.A_draws   = A_draws;
results.S_draws   = S_draws;
results.H_draws   = H_s;
results.W_draws   = W_s;
results.Sg2_draws = Sg2_draws;
% Median estimates
results.Sig_vb    = median(out3,3);
results.A0        = median(A0_draws,4);
% Saving TVP
results.Betas_tvp = betas_tvp;
results.Fcomp_tvp = F_tvp;
results.C_tvp     = C_tvp;
results.Sig_tvp   = R_tvp;
% Priors.
results.prior     = prior;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Function.

% Kalman filter and Carter and Kohn algorithm for B.
function [St,y_res,y_fit] = KalmanCarterKohn_b(beta0,VBpr,Ybar,Xbar,Q,Omega,exo_rest,idx1,idx2,nexo,p)
% Inputs:
% betao    : Initial draw for beta.
% VBpr     : Prior covariance matrix for betas.
% Ybar     : Dependent variables.
% Xbar     : Independent variables.
% Q        : Covariance matrix for state equation.
% Omega    : 
% exo_rest : Id variables for exo variables.
% idx1     : Idnetifiers for restriction on B matrix.
% idx2     : Idnetifiers for restriction on B matrix.
% nexo     : Number of deterministic and exogenous variables.
% p        : Lag order.
% Outputs:
% St       : Smoothed states variables. 
% y_res    : Smoothed residual.
% y_fit    : Smoothed fit.

% Set up matrices for the Kalman Filter
ns = size(beta0,2);
F  = eye(ns); % FIX
mu = 0;       % FIX

% Info from code.
Tbar = size(Xbar,1);
ny   = size(Ybar,2);

% Matrix to store the filtered state variable and its variance
beta_tt = [];
ptt     = zeros(Tbar,ns,ns);

% Initial states, from pre-sample data
beta11 = beta0;
p11    = VBpr;
% Kalman Filter
for i=1:Tbar        
    % Prediction
    x = kron(eye(ny),Xbar(i,:));
    beta10 = mu + beta11*F';
    p10    = F*p11*F' + Q;

    % Restrictions state equation.
    if isempty(exo_rest) == 0
        temp = zeros(1,size(idx2,2));
        temp(1,idx1) = beta10;
        beta10 = temp;        
        % Fit 
        yhat   = (x*(beta10)')';
        % Removing extra zeros.
        beta10 = beta10(idx1);

        eta    = Ybar(i,:) - yhat;

        % Removing cols from x.
        xx = x(:,idx1);
        x  = xx;

        R      = Omega(:,:,i);
        feta   = (x*p10*x') + R;
        % Kalman gain and updating.
        K      = (p10*x')/(feta);
        beta11 = (beta10' + K*eta')';
        p11    = p10 - K*(x*p10);
        clear temp xx;

    % No Restrictions state equation.
    else
        % Fit 
        yhat   = (x*(beta10)')';

        eta    = Ybar(i,:) - yhat;
        R      = Omega(:,:,i);
        feta   = (x*p10*x') + R;
        % Kalman gain and updating.
        K      = (p10*x')*(feta)^(-1);
        beta11 = (beta10' + K*eta')';
        p11    = p10 - K*(x*p10);            
    end        

    % Saving updates.
    ptt(i,:,:) = p11;
    beta_tt    = [beta_tt;beta11];
end

% Carter and Kohn backward recursion         
% Check stable draws
scheck = -1;
while scheck < 0;
    % Matrix to store draws from posterior distirbutions.
    beta2 = zeros(Tbar,ns);
    wa    = randn(Tbar,ns);
    error = zeros(Tbar,ny);

    % First iteration, period T.
    i  = Tbar;
    p00= squeeze(ptt(i,:,:)); 
    % Draw for beta ~ N(beta_tt,ptt)
    beta2(i,:) = beta_tt(i:i,:) + (wa(i:i,:)*chol(p00));
    % Var residuals
    % Restrictions state equation.
    if isempty(exo_rest) == 0
        temp = zeros(1,size(idx2,2));
        temp(1,idx1) = beta2(i:i,:);
        error(i,:) = Ybar(i,:) - Xbar(i,:)*reshape(temp,ny*p+nexo,ny);
        clear temp;
    else
        error(i,:) = Ybar(i,:) - Xbar(i,:)*reshape(beta2(i:i,:),ny*p+nexo,ny);
    end

    % Rest of backward iterations, from t-1..to .1
    i = Tbar-1;
    while i >= 1;
        pt = squeeze(ptt(i,:,:));
        % Update the filtered beta for information contained in beta[t+1], i.e. beta2(i+1:i+1,:) eq 8.16 pp193 in Kim Nelson
        bm = beta_tt(i:i,:) + (pt*F'*(F*pt*F'+Q)^(-1)*(beta2(i+1:i+1,:) - beta_tt(i,:)*F')')';
        % Update covariance of beta
        pm = pt - pt*F'*(F*pt*F' + Q)^(-1)*F*pt;

        % Checking pm matrix in burning sample and estimation smaple.
        chol_check = - 1;
        while chol_check < 0
            [~,temp] = chol(pm);
            if temp > 0 
                pm = eye(size(beta0,2))*0.000001+pm;
            else
                chol_check = 1;
            end
            clear temp
        end
        clear chol_check 

        % Draw for beta in period t from N(bm,pm)eq 8.17 pp193 in Kim Nelson
        beta2(i:i,:) = bm + (wa(i:i,:)*chol(pm));  
        % VAR residuals
        % Restrictions state equation.
        if isempty(exo_rest) == 0
            temp = zeros(1,size(idx2,2));
            temp(1,idx1) = beta2(i:i,:);
            error(i,:) = Ybar(i,:) - Xbar(i,:)*reshape(temp,ny*p+nexo,ny);
        else
            temp = beta2(i:i,:);
            error(i,:) = Ybar(i,:) - Xbar(i,:)*reshape(temp,ny*p+nexo,ny);
        end

        % Checking roots.
        % Getting companion form of the model.
        [~,temp] = F_comp(temp,ny,p,nexo);            
        if temp == -1
            i = 0;
            clear pt bm pm beta2 wa p00;
        else
            i = i - 1;
            % Terminal condition
            if i == 0
               scheck = 1; 
            end
        end
        clear temp;
    end
end
clear scheck;
% Saving results
St    = beta2;
y_res = error;
y_fit = Ybar - y_res;

% Computing the companion form.
function [F,check] = F_comp(Bdraw,nvar,p,nexo)
% Inputs:
% Bdraw  : Draw from beta.
% nvar   : Number of endogenous variables.
% p      : Lag order.
% nexo   : Number of deterministic and exogenous variables.
% Building B matrix.
Bdraw = reshape(Bdraw,nvar*p+nexo,nvar)';
% Getting companion form.
A = Bdraw(:,1:nvar*p);
if p == 1
    F = A;
elseif p > 1
    F = [A; [eye(nvar*(p-1)) zeros(nvar*(p-1),nvar)]];
end
temp = max(abs(eig(F)));
if temp < 1
    check = 1;
else
    check = -1;
end

% Identification structural shocks using a recursive identification scheme.
function [irf_all,A0_draws] = recursive(A0_draws,out1,nvar,p,nexo,J,hmax)
% A0_draws  : Draws form A0 matrix.
% out1      : Matrix with Betas draws.
% nvar      : Number of endogenous variables.
% p         : Lag order.
% nexo      : Number of deterministic and exogenous variables.
% J         : Selection matrix for IRF.
% hmax      : Max. horizon for IRF.

% Cholesky decomposition.
A0inv = A0_draws^(-1);
% Companion form of the model.
F_temp = F_comp(out1,nvar,p,nexo);

% IRF for each structural shock.
irf_all_temp(:,:,1) = (J*(F_temp^0)*J')*A0inv;
for h = 1:hmax
    irf_all_temp(:,:,h+1) = (J*(F_temp^h)*J')*A0inv;
end

% Bulding IRF.
for i0 = 1:nvar
    irf_all(:,:,i0) = squeeze(irf_all_temp(:,i0,:))';
end
A0_draws = 0;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
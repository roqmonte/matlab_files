function irf_med = PlotImpulseResponses_tvp(irf_tvp,info,fid,shock)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 6/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes IRF and confidence bands and plot results 
% using IRF(T|T).
% Inputs:
%   irf_tvp         : Draws Impulse responses of the structural model where 
%                     dim is: horizon, variable, shock, simulation, time.
%   info:
%   -.fsizes        : Font sizes to be used (1 x 2).
%   -.names         : Vector with labels of variables in the system.
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%   -.shock_names   : Shock labels.
%   fid             : Figure number id (optional).
%   shock           : Structural shock selection.
%
% Outputs:
%   irf_med         : TV Median IRF.
%
% Index:
% 1. Initial Setup.
% 2. Ploting IRF.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Initial Setup.
% Getting info from code
fsize       = info.fsizes(1);
names       = info.names;

% Shocks selection for charts
if size(shock,1)*size(shock,2) > 1
    error('Choose only one structural shock');
else
    irf = squeeze(irf_tvp(:,:,shock,:,:));
end
nvars = size(irf,2);

% Number of variables and graph setup.
if nvars <= 3
    k1 = 1; k2 = nvars;
elseif nvars <= 4
    k1 = 2; k2 = 2;
elseif nvars > 4 && nvars <= 6
    k1 = 3; k2 = 2;
elseif nvars > 6 && nvars <= 9
    k1 = 3; k2 = 3;
elseif nvars > 9 && nvars <= 16
    k1 = 4; k2 = 4;
elseif nvars > 17 && nvars <= 24
    k1 = 4; k2 = 6;
elseif nvars > 25 && nvars <= 30
    k1 = 5; k2 = 6;
elseif nvars > 30
    error('Max number of variables reached.');
end

% Plot impulse responses
if exist('fid','var') == 0
    fid = 30;
end

% Computing IRF closer to median.
Tbar = size(irf,4);
for i0 = 1:Tbar
    % Median IFR for the shock            
    irf_med(:,:,i0) = median(irf(:,:,:,i0),3);
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Ploting IRF.
% Dates
xTick      = info.dates_xTick;
xTickLabel = info.dates_label;
TT         = 1:xTick(end);
HH         = 0:size(irf,1)-1;

% Chart
figure(fid)
for i0 = 1:nvars
    subplot(k2,k1,i0)
    % Median IRFs
    temp1 = squeeze(irf_med(:,i0,:));
    matzr = zeros(size(temp1,1),xTick(end)-Tbar);
    % Surface chart
    mesh(TT,HH,[matzr temp1]);
    az = -142;
    el =   14;
    view(az,el);
    % Labels
%    ylabel('Impulse Horizon');
%    xlabel('Time');
    
    % Setting dates
    xlim([xTick(1) xTick(end)]);
    set(gca,'XTick',xTick);
    set(gca,'XTickLabel',xTickLabel);
    
    % Adjusting time frame for chart
    X_lim_temp = size(matzr,2)+1;
    xlim([X_lim_temp xTick(end)]);
    ylim([0 HH(end)]);
    % Title
    title(names(i0),'FontSize',fsize);
    clear j i temp;
end
% Title
temp = strcat('TV impulse response functions. Structural shocks_ :',info.shock_names(shock));
axes('Position',[0 0 1 1],'Visible','off');
text(0.39,0.975,temp,'FontSize',12','FontWeight','Bold');
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
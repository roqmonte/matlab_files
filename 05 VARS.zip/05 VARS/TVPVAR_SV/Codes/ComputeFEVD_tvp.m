function FEVD = ComputeFEVD_tvp(results,info,print,hor)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 6/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes the TV Forecast Error Variance Decomposition (FEVD)
% at the posterior median of the reduced form parameters, at a specific 
% forecast horizon.
% Inside variables "h" control FEVD horizon.
% Input:
%   results:
%   -.B_draws      : Draws from the reduced form parameters.
%   -.R_draws      : Draws R matrix var/cov observaion equation.
%   info:
%   -.p            : Lag order of the VAR.
%   -.names        : Labels variables in the VAR.
%   -.shock_names  : Shock labels.
%   -.fsizes       : Font sizes to be used (1 x 2).
%   -.dates_xTick  : Xtick for dates.
%   -.dates_label  : Labels for dates.
%   print          : Do graph and graph id (if print > 0); (0) no graph.
%   hor            : Horizon to report for FEVD, must be greater than 1.
%
% Output:
%   FEVD         : Forecast Error Variance Decomposition (hor,n,shock,time).
%
% Index.
% 1. Computing FEVD
% 2. Printing results
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Computing FEVD
% Getting info
nvars= size(results.Y,2);
p    = info.p;
nexo = size(results.X,2) - nvars*p;
J    = [eye(nvars) zeros(nvars,nvars*(p-1))];
fsize     = info.fsizes(1);
fsize_alt = info.fsizes(2);

% Waitbar
h_wait = waitbar(0,'Computing TV FEVD from posterior distribution, please wait...');

% Doing loop in time
Tbar = size(results.B_draws,1);
for i = 1:Tbar;
    R_draws = squeeze(results.R_draws(:,:,i,:));
    % Draws from posterior.
    for jj = 1:size(results.B_draws,3)
        % Building companion form
        Bdraw = reshape(results.B_draws(i,:,jj),nvars*p+nexo,nvars)';
        % Getting companion form.
        A = Bdraw(:,1:nvars*p);
        if p == 1
            F = A;
        elseif p > 1
            F = [A; [eye(nvars*(p-1)) zeros(nvars*(p-1),nvars)]];
        end
        % Computing posterior median for draws.
        A0inv = chol(R_draws(:,:,jj),'lower');
        clear Bdraw A;

        % Building IRF.    
        irf_all(:,:,1) = (J*(F^0)*J')*A0inv;
        for h = 1:12
            irf_all(:,:,h+1) = (J*(F^h)*J')*A0inv;
        end

        % Computing RMSE
        h    = 12;
        RMSE = zeros(1+h,nvars);
        aux  = zeros(nvars,nvars);
        for i0 = 1:1+h
            aux = aux + irf_all(:,:,i0)*irf_all(:,:,i0)';
            RMSE(i0,:) = diag(aux)';
        end
        clear aux;

        % Computing contribution to from each structual shock
        num = zeros(1+h,nvars,nvars);
        Iaux = eye(nvars,nvars);
        for i0 = 1:nvars
            temp_ek = Iaux(:,i0);
            for i1 = 1:nvars
                aux     = 0;
                temp_ej = Iaux(:,i1);
                for i2 = 1:1+h
                    aux = aux + (temp_ej'*irf_all(:,:,i2)*temp_ek)^(2);
                    num(i2,i0,i1) = aux;
                end        
            end
        end

        % Final results
        FEVD2 = zeros(1+h,nvars,nvars);
        for i0 = 1:nvars
            aux = (num(:,:,i0)./repmat(RMSE(:,i0),1,nvars))*100;
            FEVD2(:,:,i0) = aux;
        end
        clear aux num RMSE i0 i1 i2 A0inv F Iaux irf_all temp_ej temp_ek
        % Saving draws and updating waitbar
        FEVD3(:,:,:,jj) = FEVD2;   
        waitbar(i/Tbar,h_wait);
    end
    % Median FEVD
    for i0 = 1:nvars
       FEVDdd(:,:,i0,i) = mean(FEVD3(:,:,i0,:),4);
    end
end
close(h_wait);
% Choosing horizon in FEVD
if hor == 1
   hor =  2;
   display('Note: FEVD target horizon has been changed to 2, otherwise no variation in FEVD at Hor(1)');
end
for i = 1:Tbar
    FEVD(i,:,:) = FEVDdd(hor,:,:,i);
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Printing results

% Do graph.
vars = 1:nvars;
if exist('print','var') == 1
    if print > 0
        % Setup for subplot. Number of variables and graph setup.
        xTick     = info.dates_xTick;
        xTickLabel= info.dates_label;
        if nvars <= 3
            k1 = 1; k2 = nvars;
        elseif nvars <= 4
            k1 = 2; k2 = 2;
        elseif nvars > 4 && nvars <= 6
            k1 = 3; k2 = 2;
        elseif nvars > 6 && nvars <= 9
            k1 = 3; k2 = 3;
        elseif nvars > 9 && nvars <= 16
            k1 = 4; k2 = 4;
        elseif nvars > 16 && nvars <= 24
            k1 = 4; k2 = 6;
        elseif nvars > 24 && nvars <= 30
            k1 = 5; k2 = 6;
        elseif nvars > 30
            error('Max number of variables reached.');
        end
              
        % Building decomposition for each variable.
        figure(print)
        for i0 = 1:nvars
            subplot(k2,k1,i0)
            aux_0 = [NaN(info.dates_xTick(end)-Tbar,nvars); FEVD(:,:,vars(i0))];
            area(aux_0);
            title(info.names(vars(i0)),'FontSize',fsize);
            set(gca,'FontSize',fsize_alt);
            if size(results.Y,2) < 10
                legend1 = legend(info.shock_names);
                set(legend1,'FontSize',fsize_alt-2,'Orientation','vertical','Location','southeast','Box', 'on');
            else
                if i0 == nvars
                    legend1 = legend(info.shock_names);
                    set(legend1,'FontSize',fsize_alt-2,'Position',[0.95 0.59 0.0 0.25],'Orientation','vertical','Box', 'on');
                end
            end
            xlim([xTick(1) xTick(end)]);
            set(gca,'XTick',xTick);
            set(gca,'XTickLabel',xTickLabel);
            % Adjusting time frame for chart
            X_lim_temp = size(NaN(info.dates_xTick(end)-Tbar,nvars),1) + 1;
            xlim([X_lim_temp xTick(end)]);
            ylim([0 100]);
        end
        axes('Position',[0 0 1 1],'Visible','off');
        text(0.35,0.975,(['TV Forecast Error Variance Decomposition at forecast horizon (' num2str(hor) ')']),'FontSize',12','FontWeight','Bold');
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
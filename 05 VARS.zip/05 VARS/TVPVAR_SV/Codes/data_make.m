function [data,info,determ] = data_make(data_ini,info,cte,trend,exo)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 6/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Generates data for VAR model.
% Input:
%   data_ini        : Matriz with all data.
%   info:
%   -.px            : Lag order exo variables.
%   -.presmaple     : Controls sample size of pre-sample data.
%   -.endo_names    : Labels for endo variables.
%   -.names         : Labels variables in the VAR.
%   -.shock_names   : Shock labels.
%   -.dates_ini     : Setting for dates: (year,month,freq).
%                     Where, freq: (1) monthly;(2) quaterly data.
%   cte             : (0) No constant; (1) Constant (default).
%   trend           : (0) No trend (default); (1) linear trend; (2) quadratic trend.
%   exo             : Exogenous variables of the model.
%
% Output:
%   data:
%   -.all           : All data.
%   -.endo          : Data VAR.
%   -.prior_endo    : Pre sample data endo variables.
%   -.prior_all     : Pre sample data all variables.
%   -.prior_determ  : Pre sample data determ variables.
%   info:
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%   -.determ_cte    : Contant term.
%   -.determ_trend  : Linear trend.
%   -.determ_trend2 : Quadratic term.
%   -.determ_exo    : Exogebous variable.
%   -.px            : Lag order exo variables.
%   determ          : Constant term, trends and exo variables for VAR.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Checking exo variables
if exist('exo','var') == 0
    exo = [];
    px = 0;
else
    px = info.px*(1-isempty(exo));
end

% Getting inputs
var_names  = info.labels_all;
endo_names = info.endo_names;
nvar       = length(endo_names);
% Locate positions of variables.
for i = 1:nvar
    pos_endo(i) = loc(char(var_names),char(endo_names(i)));
end;
% Results.
data.endo  = data_ini(1+px:end,pos_endo);
data.all   = data_ini(1+px:end,pos_endo);
% Labels for variables.
if isfield(info,'names') == 0
    info.names = var_names(pos_endo);
end
% Labels for shocks.
aux_t1 = {'Shock '}; aux_t2 = {};
for i0 = 1:nvar
    aux_t2 = [aux_t2 strcat(aux_t1,num2str(i0))];
end
% Checking consistency for shocks labels
if isfield(info,'shock_names') == 0
    info.shock_names = aux_t2;
else
    if size(info.shock_names,2) < nvar
        info.shock_names = [info.shock_names aux_t2(:,size(info.shock_names,2)+1:end)];
    end
end
clear aux_t1 aux_t2 i0;

% Building exo variables.
% Constant term
if cte == 0
    info.determ_cte = [];
elseif cte == 1
    info.determ_cte = ones(size(data_ini,1),1);    
else
   error('Check cte variable'); 
end
% Trends
if trend == 0
    info.determ_trend = [];
    info.determ_trend2= [];
elseif trend == 1
    info.determ_trend = (1:size(data_ini,1))';
    info.determ_trend2= [];
elseif trend == 2
    info.determ_trend = (1:size(data_ini,1))';
    info.determ_trend2= ((1:size(data_ini,1)).^(2))';
else
   error('Check trend variable'); 
end
% Exo variables.
if size(exo,2) == 0 
    info.determ_exo = [];
elseif size(exo,2) > 0
    exo2 = LagN(exo,px);
    info.determ_exo = exo2;
end
% Deterministic variables.
determ = [info.determ_cte(1+px:end) info.determ_trend(1+px:end) info.determ_trend2(1+px:end) info.determ_exo];

% Generating dates.
T = length(data_ini);
if info.dates_ini(end) == 1
	freq = 'm';
elseif info.dates_ini(end) == 2
	freq = 'q';
end
[time1,time2] = calendar(info.dates_ini(1),info.dates_ini(2),T,freq);
info.dates_xTick = time1;
info.dates_label = time2;
info.px    = px;

% Building final data
if info.presample > 0
    data.prior_endo   = data.endo(1:info.presample,:);
    data.prior_all    = data.all(1:info.presample,:);
    data.prior_determ = determ(1:info.presample,:);
else
    error('Check pre-sample data configuration');
end
% Data
data.endo = data.endo(info.presample+1:end,:);
data.all  = data.all(info.presample+1:end,:);
determ    = determ(info.presample+1:end,:);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
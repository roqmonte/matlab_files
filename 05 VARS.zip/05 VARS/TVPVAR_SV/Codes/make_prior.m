function prior = make_prior(data_model,info)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 03/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Funtion generates priors for TVVAR with SV model.
% Inputs:
%   data::
%   -.all           : All data (both groups).
%   -.endo          : Data VAR model.
%   info:
%   -.p             : Lag order.
%   -.presample     : Presample data for prior.
%   -.kQ            : Scale parameter for Q matrix.
%
% Outputs:
%   prior:
%   -.Aind          : Indicators variables for aij elements of A matrix.
%   -.TS            : Degrees of freedom for S.
%   -.Bpr           : Prior for B.
%   -.VBpr          : Prior for cov(B).
%   -.Qpr           : Prior for Q matrix.
%   -.Apr           : Prior for A elements of A mtrix.
%   -.VApr          : Prior for cov(A(t))elements of A mtrix.
%   -.HApr          : Prior for H(t).
%   -.VHApr         : Prior for cov H(t).
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Setup of the code.
% Data for prior 
data_p = data_model.prior_all;
exo    = data_model.prior_determ; 

% Model estiation.
res_var = EstimateVAR(data_p,info.p,exo);
% Output from model.
y0  = res_var.Y;
x0  = res_var.X;

% Number of variables, states and lower-triangular elements
ny = size(y0,2);
nB = size(x0,2)*ny;
nA = ny*(ny-1)/2;
T0 = info.presample;

% Index for elements off diaganol of A(t).
Atemp = zeros(ny,ny);
j = 1;
for i0 = 1:ny
    for i1 = 1:ny
        Atemp(i0,i1) = j;
        j = j + 1;
    end
end
% Id variables for aij elements
Aind = [];
j = 1;
for i0 = 2:ny
    temp = Atemp(i0,1:j);
    Aind = [Aind temp];
    j = j + 1;
end
clear j i0 i1;

% Priors for B(t) and cov(B(t)) by OLS
Bpr  = [res_var.F(1:ny,:)'; res_var.C'];
r0   = res_var.resid;
% Final sample size training sample.
T0   = size(r0,1);
Om0  = (r0'*r0)/T0;%res_var.Sig;
VBpr = kron(Om0,eye(nB/ny)/(x0'*x0));
Qpr  = T0*VBpr*info.kQ^2;

% Priors for A(t) by OLS on residuals
% use Primiceri formula: A(t)*Omega(t)*A(t)'=Sigma(t)*Sigma(t)'
% LHS variable in A(t) regression
yA   = reshape(r0,T0*ny,1); 
aux  = kron(eye(ny),r0);
% RHS variable in A(t) regression
xA   = aux(:,Aind);
% Prior for A(t)
Apr  = (xA'*xA)\xA'*yA;
% Prior covariance matrix of A(t)
eA   = reshape(yA - xA*Apr,T0,ny);
OmA  = (eA'*eA)/T0;
VAx  = (xA'*xA)\xA'*(kron(OmA,eye(T0)))*xA/(xA'*xA);
VApr = zeros(nA);
m    = 1;
for j=1:ny-1
    VApr(m:m+j-1, m:m+j-1) = VAx(m:m+j-1, m:m+j-1);
    m = m + j;
end

% Priors for H(t) and covariance matrix of H(t)
Rpr  = diag(eA'*eA/length(eA));
Hpr  = 0.5*log(Rpr);

VHpr = eye(ny);

% Indicators variables for aij elements of A matrix.
prior.Aind  = Aind;
% Degrees of freedom for S.
prior.TS      = 2:ny;
% Saving prios for B(t) and cov(B(t)) by OLS.
prior.Bpr  = Bpr;
prior.VBpr = VBpr;
prior.Qpr  = Qpr;
% Saving prios for A(t) and cov(A(t)) by OLS.
prior.Apr  = Apr;
prior.VApr = VApr;
% Saving priors for H(t) and cov(H(t)).
prior.Hpr  = Hpr;
prior.VHpr = VHpr;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
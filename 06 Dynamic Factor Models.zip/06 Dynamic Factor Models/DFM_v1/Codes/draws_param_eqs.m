function [b0,s20,phi1,facts] = draws_param_eqs(y,p,ChibGren,prior,b0,s20,phi0,id,fac_id,facts,check)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 10/May/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Function draws loadings and AR terms from the observable 
% equation and idiosincratic component, conditional on factors. The code 
% also checks sign factors for factor identification.
% Inputs:
%   y               : Data, column vector.
%   p               : # of AR lags to include in each observable equation.
%   ChibGren        : (1) Do Chib and Greenberg when sampling ar terms (Default).
%   prior:
%   -.b0_           : Priors for observable equations in factor model.
%   -.B0__          : Prior precision of factor loading.
%   -.r0_           : Prior mean of phi (idiosyncratic AR polynomial).
%   -.R0__          : Prior mean precision of phi (idiosyncratic AR polynomial)
%   -.v0_           : Inv. gamma param. for innovation variances R, integer.
%   -.d0_           : Inv. gamma param. for innovation variances R.
%   b0              : Starting value for loadings.
%   s20             : Starting value for Sg2 residuals.
%   phi0            : Starting value AR coeff idiosincratic term of the model.
%   id              : id variable in panel data.
%   fac_id          : Factor id.
%   facts           : Factors.
%   check           : If 1, then checks loadings signs identification.
%
% Outputs:
%   b0              : Draw loadings.
%   s20             : Draw Sg2 term observable equation.
%   phi1            : Draw AR coeff, idiosincratic term of observable equation.
%   facts           : Sign adjusted factors.
%
% Index:
% 1. Smapling AR terms.
% 2. Finctions
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Smapling AR terms.
% Getting priors.
b0_  = prior.b0_;
B0__ = prior.B0__;
r0_  = prior.r0_;
R0__ = prior.R0__;
v0_  = prior.v0_;
d0_  = prior.d0_; 

% Sample size
n    = size(y,1);
% # of regressors in each observable equation, constant plus factors.
nreg = size(b0,1);
% Factors plus constant term for observable equation.
x = [ones(n,1) facts(:,1) facts(:,fac_id)]; 

% Terminal conditions for sign factor identification.
signbeta1 = 1;
signbeta2 = 0;
% Setting counters for discarded draws form posterior.
signmax1  = 1;
signmax2  = 1;
% Max draws to get right sign for factor sign loading identification.
win = 100;

% Gibbs Sampling.
while ge(signbeta1+signbeta2,1)
    % Keeping first p observations.
    yp = y(1:p,1);
    xp = x(1:p,:);
    % Residuals and lagged residuals.
    e    = y - x*b0;
    temp = LagN(e,p);
    e1   = temp(:,1);
    ecap = temp(:,2:end);
    clear temp;
    
    % Candidate draw AR coeff from idiosincratirm term of the model.
    V      = (R0__ + s20^(-1)*(ecap'*ecap))^(-1);
    phihat = V*(R0__*r0_ + s20^(-1)*ecap'*e1);
    phi1   = phihat + chol(V)'*randn(p,1);
    
    % Checking if no arterms in the model.
    if isempty(phi1) == 0
        % Check stationarity and Pb of acceptance for candidate draw.
        coef = [-rev(phi1); 1];
        root = roots(coef');
        rootmod = abs(root);
        scheck = ge(min(rootmod),1.001);
        if scheck == 0
            phi1 = phi0;
        elseif scheck == 1
            % Numerator of acceptance prob
            sigma1  = sigmat(phi1,p);
            sigroot = chol(sigma1);
            p1   = inv(sigroot)';
            ypst = p1*yp;
            xpst = p1*xp;
            d    = det(p1'*p1);
            psi1 = (d^(1/2))*exp(-0.5*(ypst-xpst*b0)'*(ypst-xpst*b0)/s20);

            % Denominator of acceptance prob
            sigma1  = sigmat(phi0,p);
            sigroot = chol(sigma1);
            p1   = inv(sigroot)';
            ypst = p1*yp;
            xpst = p1*xp;
            d    = det(p1'*p1);
            psi0 = (d^(1/2))*exp(-0.5*(ypst-xpst*b0)'*(ypst-xpst*b0)/s20);

            % Condition to accept draws from posterior.
            if psi0 == 0 
                accept = 1;
            else
                u = rand(1,1)*ChibGren;
                accept = le(u, psi1/psi0);
            end
            % Draw AR terms obserbvable equation.
            phi1 = phi1*accept + phi0*(1-accept);
        end
    end
    
    % Using updated draw AR coeff of idiosincratic term of the mdoel.
    sigma   = sigmat(phi1,p);
    sigroot = chol(sigma);
    p1   = inv(sigroot)';
    ypst = p1*yp;
    xpst = p1*xp;
    yst  = [ypst; gendiff(y,phi1)];
    xst  = [xpst; gendiff(x,phi1)];
    
    % Draw loading (beta observable equation).
    V    = (B0__ + s20^(-1)*(xst'*xst))^(-1);
    bhat = V*(B0__*b0_ + s20^(-1)*xst'*yst);
    b1   = bhat + chol(V)'*randn(nreg,1);
    
    % Checking conditions on factors loadings. Turn off "signbeta" varrs.
    % Global factor, (+) loading on first panel variable.
    signbeta1 = le(b1(2,1),0.0)*(id == 1);
    signmax1  = signmax1 + (1*signbeta1);
    % Block factor, (+) loading on first block variable.
    signbeta2 = le(b1(3,1),0.0)*(check);
    signmax2  = signmax2 + (1*signbeta2);
    
    % Counting # draws to get right sign for factor sign loading identification, 
    % if draws # greater or equal to "win", then change factor sign and
    % store updated factor.
    % Global factor.
    if ge(signmax1,win)
        facts(:,1) = (-1)*facts(:,1);
        x(:,2)     = facts(:,1);
        signmax1   = 1;
    end
    % Block factor.
    if ge(signmax2,win)
        facts(:,fac_id) = (-1)*facts(:,fac_id);
        x(:,3)       = facts(:,fac_id);
        signmax2     = 1;
    end
end

% Sigma2 Draw from posterior.
nn  = n + v0_;
% Residual observation equation.
d   = d0_ + (yst-xst*b1)'*(yst-xst*b1);
c   = rnchisq(nn);
t2  = c/d;
s21 = 1/t2;
% Loadings and Sg2 draws.
b0  = b1;
s20 = s21;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Functions.

% Function computes stationary covariance matrix.
function sigma = sigmat(phi,p)
r2 = p^2;
i  = [eye(p-1) zeros(p-1,1)];
Pcap = [phi'; i];
pp   = eye(r2) - kron(Pcap,Pcap);
e1   = [1; zeros(p-1,1)];
sig  = (pp)^(-1)*vec(e1*e1');
sigma= (reshape(sig',p,p)')';

% Function do data (matrix) differentiation.
function zgdiff = gendiff(z,phi)
p      = size(phi,1);
ztrim  = z(p+1:end,:);
zgdiff = ztrim;
for i = 1 : p
    zgdiff = zgdiff - phi(i,1)*trimr(z,p-i,i);
end

% Draw random number from Xi-square distribution.
function g = rnchisq(m)  % m is an integer
v = m/2;
if (round(v)-v) == 0
    g = -2*sum(log(rand(v,1)),1);
else
    v = (m-1)/2;
    g = -2*sum(log(rand(v,1)),1) + randn(1,1)^2;
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function z = trimr(x, n1, n2)
% Purpose: return a matrix(or a vector) x stripped of 
%          the specified rows
% ------------------------------------------------------
% Usage: z = trimr(x, n1, n2)
% where: x = input matrix (or vector)
%        n1 = first n1 rows to strip
%        n2 = last n2 rows to strip
% ------------------------------------------------------
% Returns: z = x(n1+1:n-n2,:)
% ------------------------------------------------------
% Note: This function is compatible with Gauss function
%       'trimr'
% Reference: LeSage, James and R. Kelley Pace(2009) 
%            "Introduction to Spatial Econometrics,"
%            CRC Press, 
%            http://www.spatial-econometrics.com/util/
% ------------------------------------------------------
[n junk] = size (x);
if (n1+n2) >= n
    error('Attempting to trim too much in trimr');
end

h1 = n1 + 1;
h2 = n - n2;
z = x(h1:h2,:);
return
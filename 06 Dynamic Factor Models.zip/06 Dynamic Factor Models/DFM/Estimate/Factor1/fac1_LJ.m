% fac1.prg
% by Christopher Otrok
%
% Model: 1 factor for all variables (world) 
% Idiosyncratic dynamics are modelled as independent AR processes
%
% % Changing the working directory
% % cd('C:/Users/muwizayeon/1213_RA/model1_matlab/');
% cd('C:\hkfiles\statespace\sep2014\mod1SSMH/');

function [meanz,results,etime] = fac1_LJ(data,priorsIN)

% clc;   % clear Command window
% clear; % removes all from the workspace(releasing system memory)
stime = cputime; % start to check elapsed CPU time (seconds)

% Set parameters of model
global nfact capt counter metcount arlag nreg Size m sigU % declaration of global variables

y           = data;
[capt,nvar] = size(y);        %nvar = number of variables including the variable with missing date
                              %capt = length of data of complete dataset
                              
ndraws = 1000;         % number of monte carlo draws
burnin = 50;           % number of initial draws to discard, total draws is undrws+burnin
% nfact = 1;           % number of factors to estimate, 1 common plus ? factors, 1 for each subset of variables
% arlag = 3;           % autoregressive lags in the dynamic factors
% arterms = arlag-1;   % number of AR lags to include in each observable equation, set equals to ARLAG-1 for convenience (or convince)
% nreg = 2;            % number of regressors in each observable equation, constant plus factors
% capt = 200;          % length of data to load in
% nvar = 21; % total number of observable variables
% m = nfact*arlag;

nfact   = priorsIN.K;           %number of factors to estimate
arlag   = priorsIN.Plags;       %autoregressive lags in the dynamic factors 
% arterms = arlag-1;            % number of AR lags to include in each observable equation, set equals to ARLAG-1 for convenience)
arterms = priorsIN.Llags;       % number of AR lags to include in each observable equation
Size    = nvar;                 %number of variables each factor loads on
nreg    = 1+priorsIN.K;         %number of regressors in each observable equation, constant plus K factors       
m       = nfact * arlag;        %dimension of state vector


% % load data
% load('NewG7dat.txt','ascii');
% ytemp = NewG7dat;
% y = (log(ytemp(2:capt,:)) - log(ytemp(1:capt-1,:)))*100;
% ytemp = y;
% 
% y = ytemp - repmat(mean(ytemp),[capt-1 1]);
% 
% % resort, now have C,I,Y, want Y,C,I
% for i = 1 : nfact-1;
%     y(:,((i-1)*Size+1):i*Size) = [y(:,i*Size) y(:,((i-1)*Size+1)) y(:,((i-1)*Size+2))];
% end

ytemp = y;
y     = ytemp - repmat(mean(ytemp),[capt 1]);

% set up some matricies for storage (optional)
Xtsave      = zeros(rows(y)-arterms, (ndraws+burnin)*nfact);     %just keep draw of factor, not all states (others are trivial)
bsave       = zeros(ndraws+burnin, nreg*nvar);                   %observable equation regression coefficients
ssave       = zeros(ndraws+burnin, nvar);                        %innovation variances
psave       = zeros(ndraws+burnin, nfact*arlag);                 %factor autoregressive polynomials
psave2      = zeros(ndraws+burnin, nvar*arterms);                %factor autoregressive polynomials
vdecomW2    = zeros(ndraws+burnin, nvar);
vdecomI2    = zeros(ndraws+burnin, nvar);
vdecomW1    = zeros(ndraws+burnin, nvar);
vdecomI1    = zeros(ndraws+burnin, nvar);
counter     = zeros(nfact,1);                                    %number of nonstationary draws
metcount    = zeros(nfact,1);                                    %number of accepted draws in AR proc

% include a necessary procedure
priors;

% Initialize and set up factor model
A       = zeros(nvar,1);           % Dimension some matricies for State Space model
H       = zeros(nvar,m);
SigE    = ones(nvar,1)*0.0001;
phi     = zeros(arlag,nfact);
bold    = zeros(nvar,nreg);        %starting value for regression coefficients
phimat0 = zeros(arterms,nvar);     %observable equation AR coefficients
% capt = rows(y);                  %if including idiosyncratic dynamics condition on lags for quasi-differencing

if arterms > 0
    Ylagmat = zeros(capt - arterms, nvar*arterms);
    i=1;
    j=1;
    while i <= nvar
        ii = 1;
        while ii <= arterms
            Ylagmat(:,j) = y(arterms-ii+1:capt-ii, i);
            ii = ii+1;
            j = j+1;
        end
        i = i+1;
    end
    y = y(arterms+1:capt,:);
end
capt = rows(y);

facts = randn(capt,nfact);     %random starting factor
facts(:,1) = mean(y,2)';

% for i = 1 : nfact-1
%     facts(:,i+1) = mean(y(:,((i-1)*Size)+1:i*Size),2)';
% end
ystar = y;   %just dimensioning for later

% Begin Monte Carlo Loop
%dr = 1;
for dr = 1 : ndraws+burnin
%     str = sprintf('sample, draw %d',dr);
%     disp(str); 
    nf=1;
    %i = 1;
    for i = 1 : nvar
        
        % call arobs to draw observable coefficients
        xft = [ones(capt,1) facts(:,1)];  

        [b1,s21,phi1,facts] = ar(y(:,i),xft,arterms,b0_,B0__,r0_,R0__,v0_,d0_,bold(i,:)',SigE(i),phimat0(:,i),i,nf,facts);
        bold(i,1:nreg) = b1';
        phimat0(:,i) = phi1;
        SigE(i) = s21;
        bsave(dr,((i-1)*nreg)+1:i*nreg) = b1';
        ssave(dr,i) = s21;
        psave2(dr,((i-1)*arterms)+1:i*arterms) = phi1';
        
        % set up matricies in state space model
        A(i,1) = b1(1)*(1-sum(phi1,1));
        H(i,((1-1)*arlag)+1:1*arlag) = b1(2)*[1 ((-1)*phi1)'];
        
        %variance decomp 1 (based on parameters)
        companion = [phi(:,1)' ; eye(arlag-1) zeros(arlag-1,1)];
        vtemp = 1*(inv(eye(arlag^2)-kron(companion,companion)));
        tvarW = vtemp(1);
        companion = [phi1' ; eye(arterms-1) zeros(arterms-1,1)];
        vtemp = s21*(inv(eye(arterms^2)-kron(companion,companion)));
        tvarI = vtemp(1);
        tvarD=((b1(2)^2)*tvarW)+tvarI;
        vdecomW1(dr,i) = ((b1(2)^2)*tvarW)/tvarD;
        vdecomI1(dr,i) = tvarI/tvarD;
        
        % variance decomp 2
        varag = std(y(:,i))^2;
        vdecomW2(dr,i) = ((b1(2)^2)*(std(facts(:,1))^2))/varag;
        vdecomI2(dr,i) = 1 - vdecomW2(dr,i);
        
        % set up matrix of quasi-differenced observable variables 
        if ge(arterms,1)
%             ystar(:,i) = y(:,i) - sum((repmat(phi1',[rows(Ylagmat) 1]).*Ylagmat(:,((i-1)*arterms)+1:(i*arterms))),2)';
            ystar(:,i) = y(:,i) - sum((repmat(phi1',[rows(Ylagmat) 1]).*Ylagmat(:,((i-1)*arterms)+1:(i*arterms))),2);
        else
            ystar(:,i) = y(:,i);
        end
    end %end of loop for drawing the coefficients for each observable equation
    
    scheck = 0;
    while scheck == 0; %stationarity check
        
     % draw factor AR coefficients
   
    F=zeros(m,m);
    j = 1;
    i = 1;
        phi(:,i) = arfac(facts(:,i),arlag,r0f_,R0f__,phi(:,i),i,sigU(j,1));        
        F(j:j+arlag-1,j:j+arlag-1) = [(phi(:,i)'); [eye(arlag-1), zeros(arlag-1,1)]];
        psave(dr,(i-1)*arlag+1:(i-1)*arlag+arlag)=phi(:,i)';
   

        meigsF = max(abs(eig(F)));
      
       scheck = 1;
        
        if ge(meigsF,0.99)
            scheck = 0;
%             str2 = sprintf('failed stationarity %f',meigsF);
%             disp(str2);
        end
    end
    
    BsigU = diagrv(zeros(m,m),sigU);
    BsigE = diagrv(zeros(nvar,nvar),SigE);
    [Xtgt, Stgt] = kfilter(ystar',F,H',BsigU,BsigE,ones(capt,1)',A');
    Xt = ckohn(Stgt,Xtgt,facts,F);  
    
    for i = 1 : nfact
        Xtsave(:,((dr-1)*nfact)+i) = Xt(:,1+arlag*(i-1));
        facts(:,i) = Xt(:,1+arlag*(i-1));
    end
end

% save results

Xtsave = Xtsave(:,(burnin*nfact)+1:(burnin+ndraws)*nfact);
bsave = bsave(burnin+1:burnin+ndraws,:);
ssave = ssave(burnin+1:burnin+ndraws,:);
psave = psave(burnin+1:burnin+ndraws,:);
psave2 = psave2(burnin+1:burnin+ndraws,:);
vdecomW1 = vdecomW1(burnin+1:burnin+ndraws,:);
vdecomI1 = vdecomI1(burnin+1:burnin+ndraws,:);
vdecomW2 = vdecomW2(burnin+1:burnin+ndraws,:);
vdecomI2 = vdecomI2(burnin+1:burnin+ndraws,:);

Xtsort       = sort(Xtsave,2);
results.Xt05 = Xtsort(:,round(0.05*ndraws));
results.Xt16 = Xtsort(:,round(0.16*ndraws));
results.Xt50 = Xtsort(:,round(0.50*ndraws));
results.Xt84 = Xtsort(:,round(0.84*ndraws));
results.Xt95 = Xtsort(:,round(0.95*ndraws));

results.Xt  = Xtsave;
results.B   = bsave;
results.S   = ssave;
results.P   = psave;
results.P2  = psave2;

results.VDW1 = vdecomW1;
results.VDI1 = vdecomI1;
results.VDW2 = vdecomW2;
results.VDI2 = vdecomI2;

meanz.F   = mean(Xtsave,2);
meanz.B   = mean(bsave,1);
meanz.S   = mean(ssave,1);
meanz.P   = mean(psave,1);
meanz.P2  = mean(psave2,1);

meanz.VDW1 = mean(vdecomW1,1);
meanz.VDI1 = mean(vdecomI1,1);
meanz.VDW2 = mean(vdecomW2,1);
meanz.VDI2 = mean(vdecomI2,1);

% save('C:\hkfiles\statespace\sep2014\mod1SSMH/Xtsave.mat','Xtsave');
% save('C:\hkfiles\statespace\sep2014\mod1SSMH/bsave.mat','bsave');
% save('C:\hkfiles\statespace\sep2014\mod1SSMH/ssave.mat','ssave');
% save('C:\hkfiles\statespace\sep2014\mod1SSMH/psave.mat','psave');
% save('C:\hkfiles\statespace\sep2014\mod1SSMH/psave2.mat','psave2');
% save('C:\hkfiles\statespace\sep2014\mod1SSMH/vdecomW.mat','vdecomW');
% save('C:\hkfiles\statespace\sep2014\mod1SSMH/vdecomI.mat','vdecomI');

etime = cputime - stime; % end of time
% strtime = sprintf('Elapsed CPU time %f',etime);
% disp(strtime);

            
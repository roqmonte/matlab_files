function xinv = invpd(x)
% Purpose: inverse matrix using augmented eigenvalues for
%          non positive definite case
% ------------------------------------------------------
% Usage: xinv = invpd(x)
% where: x = input matrix
% ------------------------------------------------------
% Returns: xinv = inverse matrix
% ------------------------------------------------------
% Note: In the reference, the function returns inverse
%       matrix even if input matrix is non-positive
%       using augmented egenvalues.
%       However, in order to be compatible with Gauss
%       'invpd' function, I add 'error' statement on
%       the line 35. 
% Reference: LeSage, James and R. Kelley Pace(2009) 
%            "Introduction to Spatial Econometrics,"
%            CRC Press, 
%            http://www.spatial-econometrics.com/util/
% ------------------------------------------------------
if isposdef(x)     % test a matrix for positive definiteness, using cholesky
    xinv = inv(x);
    flag = 0;
else
    flag = 1;
    [n, m] = size(x);
    [u,d,v] = svd(x);
    dd = diag(d);
    xchk = u*diag(dd)*v';
    dd = dd + 1000*eps;   % eps is a Floating-point  relative accuracy
    di = ones(n,1)./dd;
    xinv = u*diag(di)*v;
end
if flag == 1
    error('matrix is not positive definite');
end
end
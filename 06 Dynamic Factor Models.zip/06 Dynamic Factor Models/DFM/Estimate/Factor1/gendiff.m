function zgdiff = gendiff(z, phi)
p = rows(phi);
ztrim = trimr(z,p,0);
zgdiff = ztrim;
for i = 1 : p
    zgdiff = zgdiff - phi(i,1)*trimr(z,p-i,i);
end
return
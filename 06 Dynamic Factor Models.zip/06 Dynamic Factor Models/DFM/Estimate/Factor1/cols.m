function num_cols = cols(x)
% Purpose: return columns in a matrix x
% --------------------------------------
% Usage: num_cols = cols(x)
% where: x is a matrix
% --------------------------------------
% Returns: num_cols = # of columns of x
% --------------------------------------
    [m, n] = size(x);
    num_cols = n;
    return
end

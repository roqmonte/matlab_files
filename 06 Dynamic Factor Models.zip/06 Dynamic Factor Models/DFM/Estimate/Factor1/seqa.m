function seq=seqa(a, b, c)
% Purpose: produce a sequence of values
% ------------------------------------------------------
% Usage: seq = seqa(a, b, c)
% where: a = initial value of sequence
%        b = increment
%        c = number of values in the sequence
% ------------------------------------------------------
% Returns: seq = a sequence
% ------------------------------------------------------
% Note: This function is compatible with Gauss function
%       'seqa'
% Reference: LeSage, James and R. Kelley Pace(2009) 
%            "Introduction to Spatial Econometrics,"
%            CRC Press, 
%            http://www.spatial-econometrics.com/util/
% ------------------------------------------------------
    seq = (a:b:(a+b*(c-1)))';
return
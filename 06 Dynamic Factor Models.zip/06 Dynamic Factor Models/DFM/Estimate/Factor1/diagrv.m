function diagm = diagrv(X,V)
% Purpose: replaces main diagonal of a square matrix
% ------------------------------------------------------
% Usage: diagm = diagrv(X, V)
% where: x = input matrix
%        v = vector to replace main diagonal
% ------------------------------------------------------
% Returns: diagm = matrix x with v main diagonal
% ------------------------------------------------------
% Note: This function is compatible with Gauss
%       'diagrv' function
% Reference: LeSage, James and R. Kelley Pace(2009) 
%            "Introduction to Spatial Econometrics,"
%            CRC Press, 
%            http://www.spatial-econometrics.com/util/
% ------------------------------------------------------              
[row,col] = size(X);
if row ~= col
    error('X matrix is not square')
end
if length(V) ~= row
    error('V vector is not comfortable with X')
end
diagm = X - diag(diag(X)) + diag(V);
return
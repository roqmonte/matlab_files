% ckohn.m
% Latest version: 3/9/2005
% use Carter-Kohn procedure to draw factors
%
% transfered by Meongsu Lee
%

function Xt = ckohn(Stgt,Xtgt,facts,F)

global capt m nfact arlag sigU

Xt = zeros(capt,m);

% Draw X(T) from N(Xtgt, Stgt) for t = T
Stgt2 = Stgt(1:m,((capt-1)*m)+1:((capt-1)*m)+m);
Xt(capt,:) = (Xtgt(capt,:)'+(chol(Stgt2)'*randn(m,1)))';

% Build up mean/variance of state vector
t = capt - 1;

while ge(t,1)
    Xtgt2 = Xtgt(t,:)';
    Stgt2 = Stgt(1:m,((t-1)*m)+1:((t-1)*m)+m);
    
    i = 1;
    while le(i, m)
        Ei = Xt(t+1,i)'-F(i,:)*Xtgt2;
        Ri = F(i,:)*Stgt2*F(i,:)' + sigU(i);
        Xtgt2 = Xtgt2 + (Stgt2*F(i,:)'*Ei)/Ri;
        Stgt2 = Stgt2 - (Stgt2*F(i,:)'*F(i,:)*Stgt2)/Ri;
        i = i + 1;
    end
    
    stemp = zeros(nfact, nfact);
    xtemp = zeros(nfact, 1);
    i = 1; 
    j = arlag;
    while le(i,nfact)
        xtemp(i,1) = Xtgt2(j);
        stemp(i,i) = Stgt2(j,j);  %variance terms
        ii = i + 1;
        jj = 1;
        while le(ii, nfact)       %covariance terms
            stemp(ii,i) = Stgt2(j+jj*arlag,j);
            stemp(i,ii) = stemp(ii,i);
            ii = ii + 1;
            jj = jj + 1;
        end
        i = i + 1;
        j = j + arlag;
    end
    
    xtemp = xtemp + (chol(stemp)'*randn(nfact,1));
    
    i = 1;
    while le(i,m)
        Xt(t,i) = Xtgt2(i);
        if (i/arlag) == fix(i/arlag)
            Xt(t,i) = xtemp((i/arlag));
        end
        i = i + 1;
    end
    t = t - 1;
end
return
end
function y = vec(x)
% Purpose: creates a column vector by stacking columns 
%          of x
% ------------------------------------------------------
% Usage: y = vec(x)
% where: x = input matrix
% ------------------------------------------------------
% Returns: y = a vector containing stacked columns of x
% ------------------------------------------------------
% Note: This function is compatible with Gauss function
%       'vec'
% Reference: LeSage, James and R. Kelley Pace(2009) 
%            "Introduction to Spatial Econometrics,"
%            CRC Press, 
%            http://www.spatial-econometrics.com/util/
% ------------------------------------------------------
y = x(:);
return
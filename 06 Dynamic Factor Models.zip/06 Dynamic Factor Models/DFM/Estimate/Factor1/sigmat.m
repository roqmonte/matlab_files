% the (stationary) covariance matrix of yp

function sigma = sigmat(phi, p)
   r2 = p^2;
   i = [eye(p-1) zeros(p-1,1)];
   Pcap = [phi'; i];
   pp = eye(r2) - kron(Pcap,Pcap);
   e1 = [1; zeros(p-1,1)];
   sig = inv(pp)*vec(e1*e1');
   sigma = (reshape(sig',p,p)')';
return



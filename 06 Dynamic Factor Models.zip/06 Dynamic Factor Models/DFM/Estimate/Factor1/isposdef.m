function ans = isposdef(a)
% Purpose: test a matrix for positive definiteness, 
%          using cholesky decomposition.
% ------------------------------------------------------
% Usage: ans = isposdef(a)
% where: a = input matrix
% ------------------------------------------------------
% Returns: ans = 1 (positive definite)
%              = 0 (non-positive definite)
% ------------------------------------------------------
% Reference: LeSage, James and R. Kelley Pace(2009) 
%            "Introduction to Spatial Econometrics,"
%            CRC Press, 
%            http://www.spatial-econometrics.com/util/
% ------------------------------------------------------
[R, p] = chol(a);
ans = (p == 0);
end
function num_rows = rows(x)
% Purpose: return rows in a matrix x
% --------------------------------------
% Usage: num_rows = rows(x)
% where: x is a matrix
% --------------------------------------
% Returns: num_cols = # of rows of x
% --------------------------------------
[m, n] = size(x);
num_rows = m;
return
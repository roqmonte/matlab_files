% function ret = rev(x)
%     [m, n] = size(x);
%     
%     for i = 1 : n
%         for j = 1 : m
%             ret(j, i) = [x((m+1)-j,i)];
%         end
%     end
%     return
% end

function re=rev(x);
% Purpose: Reverses the elements of x
% -------------------------------------------------
% Usage: re = rev(x)
% where: x = input matrix
% -------------------------------------------------
% Returns: re = matrix whose elements are reversed
% -------------------------------------------------
% Reference: Matlab Central,
%            http://www.mathworks.com/
%                   matlabcentral/fileexchange/173
% Programmer: Sophie-Anne Van Royen
% -------------------------------------------------
d=size(x); li=d(1,1);
ind=li:-1:1;
re=x(ind,:);
return
end
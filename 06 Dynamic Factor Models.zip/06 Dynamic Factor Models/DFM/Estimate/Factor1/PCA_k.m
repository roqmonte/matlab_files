function [PC,LAM] = PCA_k(data,k)

[T,N] = size(data);
S     = data'*data;

%PCA with Covariance matrix
[V,D] = eig(S);
%V = matrix of eigenvectors
%D = matrix with eigenvalues on diagonal

%Order by largest eigenvalue
D2 = diag(sort(diag(D),'descend'));
[c,ind] = sort(diag(D),'descend');
V2 = V(:,ind);

%Finding Principal Components

LAM = sqrt(N)*V2(:,1:k);
PC  = data*LAM/N;
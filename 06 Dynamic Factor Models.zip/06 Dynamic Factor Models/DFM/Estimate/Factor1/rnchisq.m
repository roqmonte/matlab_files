function g = rnchisq(m)  % m is an integer

v = m/2;
if (round(v)-v) == 0
    g = -2*sum(log(rand(v,1)),1);
else
    v = (m-1)/2;
    g = -2*sum(log(rand(v,1)),1) + randn(1,1)^2;
end
return
end
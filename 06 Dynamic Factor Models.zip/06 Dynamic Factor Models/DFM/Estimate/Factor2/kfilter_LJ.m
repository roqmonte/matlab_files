function [Zsave, Psave] = kfilter_LJ(y,F,H,Q,R,x,A)
% This procedure uses filter from Hamilton's text
% This procedure allows for a constant term or other exogenous
% regressors
% Kalman Filter for State Space Model of Form:
% This version switches to the steady state state forecast error
% after Ptgtm1 converges
%
% Z(t+1) = F*Z(t)+v(t+1)           (state equation)
% y(t) = A'*x(t) + H'*Z(t) + w(t)  (observation equation)
%
% with E(v(t)*v(t)') = Q
% and  E(w(t)*w(t)') = R
    
    capt = cols(y);     % number of observations
    rowf = rows(F);     % dimension of state vector
    sstate = 0;
    
% store estimates of state mean and variance from filter

    Psave = zeros(rowf,rowf*capt);
    Zsave = zeros(rowf,capt);

% start recursion at unconditional mean and variance

    Ztgtm1 = zeros(rowf,1);
    Ptgtm1 = reshape((inv(eye(rowf^2)-kron(F,F))*vec(Q))',rowf,rowf)';
    %display(Ptgtm1);
    %<- Matlab's reshape are column-wise therefore if we want to get same
    %   result with Gauss's reshape function, use "reshape(A',col,row)'" 
    Ptgttest = zeros(rows(Ptgtm1),cols(Ptgtm1));
    Ptgt = Ptgtm1;
    %i = 1;
% Begin Kalman Filter Loop
    for i = 1 : capt        % consider i equivalent to t in Hamilton
     %while(i <= capt)   
        % get mean and variance of state at t given info at t
        
        if sstate == 0
            ihphr = pinv(H'*Ptgtm1*H+R);
            %display(ihphr);
            yresid = y(:,i) - A'*x(:,i) - H'*Ztgtm1;
            Ztgt = Ztgtm1 + Ptgtm1*H*ihphr*yresid;
            Ptgt = Ptgtm1 - Ptgtm1*H*ihphr*H'*Ptgtm1;
            %display(sum(sum(abs(Ptgttest-Ptgt),1)',1));
            %display(sum(sum(abs(Ptgttest-Ptgt),1)',1)/sum(diag(Ptgt),1));
            %display((sum(sum(abs(ptgttest-ptgt),1),1)/sum(diag(ptgt),1)));
            if (sum(sum(abs(Ptgttest-Ptgt),1)',1)/sum(diag(Ptgt),1)) <= 0.00000000001
                %display('enter');
                sstate = 1;
                Ptgtss = Ptgt;
                Ptgtm1ss = Ptgtm1;
                ihphrss = ihphr;
            end
            % forecast of state used in next period
            Ztgtm1 = F*Ztgtm1 + F*Ptgtm1*H*ihphr*yresid;
            Ptgtm1 = F*Ptgt*F' + Q;
        else
            yresid = y(:,i) - A'*x(:,i)-H'*Ztgtm1;
            Ztgt = Ztgtm1 + Ptgtm1ss*H*ihphrss*yresid;
            % forecaset of state used in next period
            Ztgtm1 = F*Ztgtm1 + F*Ptgtm1ss*H*ihphrss*yresid;
        end
        
        % Store Stuff
        Zsave(:,i) = Ztgt;
        Psave(1:rowf,((i-1)*rowf)+1:((i-1)*rowf)+rowf) = Ptgt;
        Ptgttest = Ptgt;
        
        %i = i+1;
    end
    Zsave = Zsave';
    return
end

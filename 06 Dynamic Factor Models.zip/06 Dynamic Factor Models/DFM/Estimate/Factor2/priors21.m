% set priors
% priors for observable equations in factor model
% priors for observable equations in factor model
b0_ = ones(nreg,1);          % prior mean of factor loading
B0__ = 0.01*eye(nreg);       % prior precision of factor loading
B0__(1,1) = 1;

b0_A = zeros(arlag,1);       % prior mean of lagged world factor
B0__A = 0.001*eye(arlag);    % prior precision of lagged world factor in other factors

r0_ = zeros(arterms,1);      % prior mean of phi (idiosyncratic AR polynomial)
phipri = 0.25;              
R0__ = phipri*eye(arterms);  % prior precision of phi

r0_v = zeros(arlag,1);       % prior mean of VAR coefficients (in F)
phipri = 0.25;
R0__V = phipri*eye(arlag);   % prior precision

r0_v2 = zeros(arlag*2,1);    % prior mean of VAR coefficients (in F)
phipri = 0.25;
R0__v2 = phipri*eye(arlag*2);  % prior precision

v0_ = ones(1,1)*ceil(capt*0.05);  % inverted gamma parameters of for innovation variances
d0_ = ones(1,1)*0.25^2;            % v0 is an integer

% prior for factor AR polynomial
% prem = [1; seqm(1,0.85,arlag-1)];
% phiprif = 1/prem;
prem = 1;
for i = 1:arlag-1
    prem = [prem;1/2^i];
end
phiprif = 1./prem;
r0f_ = zeros(arlag,1);               % prior mean of phi
R0f__ = diagrv_LJ(eye(arlag),phiprif);
% R0f__ = phipri*eye(arlag);

% Normalize innovation variance for the factor, vector since diagonal,
% variance set to 1
sigU = [1; zeros(arlag-1,1)];

for i = 2 : nfact;
    sigU = [sigU; 1; zeros(arlag-1,1)];
end
function [b0, s20, phi1, facts] = ar_LJ(y, x, p, b0_, B0__, r0_, R0__, v0_, d0_, b0, s20, phi0, xvar, nfc, facts,capt,nreg,Size)

% There is difference between Matlab and Gauss to set variables.
% In Matlab, Basically all variables are automatically defined by local
% variables. Therefore if we want to use some specific variables during a
% whole code, we have to declare 'global' variables.

n = capt;
signmax1 = 1;
signbeta1 = 1;
signmax2 = 1;
signbeta2 = 0;

while ge(signbeta1+signbeta2, 1)
    
    % generation of phi
    yp = y(1:p,1);         % the first p observations
    xp = x(1:p,:);
    
    e = y - x*b0;
    e1 = e(p+1:n,1);
    ecap = zeros(n,p);
    
    for j = 1 : p
        ecap(:,j) = lagmatrix_LJ(e,j);
    end
    
    ecap = ecap(p+1:n,:);
    
    V = invpd(R0__ + s20^(-1)*ecap'*ecap);
    phihat = V*(R0__*r0_ + s20^(-1)*ecap'*e1);
    
    phi1 = phihat + chol(V)'*randn(p,1);       % candidate draw
    
    coef = [-rev(phi1); 1];             % check stationarity
    root = roots(coef');
    rootmod = abs(root);
    accept = ge(min(rootmod),1.001);    % all the roots bigger than 1
    %counter(xvar) = counter(xvar) + (1-accept);  % number of times fails
    
    if accept == 0;
        phi1 = phi0;
    else
        sigma1 = sigmat(phi1,p);       % numerator of acceptance prob
        sigroot = chol(sigma1);
        p1 = inv(sigroot)';
        ypst = p1*yp;
        xpst = p1*xp;
        d = det(p1'*p1);
        psi1 = (d^(1/2))*exp(-0.5*(ypst-xpst*b0)'*(ypst-xpst*b0)/s20);
        
        sigma1 = sigmat(phi0,p);      % denominator of acceptance prob
        sigroot = chol(sigma1);
        p1 = inv(sigroot)';
        ypst = p1*yp;
        xpst = p1*xp;
        d = det(p1'*p1);
        psi0 = (d^(1/2))*exp(-0.5*(ypst-xpst*b0)'*(ypst-xpst*b0)/s20);
        
        if psi0 == 0 
            accept = 1;
        else
            u = rand(1,1);
            accept = le(u, psi1/psi0);
        end
        phi1 = phi1*accept + phi0*(1-accept);
    end
    
    % generation of beta
    sigma = sigmat(phi1,p);        % sigma = sigroot'*sigroot
    sigroot = chol(sigma);         % signber2v = p1'*p1
    p1 = inv(sigroot)';
    ypst = p1*yp;
    xpst = p1*xp;
    yst = [ypst; gendiff(y,phi1)];
    xst = [xpst; gendiff(x,phi1)];
    
    V = invpd(B0__ + s20^(-1)*xst'*xst);
    bhat = V*(B0__*b0_ + s20^(-1)*xst'*yst);
    b1 = bhat + chol(V)'*randn(nreg,1);   % the draw of beta
    
    signbeta1 = le(b1(2,1),0.0)*(xvar == 1);
    signmax1 = signmax1+(1*signbeta1);
    signbeta2 = le(b1(3,1),0.0)*(((xvar-1)/Size)==fix((xvar-1)/Size));
    signmax2 = signmax2+(1*signbeta2);
    
    if ge(signmax1, 100)
        facts(:,1) = (-1)*facts(:,1);
        x(:,2) = facts(:,1);
        signmax1 = 1;
%         str1 = sprintf('beta 1');
%         disp(str1);
    end
    if ge(signmax2, 100)
        facts(:,nfc) = (-1)*facts(:,nfc);
        x(:,3) = facts(:,nfc);
        signmax2 = 1;
%         str2 = sprintf('beta 2, fac %d',nfc);
%         disp(str2);
    end
end

% generation of s2
nn = n + v0_;
d = d0_ + (yst-xst*b1)'*(yst-xst*b1);
c = rnchisq(nn);
t2 = c/d;
s21 = 1/t2;
b0 = b1;
s20 = s21;

return;
end
        
        
    
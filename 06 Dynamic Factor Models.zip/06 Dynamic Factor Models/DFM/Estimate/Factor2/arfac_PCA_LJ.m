function [phi1,counter,metcount] = arfac_PCA_LJ(y, p, r0_, R0__, phi0, xvar, sig2, capt, counter, metcount)

% There is difference between Matlab and Gauss to set variables.
% In Matlab, Basically all variables are automatically defined by local
% variables. Therefore if we want to use some specific variables during a
% whole code, we have to declare 'global' variables.

% generation of phi
yp = y(1:p,1);       % the first p observations
e = y;
e1 = e(p+1:capt,1);
ecap = zeros(capt, p);

for j = 1 : p
    ecap(:,j) = lagmatrix_LJ(e, j);
end
ecap = ecap(p+1:capt,:);

V = invpd(R0__+sig2^(-1)*(ecap'*ecap));
phihat = V*(R0__*r0_+sig2^(-1)*ecap'*e1);

phi1 = phihat + chol(V)'*randn(p,1);     % candidate draw

coef = [-rev(phi1) ; 1];                 % check stationarity
root = roots(coef');

rootmod = abs(root);
accept = ge(min(rootmod),1.001);         % all the roots bigger than 1
counter(xvar,1) = counter(xvar,1) + (1-accept); % number of times fails

% if accept == 0                     % does not pass stationarity
%     phi1 = phi0;
% else
%     sigma1 = sigmat(phi1,p);       % numerator of acceptance prob
%     sigroot = chol(sigma1);
%     p1 = inv(sigroot)';
%     ypst = p1*yp;
%     d = det(p1'*p1);
%     psi1 = (d^(1/2)) * exp(-0.5*(ypst)'*(ypst)/sig2);
%     
%     sigma1 = sigmat(phi0,p);       % denominator of acceptance prob
%     sigroot = chol(sigma1);
%     p1 = inv(sigroot)';
%     ypst = p1*yp;
%     d = det(p1'*p1);
%     psi0 = (d^(1/2))*exp(-0.5 * (ypst)'*(ypst)/sig2);
%     
%     if psi0 == 0; accept = 1;
%     else
%         u = rand(1,1);
%         accept = le(u, psi1/psi0);
%     end
%     phi1 = phi1*accept + phi0*(1-accept);
% end
% metcount(xvar,1) = metcount(xvar,1) + accept;
% return
% end

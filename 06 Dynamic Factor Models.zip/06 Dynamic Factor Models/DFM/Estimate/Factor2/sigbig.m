% 

function si  = sigbig(phi, p,capt)
   rotate = seqa(0,1,capt-p);
   siupper = sigmat(phi,p);
   siupper = [ inv(chol(siupper))' zeros(p,capt-p) ];
%    silower = [ kron((rev(phi)'),ones(capt-p,1)) ones(capt-p,1) zeros(capt-p,capt-p-1) ];
   silower = [ kron((-rev(phi)'),ones(capt-p,1)) ones(capt-p,1) zeros(capt-p,capt-p-1) ];
   for s = 1 : capt-p
       silower(s,:) = circshift(silower(s,:),[0,rotate(s)]);
   end
   si = [siupper ; silower];
%    save si;
return



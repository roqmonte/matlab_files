function results = model_estimation(data,info,prior)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 10/May/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of a dinamic factor model.
% Inputs:
%   data            : Standarized data.
%   info:
%   -.rep           : Number of draws from posterior.
%   -.burn          : Burning sample.
%   -.T             : Sample size
%   -.nvar          : Number of variables in the model.
%   -.nreg          : # of regressors in each observable equation, constant plus factors.
%   -.arterms       : # of AR lags to include in idiosincratic term.
%   -.nfact         : Number of factors to estimate, global plus additional factors.
%   -.arlag         : Autoregressive lags in the dynamic factors.
%   -.m             : Dimension of state vector.
%   -.Size1         : Variables on Second factor.
%   -.Size2         : Variables on Third factor.
%   prior:
%   -.b0_           : Priors for loadins.
%   -.B0__          : Prior precision of factor loading.
%   -.r0_           : Prior mean of phi (idiosyncratic AR polynomial).
%   -.R0__          : Prior mean precision of phi (idiosyncratic AR polynomial)
%   -.v0_           : Inv. gamma param. for innovation variances R, integer.
%   -.d0_           : Inv. gamma param. for innovation variances R.
%   -.r0f_          : Prior for factor AR polynomial.
%   -.R0f__         : Prior precision for factor AR polynomial
%   -.sigU          : Factor innovation variance.
%
% Outputs:
%   results:
%   -.irf          : Draws from Impulse responses of the structural model.
%
% Index:
% 1. Setup of the model.
% 2. Simulations.
% 3. Results.
% 4. Finctions
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup of the model.
% Getting info from the code.
y       = data;
nvar    = info.nvar;
T       = info.T;
nreg    = info.nreg;
arterms = info.arterms;
nfact   = info.nfact;
arlag   = info.arlag;
m       = info.m;
draws   = info.rep;
burn    = info.burn;
Size1   = info.Size1;
Size2   = info.Size2;

% Set up some matricies to storage reults.
bsave    = zeros(draws+burn,nreg*nvar);         % Loaddngs draws.
psave2   = zeros(draws+burn,nvar*arterms);      % Idiosincratic autoregressive polynomials
ssave    = zeros(draws+burn,nvar);              % Innovation variances draws.
psave    = zeros(draws+burn,nfact*arlag);       % Factor autoregressive polynomials
Xtsave   = zeros(T-arterms,nfact,(draws+burn)); % Factor draws.

% Draws for Variance decompositions (VD)
vdecomW  = zeros(draws+burn,nvar);
vdecomI  = zeros(draws+burn,nvar);
vdecomC  = zeros(draws+burn,nvar);

% Checking AR lag order on observable equation.
if arterms > 0  
    Ylagmat = [];
    for i0 = 1:nvar
        temp_ = LagN(y(:,i0),arterms);
        temp_ = temp_(:,2:end);
        Ylagmat  = [Ylagmat temp_];
        clear temp_
    end
    % Adjusting data.
    y = y(arterms+1:T,:);
end
Tbar = size(y,1);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Simulations.

% Initialize and set up factor model
A       = zeros(nvar,1);        % Matrix for ss represenation.
H       = zeros(nvar,m);        % Matrix for ss represenation.
bold    = zeros(nvar,nreg);     % Matrix stores and tracks draws for loadings.
phimat0 = zeros(arterms,nvar);  % Matrix stores and tracks draws idiosincratic AR terms.
SigE    = ones(nvar,1)*0.0001;  % Vector stores and tracks draws Sg2 observable equation.
phi     = zeros(arlag,nfact);   % Vector stores and tracks draws AR coeff. state equation (factors).

% Factor initialization
facts      = randn(Tbar,nfact);
facts(:,1) = mean(y,2)';

% Just dimensioning for later
ystar = y;

% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');
disp('-Note: Explosive roots are discarded from simulations.');


% Simulations, the code loops over each variable to get coefficients equation by equation
for dr = 1:draws+burn
    % Check loading condition on factor.
    First = 1;
    % Sector factor identification.
    nf    = 2;
    
    % Looping over each variable
    for i = 1 : nvar
        % Draws observable equation, factor loadings and AR terms
        [b1,s21,phi1,facts] = draws_param_eqs(y(:,i),arterms,prior,bold(i,:)',SigE(i),phimat0(:,i),i,nf,facts,First);
        % Updating initial values for next draw.
        bold(i,:)    = b1';
        phimat0(:,i) = phi1;
        SigE(i)      = s21;        
                
        % Matrices with loadings for state space representation of the model.
        A(i,1) = b1(1)*(1-sum(phi1,1));
        H(i,((1-1)*arlag)+1:1*arlag) = b1(2)*[1 ((-1)*phi1)'];
        H(i,((nf-1)*arlag)+1:nf*arlag) = b1(3)*[1 ((-1)*phi1)'];
               
        % Do variance decompositoin
%         bhatv = invpd(facts(:,1)'*facts(:,1))*facts(:,1)'*facts(:,nf);
%         orthC = facts(:,nf) - facts(:,1)*bhatv;
%         bhatv = invpd([facts(:,1) orthC]'*[facts(:,1) orthC])*[facts(:,1) orthC]'*y(:,i);
%         bhatv = bhatv.^2;
%         varag = std(y(:,i))^2;
%         bsave(dr,((i-1)*nreg)+1:i*nreg) = b1';
%         ssave(dr,i) = s21;
%         psave2(dr,((i-1)*arterms)+1:i*arterms) = phi1';               
%         vdecomW2(dr,i) = (bhatv(1)*(std(facts(:,1))^2))/varag;
%         vdecomC2(dr,i) = (bhatv(2)*(std(orthC)^2))/varag;
%         vdecomI2(dr,i) = 1 - vdecomW2(dr,i) - vdecomC2(dr,i);
        
        % Quasi-differenced observable variables if ar-terms are specified in the observable equation.
        if ge(arterms,1)
            ystar(:,i) = y(:,i) - sum((repmat(phi1',size(Ylagmat,1),1).*Ylagmat(:,((i-1)*arterms)+1:(i*arterms))),2);
        else
            ystar(:,i) = y(:,i);
        end
        
        % Checking if sign condition on factor variable should be check.
        if i == Size1
            % Moving to the second block factor.
            nf    = 3;
            % Condition to check loading sign.
            First = 1;
        else
            % No check on loading sign.
            First = 0;
        end   
    end
    
    % Draw factor AR coefficients
    % Stationarity check
    scheck = -1;
    while scheck < 0        
        F = zeros(m,m);    
        j = 1;
        % Do AR coefficients one at a time.
        for i = 1:nfact
            phi(:,i) = draws_param_st(facts(:,i),arlag,prior,phi(:,i),prior.sigU(j,1));
            % Storing AR terms in block-diag matrix for stationarity check.
            F(j:j+arlag-1,j:j+arlag-1) = [(phi(:,i)'); [eye(arlag-1), zeros(arlag-1,1)]];
            %psave(dr,(i-1)*arlag+1:(i-1)*arlag+arlag)=phi(:,i)';
            j = j+arlag;
        end
        % Checkinng stationarity.
        scheck = StatioFun(F);
    end
    clear j i scheck;
    
    % Draws of factors.
    BsigU = diag(prior.sigU);
    BsigE = diag(SigE);
    % Kalman filter 
    [Xtgt,Stgt] = kfilter_LJ(ystar,F,H,BsigU,BsigE,ones(Tbar,1),A);
    Xt          = kf_ckohn_LJ_factor(Stgt,Xtgt,F,nfact,arlag,prior.sigU);
    
    % Saving and updating factors.
    for i = 1 : nfact
        Xtsave(:,i,dr) = Xt(:,1+arlag*(i-1));
        facts(:,i) = Xt(:,1+arlag*(i-1));
    end
    clear b1 s21 phi1 BsigU BsigE Xtgt Stgt F;
end

% save results
Xtsave = Xtsave(:,:,burnin+1:burnin+ndraws);
bsave = bsave(burnin+1:burnin+ndraws,:);
ssave = ssave(burnin+1:burnin+ndraws,:);
psave = psave(burnin+1:burnin+ndraws,:);
psave2 = psave2(burnin+1:burnin+ndraws,:);
vdecomW2 = vdecomW2(burnin+1:burnin+ndraws,:);
vdecomI2 = vdecomI2(burnin+1:burnin+ndraws,:);
vdecomC2 = vdecomC2(burnin+1:burnin+ndraws,:);
vdecomW1 = vdecomW1(burnin+1:burnin+ndraws,:);
vdecomI1 = vdecomI1(burnin+1:burnin+ndraws,:);
vdecomC1 = vdecomC1(burnin+1:burnin+ndraws,:);

Xtsort       = sort(Xtsave,3);
results.Xt05 = Xtsort(:,:,round(0.05*ndraws));
results.Xt16 = Xtsort(:,:,round(0.16*ndraws));
results.Xt50 = Xtsort(:,:,round(0.50*ndraws));
results.Xt84 = Xtsort(:,:,round(0.84*ndraws));
results.Xt95 = Xtsort(:,:,round(0.95*ndraws));

results.Xt  = Xtsave;
results.B   = bsave;
results.S   = ssave;
results.P   = psave;
results.P2  = psave2;
results.VDW2 = vdecomW2;
results.VDI2 = vdecomI2;
results.VDC2 = vdecomC2;
results.VDW1 = vdecomW1;
results.VDI1 = vdecomI1;
results.VDC1 = vdecomC1;

meanz.F   = mean(Xtsave,3);
meanz.B   = mean(bsave,1);
meanz.S   = mean(ssave,1);
meanz.P   = mean(psave,1);
meanz.P2  = mean(psave2,1);
meanz.VDW2 = mean(vdecomW2,1);
meanz.VDI2 = mean(vdecomI2,1);
meanz.VDC2 = mean(vdecomC2,1);
meanz.VDW1 = mean(vdecomW1,1);
meanz.VDI1 = mean(vdecomI1,1);
meanz.VDC1 = mean(vdecomC1,1);



close(h_wait);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.





%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions.

% Funtion check stationarity of a companion form matrix (1 if stationary).
function check = StatioFun(F)
if max(abs(eig(F))) < 1
    check = 1;
else
    check = -1;
end


%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
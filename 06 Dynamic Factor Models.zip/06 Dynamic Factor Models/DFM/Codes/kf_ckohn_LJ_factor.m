function Xt = kf_ckohn_LJ_factor(Stgt,Xtgt,F,nfact,arlag,sigU)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero 
% Date: 12/Jun/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Use Carter-Kohn procedure to draw state variables form
% kalman filter.
%
% Inputs:
%  Stgt   : State variance from kalman filter.
%  Xtgt   : State mean from kalman filter.
%  F      : Coeff. matrix state equation.
%  nfact  : Number of factors.
%  arlag  : Autoregressive lags in the dynamic factors.
%  sigU   : Variance state equation.
%
% Outputs:
%  Xt     : Smoothed state variables.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting info form code.
T  = size(Xtgt,1);
m  = size(Xtgt,2);
Xt = zeros(T,m);
% Draw X(T) from N(Xtgt, Stgt) for t = T
Stgt2   = Stgt(1:m,((T-1)*m)+1:((T-1)*m)+m);
Xt(T,:) = (Xtgt(T,:)' + (chol(Stgt2)'*randn(m,1)))';

% Build up mean/variance of state vector
t = T - 1;

% Do Carter-Kohn procedure.
while ge(t,1)
    % Getting filtered states mean and variance.
    Xtgt2 = Xtgt(t,:)';
    Stgt2 = Stgt(1:m,((t-1)*m)+1:((t-1)*m)+m);
    % Backward recursion, mean and state variance.
    Xtgt2 = Xtgt2 + Stgt2*F'*(F*Stgt2*F' + diag(sigU))^(-1)*(Xt(t+1,:)' - F*Xtgt2);
    Stgt2 = Stgt2 - Stgt2*F'*(F*Stgt2*F' + diag(sigU))^(-1)*F*Stgt2;

    % Choosing last factor and striping zeros from Ptt matrix
    stemp = zeros(nfact,nfact);
    xtemp = zeros(nfact,1);
    i = 1; 
    j = arlag;
    while le(i,nfact)
        % State variable.
        xtemp(i,1) = Xtgt2(j);
        % Variance terms
        stemp(i,i) = Stgt2(j,j);  
        ii = i + 1;
        jj = 1;
        % Covariance terms
        while le(ii, nfact)       
            stemp(ii,i) = Stgt2(j+jj*arlag,j);
            stemp(i,ii) = stemp(ii,i);
            ii = ii + 1;
            jj = jj + 1;
        end
        i = i + 1;
        j = j + arlag;
    end
    
    % Taking updated draw.
    xtemp = xtemp + (chol(stemp)'*randn(nfact,1));        
    i = 1;
    while le(i,m)
        Xt(t,i) = Xtgt2(i);
        if (i/arlag) == fix(i/arlag)
            Xt(t,i) = xtemp((i/arlag));
        end
        i = i + 1;
    end
    
    t = t - 1;
    clear Xtgt2 Stgt2 stemp xtemp i ii j jj
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
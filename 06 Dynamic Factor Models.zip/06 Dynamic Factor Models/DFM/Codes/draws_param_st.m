function phi1 = draws_param_st(y,p,ChibGren,prior,phi0,sig2)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 10/May/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Function draws AR coefficientes of the state equation.
% Inputs:
%   y               : Factor.
%   p               : Autoregressive lags in the dynamic factors.
%   ChibGren        : (1) Do Chib and Greenberg when sampling ar terms (Default).
%   prior:
%   -.r0f_          : Prior for factor AR polynomial.
%   -.R0f__         : Prior precision for factor AR polynomial
%   phi0            : Starting values for AR coeff. state equation.
%   sig2            : Factor innovation variance.
%
% Outputs:
%   phi1            : Draw AR coefficients state equation.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting priors.
r0_  = prior.r0f_;
R0__ = prior.R0f__;

% Keeping first p observations.
yp   =  y(1:p,1);
% Residuals and lagged residuals.
e    = y;
temp = LagN(e,p);
e1   = temp(:,1);
ecap = temp(:,2:end);
clear temp;

% Candidate draw AR coeff from idiosincratirm term of the model.
V      = (R0__+sig2^(-1)*(ecap'*ecap))^(-1);
phihat = V*(R0__*r0_+sig2^(-1)*ecap'*e1);
phi1   = phihat + chol(V)'*randn(p,1);

% Check stationarity and Pb of acceptance for candidate draw.
scheck = StatioFun(phi1);
if scheck == -1
    phi1 = phi0;
elseif scheck == 1
    % Numerator of acceptance prob
    sigma1  = sigmat(phi1,p);
    sigroot = chol(sigma1);
    p1   = inv(sigroot)';
    ypst = p1*yp;
    d    = det(p1'*p1);
    psi1 = (d^(1/2)) * exp(-0.5*(ypst)'*(ypst)/sig2);
    
    % Denominator of acceptance prob
    sigma1  = sigmat(phi0,p);
    sigroot = chol(sigma1);
    p1   = inv(sigroot)';
    ypst = p1*yp;
    d    = det(p1'*p1);
    psi0 = (d^(1/2))*exp(-0.5 * (ypst)'*(ypst)/sig2);
    
    % Condition to accept draws from posterior.
    if psi0 == 0; 
        accept = 1;
    else
        u = rand(1,1)*ChibGren;
        accept = le(u, psi1/psi0);
    end
    % Draw AR terms obserbvable equation.
    phi1 = phi1*accept + phi0*(1-accept);
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Functions.

% Funtion check stationarity of a companion form matrix (1 if stationary).
function check = StatioFun(betas)
b = vec(betas);
k = size(b,1);
% One parameter.
if k == 1
    F = b;
    if abs(F) < 1
        check = 1;
    elseif abs(F) >= 1
        check = -1;
    end
% More than one parameter.
elseif k > 1
    F = [b'; eye(k-1) zeros(k-1,1)];
    if max(abs(eig(F))) < 1
        check = 1;
    else
        check = -1;
    end
end

% Function computes stationary covariance matrix.
function sigma = sigmat(phi,p)
r2 = p^2;
i  = [eye(p-1) zeros(p-1,1)];
Pcap = [phi'; i];
pp   = eye(r2) - kron(Pcap,Pcap);
e1   = [1; zeros(p-1,1)];
sig  = (pp)^(-1)*vec(e1*e1');
sigma= (reshape(sig',p,p)')';

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
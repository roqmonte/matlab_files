function Plot_tvp_sg2(Sg2_draws,info,fid,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 8/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Plots Sg(t) series from SV models.
% Input:
%   Sg2_draws       : Draws TVP var/cov matrix, observation equation.
%   info:
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%   -.area_color    : Color of area for last significance level (1 x 3).
%   -.widths        : Line widths to be used (1 x 2).
%   -.fsizes        : Font sizes to be used (1 x 2).
%   -.names         : Vector with labels of variables in the system.
%   fid             : Figure number for plots.
%   vars            : Data selection for charts
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Geting inputs
if exist('fid','var') == 0
    fid = 10;
end
Sg2 = Sg2_draws;
% Checking dimension of Signa
line_width      = info.widths(1);
fsize           = info.fsizes(1);
fsize_alt       = info.fsizes(2);
names           = info.names;
xTick           = info.dates_xTick;
xTickLabel      = info.dates_label;


% Data selection for charts
if exist('vars','var') == 1
    Sg2    = Sg2(:,vars,:);
    names  = info.names(:,vars);
end
nobs  = size(Sg2,1);
nvars = size(Sg2,2);
draws = size(Sg2,3);

% Number of variables and graph setup.
aux = nvars;
if aux <= 3
    k1 = 1; k2 = aux;
elseif aux <= 4
    k1 = 2; k2 = 2;
elseif aux > 4 && aux <= 6
    k1 = 3; k2 = 2;
elseif aux > 6 && aux <= 9
    k1 = 3; k2 = 3;
elseif aux > 9 && aux <= 16
    k1 = 4; k2 = 4;
elseif aux > 16 && aux <= 24
    k1 = 4; k2 = 6;
elseif aux > 24 && aux <= 30
    k1 = 5; k2 = 6;
elseif aux > 30
    error('Max number of variables reached.');
end


% Plot data against fitted values
figure(fid)
k = 1;
for j = 1:nvars
    % Getting median and bands.
    Sg2m = quantile(Sg2(:,j,:),0.5,3);
    Sg2lbm = quantile(Sg2(:,j,:),0.16,3);
    Sg2mub = quantile(Sg2(:,j,:),0.84,3);
    
    subplot(k2,k1,k);
    plot([NaN(xTick(end)-nobs,1); Sg2m],'-b','LineWidth',line_width);
    hold on
    plot([NaN(xTick(end)-nobs,1); Sg2lbm],'--r','LineWidth',line_width);
    hold on
    plot([NaN(xTick(end)-nobs,1); Sg2mub],'--r','LineWidth',line_width);
    title(names(j),'FontSize',fsize);
    set(gca,'FontSize',fsize_alt);
    xlim([xTick(1) xTick(end)]);
    set(gca,'XTick',xTick);
    set(gca,'XTickLabel',xTickLabel);
    % Adjusting time frame for chart
    X_lim_temp = size(NaN(xTick(end)-nobs,1),1)+1;
    xlim([X_lim_temp xTick(end)]);
    k = k + 1;
    clear Sg2m Sg2mlb Sg2mub
end
legend1 = legend('Posterior mean','(16,84)th percentiles of the standard deviation of residuals');
set(legend1,'FontSize',fsize_alt,'Orientation','horizontal',...
'Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
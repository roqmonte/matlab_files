function results = GS_plot_states(data,labels,conf,print,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 15/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Code to plot states variables from draws of Gidd Sampler.
%
% Inputs:
%   data        : Draws from Gibb Sampler (T x nvars x draws).
%   labels      : Column vector with labels for data.
%   conf        : Significance levels for confidence bands (1 x 3), default is 95%.
%   print       : Figures/charts id numbers
%   dates       : Vector with info for dates: [year,month,freq].
%                 Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results:
%   -.median    : Median. 
%   -.res_lb    : Lower bounds.
%   -.res_hb    : Upper bounds.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Checking code
if exist('print','var') == 0
    print = 1;
end
% Checking confidance bands
if exist('conf','var') == 0 || isempty(conf)
    conf = [0.65 0.90 0.95];
end
% Checking dates
if exist('dates','var') == 0 || isempty(dates)
    dates = [1900,1,1];
end

% Setup
nvar  = size(data,2);
T     = size(data,1);
Tx    = (1:T)';
fsize     = 11;
fsize_alt = 9;
acolor    = [0.9 0.9 0.9];
area_step = 0.1;

% Building dates for charts.
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),T,freq);

% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    temp = zeros(nvar,1);
    lab = {'State variable .1'};
    for i0 = 2:nvar
        lab2 = strcat('State variable .',num2str(i0));
        lab = [lab; lab2];
    end        
    labels = lab;
    clear temp lab i0 lab2;
end

% Number of variables and graph setup.
if nvar <= 3
    k1 = 1; k2 = nvar;
elseif nvar <= 4
    k1 = 2; k2 = 2;
elseif nvar > 4 && nvar <= 6
    k1 = 3; k2 = 2;
elseif nvar > 6 && nvars<= 9
    k1 = 3; k2 = 3;
elseif nvar > 9 && nvar <= 16
    k1 = 4; k2 = 4;
elseif nvar > 17 && nvar <= 24
    k1 = 4; k2 = 6;
elseif nvar > 25 && nvar <= 30
    k1 = 5; k2 = 6;
elseif nvars > 30
    error('Max number of variables reached.');
end

% Bulding confidance bands
nbands = size(conf,2);
bands  = ([(1-conf); conf])*100;

% Charts for state variables
figure(print)
k = 1;
for j = 1:nvar
    subplot(k2,k1,k)
    % Median and confidance bands
    med   = median(data(:,j,:),3);
    % Area graph.
    area_color = acolor;
    ii = 1;
    for i = nbands:-1:1
        % Bands
        temp  = prctile(data(:,j,:),bands(:,i)',3);
        bands_l = temp(:,1,1);
        bands_h = temp(:,1,2);
        shadedplot((1:T),bands_l',bands_h',area_color);
        area_color = area_color-area_step;
        hold on;
        % Saving results
        res_me(:,j,ii) = med;
        res_lb(:,j,ii) = bands_l;
        res_hb(:,j,ii) = bands_h;
        ii = ii + 1;
    end
    % Zero line.
    h(1) = plot(Tx,zeros(T,1),'-k','LineWidth',0.7);
    % Median.
    h(2) = plot(Tx,med,'-b');   
    
    % Labels.
    title(labels(j,:),'FontSize',fsize);
    xlim([xTick(1) xTick(end)]);
    ylim([min(prctile(data(:,j,:),1,3)) max(prctile(data(:,j,:),99,3))]);
    set(gca,'XTick',xTick);
    set(gca,'XTickLabel',xTickLabel);
    box off
    k = k + 1;
end

% Legend
legend1 = legend(h(2),['State variables with ',num2str(conf(1)*100) ', ',num2str(conf(2)*100) ' and ',num2str(conf(3)*100) ' percent confidence bands']);
set(legend1,'FontSize',fsize_alt,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');

% Saving results
results.median = res_me;
results.res_lb = res_lb;
results.res_hb = res_hb;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
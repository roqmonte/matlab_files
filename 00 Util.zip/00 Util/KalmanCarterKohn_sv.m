function [St,y_res,y_fit,Pm] = KalmanCarterKohn_sv(res,res_x,bt00,p00,Rtot,Q)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero 
% Date: 6/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: The code runs the Kalman filter and Carter-Kohn backward 
% recursions to obtain smoothed estimates of states from the following 
% state-space model:
% 
%  res(t) =   aij(t)*res_x(t) + e(t),  e(t)~N(0,diag(exp(2*H)))
%  aij(t) =          aij(t-1) + w(t),  w(t)~N(0,Q) for i!=j
%
% Note: The code has been customized for SV models as Rtot is time varying.
% With H = log(diag(chol(Omega))). Where Omega is the var/cov matrix of residuals.
%
% Inputs: 
%  Y      : Residualas from conditional mean(T x ny).
%  X      : Regressors for each aij coefficient.
%  bt00   : Initial states values for St (1 x ns)
%  p00    : Initial value for covariance matrix of St (ns x ns)
%  Rtot   : TV elements of diag(Sg2(t)).
%  Q      : Cov matrix of transition equation error.
%
% Output: 
%  St       : Smoothed states variables (T,n_st)
%  y_res    : Smoothed residual.
%  y_fit    : Smoothed fit.
%  Pm       : Smoothed cov matrix of states CK (T,n_st,n_st).
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Setup of the code.
% Checking option to check stability of the model.
Y      = res;
X      = res_x;
[T,ny] = size(Y);
ns     = size(bt00,1);
bt_tt  = NaN(T,ns);
ptt    = NaN(T,ns,ns);

bt11    = bt00;
p11     = p00;

% Kalman Filter.
for t=1:T
    % This is for A(2:3,2:3,t).
    if ndims(Rtot) == 3   
        R = Rtot(:,:,t);
    % This is for A(1,1,t)
    elseif ismatrix(Rtot) 
        R = Rtot(:,t);
    end
    
    % Case for which x is a matrix with dime 3 (For for A(t))
    x = squeeze(X(t,:,:))';
    y = Y(t,:);
    
    % Prediction and prediction error.
    bt10 = bt11;
    p10 = p11 + Q;
    eta = y - (x*bt10)';
    % Kalman gain
    K = p10*x'/(x*p10*x'+R);
    % Updating
    bt11 = (bt10+K*eta');
    p11 = p10 - K*x*p10;
    % Saving results
    ptt(t,:,:) = p11;
    bt_tt(t,:) = bt11;
end

% Carter-Kohn algorithm
% Matrices to store results.
bt  = zeros(T,ns);
res = zeros(T,ny);

% Backward iterations.
p00     = squeeze(ptt(T,:,:));
bt(T,:) = mvnrnd(bt_tt(T,:)',p00/2+p00'/2,1);
% Residuals for A(t) regression
res(T,:)  = Y(T,:)-(squeeze(X(T,:,:))'*bt(T,:)')';

% Periods T-1 to 1
for t = T-1:-1:1
    pt = squeeze(ptt(t,:,:));
    % Update bt with information in bt[t+1]
    bm = bt_tt(t:t,:) + (pt/(pt+Q)*(bt(t+1:t+1,:)-bt_tt(t,:))')';
    % Update covariance of bt
    pm = pt - pt/(pt+Q)*pt;
    bt(t:t,:) = mvnrnd(bm,pm/2+pm'/2,1);

    % Residuals for A(t) regression
    res(T,:)  = Y(t,:)-(squeeze(X(t,:,:))'*bt(t,:)')';
end

% Saving results
St    = bt;
y_res = res;
y_fit = Y - y_res;
Pm    = pm;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
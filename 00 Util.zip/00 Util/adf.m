function results =  adf(x,mod,l,ic)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 17/Aug/2018
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Descripci�n: Carry out DF tests on a time-series vector
%           y(t) = c + d*t + a*y(t-1) + bj*lags(dy) + e(t)
%
% Inputs:
%   x   : a time-series vector
%   mod : Order of time polynomial in the null-hypothesis
%         -1, no deterministic part
%          0, for constant term
%          1, for constant plus time-trend
%   l   : Max lag for automatic search
%   ic  : Information criteria: 'AIC','HQC','BIC'. If empty use "l" lags.
%
% Outputs:
%   results: 
%   -.meth  : 'adf'
%   -.alpha : estimate of the autoregressive parameter
%   -.adf   : ADF t-statistic
%   -.crit  : Col vector of critical values [1% 5% 10%].
%   -.nlag  : Lag chosen for model
%   -.nobs  : Number of obs.
%   -.reg   : Set of results from OLS model.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Checking in inputs
if mod < -1
    error('p less than -1 in adf');
elseif mod > 1
    error('p greater than -1 in adf');
end
if size(x,2) > 1
    error('adf cannot handle a matrix -- only vectors');
end
if exist('ic','var')
   ic = []; 
end

% Data setup
y     = x(l+2:end);
ylag  = x(l+1:end-1);
dylag = LagN(x(2:end,1)-x(1:end-1,1),l);
dy    = dylag(:,1);
dylag = dylag(:,2:end);
% Constant terms.
if mod > -1
    dte = ptrend(mod,size(dy,1));
else
    dte = [];
end

% Checking lag selection
if max(size(ic)) > 0 
    % OLS estimation
    res_opt = ARxopt(y,[dte ylag],dylag,0);
    if strcmp(ic,'AIC')
        lopt = res_opt.lags(1,1);
    elseif strcmp(ic,'HQC')
        lopt = res_opt.lags(2,1);
    elseif strcmp(ic,'BIC')
        lopt = res_opt.lags(3,1);
    end
else
    lopt = l;
end

% Model estimation
res_ols = OLSest(y,[dte dylag(:,1:lopt) ylag],'OLS',0.05,0);
res     = res_ols.uhat;
vcov    = res_ols.bvar;
T       = size(res,1);

% Results
results.n     = size(res,1);
results.nlag  = lopt;
results.alpha = res_ols.b(end)-1;
results.adf   = (res_ols.b(end) - 1) / sqrt(vcov(end,end));
results.crit  = ztcrit(T,mod);
results.meth   = 'adf';
results.reg    = res_ols;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Function, produce an explanatory variables matrix containing a polynomial time-trend
function xmat = ptrend(p,nobs)
% Input: 
%   p    : order of the time-trend polynomial
%          p < 0, xmat = iota (nobs x 1) vector of ones
%          p = 1, xmat = time trend
%          p > 1, xmat = higher order polynomial in time
%   nobs : size of the matrix
u = ones(nobs,1) ;
if p > 0
    timep = zeros(nobs,p) ;
    t = 1:nobs;
    t = (t')/nobs;
    m        = 1 ;
    while (m <= p)
        timep(:,m) = t.^m ;
        m = m + 1 ;
    end;
    xmat = [u timep];
else
    xmat = u ;
end

% Return critical values for the Zt statistic used in adf()
function cvalues = ztcrit(T,mod)
% Input: 
%   T    : size of the matrix
%   mod  : order of the time-trend polynomial
%         -1, no deterministic part
%          0, for constant term
%          1, for constant plus time-trend
% Output: 
%   cvalues : Critical values [1% 5% 10%].

% Table with betas
table = zeros(3,4,3);
% No deterministic terms
table(:,:,1) = [-2.56574  -2.2358  -3.627   0.000;...
                -1.94100  -0.2686  -3.365  31.223;...
                -1.61682   0.2656  -2.714  25.364];
% Constant term only
table(:,:,2) = [-3.43035  -6.5393 -16.786  -79.433;...
                -2.86154  -2.8903  -4.234  -40.040;...
                -2.56677  -1.5384  -2.809    0.000];
% Constant term and linear trend
table(:,:,3) = [-3.95877  -9.0531 -28.428 -134.155;...
                -3.41049  -4.3904  -9.036  -45.374;...
                -3.12705  -2.5856  -3.925  -22.380];

% Chosing model config
if mod == -1
   temp = table(:,:,1); 
elseif mod == 0
    temp = table(:,:,2);
elseif mod == 1
    temp = table(:,:,3);
end
% Critical values.
cvalues = temp(:,1) + temp(:,2)/T + temp(:,3)/T^2 + temp(:,4)/T^3;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
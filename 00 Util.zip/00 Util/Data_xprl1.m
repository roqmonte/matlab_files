function results = Data_xprl1(data,labels,id,print,labels2)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 21/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Scatter plot to explore data. The function plots
% each column at a time vs. the rest. The function highlights the last data
% point on each chatr.
%
% Inputs:
%   data        : Data.
%   labels      : Column vector with labels for data.
%   id          : Vectors with unit/zeros entries to highlight point in charts.
%   print       : (1) Do charts and print results on screen.
%   labels2     : Labels for sub-smaples.
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Checking code
nvar  = size(data,2);

% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    lab = {'Var .1'};
    for i0 = 2:nvar
        lab2 = strcat('Var .',num2str(i0));
        lab = [lab; lab2];
    end        
    labels = lab;
    clear temp lab i0 lab2;
end
% Checking print.
if exist('print','var') == 0
    print = 1;
end
% Checking Sub-sample.
if exist('id','var') == 0  || isempty(id)
    id2 = 0;
else
    id2 = 1;
end

% Font size for labels
if nvar < 9 
    fontsize = 10;
else
    fontsize = 8;
end

% Charts for state variables
figure(print)
temp = reshape(1:nvar^2,nvar,nvar);
temp = temp(:,1);
aux  = diag(reshape(1:nvar^2,nvar,nvar));
jj = 1;
i3 = 1;
for i0 = 1:nvar    
    % Data
    mat = data;
    % Charts
    for i1 = 1:nvar              
        subplot(nvar,nvar,jj)
        if aux(i0) == jj
            histogram(mat(:,i0),15,'FaceColor',[0 0 1],'EdgeAlpha',1);
            
        else
            % Scatter plot
            h(1) = scatter(mat(:,i1),mat(:,i0),15,[0 0.5 0.5],'filled');
            hline = refline;
            hline.Color = 'r';
        % Last point/selected data
            hold on
            h(2) = scatter(mat(id==1,i1),mat(id==1,i0),25,[0.75 0 0],'filled');
        end
        
        % Labels yx
        if i1 == 1;
            ylabel(labels(temp(i0)),'FontSize',fontsize);
        end
        % Labels xs        
        if jj > nvar*nvar-nvar
            xlabel(labels(i3),'FontSize',fontsize);
            i3 = i3 + 1;
        end
        jj = jj + 1;
    end
    box off
end
% Labels for legends
if id2 == 1
    if exist('labels2','var') == 0 || isempty(labels2)
        labels2 = [{'Full sample'}; {'Sub-sample'}];
    end
    legend1 = legend(h([1 2]),labels2);
    set(legend1,'FontSize',10,'Orientation','horizontal',...
    'Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
end
results = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
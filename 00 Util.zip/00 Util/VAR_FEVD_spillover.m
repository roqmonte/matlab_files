function results = VAR_FEVD_spillover(FEVD,hor)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 22/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes predictive directional measurement of volatility 
% spillovers, as in Diebold and Yilmaz (2012).
% Input:
%   FEVD        : FEVD output from VAR model (h,n,nshock).
%   hor         : Horizon for the spillover analysis, (default 5).
%
% Output:
%   results:
%   -.total     : Total net volatility spillover.
%   -.received  : Volatility spillovers received by market i from all other markets j
%   -.trans     : Volatility spillovers transmited by market i to all other markets j
%   -.NetSpills : Net spillovers.
%   -.atri      : Contribution to volatility spillovers for each variable.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Checking horizon.
if exist('hor','var') == 0
    hor = 5;
end
% Number of variables
n = size(FEVD,2);

id_aux = reshape(ones(n)-eye(n),1,n*n);

% Normalization
fdn = FEVD./repmat(sum(FEVD,2),1,n);
% Total spillovers.
spill_tot = (id_aux*reshape(squeeze(fdn(hor,:,:)),1,n*n)')/n*100;
% Directional spillovers
for i1 = 1:n
    % Volatility spillovers received by market i from all other markets j
    ei     = ones(1,n);
    ei(i1) = 0;
    spill_rec(1,i1) = sum(ei.*fdn(hor,:,i1))/n*100;
    
    % Volatility spillovers transmited by market i to all other markets j
    ej     = ones(1,n);
    ej(i1) = 0;
    spill_tra(1,i1) = sum(ej*squeeze(fdn(hor,i1,:)))/n*100;
    
    % Aditional results
    xrq(i1,:) = [fdn(hor,:,i1) squeeze(fdn(hor,i1,:))'];

end    
% Net spillovers
spill_net(1,:) = spill_tra(1,:) - spill_rec(1,:);
clear ei ej;

% Saving results
results.total     = spill_tot;
results.received  = spill_rec;
results.trans     = spill_tra;
results.NetSpills = spill_net;
results.atri      = xrq;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
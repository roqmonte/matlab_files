function [sdata,mu,sigma] = standardise(data)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 22/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: The function standarizes the data, by subtracting the mean 
% of every column and dividing all column elements by the respective columns
% standard deviation.
% Input:
%   data   : Data
%
% Output:
%   sdata  : Standardise data.
%   mu     : Mean of each column.
%   sigma  : standar deviation each column.

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Info form data
t = size(data,1); 
n = size(data,2);

% Create matrices mean and stds which contain the means and SD of each column.
mu    = repmat(mean(data),t,1); 
sigma = repmat(std(data),t,1);

%Subtract the mean from all column elements and divide them by the standard deviation
sdata = (data - mu)./sigma;
mu    = mu(1,:);
sigma = sigma(1,:);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
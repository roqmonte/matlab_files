function [s,v2j,yss_mj] = KF_KimShephardChib(A,Tbar,ny,resB,H)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 6/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Function use Kim et al. (1998) procedure for "mixture of 
% normals approximation of the log chi-squared distribution", Primiceri p846
% Sample S from a 7-point discrete density (see Kim et al., 1998)
%
% To get draw for H(t), use:
%
% covH = zeros(ny,ny,Tbar);
% for t = 1:Tbar
%   covH(:,:,t) = diag(v2j(s(t,:)));
% end
% H = KalmanCarterKohn_sv(yss_mj,ones(Tbar,1)*2,Hpr,VHpr,covH,W);
%
% With H = log(diag(chol(Omega))). Where Omega is the var/cov matrix of residuals.
%
% Inputs:
%   A        : Matrix with a(ij) elements per row (i!=j).
%   Tbar     : Sample size.
%   ny       : Number of variables in the model.
%   resB     : Residuals from model for conditional mean.
%   H        : Draw H(t), where H = log(diag(Omega)), 
%              With Omega is the var/cov matrix of residuals.
%
% Outputs:
%   results:
%   s        : Indicator variable.
%   v2j      : Selection of the mixing distribution to be log Xi2(1):
%   yss_mj   : Sample S from a 7-point discrete density.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Kim et al. (1998) procedure 

% Parameters of the seven normals to be mixed to approximate log
% Chi-squared distribution.
cbar = 0.001; % Fffseting constant term used to draw Sigma(t)
qj   = [.0073 .10556 .00002 .04395 .34001 .24566 .2575];
mj   = [-10.12999 -3.97281 -8.56686 2.77786 .61942 1.79518 -1.08819] ...
        - 1.2704;  % means already adjusted by - 1.2704
v2j  = [5.79596 2.61369 5.17950 .16735 .64009 .34023 1.26261];

% Arrenge elements from A matrix into At matrix
At = repmat(eye(ny),Tbar,1);
for  ii = 1:Tbar
    z1 = 1; j1 = 1; j2 = 1;
    for i0 = 2:ny
        At((ii-1)*ny+i0,1:z1) = -A(ii,j1:j2);            
        z1 = z1 + 1;
        j1 = j1*2;
        j2 = j2*2 + 1;
    end
end

% Create y*(t) as in (A.3), p845 and y**(t) as in (A.4), p846
ys = NaN(Tbar,ny);
for t = 1:Tbar
    ys(t,:) = At((t-1)*ny+1:(t-1)*ny+ny,:)*resB(t,:)';
end
yss = log(ys.^2 + cbar);    

% Sample S from a 7-point discrete density (see Kim et al., 1998)
s = zeros(Tbar,ny);
for i=1:ny        
    q = repmat(qj,Tbar,1).*normpdf( repmat(yss(:,i),1,7), ...
        2*repmat(H(:,i),1,7) + repmat(mj,Tbar,1), ...
        repmat(sqrt(v2j),Tbar,1));
    q = q./repmat(sum(q,2),1,7);
    f = (q + makelag(q',1)' + makelag(q',2)' + makelag(q',3)' ...
        + makelag(q',4)' + makelag(q',5)' + makelag(q',6)');
    z1 = unidrnd(100000,Tbar,1)/100000;
    z2 = sum(z1*ones(1,7) >= f, 2) + 1;
    z3 = z2 > 7;
    s(:,i) = z2 - z3;
end
% Draws
if ny == 1
    yss_mj = yss-mj(s)';
else
    yss_mj = yss-mj(s);
end

% Creates the nlagth lag of a vector or matrix y
function ylag = makelag(y,nlag)
[nr, nc] = size(y);
y1   = y(1:(nr - nlag),:);
ylag = [zeros(nlag,nc); y1];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
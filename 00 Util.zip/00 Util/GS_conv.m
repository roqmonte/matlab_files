function results = GS_conv(data,labels,print,pac)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 15/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Code check convergence of Gibb Sampler.
%
% Inputs:
%   data        : Draws from Gibb Sampler (T x nvars).
%   labels      : Column vector with labels for data.
%   print       : Figures/charts id numbers
%   pca         : (1) do autocorrelation of retained Gibbs draws.
%
% Outputs:
%   results :
%   -.rec_mean  : Recursive mean.
%   -.acf_pac   : ACF and PAC of Gibb Sampler draws.
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Checking code
if exist('print','var') == 0
    print = 1;
end
if exist('pac','var') == 0
    pac = 0;
end
draws = size(data,1);
nvar  = size(data,2);
fsize     = 11;
fsize_alt = 9;

% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    temp = zeros(nvar,1);
    lab = {'Var.1'};
    for i0 = 2:nvar
        lab2 = strcat('Var.',num2str(i0));
        lab = [lab; lab2];
    end        
    labels = lab;
    clear temp lab i0 lab2;
end

% Number of variables and graph setup.
if nvar <= 3
    k1 = 1; k2 = nvar;
elseif nvar <= 4
    k1 = 2; k2 = 2;
elseif nvar > 4 && nvar <= 6
    k1 = 3; k2 = 2;
elseif nvar > 6 && nvars<= 9
    k1 = 3; k2 = 3;
elseif nvar > 9 && nvar <= 16
    k1 = 4; k2 = 4;
elseif nvar > 17 && nvar <= 24
    k1 = 4; k2 = 6;
elseif nvar > 25 && nvar <= 30
    k1 = 5; k2 = 6;
elseif nvars > 30
    error('Max number of variables reached.');
end

% Sequence of retained Gibbs draws
figure(print)
k = 1;
for j = 1:nvar
    subplot(k2,k1,k)
    % Chart.
    h(1) = plot(data(:,j),'-','Color','b','LineWidth',1);    
    % Labels.
    title(labels(j,:),'FontSize',fsize);
    xlabel('Gibbs iterations','FontSize',fsize_alt);
    %set(gca,'FontSize',fsize_alt)
    xlim([0 draws])
    box off
    k = k + 1;
end
clear k j i;
% Setting the legend of the graphs.
legend1 = legend(h(1),'Sequence of retained Gibbs draws');
set(legend1,'FontSize',fsize,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');


% Recursive means
Ts = (1:draws)';
cs = cumsum(data);
% Recursive means of retained Gibbs draws
figure(print+1)
k = 1;
res_rec_mean = [];
for j = 1:nvar
    subplot(k2,k1,k)    
    % Chart
    aux_0 = cs(:,j)./Ts;
    h(1) = plot(aux_0,'-','Color','b','LineWidth',1);    
    % Labels.
    title(labels(j,:),'FontSize',fsize);
    xlabel('Gibbs iterations','FontSize',fsize_alt);
    %set(gca,'FontSize',fsize_alt)
    xlim([0 draws])
    box off
    % Saving results
    res_rec_mean = [res_rec_mean aux_0];
    k = k + 1;    
end
clear k j i aux_0;
% Setting the legend of the graphs.
legend1 = legend(h(1),'Recursive means of retained Gibbs draws');
set(legend1,'FontSize',fsize,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');

if pac == 1
    % Autocorrelation of retained Gibbs draws
    figure(print+2)
    k = 1;
    res_acf = cell(13,7,nvar);
    for j = 1:nvar
        subplot(k2,k1,k)
        % ACF and PAC functions
        [temp0,temp1] = acf(data(:,j));
        % Chart
        bar((-1:20),[NaN(1,2); temp1(1:21,[1,2])]);
        hold on        
        plot((-1:20),repmat(temp1(1:21,3),1,22),':k');
        hold on
        plot((-1:20),repmat(temp1(1:21,4),1,22), ':k');
        xlim([-1 21]);
        ylim([-1 1]);
        % Labels.
        title(labels(j,:),'FontSize',fsize);
        xlabel('Lag','FontSize',fsize_alt);
        legend('Sample Auto-correlations','Partial correlation function','Location','northeast');
        box off
        % Sabing table
        res_acf(:,:,j) = temp0;
        k = k + 1;
    end
    clear k j i temp0 temp1;
else
    res_acf = [];
end

% Saving results
results.rec_mean = res_rec_mean;
results.acf_pac  = res_acf;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
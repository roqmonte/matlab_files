function results = Data_xprl2(Y,X,laby,labx,id,print,labels2)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 26/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Scatter plot to explore data. The function plots each column
% of Y, against each column of X. The function highlights the last data
% point on each chatr by default. But the code also has the option to
% highlights specific points using the "id: vector.
%
% Inputs:
%   Y           : Dependent data (y axis) for scatter plots.
%   X           : Indep. data (x axis) for scatter plots.
%   laby        : Column vector with labels for Y.
%   labx        : Column vector with labels for X.
%   id          : Vectors with unit/zeros entries to highlight point in charts.
%   print       : (1) Do charts and print results on screen.
%   labels2     : Labels for sub-smaples.
%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Checking code
nvary  = size(Y,2);
nvarx  = size(X,2);

% Checking labels.
if exist('laby','var') == 0 || isempty(laby)
    laby = {'Y1'};
    for i0 = 2:nvary
        lab2 = strcat('Y',num2str(i0));
        laby = [laby; lab2];
    end        
    labelsY = laby;
    clear temp laby i0 lab2;
end
if exist('labx','var') == 0 || isempty(labx)
    labx = {'X1'};
    for i0 = 2:nvarx
        lab2 = strcat('X',num2str(i0));
        labx = [labx; lab2];
    end        
    labelsX = labx;
    clear temp labx i0 lab2;
end
% Checking print.
if exist('print','var') == 0
    print = 1;
end
% Checking Sub-sample.
if exist('id','var') == 0  || isempty(id)
    id2 = 0;
else
    id2 = 1;
end

% Font size for labels
if nvary + nvarx < 9 
    fontsize = 10;
else
    fontsize = 8;
end

% Charts for state variables
figure(print)
temp = reshape(1:nvarx*nvary,nvarx,nvary)';
rowx = temp(end,:);
temp = temp(:,1);
jj = 1;
i3 = 1;
for i0 = 1:nvary    
    % Charts
    for i1 = 1:nvarx
        subplot(nvary,nvarx,jj)
        % Scatter plot
        h(1) = scatter(X(:,i1),Y(:,i0),15,[0 0.5 0.5],'filled');
        hline = refline;
        hline.Color = 'r';
        % Last point/selected data
        hold on
        h(2) = scatter(X(id==1,i1),Y(id==1,i0),15,[0.75 0 0],'filled');

        % Labels yx
        if max((jj==temp));
            ylabel(labelsY(i0),'FontSize',fontsize);
        end
        % Labels xs        
        if max((rowx == jj)) == 1
            xlabel(labelsX(i3),'FontSize',fontsize);
            i3 = i3 + 1;
        end
        jj = jj + 1;
    end
    box off
end

% Labels for legends
% Labels for legends
if id2 == 1
    if exist('labels2','var') == 0 || isempty(labels2)
        labels2 = [{'Full sample'}; {'Sub-sample'}];
    end
    legend1 = legend(h([1 2]),labels2);
    set(legend1,'FontSize',10,'Orientation','horizontal',...
    'Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
end
results = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
function [Zsave,Psave] = kfilter_LJ(y,F,H,Q,R,x,A,rho,mu)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero 
% Date: 12/Jun/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: This procedure uses filter from Hamilton's text. The code
% allows for a constant term or other exogenous regressors.
% Kalman Filter for State Space Model of Form:
%
% Z(t+1) = rho*mu  + F*Z(t)  + v(t+1) / State equation.
% y(t)   = A'*x(t) + H'*Z(t) + w(t)   / Observation equation.
%
% With E(v(t)*v(t)') = Q; and E(w(t)*w(t)') = R.
% Note: This version switches to the steady state state forecast error
% after Ptgtm1 converges
%
% Inputs:
%  y        : Data.
%  F        : Coeff. matrix state equation.
%  H        : Coeff. matrix for states in observation equation.
%  Q        : Cov. matrix state equation
%  R        : Cov. matrix observation equation.
%  x        : Exogenous variables.
%  A        : Coeff. matrix exo varibles, observation equation.
%  rho      : Coeff. vector param. for mean, state equation.
%  mu       : Coeff. vector for mean, state equation.
%
% Outputs:
%  Zsave   : State mean from kalman filter.
%  Psave   : State variance from kalman filter.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting data and matrices ready for KF code.
y  = y';
H  = H';
x  = x';
A  = A';
% Getting info from data
n      = size(y,2);
nstate = size(F,1);
sstate = 0;
if nargin == 7
   rho = 0;
   mu  = zeros(nstate,1);
end

% Matrix to store states mean and variance from filter
Psave = zeros(nstate,nstate*n);
Zsave = zeros(nstate,n);

% Start recursion at unconditional mean and variance.
Ztgtm1   = zeros(nstate,1);
Ptgtm1   = reshape(((eye(nstate^2) - kron(F,F))^(-1) * vec(Q))',nstate,nstate)';
Ptgttest = zeros(size(Ptgtm1,1),size(Ptgtm1,2));
Ptgt     = Ptgtm1;

% Do Kalman Filter Loop
for i = 1:n
    if sstate == 0
        % Variance of the prediction error.
        ihphr = pinv(H'*Ptgtm1*H+R);
        % Kalman gain.
        Kgain = Ptgtm1*H*ihphr;
        % Residual observable equation.
        yresid = y(:,i) - A'*x(:,i) - H'*Ztgtm1;
        % Updating equations.
        Ztgt = Ztgtm1 + Kgain*yresid;
        Ptgt = Ptgtm1 - Kgain*H'*Ptgtm1;
        
        % Checking steady state forecast error
        if (sum(sum(abs(Ptgttest-Ptgt),1)',1)/sum(diag(Ptgt),1)) <= 0.00000000001            
            sstate   = 1;
            % Variance of the prediction error.
            ihphrss  = ihphr;
            % State variance
            Ptgtm1ss = Ptgtm1;
            % Kalman gain.
            Kgainss  = Ptgtm1ss*H*ihphrss;
        end
        
        % Predicting equation (t+1).
        Ztgtm1 = rho*mu + F*Ztgtm1 + F*Kgain*yresid;
        Ptgtm1 = F*Ptgt*F' + Q;
    else
        % Residual observable equation.
        yresid = y(:,i) - A'*x(:,i) - H'*Ztgtm1;
        
        % Updating equations.
        Ztgt = Ztgtm1 + Kgainss*yresid;
        
        % Predicting equation (t+1).
        Ztgtm1 = rho*mu + F*Ztgtm1 + F*Kgainss*yresid;
    end

    % Saving results.
    Zsave(:,i) = Ztgt;
    Psave(1:nstate,((i-1)*nstate)+1:((i-1)*nstate)+nstate) = Ptgt;
    % Updating variance of the state to check convergence of steady state.
    Ptgttest = Ptgt;
end
% Saving states.
Zsave = Zsave';

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [St,y_res,y_fit,Pm] = kfilter_LJ(y,F,H,Q,RR,x,A,rho,mu,St00,P00)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero 
% Date: 12/Jun/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: This procedure uses filter from Hamilton's text. The code
% allows for a constant term or other exogenous regressors.
% Kalman Filter for State Space Model of Form:
%
% Z(t+1) = rho*mu  + F*Z(t) + v(t+1) / State equation.
% y(t)   = A*x(t)  + H*Z(t) + w(t)   / Observation equation.
%
% With E(v(t)*v(t)') = Q; and E(w(t)*w(t)') = R.
% Note: This version switches to the steady state state forecast error
% after Ptgtm1 converges
%
% Inputs:
%  y        : Data (T,nvar).
%  F        : Coeff. matrix state equation (nstate,nstate).
%  H        : Coeff. matrix for states in observation equation (nvar,nstate).
%  Q        : Cov. matrix state equation (nstate,nstate).
%  RR       : Cov. matrix observation equation (nvar,nvar).
%  x        : Exogenous variables (T,nexo).
%  A        : Coeff. matrix exo varibles, observation equation (nvar,nexo).
%  rho      : Coeff. vector param. for mean, state equation.
%  mu       : Coeff. vector for mean, state equation.
%  S00rho   : Iinitial states (1 x ns).
%  P00      : Initial value for covariance matrix for states variables (ns x ns).
%
% Outputs:
% Outputs:
%  St       : Filtered states variables (T,n_st)
%  y_res    : Filtered residual.
%  y_fit    : FIltered fit.
%  Pm       : Filtered ov matrix of states CK (T,n_st,n_st).
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting info from data
n      = size(y,1);
nstate = size(F,1);
sstate = 0;

% Checking deterministic terms obs. equation.
if exist('x','var') == 0 || isempty(x) == 1
	x = zeros(n,1);
    A = zeros(1,1);
end
% Checking deterministic terms state equation.
if exist('mu','var') == 0 || isempty(mu) == 1
	mu  = zeros(nstate,1);
    rho = 0;
end

% Getting data and matrices ready for KF code.
y  = y';
H  = H';
x  = x';
A  = A';

% Start recursion at unconditional mean and variance or given point.
if exist('St00','var')*exist('P00','var') == 0
    Ztgtm1   = zeros(nstate,1);
    Ptgtm1   = reshape(((eye(nstate^2) - kron(F,F))^(-1) * vec(Q))',nstate,nstate)';
    Ptgttest = zeros(size(Ptgtm1,1),size(Ptgtm1,2));
    Ptgt     = Ptgtm1;
else
    Ztgtm1   = rho*mu + (St00'*F)';
    Ptgtm1   = F*P00*F' + Q;
    Ptgttest = zeros(size(Ptgtm1,1),size(Ptgtm1,2));
    Ptgt     = Ptgtm1;
end

% Checking if H is a vector of parameters or data
if size(H,2) == size(x,2)
    H_check = 1;
else
    H_check = 0;
    HH = H;
end

% Case for fix R, check if R is a matrix.
if ismatrix(RR) == 1;
    R = RR;
end

% Do Kalman Filter Loop
for i = 1:n
    % Checking if Ht contains data.
    if H_check == 1
        HH = H(:,i);
    end

    % Checking if RR is time varying.
    if ndims(RR) == 3   
        R = RR(:,:,i);
    end
    
    if sstate == 0
        % Variance of the prediction error.
        ihphr = pinv(HH'*Ptgtm1*HH+R);
        % Kalman gain.
        Kgain = Ptgtm1*HH*ihphr;
        % Residual observable equation.
        yresid = y(:,i) - A'*x(:,i) - HH'*Ztgtm1;
        % Updating equations.
        Ztgt = Ztgtm1 + Kgain*yresid;
        Ptgt = Ptgtm1 - Kgain*HH'*Ptgtm1;
        
        % Checking steady state forecast error
        if (sum(sum(abs(Ptgttest-Ptgt),1)',1)/sum(diag(Ptgt),1)) <= 0.00000000001            
            sstate   = 1;
            % Variance of the prediction error.
            ihphrss  = ihphr;
            % State variance
            Ptgtm1ss = Ptgtm1;
            % Kalman gain.
            Kgainss  = Ptgtm1ss*HH*ihphrss;
        end
        
        % Predicting equation (t+1).
        Ztgtm1 = rho*mu + F*Ztgtm1 + F*Kgain*yresid;
        Ptgtm1 = F*Ptgt*F' + Q;
    else
        % Residual observable equation.
        yresid = y(:,i) - A'*x(:,i) - HH'*Ztgtm1;
        
        % Updating equations.
        Ztgt = Ztgtm1 + Kgainss*yresid;
        
        % Predicting equation (t+1).
        Ztgtm1 = rho*mu + F*Ztgtm1 + F*Kgainss*yresid;
    end

    % Saving results.
    Zsave(:,i) = Ztgt;
    Psave(i,:,:) = Ptgt;
    % Updating variance of the state to check convergence of steady state.
    Ptgttest = Ptgt;
    
    % Saving residuals.
    res(i,:)  = yresid;
end
% Saving results
St    = Zsave';
y_res = res;
y_fit = y' - y_res;
Pm    = Psave;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
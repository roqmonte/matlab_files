function results = STARx2(y,yl,x,setup)
%-------------------------------------------------------------------------%
% Matlab 7.1
% Autor: Roque Montero
% Date: 02/Feb/2015
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of a STARx(2) by maximun likelihood. The code 
% estimate the best STARx(2) model by minimizing SSR conditional to the 
% number of lags specified.
% Inputs:
%   y  : Endogenous vairable.
%   yl : Thresholds varialbes: lags of the dept. and/or exo. variables.
%   x  : Exogenous variables (excluding constant term).
%   setup  :
%   -.cte    : (0) no constant; (1) with constant term.
%   -.delay  : Max. variables to search over yl.
%   -.fnt    : Transition function: 'log', 'exp'.
%   -.method : White/NWest/OLS. HAC matrix correction to var/cov matrix.
%              Default: "NWest".
%
% Outputs:
%   results   :
%   -.info : Info of estimation
%   -.dta  : Data for each regime and estimation.
%   -.Est  : Results for OLS and STARx(2) models.
%   -.yhat : Fit of the model.
%   -.uhat : residuals.
%   -.id   : Dummy variable for regime.
%	-.delay  : delay parameter.
%	-.th     : threshold parameter
%	-.betas  : Estimation: OLS, b(1) b(2).
%	-.T      : Sample size.
%	-.k      : Number of parameters.
%   -.SSR    : SSR of models: OLS & STAR
%   -.R2     : R2 of models : OLS & STAR
%   -.AIC    : AIC of models: OLS & STAR
%   -.HQC    : HQC of models: OLS & STAR
%   -.BIC    : BIC of models: OLS & STAR
%
% Index.
% 1. Checking the inputs.
% 2. Setup of data.
% 3. Estimation.
% 4. Results.
% 5. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Checking the inputs.
if setup.cte == 0 && size(x,2) == 0 && size(yl,2) == 0;
    error('Wrong arguments for the code.');
end
if size(yl,2) == 0;
    error('Check variable: "yl".');
end

% Configuration
display('**********  Estimation STARx(2) Model  **********');
if setup.cte == 0;
    display('* Without constant term')
else
    display('* With constant term')
end
if size(x,2) == 0;
    display('* Without exogenous variables')
else 
    display(['* Nunmber of exogenous variables: ', num2str(size(x,2))] );
end
display(['* Number of lags: ', num2str(size(yl,2))] );
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Setup of data.

% Original data back up.
if setup.cte == 1;
    dta = [y ones(size(y,1),1) x yl];
elseif setup.cte == 0;
    dta = [y x yl];
end;

% Creating variables for estimation.
% Lag parameter.
if setup.delay > size(yl,2);
    maxd = size(yl,2);
else
    maxd = setup.delay;
end

% Final data for estimation
y = dta(:,1);
x = dta(:,2:end);
% Sample information
T = size(y,1);
k = size(x,2);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Estimation.

% Matrix to store results
SSRini = zeros(maxd,2);
C      = zeros(maxd,1);
gamma  = zeros(maxd,1);
% Estimation STARx2(p) model for several values of the delay parameter.
for i0 = 1:maxd;
    [SSRini(i0,:),C(i0),gamma(i0)] = st1(dta,setup,yl(:,i0));
end
% Choosing parameters to min SSR star model.
[SSRsetar,dl] = min(SSRini(:,2));
% Threshold estimation (gamma);
thf = th(dl);
% Computing threshold statistic of the linearity test Hansen (1999).
SSRols = SSRini(1,1);
F = T*( (SSRols - SSRsetar) / SSRsetar);    
clear i0 th;

% SETARx(2) Estimation.
% Less or equal to th / Greater than th.
auxle = le(yl(:,dl),thf);
auxgt = gt(yl(:,dl),thf);
% Spliting the sample
dta1 = msel(dta,auxle);
dta2 = msel(dta,auxgt);
% OLS and SETAR estimation for each model.
r0 = OLSest(dta(:,1),dta(:,2:end),'NWest');
r1 = OLSest(dta1(:,1),dta1(:,2:end),'NWest');
r2 = OLSest(dta2(:,1),dta2(:,2:end),'NWest');

% Fit of the model.
yhat = zeros(size(dta,1),1);
idrg = zeros(size(dta,1),1);
for i = 1:size(dta,1);
    if yl(i,dl) <= thf;
        yhat(i,1) = dta(i,2:end)*r1.b;
        idrg(i,1) = -1;
    else
        yhat(i,1) = dta(i,2:end)*r2.b;
        idrg(i,1) = 1;
    end;    
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Results.
% Other results.
T1   = size(r1.uhat,1);
T2   = size(r2.uhat,1);
uhat = y - yhat;
e1   = r1.uhat;
e2   = r2.uhat;

% Estimation info
results.info = setup;
results.yhat = [y r0.yhat yhat];
results.uhat = [r0.uhat uhat];
results.id   = idrg;
results.delay = dl;
results.th    = thf;
results.betas = [r0.b r1.b r2.b];
results.T     = [T T1 T2];
results.k     = k;
% Estimation data.
results.dta.ols  = dta;
results.dta.mod1 = dta1;
results.dta.mod2 = dta2;
% Estimation Results.
results.SSR(1,1)= SSRols;
results.SSR(1,2)= SSRsetar;
results.R2(1,1) = r0.R2;
results.R2(1,2) = ((yhat - mean(y))'*(yhat - mean(y))) / ((y - mean(y))'*(y - mean(y)));
results.AIC(1,1)= r0.AIC;
results.HQC(1,1)= r0.HQC;
results.BIC(1,1)= r0.BIC;
results.AIC(1,2)= log((e1'*e1)/T1) + 2*(k/T1)              + log((e2'*e2)/T2) + 2*(k/T2);
results.HQC(1,2)= log((e1'*e1)/T1) + 2*(k/T1)*log(log(T1)) + log((e2'*e2)/T2) + 2*(k/T2)*log(log(T2));
results.BIC(1,2)= log((e1'*e1)/T1) +   (k/T1)*log(T1)      + log((e2'*e2)/T2) +   (k/T2)*log(T2);
% OLS-SETARx(2).
results.EstD.ols    = r0;
results.EstD.mod1   = r1;
results.EstD.mod2   = r2;
% Threshold test and statistic.
results.test.F  = F;
results.test.th = thf;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 5. Functions.
% Function estimate a STARx(2) model.
function [SSR,C,gamma]  = st1(data,setup,yl)
% Inputs:
%   dta   : data.
%   setup : Option of the code.
%   dta   : Threshold variables.
%
% Output:
%   SSR  : Sum square residuals OLS and SETAR models.
%   C    : Threshold value for the transition function.
%   gamma: Smoothness parameter.

% Creating data for estimation.
y = data(:,1);
x = data(:,2:end);

% Initial values
C0 = mean(yl);
g0 = 0.5;
raux = OLSest(y,x);
theta0 = [C0;g0;raux.b;raux.b*randn];

% Computing the Hessian matrix.
H = fdhess('STAR_aux',theta0,y,x,setup);
H0inv = H\eye(size(H));
% Checking the consistency of the Hessian Matrix.
if max(max(isnan(H0inv))) == 1 || max(max(isinf(H0inv))) == 1;
    H = eye(size(thetatran,1));
else
    [V,Diag] = eig(H0inv);
    Diag     = abs(Diag);
    H        = V*Diag*V';
end;
% Optimizaci�n.
tol = 1e-08; n_ite = 2000; 
[~,xh,gh,H] = csminwel('MSarp_evalf',thetatran,H,[],tol,n_ite,y,x,setup);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
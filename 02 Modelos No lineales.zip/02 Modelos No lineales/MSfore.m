function results = MSfore(y,yl,x,setup)
%-------------------------------------------------------------------------%
% Matlab 7.1
% Autor: Roque Montero
% Date: 29/jan/2015
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation/forecast MSAR(p) model by maximum likelihood. 
% Note, data for code is consistent with the following notation (row t):
%                               y(t) = A*y(t-h) + e(t)
% Where y(t) = f(y(t),y(t-h)) and y(t-h) = f(y(t-h),y(t-h-1)).
% Inputs.
%   y  : Endogenous vairable.
%   yl : Matrix with lags of the dept. variable.
%   x  : Independet variables (constant term by default if not included in first col).
%   setup  :
%   -.St    : Number of regimes (up to three).
%   -.mod   : Discrete variable for the model.
%             (1) All the parameters change with the regimen.
%             (2) Constants change with the regimen.
%             (3) Betas change with the regimen.
%             (4) Sigmas2 change with the regimen.
%             (5) Constants and betas change with the regimen.
%             (6) Constants and Sigma2 change with the regimen.
%             (7) Betas and Sigma2 change with the regimen.
%   -.mfore : (0) recursive estimation; (1) rolling estimation.
%   -.fopt  : (0) Estimate SETAR once with initial estimation window (Default)
%             (1) Estimate SETAR each time new obs is added from eval window.
%   -.frp  : Number of observation for evaluation.
%   -.fhr  : Forecast horizon; (1) computes direct and recursive forecast.
%
% Outputs:
%   results:
%   -.dta     : Initial data.
%   -.dtf     : Initial evaluation sample.
%   -.param   : Vector of parameters.
%   -.yhat    : In-sample fit.
%   -.uhat    : In-sample residuals.
%   -.ForeF   : Type of forecast.
%   -.yeft    : Vector with forecast data.
%   -.fore    : Vectot h-steap-ahead forecas (direct forecast).
%   -.fore_rec: Matrix h-steap-ahead forecas (per column, recursive forecast).
%   -.ForeT   : Estimation method.
%   -.setup   : Options.
%   -.filter  : #times the filter forecast was applied.
%   -.niter   : Number of iterations.
%
% Index.
% 1. Data setup.
% 2. Forecast.
% 3. Functions.   
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Data setup.
% Checking inputs.
if size(x,2) == 0 && size(yl,2) == 0
    error('Wrong arguments for the code.');
end
if isfield(setup,'fopt') == 0
    setup.fopt = 0;
end
% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
% Configuration SETAR model for the estimation of the intial values for the
% numerical optimization of the likelihood.
sp.thr = 0;
% Options
P = setup.frp;
% Data
dta  = [y x yl];
ylini= []; 
ylf  = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Forecast.
h_wait = waitbar(0,'Generating forecast, please wait...');
% Forecasting.
wx = 1;
for w = 1:P+1-setup.fhr
    % Waiting bar.
    waitbar(w/setup.frp,h_wait)
    % Forecast exercise (recursive or rolling estimation).
    if setup.mfore == 1
        wx = w;
    end
    % Generating Dependent variable.
    yini = y(wx:end-P+w-1,:);        
    % Spliting yl matrix (it could contain lags values).    
    if size(yl,2) > 0
        ylini= yl(wx:end-P+w-1,:);
        ylf  = yl(end-P+w:end,:);
    end    
    % Generating Exogenous variables.
    xini= x(wx:end-P+w-1,:);
    xf2 = x(end-P+w:end,:);
    
    % Model estimation.
    % Fixing initial values for the estimation of the MSAR model, otherwise
    % SETAR model is estimated each time a new obs. is available from the
    % evaluation window.
    if w == 1 && setup.fopt == 0
        eval(['setup.paramini = SETARx' num2str(setup.St) '(y,[x yl],sp);']);
    end;    
    res_o = MSarp(yini,ylini,xini,setup); 
    param(w,:) = [res_o.Param.betas(:); res_o.Param.Sg2(:); res_o.Param.P(:)]';
    uhat(w).u  = res_o.uhat;
    yhat(w).yt = res_o.yhat;
    
    % Forecasting.
    setup.junk  = w;
    [fcast(:,w), Etfore(:,:,w),idx] = fore(yini,xf2,ylf,setup,res_o);
    id(w) = idx;
    niter(w) = res_o.niter;
    clear res_o;
end
close(h_wait)

% Formating the results.
if setup.fhr > 1
    fcast = fcast(1,:)';
    ForeF = {'Direct forecast'};
elseif setup.fhr == 1
    results.fore_rec = format(fcast,P);
    fcast = fcast(1,:)';   
    ForeF = {'Recursive forecast'};    
end

% Results.
results.dta  = [dta(1:end-P,1)     dta(1:end-P,2:end)];
results.dtf  = [dta(end-P+1:end,1) dta(end-P+1:end,2:end)];
results.Etfore= Etfore;
results.Param = param;
results.info  = setup;
results.filter= id;
results.niter = niter;
% Forecast info options.
results.ForeF = char(ForeF);
results.yeft = dta(end-P+1:end,1);
results.fore = fcast;
results.yhat = yhat;
results.uhat = uhat;
if setup.mfore == 0
    results.ForeT = 'Recursive Estimation';
else
    results.ForeT = 'Rolling window estimation';
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Funciones.
% Function calculates the h step ahead forecast matrix.
function [yf,Etfore,id] = fore(y,xf,ylf,setup,param)
% Imputs.
%   y      : Data from Estimation window, target variable.
%   xf     : Data from Evaluation window, exo variables.
%   ylf    : Lags from Evaluation window, lags.
%   setup  : options.
%   param  : Vector of parameters
% Outputs:
%   yf      : h step ahead forecast.
%   Etfore  : Forecast of the state.
%   id      : Forecast filter id.

% Parameters of the model.
betas = param.Param.betas;
Pmat  = param.Param.P;
Smt   = param.Smt;

% Matrix to store results.
yf     = zeros(setup.frp,1);
Etfore = zeros(setup.frp,2);
% Id variable.
junk   = setup.junk-1;
% Defining filter.
mod = 'max';
if strcmp(mod, 'max')
    trimb = max(abs(y));
elseif strcmp(mod, 'desv')
    trimb = std(y);
end;

% Direct forecast for h = 1 and recursive forecast.
if setup.fhr == 1
    % Reshape of variables.
    ar   = size(ylf,2);
    yaux = y(end-ar+1:end);
    yfun = yaux(size(yaux,1):-1:1);
    clear yaux;
    % Forecasting.
    for i = 1:setup.frp-junk
        % Forecasting.
        yf2 = [xf(i,:) yfun']*betas;
        % Forecast of the state.
        Et_plus_k = Pmat^(i)*Smt(end,:)';
        Etfore(i,:) = Et_plus_k';
        % Forecast dependent variable.
        yf3b = yf2*Et_plus_k;
        % Applying insanity filter
        [yf3,id] = insanity(y,yf3b,trimb);
        % Storing forecast.
        yf(i,1) = yf3;
        % Adding forecast for recursive forecast.
        y   = [y; yf3];
        % Sorting forecast.
        yaux = y(end-ar+1:end);
        yfun = yaux(ar:-1:1);
        clear yaux yf2 yf3 yf3b;
    end

% Direct forecast for h > 1: y_{t+h|t}
elseif setup.fhr > 1
    % Forecast horizon.
    hf = setup.fhr;
    % Condition for lags.
    yl_aux = [];
    if size(ylf,2) > 0
        yl_aux = ylf(hf,:);
    end
    % Forecasting.
    yf2 = [xf(hf,:) yl_aux]*betas;
    % Forecast of the state.
    Et_plus_k = Pmat^(1)*Smt(end,:)';
    Etfore(1,:) = Et_plus_k';
	% Forecast.
	yf3 = yf2*Et_plus_k;
    % Applying insanity filter
    [yf,id] = insanity(y,yf3,trimb);
end

% Insanity filter: Swason & White (1995).
function [yfil,id]= insanity(y,yf,trimb)
% Imputs.
%   y     : Endogenous variable.
%   yf    : Forecast.
%   trim  : Threshold for filtering forecast.
% Outputs:
%   yfil  : Filter forecast.
%   id    : Tag of filter.
% Filtering
if abs(yf) > trimb
    yfil = mean(y);
    id = 1;
else
    yfil = yf;
    id = 0;
end

% Formating the forecast.
function fcast = format(fcast,a)
% Imputs.
%   fcast : Matrix forecast raw.
%   a     : Size evaluation window.
% Outputs:
%   fcast : Forecast Matrix (each row: h-step-ahead forecast).
fcast = fcast';
% Forecast
fcast2 = NaN(a,a);
i = 1;
for j0 = 1:a
    fcast2(i:end,j0)= fcast(1:end-i+1,j0);
    i = i + 1;
end
fcast = fcast2;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
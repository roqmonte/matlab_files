function [logf,e0,sm,param,yhat,uhat] = MSarp_evalf(theta,y,x,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Jan/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Evaluation of the log-likelihood of an MRAR(p) model.
%   mod  : Discrete variable for the model.
%   -(1) All the parameters change with the regimen.
%   -(2) Constants change with the regimen.
%   -(3) Betas change with the regimen.
%   -(4) Sigmas2 change with the regimen.
%   -(5) Lags change with the regime.
%   -(6) Exo variables change with the regime (other than lags).
%   -(7) Constants and betas change with the regimen.
%   -(8) Constants and Sigma2 change with the regimen.
%   -(9) Betas and Sigma2 change with the regimen.
%
% Imputs: 
%   theta: Value for the vector of parameter.
%   y    : Endogenous variable.
%   x    : Independet variables.
%   setup:
%   -.St : Number of regimes (up to three).
%   -.mod: Discrete variable for the model.
%
% Outputs:
%   logf : Log-like function.
%   e0   : Filter probabilities.
%   sm   : Smoothed probabilities.
%   param: parameters for each regime
%   yhat : fit of the model.
%   uhat : in-sample residuals.
% 
% Index:
% 1. Initial Setup
% 2. Evaluation.
% 3. Filter and Smoothed Probabilities.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Initial Setup
St = setup.St;
mod= setup.mod;
T  = size(y,1);

% Transition Matrix definition.
p = zeros(St,St);
if St == 2
    p(1,1) = theta(end-1).^(2) / (1 + theta(end-1).^(2));
    p(2,1) = 1 - p(1,1);
    p(1,2) = theta(end).^(2) / (1 + theta(end).^(2));
    p(2,2) = 1 - p(1,2);
elseif St == 3
    p(1,1) = theta(end-5).^(2) / (1 + theta(end-5).^(2) + theta(end-2).^(2));
    p(2,1) = theta(end-2).^(2) / (1 + theta(end-5).^(2) + theta(end-2).^(2));
    p(3,1) = 1 - (p(1,1) + p(2,1));
    p(1,2) = theta(end-4).^(2) / (1 + theta(end-4).^(2) + theta(end-1).^(2));
    p(2,2) = theta(end-1).^(2) / (1 + theta(end-4).^(2) + theta(end-1).^(2));
    p(3,2) = 1 - (p(1,2) + p(2,2));
    p(1,3) = theta(end-3).^(2) / (1 + theta(end-3).^(2) + theta(end).^(2));
    p(2,3) = theta(end).^(2) / (1 + theta(end-3).^(2) + theta(end).^(2));
    p(3,3) = 1 - (p(1,3) + p(2,3));
end;

% Ergodic probabilities, initial values for the filter prob.
A = [eye(size(p,1)) - p; ones(1,size(p,1))] ;
e = (A'*A)\(A')*eye(St+1);
e = e(:,end);
clear A;

% Computing Betas and Sg2 for each version of the model.
[beta,l] = msar_cases(theta,x,setup.kaux,St,mod);
% Transformation to assure Sg2 is gt 0.
sg2 = l.^(2);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Evaluation.
% Restricting the log-like.
if max(abs(p(:))) > 1 || min(p(:)) < 0 || round(sum(sum(p))) ~= St
    logf = inf;

else    
    % Log-Likelihood evaluation.
    yy = repmat(y,1,St);
    part1 = repmat((2*pi*sg2).^(-1/2),size(y,1),1);
    part2 = exp( - (yy-x*beta).^2 .* repmat(0.5./sg2,size(y,1),1));
    ll    = part1 .* part2;
    clear part1 part2;
    % Conditional density and uptating of e(j,t).
    e0 = zeros(T+1,St);
    e0(1,:) = e;
    logf = 0;
    for i = 1:T
        % Updating (forecasting) the state (t+1|t).
        if i == 1
            e1 = e0(i,:);
            fi = e1*ll(i,:)';
        else
            e1 = e0(i,:)*p';
            fi = e1*ll(i,:)';
        end
        % Conditional density of yt
        logf = logf + log(fi);
        % Filter Probability (t|t)
        e0(i+1,:) = (e1.*ll(i,:))/fi;
    end
    % log-likelihood.
    logf = -1*logf;
end;
clear i e1 fi;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Filter and Smoothed Probabilities.
if nargout > 1
    % Filter probability
    e0 = e0(2:end,:);
    % Forecast of the state (t+1|t).
    e1 = zeros(T,St);
    for i = 1:T
        e1(i,:) = (p*e0(i,:)')';
    end;
    % Smoothed probabilities.    
    sm(T,:)=e0(T,:);
    for i = T-1:-1:1
        sm(i,:)= e0(i,:)'.*((p'*(sm(i+1,:)./ e1(i,:))'));
    end; 
    % Parameters.
    param.betas = beta;    
    param.Sg2   = sg2;
    param.P     = p;
    % Computing residuals and fit
    yhat = sum((x*beta).*sm,2);
    uhat = sum((yy-x*beta).*sm,2);
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions
% Function generates the parameters from theta, conditional to the model
% version.
function [beta,sg2] = msar_cases(theta,x,K,St,mod)
% Imputs.
%   theta: Vector of parameters
%   x    : Exo variables.
%   K    : # of parameters for exo and lags.
%   St   : Number of regimems.
%   mod  : Id. tyoe of model.
%
% Outputs:
%   beta  : Betas.
%   sg2   : Sg2.
% # of parameters for each block of the model.
kx = K(1);
ky = K(2);
k  = kx + ky;
% Case(1)
if mod == 1
    beta = reshape(theta(1:k*St,1),k,St);
    sg2  = theta(k*St+1:k*St+St)';
% Case(2)
elseif mod == 2
    beta = [theta(1:St,1)'; repmat(theta(St+1:St+(k-1),1),1,St)];
    sg2  = repmat(theta(St+size(x,2)-1+1,1),1,St);
% Case(3)
elseif mod == 3
    beta = [repmat(theta(1,1),1,St); reshape(theta(2:(k-1)*St+1,1),k-1,St)];
    sg2 =  repmat(theta((k-1)*St+1+1,1),1,St);
% Case(4)
elseif mod == 4
    beta = repmat(theta(1:k,1),1,St);
    sg2  = theta(k+1:k+St)';
% Case(5)
elseif mod == 5
    beta = [repmat(theta(1:kx),1,St); reshape(theta(kx+1:kx+ky*St),ky,St)];
    sg2  = repmat(theta(kx+ky*St+1),1,St);
% Case(6)
elseif mod == 6
    beta = [repmat(theta(1),1,St); reshape(theta(2:kx*St-1),kx-1,St); repmat(theta(kx*St:kx*St+ky-1),1,St)];
    sg2  = repmat(theta(kx*St+ky),1,St);
% Case(7)
elseif mod == 7
    beta = reshape(theta(1:k*St,1),k,St);
    sg2  = repmat(theta(k*St+1),1,St);
% Case(8)
elseif mod == 8
    beta = [theta(1:St,1)'; repmat(theta(St+1:St+(k-1),1),1,St)];
    sg2  = theta(St+(k-1)+1:St+(k-1)+St)';
% Case(9)
elseif mod == 9
    beta = [repmat(theta(1,1),1,St); reshape(theta(2:(k-1)*St+1,1),k-1,St)];
    sg2  = theta((k-1)*St+1+1:(k-1)*St+1+St,1)';
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
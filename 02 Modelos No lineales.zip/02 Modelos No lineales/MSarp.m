function results = MSarp(y,yl,x,setup,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Jan/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of a MS-AR(p) model, with transition probability
% P, where P is given by:
%
%     |  P11  P21 ... Pj1  |
%     |  P12  P22 ... Pj2  |
% P = |   :    :  ...  :   |
%     |   :    :  ...  :   |
%     |  P1j  P2j ... Pjj  |
%
% Where Pkj is the probability of moving from regime k to j. The parameters
% are ordered in the following way:
% theta = [beta_reg1; beta_re2...; beta_regj; ...
%         [Sg2_reg1 ; Sg2_re2 ...; Sg2_regj;  ...
%         [P11; P21 ; ...; Pj1; P12; P22;...; Pj2;..
%         [...; P1(j-1); P2(j-1); ...; Pj(j-1)]
% 
% Imputs:
%   y   : Endogenous variable.
%   yl  : Matrix with lags of the dept. variable.
%   x   : Independet variables (constant term by default if not included).
%   setup :
%   -.St  : Number of regimes (Default: 2).
%   -.mod : Discrete variable for the model (Default: 1).
%          (1) All the parameters are regimen switching.
%          (2) Constants terms are regimen switching.
%          (3) Betas are regimen switching.
%          (4) Sigmas2 are regimen switching.
%          (5) Lags dep. variable are regimen switching.
%          (6) Exo variables are regimen switching (other than lags).
%          (7) Constants and betas are regimen switching.
%          (8) Constants and Sigma2 are regimen switching.
%          (9) Betas and Sigma2 are regimen switching.
%   -.paramini : Initial values for theta (output consistent SETAR results).
%                (Default: parameters from SETAR model).
%   print   : (1) Do charts and print results on screen.
%   labels  : Column vector with labels for dep. and indep variables.
%   dates   : Vector with info for dates: [year,month,freq].
%             Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results   :
%   -.logf     : Loglikelihood.
%   -.Fil      : Filter probability.
%   -.Smt      : Smoothed probability .
%   -.thetaini : Theta ini.
%   -.H        : Inverse Hessian matrix (var/cov matrix).
%   -.niter    : Number of iterations.
%   -.dta      : Data estimation.
%   -.yhat     : Fit of the model, based on smoothed prob.
%   -.yhat2    : Fit of each regime.
%   -.uhat     : in-sample residuals model, based on smoothed prob.
%   -.uhat2    : in-sample residuals from each regime.
%   -.thetaf   : Theta hat.
%   -.Param    : Parameters of the model.
%   -.Pval     : Asymtotic Pvalues.
%   -.Sg2      : variance.
%   -.SSR      : Sum square resids.
%   -.R2       : R-square.
%   -.R2adj    : Adjusted R-square.
%   -.AIC      : AIC.
%   -.HQC      : HQC.
%   -.BIC      : BIC.
%   -.T        : Sample size.
%   -.k        : Number of parameters.
%   -.irf      : IRF up to max-horizon.
%   -.table    : Table with print results.
%
% Index:
% 1. Initial Setup.
% 2. Estimation of MSAR models.
% 3. Additional results.
% 4. Function.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%  
% 1. Initial Setup.
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end

% Checking inputs.
if size(x,2) == 0 && size(yl,2) == 0
    error('Wrong arguments for the code.');
end
if size(yl,2) == 0 && setup.mod == 5
    error('Wrong arguments for the code.');
end
if size(x,2) == 0 && setup.mod == 6
    error('Wrong arguments for the code.');
end
if size(x,2) == 1 && mean(x(:,1),1) ~= 1 && setup.mod == 6
    error('Wrong arguments for the code.');
end
if isfield(setup,'St') == 0
    setup.St = 2;
end
if isfield(setup,'mod') == 0
    setup.mod = 1;
end
if isfield(setup,'paramini') == 0
    setup.paramini = [];
end
% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end

% Checking labels.
lab_yl = [];
for i0 = 1:size(yl,2)
    lab_yl2 = strcat('ylag',num2str(i0));
    lab_yl = [lab_yl; lab_yl2];
end
if exist('labels','var') == 0 || isempty(labels)
    lab_x = {'dep var'};
    for i0 = 2:size(x,2)
        lab_x2 = strcat('xvar ',num2str(i0-1));
        lab_x = [lab_x; lab_x2];
    end
else
    lab_x = labels;
end
labels = [lab_x; lab_yl];
clear lav_yl lav_yl2 lab_x lab_x2

% Info for estimation
St    = setup.St;
mod   = setup.mod;
if size(setup.paramini,1) == 0
    % Initial values.
    setup.thr  = 0; 
    eval(['setup.paramini = SETARx' num2str(St) '(y,[x yl],setup);']);
end
% Initial values.
setup.kaux = [size(x,2) size(yl,2)];
[betas,l,p_l] = initial_param(setup.paramini,St,mod,setup.kaux);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation of MSAR model.
% Infor for the opt. routine.
theta = [betas;l;p_l];
x = [x yl];
T = size(y,1);

% Hessian Matrix.
H = fdhess('MSarp_evalf',theta,y,x,setup);
H0inv = H\eye(size(H));
% Checking the consistency of the Hessian Matrix.
if max(max(isnan(H0inv))) == 1 || max(max(isinf(H0inv))) == 1 || isreal(H0inv) == 0 || isreal(H) == 0
    H = eye(size(theta,1));
else
    [V,Diag] = eig(H0inv);
    Diag     = abs(Diag);
    H        = V*Diag*V';
end
% Numerical Optimizaci�n.
tol = 1e-08; n_ite = 2000; 
[~,thetaf,~,H,~,~,niter] = csminwel('MSarp_evalf',theta,H,[],tol,n_ite,y,x,setup);

% Filter and Smoothed probabilities.
[lf,e0,sm,param,yhat,uhat] = MSarp_evalf(thetaf,y,x,setup);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Pvalues of parameters.
k   = size(thetaf,1);
nb  = size(betas,1);
nbx = size(x,2) - size(yl,2);
vb  = diag(H(1:nb,1:nb));
bms = thetaf(1:nb);
tts = bms ./ vb.^(1/2);

% Results.
results.logf     = -1*lf;
results.Fil      = e0;
results.Smt      = sm;
results.thetaini = setup.paramini;
results.H        = H;
results.niter    = niter;

% Estimation results.
results.dta    = [y x];
results.yhat   = yhat;
results.yhat2  = x*param.betas;
results.uhat   = uhat;
results.uhat2  = repmat(y,1,St) - results.yhat2;
results.thetaf = thetaf;
results.Param  = param;

% Pvalues.
Pvalb = 2*(1-tcdf(abs(tts),T - size(H,1)));
for i0 = 1:length(Pvalb)
   if Pvalb(i0,1) < 0.001
        Pvalb(i0,1) = 0;
   end
end
% Building matrix with results.
kx = setup.kaux(1);
ky = setup.kaux(2);
if setup.mod == 1
    results.Param.Pvalb = reshape(Pvalb,nb/St,St);
elseif setup.mod == 2
    results.Param.Pvalb = [Pvalb(1:St)'; repmat(Pvalb(St+1:end),1,St)];
elseif setup.mod == 3
    results.Param.Pvalb = [repmat(Pvalb(1),1,St); reshape(Pvalb(2:end),(nb-1)/St,St)];
elseif setup.mod == 4
    results.Param.Pvalb = repmat(Pvalb,1,St);
elseif setup.mod == 5
    results.Param.Pvalb = [repmat(Pvalb(1:nbx),1,St); reshape(Pvalb(nbx+1:end),ky,St)];
elseif setup.mod == 6
    results.Param.Pvalb = [repmat(Pvalb(1),1,St); reshape(Pvalb(2:kx*St-1),kx-1,St); repmat(Pvalb(kx*St:kx*St+ky-1),1,St)];
elseif setup.mod == 7
    results.Param.Pvalb = reshape(Pvalb(1:(kx+ky)*St,1),kx+ky,St);
elseif setup.mod == 8
    results.Param.Pvalb = [Pvalb(1:St,1)'; repmat(Pvalb(St+1:St+((kx+ky)-1),1),1,St)];
elseif setup.mod == 9    
    results.Param.Pvalb = [repmat(Pvalb(1,1),1,St); reshape(Pvalb(2:((kx+ky)-1)*St+1,1),(kx+ky)-1,St)];
else
    error('Fix this part of the code');    
end

% Building IRF
if size(yl,1) > 0
    yl_coef = results.Param.betas(nbx+1:end,:);
    p   = size(yl,2);
    irf = zeros(24,St);
    J   = [eye(1) zeros(1,p-1)];
    for i0 = 1:St                
        % Building IRF using Companion form of the model                
        A = yl_coef(:,i0)';
        if p == 1
            F = A;
        elseif p > 1
            F = [A; [eye(p-1) zeros(p-1,1)]];
        end
        % Storing IRF up to h-horizon.
        for i = 0:23
            irf(i+1,i0) = J*(F)^(i)*J';
        end
    end
else
    irf = [];
end

% More results
results.SSR  = uhat'*uhat;
results.Sg2  = results.Param.Sg2;
results.R2   = 1 - results.SSR / ((y-mean(y))'*(y-mean(y)));
results.R2adj= 1 - (1 - results.R2)*(T - 1)/(T - k);
results.AIC  = -(2/T)*results.logf + 2*(k/T);
results.HQC  = -(2/T)*results.logf + 2*(k/T)*log(log(T));
results.BIC  = -(2/T)*results.logf + (k/T)*log(T);
results.T    = T;
results.k    = k;
results.irf  = irf;
% Table.
results.table = print_res(results,setup,labels,print);

% Do charts
if print == 1       
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1];
    end
    print_charts(results,dates,labels);
end    
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Function.
% Function computes intial values for estimation.
function [betas,l,p_l] = initial_param(p_ini,St,mod,K)
% Imputs.
%   p_ini: Initial values for the parameters.
%   St   : # of regimes
%   mod  : Id model.
%   K    : # of parameters for exo and lags.
% Outputs:
%   betas : Betas.
%   l     : Sg2 transformation to assure Sg2 t 0.
%   pbs   : transition probabilities (transformed).
% # of parameters for each block of the model.
kx = K(1);
% Selecting the number of states and defining initial values for the prob.
if St == 2
    p_l = ones(2,1);
elseif St == 3
    p_l = ones(6,1)*(1/2);
else
    error('Wrong number of regimes.');
end
% Transformation of P.
p_l = p_l.^(0.5);
% Case(1): All the parameters change with the regimen.
if mod == 1
    % Initial Values
    betas = p_ini.betas(:);
    sigma = p_ini.Sg2(:);
    
% Case(2): Constants change with the regimen.
elseif mod == 2
    betas = [p_ini.betas(1,:)'; mean(p_ini.betas(2:end,:),2)];
    sigma = mean(p_ini.Sg2,2);
 
% Case(3): Betas change with the regimen.
elseif mod == 3
    betas = [mean(p_ini.betas(1,:),2); vec(p_ini.betas(2:end,:))];
    sigma = mean(p_ini.Sg2,2);
    
% Case(4): Sigmas2 change with the regimen.
elseif mod == 4
    betas = mean(p_ini.betas,2);
    sigma = p_ini.Sg2(:);
        
% Case(5): Lags change with the regime.
elseif mod == 5
    betas = [mean(p_ini.betas(1:kx,:),2); vec(p_ini.betas(kx+1:end,:))];
    sigma = mean(p_ini.Sg2,2);
    
% Case(6): Exo variables change with the regime (other than lags).
elseif mod == 6
    betas = [mean(p_ini.betas(1,:),2); vec(p_ini.betas(2:kx,:)); mean(p_ini.betas(kx+1:end,:),2)];
    sigma = mean(p_ini.Sg2,2);
    
% Case(7): Constants and betas change with the regimen.
elseif mod == 7
    betas = p_ini.betas(:);
    sigma = mean(p_ini.Sg2,2);
    
% Case(8): Constants and Sigma2 change with the regimen.
elseif mod == 8
    betas = [p_ini.betas(1,:)'; mean(p_ini.betas(2:end,:),2)];
    sigma = p_ini.Sg2(:);

% Case(9): Betas and Sigma2 change with the regimen.
elseif mod == 9  
    betas = [mean(p_ini.betas(1,:),2); vec(p_ini.betas(2:end,:))];
    sigma = p_ini.Sg2(:);
    
else
    error('Wrong case definition.');
end;
% Transformation sg2.
l = sigma.^(0.5);

% Funtion do table.
function Estimation_results = print_res(results,setup,labels,print)
% labels for exo variables.
lab_0 = labels(2:end);
lab1 = {'cte'};
for i0 = 2:length(results.Param.betas)
    lab2 = lab_0(i0-1,:);
    lab1 = [lab1 lab2];
    clear lab2;
end
% Sigma square.
lab = lab1';
clear lab1 i i0;

% Building table
St = size(results.Param.betas,2);
% Regime 1
reg1   = [lab num2cell([results.Param.betas(:,1) results.Param.Pvalb(:,1)])];
labels = {'Reg. 1' 'Param' 'Pvalue'};
temp_1 = ['Sg2' num2cell(results.Sg2(1)) ' '];
Reg_1  = [labels; reg1; temp_1];
clear labels temp_1 reg1;
% Regime 2
reg2   = [lab num2cell([results.Param.betas(:,2) results.Param.Pvalb(:,2)])];
labels = {'Reg. 2' 'Param' 'Pvalue'};
temp_1 = ['Sg2' num2cell(results.Sg2(2)) ' '];
Reg_2  = [labels; reg2; temp_1];
clear labels temp_1 reg2;
% Regime 3
if St == 2
    Reg_3  = [];
elseif St == 3
    reg3   = [lab num2cell([results.Param.betas(:,3) results.Param.Pvalb(:,3)])];
    labels = {'Reg. 3' 'Param' 'Pvalue'};
    temp_1 = ['Sg2' num2cell(results.Sg2(3)) ' '];
    Reg_3  = [labels; reg3; temp_1];
    clear labels temp_1 reg3;
end

% Formating table
nmax  = max([size(Reg_1,1) size(Reg_2,1) size(Reg_3,1)]);
Part_1= repmat({'' '' '' '' '' '' '' '' ''},nmax,1);
Part_1(1:size(Reg_1,1),1:3) = Reg_1;
Part_1(1:size(Reg_2,1),4:6) = Reg_2;
if St == 3
    Part_1(1:size(Reg_3,1),7:9) = Reg_3;
end

% Second part
temp_1 = {'AIC'; 'HQC';  'BIC'};
temp_2 = num2cell([results.AIC;results.HQC;results.BIC]);
temp_3 = [{'SSR'; 'R2'; 'R2adj'} num2cell([results.SSR;results.R2;results.R2adj])];
temp_4 = [{'T'} num2cell(results.T); {'k'} num2cell(results.k); {'Iterations'} num2cell(results.niter)];
temp_5 = [{'#Regime'} num2cell(St) {'logf'} num2cell(results.logf) {'Model'} num2cell(setup.mod)];
stats  = [[{'' '' '' '' '' ''}; temp_1 temp_2 temp_3 temp_4; temp_5] repmat({'' '' ''},5,1)];
clear temp_1 temp_2 temp_3 temp_4 temp_5;
% Transition matrix
aux = results.Param.P;
for i0 = 1:St
    for i1 = 1:St
        if aux(i0,i1) < 0.001
            aux(i0,i1) = 0;
        end
    end 
end
results.Param.P = aux;
if St == 2
    Pmat  = [[{'P'}  num2cell((1:St)) ;num2cell([(1:St)' results.Param.P])] repmat({'' '' ''},3,2)];
elseif St == 3
    Pmat  = [[{'P'}  num2cell((1:St)) ;num2cell([(1:St)' results.Param.P])] repmat({''},4,5)];
end

% Print results.
Estimation_results = [Part_1; stats; repmat({'' '' ''},1,3); Pmat];
if St == 2
    Estimation_results = Estimation_results(:,1:6);
end
if print == 1
    fid = 1;
    fprintf(fid,'************************************************************************************\n');    
    display(Estimation_results);
    if setup.mod == 1
        text_aux = '(1): All the parameters change with the regimen.';
    elseif setup.mod == 2
        text_aux = '(2): Constants change with the regimen.';
    elseif setup.mod == 3
        text_aux = '(3): Betas change with the regimen.';
    elseif setup.mod == 4
        text_aux = '(4): Sigmas2 change with the regimen.';
    elseif setup.mod == 5
        text_aux = '(5): Lags change with the regime.';
    elseif setup.mod == 6
        text_aux = '(6): Exo variables change with the regime (other than lags).';
    elseif setup.mod == 7
        text_aux = '(7): Constants and betas change with the regimen.';
    elseif setup.mod == 8
        text_aux = '(8): Constants and Sigma2 change with the regimen.';
    elseif setup.mod == 9
        text_aux = '(9): Betas and Sigma2 change with the regimen.'   ;
    end
    fprintf(fid,'************************************************************************************\n');
    fprintf(fid,['Model ' text_aux '\n']);
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Label for chart.
lab_dep_var = char(labels(1,:));
St = size(results.Param.betas,2);
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),results.T,freq);

% Filter and Smoothed probabilities.
if St == 2
    figure(1)
    subplot(2,3,3)
    plot(results.Fil(:,1),'Color',[0 0 1]);
    hold on;
    plot(results.Fil(:,2),'Color',[1 0.1, 0]);
    ylim([0 1]);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);
    title(('Filter Probability'),'FontWeight','bold','FontSize',11,'FontName','Arial');
    legend('Regime 1','Regime 2','Location','northwest');
    subplot(2,3,6)
    plot(results.Smt(:,1),'Color',[0 0 1]);
    hold on;
    plot(results.Smt(:,2),'Color',[1 0.1, 0]);
    ylim([0 1]);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);
    title(('Smoothed Probability'),'FontWeight','bold','FontSize',11,'FontName','Arial');
    legend('Regime 1','Regime 2','Location','northwest');
    
elseif St == 3
    figure(1)
    subplot(2,3,3)
    plot(results.Fil(:,1),'Color',[0 0 1]);
    hold on;
    plot(results.Fil(:,2),'Color',[1 0.1, 0]);
    ylim([0 1]);
    plot(results.Fil(:,3),'Color',[1 1, 0.25]);
    ylim([0 1]);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);
    title(('Filter Probability'),'FontWeight','bold','FontSize',11,'FontName','Arial');
    legend('Regime 1','Regime 2','Regime 3','Location','northwest');
    subplot(2,3,6)
    plot(results.Smt(:,1),'Color',[0 0 1]);
    hold on;
    plot(results.Smt(:,2),'Color',[1 0.1, 0]);
    hold on;
    plot(results.Smt(:,3),'Color',[1 1, 0.25]);
    ylim([0 1]);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);  
    title(('Smoothed Probability'),'FontWeight','bold','FontSize',11,'FontName','Arial');    
    legend('Regime 1','Regime 2','Regime 3','Location','northwest');
end

% Do graph, fit and residuals of the model.
subplot(2,3,1)
plot(results.dta(:,1), '-k','LineWidth',0.75);
hold on
plot(results.yhat2(:,1),'Color',[0 0 1],'LineWidth',0.9);
hold on
plot(results.yhat2(:,2),'Color',[1 0.1, 0],'LineWidth',0.9);
if St == 3
    hold on
    plot(results.yhat2(:,3),'Color',[1 1, 0.25],'LineWidth',0.9);
end
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fit of the model versus data','FontSize',11);
if St == 2
    legend(lab_dep_var,'Regime 1','Regime 2','Location','northwest');
elseif St == 3
    legend(lab_dep_var,'Regime 1','Regime 2','Regime 3','Location','northwest');
end
subplot(2,3,4)
plot(results.uhat, '-b');
hold on
plot(repmat(2*std(results.uhat),results.T,1), ':k');
hold on
plot(repmat(-2*std(results.uhat),results.T,1), ':k');
hold on
plot(zeros(results.T,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Residuals +/- 2 S.D.','FontSize',11);

% Chart IRF.
subplot(2,3,2)
% Zero line.
if size(results.irf,2) > 0
    hold on
    % IRF plot.
    plot((0:12),results.irf(1:13,1),'-b','LineWidth',1);
    hold on
    plot((0:12),results.irf(1:13,2),'-r','LineWidth',1);
    title('Impulse response function','FontSize',11);
    hold on
    if St == 3                
        plot((0:12),results.irf(1:13,3),'-k','LineWidth',1);
        legend('Regime 1','Regime 2','Regime 3','Location','northwest')
    elseif St == 2
        legend('Regime 1','Regime 2','Location','northwest')
    end
    hold on 
    plot((0:12),zeros(1,13),'-','Color',[0 0 0],'LineWidth',1);
    xlim([0 12]);
    box off
% Do graph, fit and residuals of the MS model.
else
    subplot(2,3,2)    
    plot(results.dta(:,1), '-k','LineWidth',0.75);
    hold on
    plot(results.yhat,'Color',[0 0 1],'LineWidth',0.9);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);
    title('In sample fit of the model versus data','FontSize',11);
    legend(lab_dep_var,'MS model','Location','northwest');
end

% Distribution of the residuals.
subplot(2,3,5)
histogram(results.uhat2(:,1),15,'FaceColor',[0 0 1],'EdgeAlpha',1);
hold on
histogram(results.uhat2(:,2),15,'FaceColor',[1 0 0],'EdgeAlpha',1);
legend('Regime 1','Regime 2','Location','northwest');
if St == 3
    hold on
    histogram(results.uhat2(:,3),15,'FaceColor',[1 1, 0.25],'EdgeAlpha',1);
    legend('Regime 1','Regime 2','Regime 3','Location','northwest');
end
title('Histogram for residuals','FontSize',11);
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
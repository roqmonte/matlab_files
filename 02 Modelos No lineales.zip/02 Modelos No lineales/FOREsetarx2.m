function results = FOREsetarx2(y,yl,x,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Jan/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation/forecast SETARX(2,p) model by OLS. Note, data for
% code is consistent with the following notation (row t):
%                               y(t) = A*y(t-h) + e(t)
% Where y(t) = f(y(t),y(t-h)) and y(t-h) = f(y(t-h),y(t-h-1)).
% Inputs:
%   y  : Endogenous vairable.
%   yl : Thresholds varialbes: lags of the dept. and/or exo. variables.
%   x  : Independet variables (constant term by default if not included in first col).
%   setup:
%   -.por   : Min %data per regime (Default: 20%).
%   -.thr   : Thershold search procedure: (0) Kernel (default); (1) complete search.
%   -.sim   : # sim. for recursive h-stp ahead forecast (h>1).
%   -.delay : Max. value delay parameter (Default: 1).
%   -.mfore : (0) recursive estimation; (1) rolling estimation.
%   -.fhr   : Forecast horizon; (1) computes direct and recursive forecast.
%   -.frp   : Number of observation for evaluation.
%
% Outputs:
%   results :
%   -.dta     : Initial data.
%   -.dtf     : Initial evaluation sample.
%   -.yhat    : In-sample fit.
%   -.uhat    : In-sample residuals.
%   -.betas   : Parameters.
%   -.th      : Threshold parameter.
%   -.d       : Delay parameter.
%   -.info    : Options.
%   -.yeft    : Vector with forecast data.
%   -.fore    : Vectot h-steap-ahead forecas (direct forecast).
%   -.fore_rec: Matrix h-steap-ahead forecas (per column, recursive forecast).
%   -.ForeF   : Type of forecast.
%   -.ForeT   : Estimation method.
%
% Index.
% 1. Data setup.
% 2. Forecast.
% 3. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Data setup.
if size(x,2) == 0 && size(yl,2) == 0
    error('Wrong arguments for the code.');
end
if isfield(setup,'thr') == 0
    setup.thr = 0;
end
if isfield(setup,'delay') == 0
    setup.delay = 1;
end
if isfield(setup,'por') == 0
    setup.por = 0.2;
end
% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
% Options
setup.method = 'Nwest';
% Evaluation window
P = setup.frp;
% Data
dta  = [y x yl];
ylini= []; 
ylf  = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Forecast.
h_wait = waitbar(0,'Generating forecast, please wait...');
% Estimation and forecast.
wx = 1;
for w = 1:P+1-setup.fhr
    % Waiting bar.
    waitbar(w/setup.frp,h_wait)
    % Forecast exercise (recursive or rolling estimation).
    if setup.mfore == 1
        wx = w;
    end
    % Generating Dependent variable.
    yini = y(wx:end-P+w-1,:);
    % Spliting yl matrix (it could contain lags values).  
    if size(yl,2) > 0
        ylini= yl(wx:end-P+w-1,:);
        ylf  = yl(end-P+w:end,:);
    end;
    % Generating Exogenous variables.
    xini= x(wx:end-P+w-1,:);
    xf2 = x(end-P+w:end,:);
    
    % Model estimation.
    res_o = SETARx2(yini,[xini ylini],setup);
    b(:,w,1) = res_o.betas(:,1);
    b(:,w,2) = res_o.betas(:,2);
    th(w,1)  = res_o.th;
    dl(w,1)  = res_o.delay;    
    uhat(w).u  = res_o.uhat;
    yhat(w).yt = res_o.yhat;
    
    % Forecasting    
    setup.junk  = w;
    fcast(:,w) = fore(yini,xf2,ylf,setup,res_o);
    clear res_o;
end
close(h_wait)

% Formating the results.
if setup.fhr > 1
    fcast = fcast(1,:)';
    ForeF = {'Direct forecast'};
elseif setup.fhr == 1
    results.fcast_rec = format(fcast,P);
    fcast = fcast(1,:)';
    ForeF = {'Recursive forecast'};    
end

% Results.
results.dta  = [dta(1:end-P,1)     dta(1:end-P,2:end)];
results.dtf  = [dta(end-P+1:end,1) dta(end-P+1:end,2:end)];
results.betas= b;
results.th   = th;
results.d    = dl;
results.info = setup;
% Forecast info options.
results.ForeF= char(ForeF);
results.yeft = dta(end-P+1:end,1);
results.fore = fcast;
results.yhat = yhat;
results.uhat = uhat;
if setup.mfore == 0
    results.ForeT = 'Recursive Estimation';
else
    results.ForeT = 'Rolling window estimation';
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions
% Function computes the h step ahead forecast matrix.
function yf = fore(y,xf,ylf,setup,param)
% Imputs.
%   y      : Data from Estimation window, target variable.
%   xf     : Data from Evaluation window, exo variables.
%   ylf    : Lags from Evaluation window, lags.
%   setup  : options.
%   param  : Parameters of the model.
% Outputs:
%   yf     : h step ahead forecast.

% Parameters of the model.
b  = param.betas;
th = param.th;
d  = param.delay;    
uhat1 = param.uhat2(1).u;
uhat2 = param.uhat2(2).u;

% Sample size of each regime
T1 = size(uhat1,1);
T2 = size(uhat2,1);

% Matrix to store results.
yf = zeros(setup.frp,setup.sim);
% Id variables.
junk = setup.junk-1;

% Direct forecast for h = 1 and recursive forecast.
if setup.fhr == 1
    % Storing last p lags form the evaluation window.
    ar   = size(ylf,2);
    yaux = y(end-ar+1:end);
    yfuni= yaux(ar:-1:1);
    clear yaux;     
    % Simulations..
    for i0 = 1:setup.sim
        % Drop yfun.
        clear yfun;
        % Initialization for the simulation.
        ysim = y;
        yfun = yfuni;
        % Forecasting.
        for i = 1:setup.frp-junk
            % Selecting betas & residuals.
            thaux = yfun';
            if thaux(d) <= th
                bx = b(:,1);        
                auxi2 = uhat1(randi([1,T1]),1);
            else
                bx = b(:,2);
                auxi2 = uhat2(randi([1,T2]),1);
            end;        
            % Forecasting.
            if i == 1
                yf2 = [xf(i,:) yfun']*bx;
            else
                yf2 = [xf(i,:) yfun']*bx + auxi2;
            end;
            % Storing forecast.
            yf(i,i0) = yf2;
            % Adding forecast for recursive forecast.
            ysim  = [ysim; yf2];
            % Storing last p lags form the evaluation window.
            yaux  = ysim(end-ar+1:end);
            yfun  = yaux(ar:-1:1);
            clear yaux yf2 auxi2;
        end
    end      
    % Final Forecast.
    yf = mean(yf,2);    

% Direct forecast for h > 1: y_{t+h|t}
elseif setup.fhr > 1
    % Forecast horizon.
    hf = setup.fhr;
    % Condition for lags.
    yl_fore = [];
    if size(ylf,2) > 0
       yl_fore = ylf(hf,:);
    end    
    % Selecting betas & residuals.
    if y(end+1-d,1) <= th 
        bx = b(:,1);        
    else
        bx = b(:,2);
    end;        
    yf = [xf(hf,:) yl_fore]*bx;
end

% Formating the forecast.
function fcast = format(fcast,a)
% Imputs.
%   fcast : Matrix forecast raw.
%   a     : Size evaluation window.
% Outputs:
%   fcast : Forecast Matrix (each row: h-step-ahead forecast).
fcast = fcast';
% Forecast
fcast2 = NaN(a,a);
i = 1;
for j0 = 1:a
    fcast2(i:end,j0)= fcast(1:end-i+1,j0);
    i = i + 1;
end
fcast = fcast2;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function results = TARx2(y,x,xth,setup,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 29/Jan/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation TARx(2) by OLS. The code estimates best model
% by minimizing SSR conditional to number of lags. Standard errors computed
% using Newey-West estimator.
% Model representation:
% yt = xt*b(1) + et         if xth <= gamma
%
% yt = xt*b(2) + et         if xth >  gamma
%
% Inputs:
%   y  : Endogenous variable.
%   x  : Independet variables (constant term by default if not included in first col).
%   xth: Matrix with threshold variables.
%   setup :
%   -.thr    : Search method, (0) Kernel (default); (1) complete search.
%   -.por    : Min. %data per/regime (Default: 20%).
%   print    : (1) Do charts and print results on screen.
%   labels   : Column vector with labels for dep. and indep variables.
%   dates    : Vector with info for dates: [year,month,freq].
%              Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results :
%   -.id     : Dummy variable for each regime.
%   -.dta    : Estimation sample.
%   -.dta2   : Estimation sample for each regime.
%   -.yhat   : Fit of the model.
%   -.uhat   : Residuals.
%   -.uhat2  : Residuals for each regime.
%   - thtest : threshold and statistic of the break.
%   -.th     : threshold parameter
%   -.betas  : Parameters for each regime.
%   -.Pval   : Asymtotic Pvalues.
%   -.SSR    : SSR SETAR.
%   -.Sg2    : Sg2 for each regime.
%   -.Sg2f   : Sg2 model.
%   -.R2     : R2 SETAR.
%   -.AIC    : AIC SETAR.
%   -.HQC    : HQC SETAR.
%   -.BIC    : BIC SETAR.
%   -.T      : Sample size.
%   -.k      : Number of parameters.
%   -.table  : Table with print results.
%
% Index.
% 1. Checking inputs and data setup.
% 2. Estimation.
% 3. Results.
% 4. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Checking inputs and data setup.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
if isfield(setup,'thr') == 0
    setup.thr = 0;
end
if isfield(setup,'por') == 0
    setup.por = 0.2;
end

% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end

% Original data for estimation.
dta = [y x];
% Final data for estimation
y = dta(:,1);
x = dta(:,2:end);
% Sample information
T = size(y,1);
k = size(x,2);
maxth = size(xth,2);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation.
% Matrix to store results
SSRini = zeros(maxth,2);
th     = zeros(maxth,1);
% Estimation TARx2(p) model for threshold variables.
for i0 = 1:maxth
    [SSRini(i0,:),th(i0)] = tar1(dta,setup,xth(:,i0));
end
% Choosing threshold by min SSR setar model.
[SSRtar,dl] = min(SSRini(:,2));
% Threshold estimation (gamma);
thf = th(dl);
% Threshold statistic Hansen (1999) linearity test.
SSRols = SSRini(1,1);
F = T*( (SSRols - SSRtar) / SSRtar);
clear i0 th;

% TARx(2) Estimation.
% Less or equal to th / Greater than th.
auxle = le(xth(:,dl),thf);
auxgt = gt(xth(:,dl),thf);
% Spliting the sample
dta1 = msel(dta,auxle);
dta2 = msel(dta,auxgt);
% TAR estimation.
r1 = OLSest(dta1(:,1),dta1(:,2:end),'NWest');
r2 = OLSest(dta2(:,1),dta2(:,2:end),'NWest');

% Fit of the model.
yhat = zeros(T,1);
idrg = NaN(T,2);
for i = 1:T
    if xth(i,dl) <= thf
        yhat(i,1) = dta(i,2:end)*r1.b;
        idrg(i,1) = 1;
    else
        yhat(i,1) = dta(i,2:end)*r2.b;
        idrg(i,2) = 1;
    end;    
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Other results.
T1   = size(r1.uhat,1);
T2   = size(r2.uhat,1);
uhat = y - yhat;
e1   = r1.uhat;
e2   = r2.uhat;

% Estimation info
results.id   = idrg;
results.dta  = dta;
results.dta2(1).dta = dta1;
results.dta2(2).dta = dta2;

% Estimation rsults
results.yhat = yhat;
results.uhat = uhat;
results.uhat2(1).u= e1;
results.uhat2(2).u= e2;
% Threshold test and statistic.
results.thtest= [F thf];
results.th    = thf;
results.varid = dl;
results.betas = [r1.b r2.b];
results.Pval  = [r1.Pval r2.Pval];
% More statistics.
results.SSR = SSRtar;
results.Sg2 = [e1'*e1/(T1-k) e2'*e2/(T2-k)];
results.Sg2f= (e1'*e1 + e2'*e2)/(T1+T2-2*k);
results.R2  = 1 - results.SSR / ((y-mean(y))'*(y-mean(y)));
results.AIC = log((e1'*e1)/T1) + 2*(k/T1)              + log((e2'*e2)/T2) + 2*(k/T2);
results.HQC = log((e1'*e1)/T1) + 2*(k/T1)*log(log(T1)) + log((e2'*e2)/T2) + 2*(k/T2)*log(log(T2));
results.BIC = log((e1'*e1)/T1) +   (k/T1)*log(T1)      + log((e2'*e2)/T2) +   (k/T2)*log(T2);
results.T   = [T1 T2];
results.k   = k;
% Table.
results.table = print_res(results,labels,print);

% Do charts
if print == 1       
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1];
    end
    print_charts(results,dates,labels);
end  
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions.
% Function estimates TARx(2) model given ar order and delay parameter.
function [SSR,th] = tar1(data,setup,yth)
% Inputs:
%   dta   : data for estimation.
%   setup: 
%   -.thr : search method, (0) Kernel; (1) complete search,.
%   -.por : Min. % of  data for each regime.
%   yth   : Threshold variables for TAR.
% Output:
%   SSR      : Sum square residuals OLS and TAR models.
%   tx       : Threshold.
% Creating Threshold variable.
% Complete search.
if setup.thr  == 1
    % Sorting the data
    yord = sort(yth,1);
    % Threshold definition.
    thinf = round(size(yth,1)*setup.por);
    thsup = size(yord,1) - thinf;
% Kernel distribution.
elseif setup.thr  == 0
    % Distribution of data
    yord = prctile(yth,0:100)';
    thinf = round(100*setup.por);
    thsup = 100 - thinf;
end

% OLS Estimation full sample.
r0    = OLSest(data(:,1),data(:,2:end),'NWest');
SSRols= r0.SSR;
% Matrix to store results;
thres  = zeros(thsup-thinf+1,1);
SSRtar = zeros(thsup-thinf+1,1);

% Estimation TAR model conditional to threshold variable.
w = 1;
for i1 = thinf:thsup
    % Definition thresholds
    th = yord(i1);
    % Less or equal to th.
    auxle = le(yth,th);
    % Greater than th.
    auxgt = gt(yth,th);
    % Spliting the sample
    dta1 = msel(data,auxle);
    dta2 = msel(data,auxgt);
    % OLS estimation for each model.
    r1 = OLSest(dta1(:,1),dta1(:,2:end),'NWest');
    r2 = OLSest(dta2(:,1),dta2(:,2:end),'NWest');
    % Saving Sigma Square hat.
    thres(w,1) = th;
    SSRtar(w,1) = r1.SSR + r2.SSR;
    w = w + 1;
    clear th auxle auxgt dta1 dta2;
end;
% Threshold (Threshold estimation).
[SSRmin,id] = min(SSRtar);
th = thres(id,1);
SSR = [SSRols SSRmin];
clear i1 w i r0 r1 r2;

% Function selects elements of a matrix given an index variable.
function matrix = msel(dta,index)
% Inputs:
%   dta   : data.
%   index : Index variable
% Output:
%   matrix : Selected observation from dtaaccording to index.
% Matrix to store results
matrix = zeros(sum(index),size(dta,2));
i = 1;
for i0 = 1:size(index,1)
   if index(i0) == 1
      matrix(i,:) = dta(i0,:);
      i = i + 1;
   end 
end

% Funtion do table.
function Estimation_results = print_res(results,labels,print)
T = size(results.dta,1);
% Labels
if isempty(labels)
    lab_0 = [];
else
    lab_0 = labels(2:end);
end
% Do table.
% labels for exo variables.
lab = {'cte'};
for i0 = 2:results.k
    if isempty(lab_0)
        lab2 = strcat('b',num2str(i0-1));
    else
        lab2 = lab_0(i0-1,:);
    end        
    lab = [lab; lab2];
end

% Building table
% First part.
labels = {'Reg. 1' 'Param'  'Pvalues' 'Reg. 2' 'Param' 'Pvalues'};
temp_1 = ['Sg2' num2cell(results.Sg2(1)) ' ' 'Sg2' num2cell(results.Sg2(2)) ' '];
part_1 = [labels; lab num2cell([results.betas(:,1) results.Pval(:,1)]) lab num2cell([results.betas(:,2) results.Pval(:,2)]); temp_1];
clear temp_1
% Second part
temp_1 = {'AIC'; 'HQC';  'BIC'};
temp_2 = num2cell([results.AIC;results.HQC;results.BIC]);
temp_3 = [temp_1 temp_2];
temp_4 = [{'R2'; 'Sg2'; 'SSR'} num2cell([results.R2;results.Sg2f;results.SSR])];
temp_5 = {'T'; 'T1'; 'T2'};
temp_6 = num2cell([T;results.T(1);results.T(2)]);
temp_7 = ['LF-test' num2cell(results.thtest(1)) 'Th' num2cell(results.th) 'thres' num2cell(results.varid) ];
part_2 = [{'' '' '' '' '' ''} ;temp_3 temp_4 temp_5 temp_6; temp_7];
clear temp_1 temp_2 temp_3 temp_4 temp_5 temp_6 temp_7;
% Print results.
Estimation_results = [part_1; part_2];
if print == 1
    fid = 1;
    fprintf(fid,'****************************************************************************************\n');    
    display(Estimation_results);
    fprintf(fid,'****************************************************************************************\n');
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Dates
T = size(results.dta,1);
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),T,freq);

% Label for chart.
if isempty(labels)
    lab_dep_var = 'data';
else
    lab_dep_var = char(labels(1,:));
end
% Do graph, fit and residuals.
figure(1)
subplot(2,2,1)
plot(results.dta(:,1), '-k','LineWidth',0.75);
hold on
plot(results.id(:,1).*results.yhat,'Color',[0 0 1],'LineWidth',0.9);
hold on
plot(results.id(:,2).*results.yhat,'Color',[1 0.1, 0],'LineWidth',0.9);
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fit of the model versus data','FontSize',11);
legend(lab_dep_var,'Regime 1','Regime 2','Location','northwest')
subplot(2,2,3)
plot(results.uhat, '-b');
hold on
plot(repmat(2*sqrt(results.Sg2f),T,1), ':k');
hold on
plot(repmat(-2*sqrt(results.Sg2f),T,1), ':k');
hold on
plot(zeros(T,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Residuals +/- 2 S.D.','FontSize',11);

% ACF and PAC functions.
subplot(2,2,2)     
[~,temp1] = acf(results.uhat2(1).u);
[~,temp2] = acf(results.uhat2(2).u);
if min(size(temp1,1),size(temp2,1)) < 25
    n_aux = min(size(temp1,1),size(temp2,1));
    n_lim = n_aux-1;
else
    n_aux = 25;
    n_lim = 18;
end        
bar((-1:n_aux-1),[NaN(1,2); [temp1(1:n_aux,1) temp2(1:n_aux,1)]]);
hold on
plot((-1:n_aux-1),repmat(temp1(1:n_aux,3),1,n_aux+1), ':k');
hold on
plot((-1:n_aux-1),repmat(temp1(1:n_aux,4),1,n_aux+1), ':k');
xlim([-1 n_lim]);
ylim([-1 1]);
title('Sample Auto-correlations','FontSize',11);
legend('Regime 1','Regime 2','Location','northwest')

% Distribution of the residuals.
subplot(2,2,4)
histogram(results.uhat2(1).u,15,'FaceColor',[0 0 1],'EdgeAlpha',1);
hold on
histogram(results.uhat2(2).u,15,'FaceColor',[1 0 0],'EdgeAlpha',1);
title('Histogram for residuals','FontSize',11);
legend('Regime 1','Regime 2','Location','northwest');
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
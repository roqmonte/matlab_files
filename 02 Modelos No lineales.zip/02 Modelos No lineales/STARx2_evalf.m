function [logf,param] = STARx2_evalf(theta,y,x,setup)
% Matlab 7.1
% Autor: Roque Montero
% Date: 21/Feb/2015
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Evaluation of the log-likelihood of an STARx(p) model.
% Imputs: 
%   theta :
%   y     : Endogenous variable.
%   x     : Exogenous variables (cte by default.)
%   setup  :
%
% Outputs:
%   logf : Log-like function.
%   param: parameters for each regime
% 
% Index:
% 1. Initial Setup
% 2. Evaluation.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Initial Setup
St    = setup.St;
trans = setup.trans;
k  = size(x,2); 
T  = size(y,1);   
mod = setup.mod;
% Transformation of theta.
if trans == 1
    % Inverse function.
    [betas,sigmas2,matp] = fn1(theta,k,St,setup.mod);
    % Theta Original
    theta = [betas; sigmas2; matp];
end;

% Transition Matrix definition.
p = zeros(St,St);
if St == 2;
    p(1,1) = theta(end-1);
    p(2,1) = 1 - theta(end-1);
    p(1,2) = theta(end);
    p(2,2) = 1 - theta(end);    
elseif St == 3;
    p(1,1) = theta(end-5);
    p(2,1) = theta(end-2);
    p(3,1) = 1 - (theta(end-5) + theta(end-2));
    p(1,2) = theta(end-4);
    p(2,2) = theta(end-1);
    p(3,2) = 1 - (theta(end-4) + theta(end-1));
    p(1,3) = theta(end-3);    
    p(2,3) = theta(end);
    p(3,3) = 1 - (theta(end-3) + theta(end));
end;

% Ergodic probabilities, initial values for the filter prob.
A = [eye(size(p,1)) - p; ones(1,size(p,1))] ;
e = (A'*A)\(A')*eye(St+1);
e = e(:,end);
clear A;

% Computing Betas and Sg2 for each version of the model.
[beta,sg2] = fn2(theta,x,k,St,mod);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Evaluation.
% Restricting the log-like.
if max(abs(p(:))) > 1 || min(p(:)) < 0 || min(sg2) <= 0 || round(sum(sum(p))) ~= St;
    if setup.llsig ==  0
        logf = inf;
    else
        logf = -1*inf;
    end;
else    
    % Log-Likelihood evaluation.
    yy = repmat(y,1,St);
    part1 = repmat((2*pi*sg2).^(-1/2),size(y,1),1);
    part2 = exp( - (yy-x*beta).^2 .* repmat(0.5./sg2,size(y,1),1));
    ll    = part1 .* part2;
    clear part1 part2;
    % Conditional density and uptating of e(j,t).
    e0 = zeros(T+1,St);
    e0(1,:) = e;
    logf = 0;
    for i = 1:T;
        fi = e0(i,:)*p'*ll(i,:)';
        % Conditional density of yt
        logf = logf + log(fi);
        % Filter Probability
        e0(i+1,:) = ((e0(i,:)*p').*ll(i,:))/fi;
    end;
    if setup.llsig ==  0
        logf = -1*logf;
    else
        logf = 1*logf;
    end;
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
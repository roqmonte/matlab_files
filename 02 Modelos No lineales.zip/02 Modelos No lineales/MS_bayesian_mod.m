function results = MS_bayesian_mod(y,x,setup,priors,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 27/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of a Bayesian MS-AR(p) model, using Hamilton
% Filter. Transition probability P is defined as:
%
%     |  P11  P21 ... Pj1  |
%     |  P12  P22 ... Pj2  |
% P = |   :    :  ...  :   |
%     |   :    :  ...  :   |
%     |  P1j  P2j ... Pjj  |
%
% Where Pkj is the probability of moving from regime k to j. 
% 
% Imputs:
%   y           : Endogenous variable.
%   x           : Independet variables (constant term by default if not included).
%   setup :
%   -.ar        : Lag order of the model, contant parameters.
%   -.St        : Number of regimes (Default: 2).
%   -.rep       : Number of final draws from posterior posterior.
%   -.burn      : Burning sample.
%   -.keep      : Keepd every x draws, to reduce correlation among draws (default 1).
%   -.id        : Vector dim (k,1) that selects param. to identify regime. If .id(j)
%                 is a unit entry, then b(j,St1) > b(j,St2). If id is zero vector,
%                 then restriction in on the variance of the model.
%   -.ncrit     : MMinimun # obs. per regime (default is 10).
%   priors      : 
%   -.B0        : Prior for B0 (k,St).
%   -.VB0       : Priors variance for B0(k,St).
%   -.d         : Col vector(St), prior for scale variance
%   -.v         : Col vector(St), prior for DF variance
%   -.u00       : Prior for transition probabilities St(1)
%   -.u11       : Prior for transition probabilities St(2)
%   print       : (1) Do charts and print results on screen.
%   labels      : Column vector with labels for dep. and indep variables.
%   dates       : Vector with info for dates: [year,month,freq].
%                 Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results:
%   -.B_draws    : Draws from betas eacg regime.
%   -.Sg_draws   : Draws sigma2 for each regime.
%   -.Smth_draws : Draws of the smoothed probaiblity of state.
%   -.Fill_draws : Draws of the filter probability of state.
%   -.Pmat_draws : Draws transition matrix.
%   -.Fil        : Median posterior filter probability.
%   -.Smt        : Median posterior Smoothed probability .
%   -.Betas      : Median posterior of the parameters.
%   -.Sg2        : Median posterior Sg2.
%   -.Pmat       : Median posterior transition matrix.
%   -.Pval       : Asymtotic Pvalues.
%   -.dta        : Data estimation.
%   -.yhat       : Fit of the model, based on smoothed prob.
%   -.yhat2      : Fit of each regime.
%   -.uhat       : in-sample residuals model, based on smoothed prob.
%   -.uhat2      : in-sample residuals from each regime.
%   -.SSR        : Sum square resids.
%   -.R2         : R-square.
%   -.R2adj      : Adjusted R-square.
%   -.T          : Sample size.
%   -.k          : Number of parameters.
%   -.table      : Table with print results.
%
% Index:
% 1. Initial Setup.
% 2. Estimation of MSAR models.
% 3. Additional results.
% 4. Function.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%  
% 1. Initial Setup.
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end
% Checking number of states.
if isfield(setup,'St') == 0
    setup.St = 2;
end
% Checking which draws to keep from final simulations.
if isfield(setup,'keep') == 0
    setup.keep = 1;
end
% Checking minimun number of obs. per regime.
if isfield(setup,'ncrit') == 0
    setup.ncrit = 10;
end

% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
% Checking fix AR terms and adjusting data.
if isfield(setup,'ar') == 0
    setup.ar = 0;    
else
    % Getting lags
    temp = LagN(y,setup.ar);
    % Adjusting sample size and data
    y = temp(:,1);    
    x = [x(setup.ar+1:end,:) temp(:,2:end)];
end
clear temp


% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    lab_x = {'dep var'};
    for i0 = 2:size(x,2)
        lab_x2 = strcat('xvar ',num2str(i0-1));
        lab_x  = [lab_x; lab_x2];
    end
else
    lab_x = labels;
end
labels = lab_x;
clear lab_x lab_x2

% Getting info from the code.
ncrit    = setup.ncrit;
St       = setup.St;
T        = size(y,1);
draws    = setup.rep*setup.keep;
burn     = setup.burn;
k        = size(x,2);

% Seeting Priors
if exist('priors','var') == 0 || isempty(priors)
    % Betas and Sg2
    B0 = rand(k,St);
    VpB1 = eye(k)*1000;
    VpB2 = eye(k)*1000;
    % Prior for variance, DF and scale.
    d1 = 0.1; v1 = 1;
    d2 = 0.1; v2 = 1;
    % Prior for transition probabilities
    if St == 2
        u00 = 1; u01 = 1;
        u11 = 1; u10 = 1;
    elseif St == 3
        VpB3 = eye(k)*1000;
        d3    = 0.1; v3 = 1;
    end

else
    % Betas and Sg2
    B0   = priors.B0;
    VpB1 = diag(priors.VB0(:,1));
    VpB2 = diag(priors.VB0(:,2));
    % Prior for variance, DF and scale.
    d1 = priors.d(1); v1 = priors.v(1);
    d2 = priors.d(2); v2 = priors.v(2);
    % Prior for transition probabilities
    if St == 2
        u00 = priors.u00(1); u01 = priors.u00(2);
        u11 = priors.u11(1); u10 = priors.u11(2);
    elseif St == 3
        VpB3 = diag(priors.VB0(:,3));
        d3   = priors.d(3); v3 = priors.v(3);
    end
end

% Gibbs sampling initialization
phi1  = B0(:,1);  % Regime 1 coefficients.
phi2  = B0(:,2);  % Regime 2 coefficients.
sig1  = 1;        % Regime 1 variance.
sig2  = 1;        % Regime 2 variance.
if St == 2
    phi3 = [];   sig3 = [];
    p    = 0.95; q    = 0.95;
    pmat = [p 1-q;1-p q];
elseif St == 3
    phi3  = B0(:,3);  % Regime 3 coefficients.
    sig3  = 1;        % Regime 3 variance.
end
sig   = [sig1; sig2; sig3];

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation of MSAR model.
% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');

% Simulations.
record  = 0;
ndraw   = 1;
while record < burn + draws + 1
    % Step 1, sample states.
    % Unconditional probabilities
    A  = [(eye(St)-pmat); ones(1,St)];
    EN = [zeros(St,1); 1];
    ett11 = pinv(A'*A)*A'*EN;
    
    % Hamilton's filter.
    filter = zeros(T,2);
    lik = 0;
    for j = 1:T
        % Residual fom each state.
        em  = y(j) - sum(repmat(x(j,:),St,1).*[phi1'; phi2'; phi3'],2);
        % Density of each state, F(Y | S=0/1)
        neta  = (sig.^(-1/2)).*exp(-0.5*(em.*sig.^(-1).*em));
        % Forecast, state equation. 
        ett10 = pmat*ett11;
        
        % Update state, joint density F(Y,S)
        ett11 = ett10.*neta;
        % Marginal density F(Y)
        fit   = sum(ett11);     
        % Conditional density F(S\Y), weights of the likelihood
        ett11 = (ett11)/fit;
        % Filter probabilities of states.
        filter(j,1:2) = ett11';
        % Log-likelihood.
        lik = lik + log(fit);        
    end
    clear j em neta A EN ett1;
    
    % Backward recursion, sample H(S[t]\S[t+1],y)
    check = -1;
    xid   = 1;
    while check < 0       
        % Two regimes.
        if St == 2
            % Number of states and last iteration from filter.
            S = zeros(T,1);       
            p = filter(end,1)/sum(filter(end,:));
            % Indeitifcation of the state at T. (CHECK ST3)
            u = rand(1,1);
            S(T,1) = (u >= p);
            for t = T-1:-1:1
                if S(t+1) == 0
                    pp = pmat(:,1).*filter(t,:)';
                elseif S(t+1) == 1
                    pp = pmat(:,2).*filter(t,:)';
                end
                % Indeitifcation of the state at T-i
                u = rand(1,1);
                p = pp(1)/sum(pp);
                if u < p
                    S(t) = 0;
                else
                    S(t) = 1;
                end
                % Terminal condition
                if sum(S==0)>= ncrit && sum(S==1)>=ncrit
                    check = 1;
                end
            end
            % Discard dtaws
            if check == -1
                xid = xid + 1;
                if gt(xid,500)
                    check = 1;
                    S = (rand(T,1)>0.5);
                end
            end
        % Three regimes.
        elseif St == 3

        end
    end
    clear u t pp check xid;
 
    % Step 2, sample transition matrix P (CHECK ST3)
    if St == 2
        tranmat = switchg(S+1,[1;2]);
        N00 = tranmat(1,1);
        N01 = tranmat(1,2);
        N10 = tranmat(2,1);
        N11 = tranmat(2,2);
        % Draw transition matrix.
        pmat = [drchrnd([N00+u00;N01+u01]) drchrnd([N10+u10;N11+u11])];
        clear N00 N01 N10 N11
    elseif St == 3
        
    end

    % Step 3, sample betas
    % Select data in regime 1
    scheck = -1;
    while scheck < 0
        y1 = y(S==0);
        x1 = x(S==0,:);
        M  = (VpB1^(-1) + (1/sig1)*(x1'*x1))^(-1)*(VpB1^(-1)*B0(:,1) + (1/sig1)*x1'*y1); 
        V  = (VpB1^(-1) + (1/sig1)*(x1'*x1))^(-1);
        phi1 = M + (randn(1,k)*chol(V))';
        % Select data in regime 2
        y2 = y(S==1);
        x2 = x(S==1,:);
        M  = (VpB2^(-1) + (1/sig2)*(x2'*x2))^(-1)*(VpB2^(-1)*B0(:,2) + (1/sig2)*x2'*y2); 
        V  = (VpB2^(-1) + (1/sig2)*(x2'*x2))^(-1);
        phi2 = M + (randn(1,k)*chol(V))';
        % Select data in regime 3
        if St == 3;
            y3 = y(S==2);
            x3 = x(S==2,:);
            M  = (VpB3^(-1) + (1/sig3)*(x3'*x3))^(-1)*(VpB3^(-1)*B0(:,3) + (1/sig3)*x3'*y3); 
            V  = (VpB3^(-1) + (1/sig3)*(x3'*x3))^(-1);
            phi3 = M + (randn(1,k)*chol(V))';
        end
        % Checking stable draw for the AR component.
        if setup.ar > 0
            temp = StatioFun(phi1(end-setup.ar+1:end)) + StatioFun(phi2(end-setup.ar+1:end));
            if temp == 0
                scheck = 0;
            end
        else
            scheck = 0;
        end        
    end
        
    % Step 4, Sample sigma.
    % Residuals and draw from IG, regime 1
    D1   = (y1 - x1*phi1)'*(y1 - x1*phi1) + d1;
    z0   = randn(v1 + size(y1,1),1);
    sig1 = D1/(z0'*z0); 
    % Residuals and draw from IG, regime 2
    D2 = (y2 - x2*phi2)'*(y2 - x2*phi2) + d2;
    z0   = randn(v2 + size(y2,1),1);
    sig2 = D2/(z0'*z0);
    % Residuals and draw from IG, regime 3
    if St == 3;
        D3 = (y3 - x3*phi3)'*(y3 - x3*phi3) + d3;
        z0   = randn(v3 + size(y3,1),1);
        sig3 = D3/(z0'*z0);
    end
    clear y1 x1 y2 x2 y3 x3 M V D1 D2 D3 z0;
    
    % Save and impose regime identification.
    if record > burn
        % Update waitbar
        waitbar(ndraw/draws,h_wait);
        % Identification on sign of betas.
        if sum(setup.id) == 1
            if St == 2
                chck = phi1(setup.id==1) > phi2(setup.id==1);
            elseif St == 3

            end
        % Identification on the variance of the model.    
        elseif sum(setup.id) == 0
            if St == 2
                chck = sig1 > sig2;
            elseif St == 3
                
            end
        end
        % Storing the draws.
        if chck == 1
            out1(:,:,ndraw) = [phi1 phi2 phi3]; % Draws betas for regime.
            out2(ndraw,:)   = [sig1 sig2 sig3]; % Draws sigma2 for regime.
            out3(:,ndraw)   = S;           % Draws smoothed probaiblity of state.
            out4(:,:,ndraw) = filter;      % Draws filter probability of state.
            out5(:,:,ndraw) = pmat;        % Draws transition matrix.
            ndraw = ndraw + 1;
        end

    end
   
    % Moving top next draw if all conditions are satisfied.
    record = record + 1;
    % Cleaning memory.
    clear check i0 lik chck ett10 ett11 tranmat
end
close(h_wait);
clear record ndraw;

% Adjusting draws fom posterior to reduce correlation in draws.
if setup.keep > 1;    
    out1 = out1(:,:,1:setup.keep:end);
    out2 = out2(1:setup.keep:end,:);
    out3 = out3(:,1:setup.keep:end);
    out4 = out4(:,:,1:setup.keep:end);
    out5 = out5(:,:,1:setup.keep:end);
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Saving draws
results.B_draws   = out1;
results.Sg_draws  = out2;
results.Smth_draws= out3;
results.Fill_draws= out4;
results.Pmat_draws= out5;
clear out1 out2 out3 out4 out5 chck h_wait;

% Results form the simulations.
if St == 2
    results.Smt = [1-mean(results.Smth_draws,2) mean(results.Smth_draws,2)];
elseif St == 3
    
end
results.Fil      = mean(results.Fill_draws,3);
results.Betas    = mean(results.B_draws,3);
results.Sg2      = mean(results.Sg_draws,1);
results.Pmat     = mean(results.Pmat_draws,3);
% Getting ttestfor each coeff. for Pvalues.
Pvalb = zeros(k,St);
for i0 = 1:St
    for i1 = 1:k
        ttestb = results.Betas(i1,i0)/std(squeeze(results.B_draws(i1,i0,:)));
        Pvalb(i1,i0) = 2*(1-tcdf(abs(ttestb),T - k));
        if Pvalb(i1,i0) < 0.001
            Pvalb(i1,i0) = 0;
        end
    end
end
clear i0 i1;

% Estimation results.
results.dta    = [y x];
results.yhat   = sum(x*results.Betas.*results.Smt,2);
results.yhat2  = x*results.Betas;
results.uhat   = y - results.yhat;
results.uhat2  = repmat(y,1,St) - results.yhat2;
% More results
results.SSR   = results.uhat'*results.uhat;
results.Sg2   = mean(results.Sg_draws,1);
results.Pvalb = Pvalb;
results.R2    = 1 - results.SSR / ((y-mean(y))'*(y-mean(y)));
results.R2adj = 1 - (1 - results.R2)*(T - 1)/(T - k);
results.T     = T;
results.k     = k;
% Table.
results.table = print_res(results,setup,labels,print);

% Do charts
if print == 1       
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1];
    end
    print_charts(results,dates,labels);
end    
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Function.

% Function calculate the number of regime switches.
function out=switchg(s,g)
n   = size(s,1);
m   = size(g,1);
swt = zeros(m,m);
t   = 2;
while t <= n
    st1 = s(t-1);
    st  = s(t);
    swt(st1,st) = swt(st1,st) + 1;
    t   = t + 1;
end
out = swt;

% Function gets a draw from the the dirichlet density.
function out= drchrnd(a)
m = 1;
n = length(a);
r = zeros(n,1);
out = zeros(n,1);
for i = 1:n
    r(i) = gamrnd(a(i),m,1,1);
end
out(1:n-1) = r(1:n-1)./sum(r(1:n));
out(n) = 1 - sum(out(1:n-1));

% Funtion check stationarity of a companion form matrix.
function check = StatioFun(betas)
b = vec(betas);
k = size(b,1);
% One parameter.
if k == 1
    F = b;
    if abs(F) < 1
        check = 0;
    elseif abs(F) >= 1
        check = -1;
    end
% More than one parameter.
elseif k > 1
    F = [b'; eye(k-1) zeros(k-1,1)];
    if max(abs(eig(F))) < 1
        check = 0;
    else
        check = -1;
    end
end

% Funtion do table.
function Estimation_results = print_res(results,setup,labels,print)
% labels 
lab = ['cte'; labels(2:end,:)];

% Building table
St = size(results.Betas,2);
% Regime 1
reg1   = [lab num2cell([results.Betas(:,1) results.Pvalb(:,1)])];
labels = {'Reg. 1' 'Param' 'Pvalue'};
temp_1 = ['Sg2' num2cell(results.Sg2(1)) ' '];
Reg_1  = [labels; reg1; temp_1];
clear labels temp_1 reg1;
% Regime 2
reg2   = [lab num2cell([results.Betas(:,2) results.Pvalb(:,2)])];
labels = {'Reg. 2' 'Param' 'Pvalue'};
temp_1 = ['Sg2' num2cell(results.Sg2(2)) ' '];
Reg_2  = [labels; reg2; temp_1];
clear labels temp_1 reg2;
% Regime 3
if St == 2
    Reg_3  = [];
elseif St == 3
    reg3   = [lab num2cell([results.Betas(:,3) results.Pvalb(:,3)])];
    labels = {'Reg. 3' 'Param' 'Pvalue'};
    temp_1 = ['Sg2' num2cell(results.Sg2(3)) ' '];
    Reg_3  = [labels; reg3; temp_1];
    clear labels temp_1 reg3;
end

% Formating table
nmax  = max([size(Reg_1,1) size(Reg_2,1) size(Reg_3,1)]);
Part_1= repmat({'' '' '' '' '' '' '' '' ''},nmax,1);
Part_1(1:size(Reg_1,1),1:3) = Reg_1;
Part_1(1:size(Reg_2,1),4:6) = Reg_2;
if St == 3
    Part_1(1:size(Reg_3,1),7:9) = Reg_3;
end

% Second part
temp_1 = {'Draws'; 'Burn';  'Keep'};
temp_2 = num2cell([setup.rep;setup.burn;setup.keep]);
temp_3 = [{'SSR'; 'R2'; 'R2adj'} num2cell([results.SSR;results.R2;results.R2adj])];
temp_4 = [{'T'} num2cell(results.T); {'k'} num2cell(results.k); {'Iterations'} num2cell(999)];
temp_5 = [{'#Regime'} num2cell(St) {'Model'} num2cell(999) {' '} {' '}];
stats  = [[{'' '' '' '' '' ''}; temp_1 temp_2 temp_3 temp_4; temp_5] repmat({'' '' ''},5,1)];
clear temp_1 temp_2 temp_3 temp_4 temp_5;
% Transition matrix
aux = results.Pmat;
for i0 = 1:St
    for i1 = 1:St
        if aux(i0,i1) < 0.001
            aux(i0,i1) = 0;
        end
    end 
end
results.Pmat = aux;
if St == 2
    Pmat  = [[{'P'}  num2cell((1:St)) ;num2cell([(1:St)' results.Pmat])] repmat({'' '' ''},3,2)];
elseif St == 3
    Pmat  = [[{'P'}  num2cell((1:St)) ;num2cell([(1:St)' results.Pmat])] repmat({''},4,5)];
end

% Print results.
Estimation_results = [Part_1; stats; repmat({'' '' ''},1,3); Pmat];
if St == 2
    Estimation_results = Estimation_results(:,1:6);
end
if print == 1
    fid = 1;
    fprintf(fid,'************************************************************************************\n');    
    display(Estimation_results);
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Label for chart.
lab_dep_var = char(labels(1,:));
St = size(results.Betas,2);
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),results.T,freq);

% Filter and Smoothed probabilities.
if St == 2
    figure(1)
    subplot(2,3,3)
    plot(results.Fil(:,1),'Color',[0 0 1]);
    hold on;
    plot(results.Fil(:,2),'Color',[1 0.1, 0]);
    ylim([0 1]);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);
    title(('Filter Probability'),'FontWeight','bold','FontSize',11,'FontName','Arial');
    legend('Regime 1','Regime 2','Location','northwest');
    subplot(2,3,6)
    plot(results.Smt(:,1),'Color',[0 0 1]);
    hold on;
    plot(results.Smt(:,2),'Color',[1 0.1, 0]);
    ylim([0 1]);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);
    title(('Smoothed Probability'),'FontWeight','bold','FontSize',11,'FontName','Arial');
    legend('Regime 1','Regime 2','Location','northwest');
    
elseif St == 3
    figure(1)
    subplot(2,3,3)
    plot(results.Fil(:,1),'Color',[0 0 1]);
    hold on;
    plot(results.Fil(:,2),'Color',[1 0.1, 0]);
    ylim([0 1]);
    plot(results.Fil(:,3),'Color',[1 1, 0.25]);
    ylim([0 1]);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);
    title(('Filter Probability'),'FontWeight','bold','FontSize',11,'FontName','Arial');
    legend('Regime 1','Regime 2','Regime 3','Location','northwest');
    subplot(2,3,6)
    plot(results.Smt(:,1),'Color',[0 0 1]);
    hold on;
    plot(results.Smt(:,2),'Color',[1 0.1, 0]);
    hold on;
    plot(results.Smt(:,3),'Color',[1 1, 0.25]);
    ylim([0 1]);
    % xTickLabel Labels for chart.
    xlim([xTick(1) xTick(end)]);            
    set(gca,'xTick',xTick);
    set(gca,'xTickLabel', xTickLabel);  
    title(('Smoothed Probability'),'FontWeight','bold','FontSize',11,'FontName','Arial');    
    legend('Regime 1','Regime 2','Regime 3','Location','northwest');
end

% Do graph, fit and residuals of the model.
subplot(2,3,1)
plot(results.dta(:,1), '-k','LineWidth',0.75);
hold on
plot(results.yhat2(:,1),'Color',[0 0 1],'LineWidth',0.9);
hold on
plot(results.yhat2(:,2),'Color',[1 0.1, 0],'LineWidth',0.9);
if St == 3
    hold on
    plot(results.yhat2(:,3),'Color',[1 1, 0.25],'LineWidth',0.9);
end
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fit of the model versus data','FontSize',11);
if St == 2
    legend(lab_dep_var,'Regime 1','Regime 2','Location','northwest');
elseif St == 3
    legend(lab_dep_var,'Regime 1','Regime 2','Regime 3','Location','northwest');
end
subplot(2,3,4)
plot(results.uhat, '-b');
hold on
plot(repmat(2*std(results.uhat),results.T,1), ':k');
hold on
plot(repmat(-2*std(results.uhat),results.T,1), ':k');
hold on
plot(zeros(results.T,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Residuals +/- 2 S.D.','FontSize',11);

% Do graph, fit and residuals of the MS model.
yhat_ols = results.dta(:,2:end)*((results.dta(:,2:end)'*results.dta(:,2:end))^(-1)*results.dta(:,2:end)'*results.dta(:,1));
subplot(2,3,2)
plot(results.dta(:,1), '-k','LineWidth',0.75);
hold on
plot(results.yhat(:,1),'Color',[0 0 1],'LineWidth',0.9);
hold on 
plot(yhat_ols(:,1),'Color',[0.75 0 0],'LineWidth',0.9);
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fit of the model versus data','FontSize',11);
legend(lab_dep_var,'MS model','OLS model','Location','northwest');

% Distribution of the residuals.
subplot(2,3,5)
histogram(results.uhat2(:,1),15,'FaceColor',[0 0 1],'EdgeAlpha',1);
hold on
histogram(results.uhat2(:,2),15,'FaceColor',[1 0 0],'EdgeAlpha',1);
legend('Regime 1','Regime 2','Location','northwest');
if St == 3
    hold on
    histogram(results.uhat2(:,3),15,'FaceColor',[1 1, 0.25],'EdgeAlpha',1);
    legend('Regime 1','Regime 2','Regime 3','Location','northwest');
end
title('Histogram for residuals','FontSize',11);


% Additional charts with distribution of parameters.
lab = ['cte'; labels(2:end); 'Sg2'];
k   = size(results.Betas,1);
figure(2)
i = 1;
for i0 = 1:St    
    for i1 = 1:k+1
        % Subplot
        subplot(size(results.Betas,1)+1,St,i)
        % Getting draws fom posterior
        if i1 <= k 
            temp = squeeze(results.B_draws(i1,i0,:));
        else
            temp = results.Sg_draws(:,i0);
        end
        % Chart
        histogram(temp,15,'FaceColor',[0 0 1]);
        title(lab(i1),'FontSize',11);
        i = i + St;
    end
    if St == 2
        i = 2;
    elseif ST == 3
        i = 3;        
    end
end
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
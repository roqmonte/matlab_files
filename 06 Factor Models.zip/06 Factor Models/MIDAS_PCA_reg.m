function results = MIDAS_PCA_reg(y,x,setup,cont,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 02/Feb/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: The codes performs MIDAS estimation using a number of cators
% extracted from the PC of x. The code also adds the optionality to use Almon 
% lags to reduce the number of parameters of the model. By default, the code 
% centers target variable around zero for estimation porpouse only.
% Note 1./ Labels conf. for monthly/quarterly data. 
% Note 2./ Dim between high and low frequency variables (y,x) need to be
%          consistet for the code to work (years*3,years*12).
% Note 3./ setup.sampling variable defines the sampling frequency of the MIDAS
%          modell. If (1,3), it samples first month of the quarter for example.
%
% Inputs:
%   y          : Target variable.
%   x          : Independent variables, dim(T,n). (cte excluded).
%   setup:
%   -.k        : Number of factors (Default: 1)
%   -.lags     : Number of lags for factors (Default 0).
%   -.Almon    : (1) Do Almon quadratic lags (Default no Almon lags)
%   -.sampling : Defines sampling frequency for MIDAS estimation (Default
%                [1 3]). First entry defines staring observation, second
%                entry defines the interval.
%   -.labels   : Labels for group contributions.
%   cont       : Row vector with group id for contributions into model fit. 
%                No contributions if empty (Default no contributions).
%   print      : (1) Do charts and print results on screen.
%   labels     : Column vector with labels for dep. and indep variables.
%   dates      : Vector with info for dates: [year,month,freq].
%                Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results:
%   -.bfacts   : Loadings. Use this to get x's contribution to factors.
%   -.loadings : Loadings principal components.
%   -.betas    : Betas estimates MIDAS regression.
%   -.cte      : Constant term of the model.
%   -.Almon    : Parameters estimates Almon polinomial.
%   -.facts    : Principal components.
%   -.yhat     : Fit of the model.
%   -.uhat     : Residuals.
%   -.R2       : R-square.
%   -.R2adj    : Adjusted R-square.
%   -.data_lf  : Data for MIDAS estimation.
%   -.data_hf  : High frequency data used in MIDAS model.
%   -.yy       : Target variable and fit of the model.
%   -.ymu      : Mean target variable.
%   -.sdata    : Normalized X data.
%   -.mu       : Sample mean X.
%   -.sigma    : Sample standard deviation X.
%   -.cont_hf  : Group contribution to montly fit of centered target
%                variable. Cte included first column.
%   -.cont_lf  : Group contribution to to centered target variable. 
%                Cte included first column, residual included last column.
%
% Index.
% 1. Setup.
% 2. MIDAS estimation.
% 3. Results.
% 4. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup.
% Checking factor configuration.
if isfield(setup,'k') == 0
    setup.k = 1;
end
if isfield(setup,'lags') == 0
    setup.lags = 0;
    setup.Almon= 0;
end
if isfield(setup,'Almon') == 0
    setup.Almon = 0;
end
% Checking sampling frequency.
if isfield(setup,'sampling') == 0
    setup.sampling = [1 3];
end
% Checking contirbutions.
if exist('cont','var') == 0 || isempty(cont)
	cont = [];
end
if sum(cont,2) == 0
    cont = [];
end
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end
% Checking dates.
if exist('dates','var') == 0 || isempty(dates)
    dates = [1900,1,1];
end
    
% Sampling size and # of indep variables
[T,nvar] = size(x);

% Do PCA and keep k fatcors
res_pca = PCAf(x,1);
facts   = res_pca.pca(:,1:setup.k);
loads   = res_pca.loads(:,1:setup.k);
bfacts  = loads;
% Do lags for components
if setup.lags > 0
    x_mat = [];
    for i0 = 1:setup.k
        temp = LagN(facts(:,i0),setup.lags);
        x_mat = [x_mat temp];
    end
    % Adding zeros to keep sampling size constant
    x_mat = [zeros(setup.lags,size(x_mat,2)); x_mat];
else
% No lags of fcators.
    x_mat = facts;
end
clear i0 temp

% Do Almon matrix with quadratic polinomials.
if setup.Almon == 1
    % Checking number of lags
    if setup.lags < 3
        error('Almon lags nneds more than 2 lags');
    end
    p_aux = setup.lags;
    aux   = 1:p_aux;
    A_lags = [1 0 0; [ones(p_aux,1) aux' aux'.^2]];
    % Create block diagonal matrix with Almon lags
    M_almon = A_lags;
    for i0 = 1:setup.k-1
        M_almon = blkdiag(M_almon,A_lags);
    end
    
    % Transform x matrix using Almon lags
    xx = x_mat * M_almon;
    
    clear p_aux aux i0;
else
% Keep original factors only.
    xx = x_mat;
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. MIDAS estimation.
% Centering target variable
my = mean(y);
yy = y - my;

% Define sampling frequency
smpl = setup.sampling;
freq = (smpl(1):smpl(2):T)';

% Sampling from higher frequency data
X_mat_0 = xx(freq,:);
X_mat   = X_mat_0;

% Excluding lags from independent vairables in new frequency
id    = (sum(abs(X_mat),2)==0);
X_mat = X_mat(id==0,:);

% Sample correction for target variable based on lags of factors
if abs(size(X_mat,1) - size(yy,1)) > 0
    yy = yy(id==0,:);
end

% MIDAS estimation
midas = OLSest(yy,[ones(size(yy,1),1) X_mat],'OLS',0.05,print,labels,dates);
if setup.Almon == 0
    betas_ols = midas.b(2:end);
elseif setup.Almon == 1
    betas_ols = reshape(M_almon*midas.b(2:end),setup.lags+1,setup.k);
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Saving resuls, loadings PCS and parameter estomates.
results.bfacts   = bfacts;
results.loadings = loads;
results.MIDASb   = betas_ols;
results.cte      = midas.b(1);
results.Almon    = midas.b;
results.facts    = facts;
% MIDAS model fit and residual.
results.yhat     = midas.yhat;
results.uhat     = midas.uhat;
results.R2       = midas.R2;
results.R2adj    = midas.R2adj;
% Data of the model.
results.ymu      = my;
results.data_lf  = [yy X_mat];
results.data_hf  = X_mat_0;
results.yy       = [(yy + my) (midas.yhat + my)];
results.sdata    = res_pca.sdata;
results.mu       = res_pca.mu;
results.sigma    = res_pca.sigma;

% Do contriubtions
if size(cont,1) > 0
    [cont_hf,cont_lf] = midas_cont(cont,freq,id,results,setup,midas,dates);
    results.cont_hf = cont_hf;
    results.cont_lf = cont_lf;
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions

% This function computes contributions to the in-sample fit of the model.
function [cont_hf,cont_lf] = midas_cont(cont,freq,id,results,setup,midas,dates)
% Setup
nvar      = size(results.sdata,2);
bfacts    = results.bfacts;
betas_ols = results.MIDASb;
T         = size(results.sdata,1);

% Checking grup variables.
if abs(size(cont,2) - nvar) > 0
    error('Check dimension cont variable');
end

% Doing the contributions for each group of variable.
for i0 = 1:max(cont)
    % Group variables.
    xc_aux = results.sdata(:,(cont==i0));
    % Contribution to factors.
    fc_aux = xc_aux*bfacts((cont==i0),:)/nvar;

    % Do lags for factors.
    if setup.lags > 0
        fc_full = [];
        for i1 = 1:setup.k
            temp = LagN(fc_aux(:,i1),setup.lags);
            fc_full = [fc_full temp];
        end        
        res_cont(:,i0) = fc_full*vec(betas_ols);
    else
        res_cont(:,i0) = fc_aux*vec(betas_ols);
    end
    clear xc_aux fc_aux fc_full i1 temp
end

% Adding zeros to track dimension of the model.
res_cont_x = [zeros(setup.lags,max(cont)); res_cont];

% Checking model
aux = res_cont_x(freq,:);
aux = aux(id==0,:);
check1 = midas.yhat - (midas.b(1)+sum(aux,2));

% Results
cont_hf = [zeros(setup.lags,1+max(cont)); [ones(size(res_cont,1),1)*midas.b(1) res_cont]];
% Contribution to lower frequency variable.
cont_lf = [zeros(sum(id),1+max(cont)+1); [midas.b(1)*ones(size(aux,1),1) aux midas.uhat]];
check2 = midas.dta(:,1) - sum(cont_lf(end-midas.T+1:end,:),2);
clear aux i0 i1;

% Check internal consistency of the sum of the contributions
if sum(abs(check1)) + sum(abs(check2)) > 0.001
   display('Check contirbutions form model'); 
end

% Do charts with contirbutions
% Labels for group contributions.
if isfield(setup,'labels') == 0
    aux_t1 = {'Group '}; label_hf = {};
    for i0 = 1:max(cont)
        label_hf = [label_hf strcat(aux_t1,num2str(i0))];
    end
    label_hf = [{'constant'} label_hf];
    label_lf = [label_hf {'Residual'}];
    clear aux_t1 i0;
end    
% Figures
figure(2)
subplot(2,1,1)
[xTick,xTickLabel] = calendar(dates(1),dates(2),T,'m');
bar(cont_hf,'stacked','DisplayName','results.cont')
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Contributions to monthly target variable.','FontSize',11);
legend(label_hf,'Location','northwest')

subplot(2,1,2)
[xTick,xTickLabel] = calendar(dates(1),dates(2),size(cont_lf,1),'q');
bar(cont_lf,'stacked','DisplayName','results.cont')
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Contributions to target variable.','FontSize',11);
legend(label_lf,'Location','northwest')

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
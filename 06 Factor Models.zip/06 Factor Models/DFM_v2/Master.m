%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description:: The code estimates a dinamic factor model using a Gibbs
% Sampling algorithim. The model imposes restrictions on the loadings of
% the factors, to identify a common global factor, regional/block and group factors
% that are orthogonal by construction (2 layers). 
% The model imposes a positive loading on the first variable of each factor 
% to achieve idenitification. The model can be expresed as follows (in matrix form):
%
% Y(t) = a + b*F(t) + e(t)
%
% F(t) =    c*F(t-1)+ u(t)
%
% Where e(t) is the idiosincratic term of the model, and follows an AR(q) proces, 
% e(t) = phi(1)*e(t-1) + ... + phi(q)*e(t-q) + v(t); the factor F(t) follows 
% an AR(p) process. Where v ~ N(0,R), u ~ N(0,Q) and cov(v,u) = 0.
%
% The b matrix contains the factor's loadings and the e(t) term is the
% idiosincratic term of the model. The model assumes that Q is I(n)
% (variances of the factors are normalized to 1).
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Loading data.
clc; clear; close all;
% Seed for the random number generator.
rng(12345);

% Working folder
info.ruta = 'C:\Users\Roque Montero\Google Drive\Codigos_Matlab\06 Dynamic Factor Models\DFM_v2';
cd(info.ruta);
% Loading data.
[~,labels_ini] = xlsread('IMF_HousePriceData_AdvEm','Data','B4:H4');
data_ini = xlsread('IMF_HousePriceData_AdvEm','Data','B5:AH96');

% Data transformation.
data_ini = log(data_ini(5:end,:)) - log(data_ini(1:end-4,:));
% Factor identification
info.Regions   = [23 10];               % Regional factor identification.
info.Groups    = [3 5 15 30 33];         % Groups factor identification.

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Options for the code.
% Number of factors, global, regional/block and group factors.
info.nfact             = 1 + size(info.Regions,2) + sum(info.Regions,2)/info.Groups(1)*(size(info.Groups,2) == 1) ...
                         + size(info.Groups,2)*(1-(size(info.Groups,2) == 1));
% DMF configuration.
info.rep               = 100/2;         % Draws from the posterior.
info.burn              = 50;          % Burning sample.
info.keep              = 2;             % Keep every x draws, to reduce correlation among draws.
info.DoChibGreng       = 1;             % (1) Do Chib and Greenberg when sampling ar terms (Default).
info.arlag             = 4;             % Autoregressive lags in the dynamic factors.
info.arterms           = 3;             % # of AR lags to include in each observable equation (idiosincrstic term).
info.nreg              = 4;             % # of regressors in each observable equation, constant plus global and block factors.
info.conf              = [.68 .90 .95]; % Confidance bands for factors.
% Setting dates.
info.dates_ini  = [1991,1,2];           % First observation of the data.
% Options for plots.
info.widths     = [1 0.7];              % Line widths (zero line, point estim.).
info.fsizes     = [12 10];              % Font sizes (titles, axes).

% Prior setup for parameters of the model.
prior.b0_      = 0;                     % Prior for factor loadings.
prior.B0__     = 1;                     % Prior precision on factors loadings.
prior.r0_      = 0;                     % Prior mean of phi (idiosyncratic AR polynomial).
prior.R0__     = 10;                    % Prior mean precision of phi (idiosyncratic AR polynomial)
prior.v0_      = 1;                     % Inv. gamma param. for innovation variances R, integer.
prior.d0_      = 1;                     % Inv. gamma param. for innovation variances R.
prior.r0f_     = 0;                     % Prior for factor AR polynomial.
prior.R0f__    = 10;                    % Prior precision for factor AR polynomial
prior.sigU     = 1;                     % Factor innovation variance (normalized to 1 by default).

% Preparing data for estimation.
[data,info] = data_make(data_ini,info);
% Building priors.
prior = make_prior(prior,info);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model estimation.
% Model estimation.
[results,draws] = model_estimation(data,info,prior);


%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [data,info] = data_make(data_ini,info)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 10/May/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Generates data for dinamic factor model.
% Input:
%   data_ini        : Matriz with all data.
%   info:
%   -.dates_ini     : Setting for dates: (year,month,freq).
%                     Where, freq: (1) monthly;(2) quaterly data.
%   -.mu            : Vector with sample means.
%   -.sg            : Vector with sample standar deviations.
%   -.T             : Sample size
%   -.arterms       : # of AR lags in the idiosincratic term of the obs. equation.
%   -.nfact         : Number of factors to estimate, global plus additional factor
%   -.nvar          : Number of variables in the model.
%   -.Regions       : Regional factor identification.
%   -.Groups        : Group factor identification.
%   -.DoChibGreng   : (1) Do Chib and Greenberg when sampling ar terms (Default).
%
% Output:
%   data            : Standarize data for model estimation.
%   info:
%   -.m             : Dimension of state vector.
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Data standarization.
[data,mu,sigma] = standardise(data_ini);

% Saving result.
info.mu   = mu;
info.sg   = sigma;
info.T    = size(data,1);
info.nvar = size(data,2);
% Checking regional factor identification.
if size(info.Regions,2) == 1
    info.Regions   = [info.Regions (info.nvar-info.Regions)];
end
info.Regions = cumsum(info.Regions);

% Checking group configuration
if size(info.Groups,2) == 1
    if (floor(info.Regions(end)/info.Groups) - info.Regions(end)/info.Groups) > 0
        error('Group varialbe not consistent with dim(data)'); 
    end
else
    if info.Regions(end)/info.Groups(end) ~= 1
        error('Group varialbe not consistent with dim(data)');     
    end
end
% Dimension of state vector
info.m = info.nfact*(info.arterms + 1); 

% Checking Chib and Grenberg.
if info.DoChibGreng ~= 1
    info.DoChibGreng = 0;
end

% Generating dates.
T = length(data_ini);
if info.dates_ini(end) == 1
	freq = 'm';
elseif info.dates_ini(end) == 2
	freq = 'q';
end
[time1,time2] = calendar(info.dates_ini(1),info.dates_ini(2),T,freq);
info.dates_xTick = time1;
info.dates_label = time2;


%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
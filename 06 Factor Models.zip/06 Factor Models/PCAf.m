function results = PCAf(data,stand)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 22/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Function extracts principal components from a matrix of
% data. The code standarizes the data, and then compute the eigenvectors
% and eigenvalues to extract the principal components. Note that by
% default, loadings are normalized such that L'*L/n = In. 
%
% Use fac*load' to get normalized data
% Use fac*load'*std + mu to get original data
% Use sdata*load/n to get contribuions to factors.
%
% Inputs:
%   data       : Matrix of data (T,N).
%   info       : (1) standarize data before PCA, (0) use raw data (Default: 1).
%
% Outputs:
%   results : 
%   -.pca      : Principal components.
%   -.loads    : Loadings, such that L'*L/n = In.
%   -.evc      : Sorted eigenvectors.
%   -.eigv     : Sorted eigenvalues..
%   -.varxp    : % var. explained by each principal component.
%   -.cs_vxp   : Cumulative sum var. explained by each component.
%   -.sdata    : Normalized data.
%   -.mu       : Sample mean
%   -.sigma    : Sample standard deviation.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Checking unput from code
[T,n] = size(data);
% Standarize the data
if exist('stand','var') == 0
    stand = 1;
end
if stand == 1
    [sdata,mu,sigma] = standardise(data);
else
    sdata = data;
    mu    = mean(data,1);
    sigma = std(data,1);
end

% Variance-covariance matrix
V = cov(sdata);

% Compute eigenvectors/eigenvalues decomposition of V
[evec,eval] = eig(V);

% Sorting eigenvalues in descending order and save the sorting permutation in index
[eval,index] = sort(diag(eval),'descend');

% Sorting eigenvectors accordingly, from largest to smallest eigenvalue.
evc = zeros(n,n);
for i=1:n
    evc(:,i) = evec(:,index(i));
end

% Eigenvectors normalised by square root of #data series
load = sqrt(n)*evc;
% Compute principal component vectors from standard formula.
fac  = sdata*load/n;


% Saving results
results.pca   = fac;
results.loads = load;
results.evc   = evc;
results.eigv  = eval;
results.varxp = eval./sum(eval);
results.cs_vxp= cumsum(results.varxp);
results.sdata = sdata;
results.mu    = mu;
results.sigma = sigma;

% Data check
data_check = data - ((fac*load'.*repmat(std(data),T,1))+ repmat(mean(data),T,1));
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description:: The code estimates a dinamic factor model using a Gibbs
% Sampling algorithim. The model imposes restrictions on the loadings of
% the factors, to identify a common global factor, and regional/block factors
% that are orthogonal by construction (1 layer). 
% The model imposes a positive loading on the first variable of each factor 
% to achieve idenitification. 
% State-space representation of the model:
%
% Observation Equation : Y(t) =  a + b*F(t) + e(t)
%                        e(t) =  rho(1)*e(t-1) + ... + rho(q)*e(t-q) + v(t)
% Transition Equation  : F(t) =    f(1)*F(t-1) + ... +   f(p)*F(t-p) + u(t)
%
% Where v ~ N(0,R), u ~ N(0,Q), cov(v,u) = 0 and p > q.
%
% The b matrix contains the factor's loadings and the e(t) term is the
% idiosincratic term of the model. The model assumes that Q is I(n)
% (variances of the factors are normalized to 1).
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Loading data.
clc; clear; close all;
% Seed for the random number generator.
rng(12345);

% Working folder
info.ruta = 'C:\Users\Roque Montero\Google Drive\Codigos_Matlab\06 Factor Models\DFM_v1';
cd(info.ruta);
% Loading data.
[~,labels_ini] = xlsread('IMF_HousePriceData_AdvEm','Data','B4:AH4');
data_ini = xlsread('IMF_HousePriceData_AdvEm','Data','B5:AH96');

% Data transformation.
data_ini = log(data_ini(5:end,:)) - log(data_ini(1:end-4,:));
% Factor identification
info.Regions   = [23 10];               % Regional factor identification.

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Options for the code.
% Number of factors, global plus regional/block factors.
info.nfact             = 1 + size(info.Regions,2);
% DMF configuration.
info.rep               = 100;         % Draws from the posterior.
info.burn              = 50;          % Burning sample.
info.keep              = 1;             % Keep every x draws, to reduce correlation among draws.
info.DoChibGreng       = 1;             % (1) Do Chib and Greenberg when sampling ar terms (Default).
info.arlag             = 4;             % Autoregressive lags in the dynamic factors.
info.arterms           = 3;             % # of AR lags to include in each observable equation (idiosincrstic term).
info.nreg              = 3;             % # of regressors in each observable equation, constant plus global and block factors.
info.conf              = [.68 .90 .95]; % Confidance bands for factors.
% Setting dates.
info.dates_ini  = [1991,1,2];           % First observation of the data.
% Options for plots.
info.widths     = [1 0.7];              % Line widths (zero line, point estim.).
info.fsizes     = [12 10];              % Font sizes (titles, axes).
info.area_color = [0.9 0.9 0.9];        % Color of area for highest sign. level.
info.names      = labels_ini;           % Labels for variables.
info.fnames     = {'Global' 'Regional A' 'Regional B'}; % Labels for factors.

% Prior setup for parameters of the model.
prior.b0_      = 0;                     % Prior for factor loadings.
prior.B0__     = 1;                     % Prior precision on factors loadings.
prior.r0_      = 0;                     % Prior mean of phi (idiosyncratic AR polynomial).
prior.R0__     = 10;                    % Prior mean precision of phi (idiosyncratic AR polynomial)
prior.v0_      = 1;                     % Inv. gamma param. for innovation variances R, integer.
prior.d0_      = 1;                     % Inv. gamma param. for innovation variances R.
prior.r0f_     = 0;                     % Prior for factor AR polynomial.
prior.R0f__    = 10;                    % Prior precision for factor AR polynomial
prior.sigU     = 1;                     % Factor innovation variance (normalized to 1 by default).

% Preparing data for estimation.
[data,info] = data_make(data_ini,info);
% Building priors.
prior = make_prior(prior,info);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model estimation.

% Model estimation.
[results,draws] = model_estimation(data,info,prior);

% Plot factors.
DFM_Plot_factors(results,info,1);
% Plot in-sample fit for selected variables.
DFM_Plot_contributions(results,info,2,1:16);
% Plot variance decomposition.
DFM_Plot_Vdecomp(results,info,3);
% Plot IRF for selected factor.
[irf_v,irf_f] = DFM_Plot_IRF(results,draws,info,1,4);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function DFM_Plot_factors(results,info,fid,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 13/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Plot factors
% Input:
%   results:
%   -.F             : Posterior mean factor.
%   -.Xt(XX)        : Draws factors.
%   info:
%   -.dates_xTick : Xtick for dates.
%   -.dates_label : Labels for dates.
%   -.area_color  : Color of area for last significance level (1 x 3).
%   -.fnames      : Labels for factors.
%   -.widths      : vector with line widths.
%   -.fsizes      : vector with font sizes.
%   -.conf        : Confidance bands for factors.
%   fid           : Figure number for plots.
%   vars          : Data selection for charts
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Geting inputs
if exist('fid','var') == 0
    fid = 1;
end

% Option for plota
line_width      = info.widths(1);
fsize           = info.fsizes(1);
fsize_alt       = info.fsizes(2);
xTick           = info.dates_xTick;
xTickLabel      = info.dates_label;
area_step       = 0.1;

% Data selection
facts =  results.F;
fnames = info.fnames;
nobs  = size(facts,1);
T_aux = xTick(end);

% Data selection for charts
if exist('vars','var') == 1
    facts = facts(:,vars);
    fnames  = info.fnames(:,vars);
end
% # of factors.
nf = size(facts,2);

% Confidance bands
conf    = [(1 - info.conf)/2; 1-(1-info.conf)/2];
nbands  = length(conf);
for i0 = 1:size(conf,2)
    eval(['lb(:,:,i0) = results.Xt' num2str(round(conf(1,i0)*100)) ';']);
    eval(['ub(:,:,i0) = results.Xt' num2str(round(conf(2,i0)*100)) ';']);
end


% Plot factors only
figure(fid);
temp = NaN(xTick(end)-nobs,1);
k = 1;
for j = 1:nf
    % Do plots.
    subplot(nf,2,k);
    h(2) = plot(1:T_aux,[temp; facts(:,j)],'-b','LineWidth',line_width);   
    % Labels
    title(fnames(j),'FontSize',fsize);
    set(gca,'FontSize',fsize_alt);
    xlim([xTick(1) xTick(end)]);
    set(gca,'XTick',xTick);
    set(gca,'XTickLabel',xTickLabel);
    k = k + 2;
end

% Plot factors anc confidance bands.
figure(fid);
temp = NaN(xTick(end)-nobs,1);
k = 2;
for j = 1:nf
    % Do plots.
    subplot(nf,2,k);
    % Area graph.
    area_color = info.area_color;
    for i = nbands:-1:1
        shadedplot(1:T_aux,[temp; lb(:,j,i)]',[temp; ub(:,j,i)]',area_color);
        area_color = area_color-area_step;
        hold on
    end
    % Factor.
    h(2) = plot(1:T_aux,[temp; facts(:,j)],'-b','LineWidth',line_width);
    
    % Labels
    title(fnames(j),'FontSize',fsize);
    set(gca,'FontSize',fsize_alt);
    xlim([xTick(1) xTick(end)]);
    set(gca,'XTick',xTick);
    set(gca,'XTickLabel',xTickLabel);
    k = k + 2;
end

legend1 = legend(h(2),['Factors and ',num2str(info.conf(1)*100) ', ',num2str(info.conf(2)*100) ' and ',num2str(info.conf(3)*100) ' percent confidence bands']);
set(legend1,'FontSize',fsize_alt,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
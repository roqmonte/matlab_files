function [data,info] = data_make(data_ini,info)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 10/May/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Generates data for dinamic factor model.
% Input:
%   data_ini        : Matriz with all data.
%   info:
%   -.names         : Labels for variables.
%   -.fnames        : Labels for factors.
%   -.dates_ini     : Setting for dates: (year,month,freq).
%                     Where, freq: (1) monthly;(2) quaterly data.
%   -.mu            : Vector with sample means.
%   -.sg            : Vector with sample standar deviations.
%   -.T             : Sample size
%   -.arlag         : Autoregressive lags in the dynamic factors.
%   -.arterms       : # of AR lags to include in idiosincratic term.
%   -.nfact         : Number of factors to estimate, global plus additional factor
%   -.nvar          : Number of variables in the model.
%   -.Regions       : Regional factor identification.
%   -.DoChibGreng   : (1) Do Chib and Greenberg when sampling ar terms (Default).
%
% Output:
%   data            : Standarize data for model estimation.
%   info:
%   -.m             : Dimension of state vector.
%   -.dates_xTick   : Xtick for dates.
%   -.dates_label   : Labels for dates.
%   -.names         : Labels for variables.
%   -.fnames        : Labels for factors.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Check configuration ar terms of the model.
if info.arlag <= info.arterms
   error('Check configuration ar terms of the model.') 
end
% Data standarization.
[data,mu,sigma] = standardise(data_ini);
% Dimension of state vector
info.m = info.nfact*info.arlag;

% Saving result.
info.mu   = mu;
info.sg   = sigma;
info.T    = size(data,1);
info.nvar = size(data,2);
% Checking regional factor identification.
if size(info.Regions,2) == 1
    info.Regions   = [info.Regions (info.nvar-info.Regions)];
end
info.Regions = cumsum(info.Regions);

% Checking Chib and Grenberg.
if info.DoChibGreng ~= 1
    info.DoChibGreng = 0;
end

% Generating dates.
T = length(data_ini);
if info.dates_ini(end) == 1
	freq = 'm';
elseif info.dates_ini(end) == 2
	freq = 'q';
end
[time1,time2] = calendar(info.dates_ini(1),info.dates_ini(2),T,freq);
info.dates_xTick = time1;
info.dates_label = time2;

% Labels for variables.
aux_t1 = {'Var '}; aux_t2 = {};
for i0 = 1:size(data_ini,2)
    aux_t2 = [aux_t2 strcat(aux_t1,num2str(i0))];
end
% Checking labels for variables.
if isfield(info,'names') == 0
    info.names = aux_t2;
else
    if size(info.names,2) < size(data_ini,2)
        info.names = [info.names aux_t2(:,size(info.names,2)+1:end)];
    end
end
% Labels for factors.
aux_t1 = {'Factor '}; aux_t2 = {};
for i0 = 1:info.nfact
    aux_t2 = [aux_t2 strcat(aux_t1,num2str(i0))];
end
% Checking labels for variables.
if isfield(info,'fnames') == 0
    info.fnames = aux_t2;
else
    if size(info.fnames,2) < info.nfact
        info.fnames = [info.fnames aux_t2(:,size(info.fnames,2)+1:end)];
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
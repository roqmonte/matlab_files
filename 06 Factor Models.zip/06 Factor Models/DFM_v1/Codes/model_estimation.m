function [results,drawsp] = model_estimation(data,info,prior)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Jun/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of a dinamic factor model.
% Inputs:
%   data            : Standarized data.
%   info:
%   -.rep           : Number of draws from posterior.
%   -.burn          : Burning sample.
%   -.keep          : Keep every x draws, to reduce correlation among draws.
%   -.T             : Sample size
%   -.nvar          : Number of variables in the model.
%   -.nreg          : # of regressors in each observable equation, constant plus factors.
%   -.arterms       : # of AR lags to include in idiosincratic term.
%   -.nfact         : Number of factors to estimate, global plus additional factors.
%   -.arlag         : Autoregressive lags in the dynamic factors.
%   -.m             : Dimension of state vector.
%   -.Regions       : Regional factor identification.
%   -.conf          : Confidance bands for factors.
%   -.DoChibGreng   : (1) Do Chib and Greenberg when sampling ar terms (Default).
%   prior:
%   -.b0_           : Priors for loadins.
%   -.B0__          : Prior precision of factor loading.
%   -.r0_           : Prior mean of phi (idiosyncratic AR polynomial).
%   -.R0__          : Prior mean precision of phi (idiosyncratic AR polynomial)
%   -.v0_           : Inv. gamma param. for innovation variances R, integer.
%   -.d0_           : Inv. gamma param. for innovation variances R.
%   -.r0f_          : Prior for factor AR polynomial.
%   -.R0f__         : Prior precision for factor AR polynomial
%   -.sigU          : Factor innovation variance.
%
% Outputs:
%   results:
%   -.F             : Posterior mean factor.
%   -.B             : Posterior mean loadings.
%   -.S             : Posterior mean Sg2 observation equation.
%   -.rho           : Posterior mean arterms observation equation.
%   -.f             : Posterior mean ar coeff. state equation.
%   -.Vdecomp       : Posterior mean variance decompositoin.
%   -.Xt(XX)        : Confidance bands for factors.
%   results:
%   -.Xt            : Factor draws.
%   -.B             : Loadings draws.
%   -.S             : Draws Sg2 observation equation.
%   -.rho           : Draws arterms observation equation.
%   -.f             : Draws ar coeff. stete equation.
%   -.y             : Standarized data.
%   -.yhat          : In-sample fit model, dim(T,nvar).
%   -.f_hat         : Overall fit form factors, dim(T,nvar).
%   -.f_hat2        : Fit from each factor, dim(T,nfact,nvar).
%   -.l_cte         : Fit from constant term of the observable equation, dim(T,nvar).
%   -.rho_hat       : Fit arterms of the observable equation, dim(T,nvar).
%   -.uhat          : Residual from observable equation.
%   -.Vdecomp       : Posterior mean variance decompositoin.
%
% Index:
% 1. Setup of the model.
% 2. Simulations.
% 3. Results.
% 4. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup of the model.
% Getting info from the code.
y       = data;
nvar    = info.nvar;
T       = info.T;
nreg    = info.nreg;
arterms = info.arterms;
nfact   = info.nfact;
arlag   = info.arlag;
m       = info.m;
m2      = arterms+1;
draws   = info.rep;
burn    = info.burn;
Regions = info.Regions;
nRegions= size(Regions,2);
ChibGren= info.DoChibGreng;
% Set up some matricies to storage reults.
bsave    = zeros(draws+burn,nreg*nvar);         % Loaddngs draws.
psave2   = zeros(draws+burn,nvar*arterms);      % Idiosincratic autoregressive polynomials
ssave    = zeros(draws+burn,nvar);              % Innovation variances draws.
psave    = zeros(draws+burn,nfact*arlag);       % Factor autoregressive polynomials
Xtsave   = zeros(T-arterms,nfact,(draws+burn)); % Factor draws.

% Draws for Variance decompositions (VD)
vdecomW  = zeros(draws+burn,nvar);
vdecomR  = zeros(draws+burn,nvar);
vdecomI  = zeros(draws+burn,nvar);

% Checking AR lag order on observable equation.
if arterms > 0  
    Ylagmat = [];
    for i0 = 1:nvar
        temp_ = LagN(y(:,i0),arterms);
        temp_ = temp_(:,2:end);
        Ylagmat  = [Ylagmat temp_];
        clear temp_
    end
    % Adjusting data.
    y = y(arterms+1:T,:);
end
Tbar = size(y,1);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Simulations.

% Initialize and set up factor model
A       = zeros(nvar,1);        % Matrix for ss represenation.
H       = zeros(nvar,m);        % Matrix for ss represenation.
bold    = zeros(nvar,nreg);     % Matrix stores and tracks draws for loadings.
phimat0 = zeros(arterms,nvar);  % Matrix stores and tracks draws idiosincratic AR terms.
SigE    = ones(nvar,1)*0.0001;  % Vector stores and tracks draws Sg2 observable equation.
phi     = zeros(arlag,nfact);   % Vector stores and tracks draws AR coeff. state equation (factors).

% Factor initialization
facts      = randn(Tbar,nfact);
facts(:,1) = mean(y,2)';

% Just dimensioning for later
ystar = y;

% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');
disp('-Note: Explosive roots are discarded from simulations.');


% Simulations, the code loops over each variable to get coefficients equation by equation
for dr = 1:draws+burn
    % Update waitbar
    waitbar(dr/(draws+burn),h_wait)

    % First regional factor.
    jj  = 1;
    nf  = 2;    
    % Check loading condition on factor.
    First = 1;
    
    % Looping over each variable
    for i = 1 : nvar
        % Draws observable equation, factor loadings and AR terms
        [b1,s21,phi1,facts] = draws_param_eqs(y(:,i),arterms,ChibGren,prior,bold(i,:)',SigE(i),phimat0(:,i),i,nf,facts,First);
        % Updating initial values for next draw.
        bold(i,:)    = b1';
        phimat0(:,i) = phi1;
        SigE(i)      = s21;        
        % Storing loadings, AR idiosincratic terms Sg2 draws.
        bsave(dr,((i-1)*nreg)+1:i*nreg) = b1';
        ssave(dr,i) = s21;
        psave2(dr,((i-1)*arterms)+1:i*arterms) = phi1';
        
        % Matrices with loadings for state space representation of the model.
        A(i,1) = b1(1)*(1-sum(phi1,1));
        % Filling globalfactor.
        temp  = b1(2)*[1 ((-1)*phi1)'];
        ntemp = size(temp,2);
        H(i,1:ntemp) = temp;
        % Filling regional factors.
        H(i,((nf-1)*ntemp)+1:nf*ntemp) = b1(3)*[1 ((-1)*phi1)'];
        clear temp ntemp i1;
               
        % Variance decompositoin
        [Wvdc,Rvdc,Ivdc] = Vdecomp(facts,nf,y(:,i));
        vdecomW(dr,i) = Wvdc;
        vdecomR(dr,i) = Rvdc;
        vdecomI(dr,i) = Ivdc;
        
        % Quasi-differenced observable variables if ar-terms are specified in the observable equation.
        if ge(arterms,1)
            ystar(:,i) = y(:,i) - sum((repmat(phi1',size(Ylagmat,1),1).*Ylagmat(:,((i-1)*arterms)+1:(i*arterms))),2);
        else
            ystar(:,i) = y(:,i);
        end
        
        % Checking if sign condition on regional factor variable should be check.
        if i == Regions(jj)
            % Moving to next regional factor.
            nf = nf + 1;
            jj = jj + 1;
            % Condition to check loading sign.
            First = 1;
        else
            % No check on loading sign.
            First = 0;
        end   
    end
    
    % Draw factor AR coefficients
    % Stationarity check
    scheck = -1;
    while scheck < 0
        F = zeros(m,m);
        j = 1;
        % Do AR coefficients one at a time.
        for i = 1:nfact
            phi(:,i) = draws_param_st(facts(:,i),arlag,ChibGren,prior,phi(:,i),prior.sigU(j,1));
            % Storing AR terms in block-diag matrix for stationarity check.
            F(j:j+arterms,j:j+arterms) = [[phi(:,i)' zeros(1,m2 - arlag)]; [eye(arterms), zeros(arterms,1)]];
            psave(dr,(i-1)*arlag+1:(i-1)*arlag+arlag)=phi(:,i)';
            j = j + (arterms+1);
        end
        % Checkinng stationarity.
        meigsF = max(abs(eig(F)));
        if ge(meigsF,0.99)
            scheck = -1;
        else
            scheck = 1;    
        end
    end
    clear j i scheck meigsF;
    
    % Draws of factors.
    BsigU = diag(prior.sigU);
    BsigE = diag(SigE);
    % Kalman filter 
    [Xtgt,~,~,Stgt] = kfilter_LJ(ystar,F,H,BsigU,BsigE,ones(Tbar,1),A);
    Xt          = kf_ckohn_LJ_factor(Stgt,Xtgt,F,nfact,m2,prior.sigU);
    
    % Saving and updating factors.
    for i = 1 : nfact
        Xtsave(:,i,dr) = Xt(:,1+m2*(i-1));
        facts(:,i) = Xt(:,1+m2*(i-1));
    end
    clear b1 s21 phi1 BsigU BsigE Xtgt Stgt F i BsigU BsigE jj nf i0 bhatv orthC varag;
end
close(h_wait)

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Discarding initial draws from simulations.
Xtsave   = Xtsave(:,:,burn+1:end);
bsave    = bsave(burn+1:end,:);
ssave    = ssave(burn+1:end,:);
rho      = psave2(burn+1:end,:);
f        = psave(burn+1:end,:);
vdecomW  = vdecomW(burn+1:end,:);
vdecomR  = vdecomR(burn+1:end,:);
vdecomI  = vdecomI(burn+1:end,:);

% Adjusting draws fom posterior to reduce correlation in draws.
if info.keep > 1
    Xtsave   = Xtsave(:,:,1:info.keep:end);
    bsave    = bsave(1:info.keep:end,:);
    ssave    = ssave(1:info.keep:end,:);
    rho      = psave2(1:info.keep:end,:);
    f        = psave(1:info.keep,:);
    vdecomW  = vdecomW(1:info.keep:end,:);
    vdecomR  = vdecomR(1:info.keep:end,:);
    vdecomI  = vdecomI(1:info.keep:end,:);
end

% Saving draws from posterior.
drawsp.Xt  = Xtsave;
drawsp.B   = bsave;
drawsp.S   = ssave;
drawsp.rho = rho;
drawsp.f   = f;
drawsp.VDW = vdecomW;
drawsp.VDR = vdecomR;
drawsp.VDI = vdecomI;

% Saving posterior mean.
results.F   = mean(Xtsave,3);

% Loadings observable equation, including constant term.
temp = mean(bsave,1);
i = 1; j = 1;
for i0 = nreg:nreg:size(temp,2)
    tempB(j,:) = temp(1,i:i0);
    i = i + nreg;
    j = j + 1;
end
% Adjusting regional factor.
B2 = tempB(:,3:end);
temp = zeros(nvar,nRegions);
temp(1:Regions(1),1) = B2(1:Regions(1),1);
for i0 = 1:nRegions-1
    temp(Regions(i0)+1:Regions(i0+1),i0+1) = B2(Regions(i0)+1:Regions(i0+1),1);
end
results.B = [tempB(:,1:2) temp];

% arterms observable equation.
temp = mean(rho,1);
i = 1; j = 1;
for i0 = arterms:arterms:size(temp,2)
    results.rho(j,:) = temp(1,i:i0);
    i = i + arterms;
    j = j + 1;
end

% Sg2 observable equation.
results.S   = mean(ssave,1)';

% AR terms state equation.
temp = mean(f,1);
i = 1; j = 1;
for i0 = arlag:arlag:size(temp,2)
    results.f(j,:) = temp(1,i:i0);
    i = i + arlag;
    j = j + 1;
end

% Variance decomposition.
temp = mean(vdecomR,1);
VDR  = zeros(nvar,nRegions);
VDR(1:Regions(1),1) = temp(1:Regions(1));
for i0 = 1:nRegions-1
   temp1 = temp(Regions(i0)+1:Regions(i0+1));
   VDR(Regions(i0)+1:Regions(i0+1),i0+1) = temp1;
end
results.Vdecomp = [mean(vdecomW,1)' VDR mean(vdecomI,1)'];

% In-sample fit from model.
[yhat,f_hat,f_hat2,l_cte,rho_hat,uhat] = fit(y,results,nvar,arterms);
results.y       = y;
results.yhat    = yhat;
results.f_hat   = f_hat;
results.f_hat2  = f_hat2;
results.l_cte   = l_cte;
results.rho_hat = rho_hat;
results.uhat    = uhat;

% Confidance bands for factor.
Xtsort  = sort(Xtsave,3);
conf    = [(1 - info.conf)/2; 1-(1-info.conf)/2];
draws   = size(Xtsort,3);
for i0 = 1:size(conf,2)
    eval(['results.Xt' num2str(round(100*conf(1,i0))) '= Xtsort(:,:,round(' num2str(conf(1,i0)) ' *draws));']);
    eval(['results.Xt' num2str(round(100*conf(2,i0))) '= Xtsort(:,:,round(' num2str(conf(2,i0)) ' *draws));']);
end
results.Xt50 = Xtsort(:,:,round(0.5*draws));

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions.

% Function comptes the contribution from each component of the model to the
% in-sample fit.
function [yhat,f_hat,f_hat2,l_cte,rho_hat,uhat] = fit(y,results,nvar,arterms)
% Input
%  y       : Data.
%  resuls:
%   -.F    : Posterior mean factor.
%   -.B    : Posterior mean loadings.
%  -.rho   : Posterior mean arterms observation equation
%  nvar    : # variables.
%  arterms : ar terms idiosincratic term.
%
% Output:
%  yhat    : In-sample fit model, dim(T,nvar).
%  f_hat   : Overall fit form factors, dim(T,nvar).
%  f_hat2  : Fit from each factor, dim(Tnvar,nfact,T).
%  l_cte   : Fit from constant term of the observable equation, dim(T,nvar).
%  rho_hat : Fit arterms of the observable equation, dim(T,nvar).
%  uhat    : Residual from observable equation.

% In-sample fit of the model.
temp1 = size(results.F,1);
for i0 = 1:temp1
    % Fit from factors and constant term.
    aux(:,:,i0) = results.B.*repmat([1 results.F(i0,:)],nvar,1);
end
resid = y - squeeze(sum(aux,2))';

% Fit idiosincratic terms
for i0 = 1:size(resid,2)
    temp1 = resid(:,i0);
    temp2 = LagN(temp1,arterms);
    ecap  = [zeros(arterms,arterms); temp2(:,2:end)];
    aux2(:,i0) = ecap*results.rho(i0,:)';
end
residf = y - squeeze(sum(aux,2))' - aux2;

% Saving results
yhat    = squeeze(sum(aux,2))' + aux2;
f_hat   = squeeze(sum(aux,2))';
temp    = aux(:,2:end,:);
for i0 = 1:nvar
	f_hat2(:,:,i0) = squeeze(temp(i0,:,:))';
end
l_cte   = squeeze(aux(:,1,:))';
rho_hat = aux2;
uhat    = residf;

% Funtion performs factor ortogonalization.
function [Wvdc,Rvdc,Ivdc] = Vdecomp(facts,nf,y)
% Input:
%  facts : factors.
%  nf    : Regional factor id.
%  y     : Data.
%
% Output:
%  Gvdc  : VD global factor.
%  Rvdc  : VD regional factor.
%  Ivdc  : VD idiosincratic factor.

% Global factor ortogonalization.
bhatv = (facts(:,1)'*facts(:,1))^(-1)*(facts(:,1)'*facts(:,nf));
% Ortogonalized regional factor
orthR = facts(:,nf) - facts(:,1)*bhatv;
% New loadings.
bhatv = ([facts(:,1) orthR]'*[facts(:,1) orthR])^(-1)*([facts(:,1) orthR]'*y);
% Variance contribution from each factor.
bhatv = bhatv.^2;
% Total variance.
varag = std(y)^2;
% Storing results from decomposition.
Wvdc = (bhatv(1)*(std(facts(:,1))^2))/varag;
Rvdc = (bhatv(2)*(std(orthR)^2))/varag;
Ivdc = 1 - Wvdc - Rvdc;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
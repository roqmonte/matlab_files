function DFM_Plot_contributions(results,info,fid,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 13/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Contributions to in-sample fit (standarized data).
% Input:
%   results:
%   -.y           : Standarized data.
%   -.yhat        : In-sample fit model, dim(T,nvar).
%   -.f_hat       : Overall fit form factors, dim(T,nvar).
%   -.f_hat2      : Fit from each factor, dim(T,nfact,nvar).
%   -.l_cte       : Fit from constant term of the observable equation, dim(T,nvar).
%   -.rho_hat     : Fit arterms of the observable equation, dim(T,nvar).
%   -.uhat        : Residual from observable equation.
%   info:
%   -.dates_xTick : Xtick for dates.
%   -.dates_label : Labels for dates.
%   -.names       : Labels for variables.
%   -.widths      : vector with line widths.
%   -.fsizes      : vector with font sizes.
%   fid           : Figure number for plots.
%   vars          : Data selection for charts
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Geting inputs
if exist('fid','var') == 0
    fid = 1;
end

% Option for plota
line_width      = info.widths(1);
fsize           = info.fsizes(1);
fsize_alt       = info.fsizes(2);
names           = info.names;
xTick           = info.dates_xTick;
xTickLabel      = info.dates_label;
% Data selection
data  = results.y;
cte   = results.l_cte;
facts = results.f_hat2;
yars  = results.rho_hat;
uhat  = results.uhat;

% Data selection for charts
if exist('vars','var') == 1
    data  = data(:,vars);
    cte   = cte(:,vars);
    facts = facts(:,:,vars);
    yars  = yars(:,vars);
    uhat  = uhat(:,vars);
    names  = info.names(:,vars);
end
[nobs,nvars]    = size(data);

% Number of variables and graph setup.
aux = size(data,2);
font_aux = 0;
if aux <= 3
    k1 = 1; k2 = aux;
elseif aux <= 4
    k1 = 2; k2 = 2;
elseif aux > 4 && aux <= 6
    k1 = 3; k2 = 2;
elseif aux > 6 && aux <= 9
    k1 = 3; k2 = 3;
elseif aux > 9 && aux <= 16
    k1 = 4; k2 = 4;
elseif aux > 16 && aux <= 24
    k1 = 4; k2 = 6;
    font_aux = 1;
elseif aux > 24 && aux <= 30
    k1 = 5; k2 = 6;
    font_aux = 2;
elseif aux > 30 && aux <= 36
    k1 = 6; k2 = 6;
    font_aux = 3;
elseif aux > 36
    error('Max number of variables reached.');
end

% Adding extra labels for chart.
fnames = ['cte' info.fnames 'ar' 'residual'];

% Plot data against fitted values
figure(fid);
k = 1;
for j = 1:nvars
    % Data for charts.
    aux  = size([cte(:,j) facts(:,:,j) yars(:,j) uhat(:,j)],2);
    temp = [NaN(xTick(end)-nobs,aux); [cte(:,j) facts(:,:,j) yars(:,j) uhat(:,j)]];
    yy   = data(:,j);
    % Do plots.
    subplot(k2,k1,k);
    %bar(temp,'stacked','LineStyle','none');
    bar(temp,'LineStyle','none');
    hold on
    plot([NaN(xTick(end)-nobs,1); yy],'-k','LineWidth',line_width);
    % Labels and titles.
    title(names(j),'FontSize',fsize);
    set(gca,'FontSize',fsize_alt-font_aux);
    if j == nvars
        legend1 = legend(fnames);
        set(legend1,'FontSize',fsize_alt,'Position',[0.95 0.73 0.0 0.25],...
                    'Orientation','vertical','Box', 'on');
    end
    xlim([xTick(1) xTick(end)]);
    set(gca,'XTick',xTick);
    set(gca,'XTickLabel',xTickLabel);

    k = k + 1;    
    clear aux temp yy;
end
clear j k k1 k2;


%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
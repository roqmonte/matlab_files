function DFM_Plot_Vdecomp(results,info,fid,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 13/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Plot var. decompositions.
% Input:
%   results:
%   -.Vdecomp       : Posterior mean variance decompositoin.
%   info:
%   -.names       : Labels for variables.
%   -.widths      : vector with line widths.
%   -.fsizes      : vector with font sizes.
%   fid           : Figure number for plots.
%   vars          : Data selection for charts
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Geting inputs
if exist('fid','var') == 0
    fid = 1;
end

% Option for plota
fsize           = info.fsizes(1);
fsize_alt       = info.fsizes(2);
names           = info.names;
fnames          = info.fnames;
% Data selection
data  = results.Vdecomp(:,1:end-1);

% Data selection for charts
if exist('vars','var') == 1
    data  = data(:,vars);
    names  = info.names(:,vars);
end

% Number of variables and graph setup.
aux = size(data,1);
if aux <= 40
    k1 = 1;
    Y1 = data;
    names1 = names;
elseif aux > 40 && aux <= 80
    k1 = 2;
    Y1 = data(1:40,:);
    Y2 = data(41:aux,:);
    names1 = names(1:40);
    names2 = names(41:aux);
elseif aux > 80 && aux <= 120
    k1 = 3;
    Y1 = data(1:40,:);
    Y2 = data(41:80,:);
    Y3 = data(81:aux,:);
    names1 = names(1:40);
    names2 = names(41:80);
    names3 = names(81:aux);
elseif aux > 120
    error('Max number of variables reached.');
end

% Plot data against fitted values
figure(fid);
for j = 1:k1
    % Labels and data
    eval(['X = categorical(names' num2str(j) ');']);
    eval(['Y = Y' num2str(j) ';']);
    
    % Do plot.
    subplot(k1,1,j);
    bar(X,Y,'stacked','LineStyle','none')
    ylim([0 1]);
    
    % Labels
    title('Variance decomposition for factors contributions','FontSize',fsize);
    set(gca,'FontSize',fsize_alt);
end
legend1 = legend(fnames);
set(legend1,'FontSize',fsize_alt,'Position',[0.95 0.73 0.0 0.25],'Orientation','vertical','Box', 'on');

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
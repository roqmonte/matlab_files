function prior = make_prior(prior,info)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 10/May/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Funtion generates priors for dinamic factor model (DFM).
% Inputs:
%   prior:
%   -.b0_           : Prior loadings.
%   -.B0__          : Prior precision on factors loadings.
%   -.r0_           : Prior mean of phi (idiosyncratic AR polynomial).
%   -.R0__          : Prior mean precision of phi (idiosyncratic AR polynomial)
%   -.v0_           : Inv. gamma param. for innovation variances R, integer.
%   -.d0_           : Inv. gamma param. for innovation variances R.
%   -.r0f_          : Prior for factor AR polynomial.
%   -.R0f__         : Prior precision for factor AR polynomial
%   -.sigU          : Factor innovation variance (normalized to 1 by default).
%   info:
%   -.T             : Sample size
%   -.nvar          : Number of variables in the model.
%   -.arterms       : # of AR lags in the idiosincratic term of the obs. equation.
%   -.nfact         : Number of factors to estimate, global plus additional factors.
%   -.arlag         : Autoregressive lags in the dynamic factors.
%
% Outputs:
%   prior:
%   -.b0_           : Prior loadings.
%   -.B0__          : Prior precision on factors loadings.
%   -.r0_           : Prior mean of phi (idiosyncratic AR polynomial).
%   -.R0__          : Prior mean precision of phi (idiosyncratic AR polynomial)
%   -.v0_           : Inv. gamma param. for innovation variances R, integer.
%   -.d0_           : Inv. gamma param. for innovation variances R.
%   -.r0f_          : Prior for factor AR polynomial.
%   -.R0f__         : Prior precision for factor AR polynomial
%   -.sigU          : Factor innovation variance (normalized to 1 by default).
%
% Index:
% 1. Building priors.
% 2. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Getting info from code.
nreg    = info.nreg;
arlag   = info.arlag;
arterms = info.arterms;
nfact   = info.nfact;
T       = info.T;

% Setting priors for loadings.
b0_  = zeros(nreg,1) + prior.b0_;
B0__ = prior.B0__*eye(nreg);

% Prior mean of lagged world factor
b0_A  = zeros(arlag,1);
% Prior precision of lagged world factor in other factors
B0__A = 0.001*eye(arlag);

% Priors for idiosyncratic AR polynomial.
r0_   = zeros(arterms,1) + prior.r0_;
R0__  = prior.R0__*eye(arterms);

% Inverted gamma parameters of for innovation variances, v0 is an integer
v0_ = prior.v0_*ceil(T*0.05);
d0_ = prior.d0_*0.25^2;

% Prior for factor AR polynomial
r0f_ = zeros(arlag,1) + prior.r0f_;
R0f__ = prior.R0f__*eye(arlag);

% Normalize innovation variance for the factor.
sigU = [prior.sigU; zeros(arterms,1)];
for i = 2:nfact
    sigU = [sigU; 1; zeros(arterms,1)];
end

% Saving priors.
prior.b0_   = b0_;
prior.B0__  = B0__;
prior.r0_   = r0_;
prior.R0__  = R0__;
prior.v0_   = v0_;
prior.d0_   = d0_;
prior.r0f_  = r0f_;
prior.R0f__ = R0f__;
prior.sigU  = sigU;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
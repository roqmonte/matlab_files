function [irf_v,irf_f] = DFM_Plot_IRF(results,drawsp,info,factor_id,fid,vars)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 13/Mar/2020
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Do IRF of the variables to the factors of the model.
% Input:
%   results:
%   -.F           : Posterior mean factor.
%   -.B           : Posterior mean loadings.
%   drawsp:
%   -.B           : Loadings draws.
%   -.S           : Draws Sg2 observation equation.
%   -.rho         : Draws arterms observation equation.
%   -.f           : Draws coeff state equation.
%   info:
%   -.arlag       : Autoregressive lags in the dynamic factors.
%   -.nfact       : Number of factors to estimate, global plus additional factors.
%   -.area_color  : Color of area for last significance level (1 x 3).
%   -.conf        : Significance levels for confidence bands (1 x c).
%   -.fnames      : Labels for factors.
%   -.names       : Labels for variables.
%   -.widths      : vector with line widths.
%   -.nreg        : # of regressors in each observable equation, constant plus factors.
%   -.Regions     : Regional factor identification.
%   -.fsizes      : vector with font sizes.
%   -.conf        : Confidance bands for factors.
%   factor_id     : Choose factor to shock.
%   fid           : Figure number for plots.
%   vars          : Data selection for charts
%
% Outputs:
%   irf_v         : Draws IRF variables.
%   irf_f         : Draws IRF factors.
%
% Index:
% 1. Setting up the code
% 2. Do IRF for factors.
% 3. Do IRF for variables.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setting up the code
if exist('fid','var') == 0
    fid = 1;
end

% Option for plots and code info.
fsize           = info.fsizes(1);
fsize_alt       = info.fsizes(2);
line_width      = info.widths(1);
line_width_alt  = info.widths(2);
area_step       = 0.1;
nobs            = size(results.B,1);
nf              = info.nfact;
Regions         = info.Regions;
nRegions        = size(Regions,2);
sims            = size(drawsp.B,1);
horizon         = 18;
grey            = [0.3,0.3,0.3];
conf            = [(1 - info.conf)/2; 1-(1-info.conf)/2];
nbands          = size(conf,2);

% Reshape draws
b_x   = drawsp.B;
%rho_x = drawsp.rho;
f_x   = drawsp.f;
for i0 = 1:size(b_x,1)
    b(:,:,i0)   = reshape(b_x(i0,:),nf,nobs)';
    f(:,:,i0)   = reshape(f_x(i0,:),size(f_x,2)/nf,nf)';
end

% Do companion form for selected factor.
p = info.arlag;
J = [eye(1) zeros(1,p-1)];
h_wait = waitbar(0,'Computing IRFs...');
for i0 = 1:sims
    % IRF for factors
    FF = [];
    JJ = [];
    for i = 1:nf
        A = f(i,:,i0);
        if info.arlag == 1
            F = A;
        elseif info.arlag > 1
            F = [A; [eye(p-1) zeros(p-1,1)]];
        end
        FF = blkdiag(FF,F);
        JJ = blkdiag(JJ,J);
    end
        
    % Storing factor IRF up to h-horizon.
    for ii = 0:horizon
        % Factor IRFs.
        irf_f(ii+1,i0,:) = reshape(diag(JJ*(FF)^(ii)*JJ'),1,1,nf);
        
        % Format loadings matrix with coefficients.
        tempB = b(:,:,i0);
        % Adjusting regional factor to include zeros.
        B2 = tempB(:,3:end);
        temp = zeros(nobs,nRegions);
        temp(1:Regions(1),1) = B2(1:Regions(1),1);
        for i1 = 1:nRegions-1
            temp(Regions(i1)+1:Regions(i1+1),i1+1) = B2(Regions(i1)+1:Regions(i1+1),1);
        end
        B = [tempB(:,1:2) temp];
        clear tempB B2 temp;     
        
        % Variables IRFs.
        temp = B(:,2:end) .* repmat(squeeze(irf_f(ii+1,i0,:))',nobs,1);
        irf_v(ii+1,:,:,i0) = reshape(temp,1,nobs,nf);
        clear temp;
    end
    waitbar(i0/sims,h_wait);
end
close(h_wait);
clear p J i0 A F i temp_f i0 i1 h_wait;
irf_vars  = [];
irf_facts = [];

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Do IRF for factors.

% Confidance bands for factors.
for i = 1:nf
    for i0 = 1:size(conf,2)
        lb(:,i0,i) = quantile(irf_f(:,:,i),conf(1,i0),2);
        ub(:,i0,i) = quantile(irf_f(:,:,i),conf(2,i0),2);
        md(:,i) = quantile(irf_f(:,:,i),0.50,2);
    end
end
% Plot IRF for factors.
figure(fid)
for i0 = 1:nf  
    subplot(nf,1,i0)
    % Bands
    area_color = info.area_color;
    for i = nbands:-1:1
        shadedplot(0:horizon,lb(:,i,i0)',ub(:,i,i0)',area_color);
        area_color = area_color-area_step;
        hold on;
    end
    % Zero line.
    h(1) = plot(0:horizon,zeros(1,horizon+1),'-','Color',grey,'LineWidth',line_width_alt);
    % IRF plot model closer to median IRF.
    h(2) = plot(0:horizon,md(:,i0)','-b','LineWidth',line_width);

    % Labels.
    title(strcat(info.fnames(i0),' factor'),'FontSize',fsize);
    set(gca,'FontSize',fsize_alt)
    xlim([0 horizon])
    box off
end
if length(conf)==1
    legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ' percent confidence bands']);
elseif length(conf)==2
    legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ' and ',num2str(info.conf(2)*100) ' percent confidence bands']);
elseif length(conf)==3
    legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ',',num2str(info.conf(2)*100) ' and ',num2str(info.conf(3)*100) ' percent confidence bands']);
end
set(legend1,'FontSize',fsize_alt,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
clear i lb ub md i0 area_color i
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Do IRF for variables.

% Selecting variables.
% Data selection for charts
if exist('vars','var') == 1
    irf_v = irf_v(:,vars,:,:);
    info.names = info.names(:,vars);
end
nvars = size(irf_v,2);
nobs  = nvars;

% Number of variables and graph setup.
if nvars <= 3
    k1 = 1; k2 = nvars;
elseif nvars <= 4
    k1 = 2; k2 = 2;
elseif nvars > 4 && nvars <= 6
    k1 = 3; k2 = 2;
elseif nvars > 6 && nvars <= 9
    k1 = 3; k2 = 3;
elseif nvars > 9 && nvars <= 16
    k1 = 4; k2 = 4;
elseif nvars > 16 && nvars <= 24
    k1 = 4; k2 = 6;
elseif nvars > 24 && nvars <= 30
    k1 = 5; k2 = 6;
elseif nvars > 30 && nvars <= 36
    k1 = 6; k2 = 6;
elseif nvars > 36
    error('Max number of variables reached.');
end

% Confidance bands for factors.
j = factor_id;
for i = 1:nobs
    for i0 = 1:size(conf,2)
        lb(:,i0,i) = quantile(irf_v(:,i,j,:),conf(1,i0),4);
        ub(:,i0,i) = quantile(irf_v(:,i,j,:),conf(2,i0),4);
        md(:,i) = quantile(irf_v(:,i,j,:),0.50,4);
    end
end
% Plot IRF for factors.
figure(fid + 1)
k = 1;
for i0 = 1:nobs
    subplot(k2,k1,k)
    % Bands
    area_color = info.area_color;
    for i = nbands:-1:1
        shadedplot(0:horizon,lb(:,i,i0)',ub(:,i,i0)',area_color);
        area_color = area_color-area_step;
        hold on;
    end
    % Zero line.
    h(1) = plot(0:horizon,zeros(1,horizon+1),'-','Color',grey,'LineWidth',line_width_alt);
    % IRF plot model closer to median IRF.
    h(2) = plot(0:horizon,md(:,i0)','-b','LineWidth',line_width);

    % Labels.
    title(info.names(i0),'FontSize',fsize);
    if k1 == 1
        if i0 == nvars 
            xlabel('Periods','FontSize',fsize_alt);
        end
    elseif k1 == 2
        if i0 == nvars || i0 == nvars - 1
            xlabel('Periods','FontSize',fsize_alt);
        end
    elseif k1 == 3
        if i0 == nvars || i0 == nvars - 1 || i0 == nvars - 2
            xlabel('Periods','FontSize',fsize_alt);
        end
    elseif k1 == 4
        if i0 == nvars || i0 == nvars - 1 || i0 == nvars - 2 || i0 == nvars - 3 
            xlabel('Periods','FontSize',fsize_alt);
        end            
    elseif k1 == 5
        if i0 == nvars || i0 == nvars - 1 || i0 == nvars - 2 || i0 == nvars - 3 || i0 == nvars - 4
            xlabel('Periods','FontSize',fsize_alt);
        end
    elseif k1 == 6
        if i0 == nvars || i0 == nvars - 1 || i0 == nvars - 2 || i0 == nvars - 3 || i0 == nvars - 4 || i0 == nvars - 5
            xlabel('Periods','FontSize',fsize_alt);
        end 
    end
    set(gca,'FontSize',fsize_alt)
    xlim([0 horizon])
    box off
    k = k + 1;
end
if length(conf)==1
    legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ' percent confidence bands']);
elseif length(conf)==2
    legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ' and ',num2str(info.conf(2)*100) ' percent confidence bands']);
elseif length(conf)==3
    legend1 = legend(h(2),['Impulse responses with ',num2str(info.conf(1)*100) ',',num2str(info.conf(2)*100) ' and ',num2str(info.conf(3)*100) ' percent confidence bands']);
end
set(legend1,'FontSize',fsize_alt,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
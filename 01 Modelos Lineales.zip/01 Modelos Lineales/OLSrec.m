function results = OLSrec(y,x,setup,aalpha,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 17/Dec/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation AR(p) model using recursive estimation or
% moving window. 
% Inputs:
%   y        : Dependent variable,
%   x        : Independet variables (constant term by default if not included in first col).
%   setup:
%   -.ar     : Number of lags of the dependent variable.
%   -.opt    : (0) recursive estimation, (1) moving window.
%   -.nwin   : Size of initial window.
%   -.method : VAR/cov matrix White/NWest/OLS (Default: NWest).
%   aalpha   : Significance level for ttest and confidence intervals.
%   print    : (1) print chart with results.
%   labels   : Column vector with labels for dep. and indep variables (no lags)
%   dates    : Vector with info for dates: [year,month,freq].
%              Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results :
%   -.b      : Parameter estimators.
%   -.uhat   : Residual of the rolling estimation.
%   -.yhat   : Fit of the rolling estimation.
%   -.ic     : Confidence interval for betas.
%   -.ttest  : t-test for betas.
%   -.R2     : R-square.
%   -.R2adj  : Adjusted R-square.
%   -.method : Rolling or moving window.
%
% Index.
% 1. Setup
% 2. OLS recursive estimation.
% 3. OLS moving window.
% 4. Graphs.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking inputs.
if isfield(setup,'method') == 0
    setup.method = 'NWest';
end
% Significance level for ttest and confidence interval.
if exist('aalpha','var') == 0 || isempty(aalpha)
    aalpha = 0.05;
end
% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
% Lags dependent variable.
yr = [];
if setup.ar > 0 
    yr = LagN(y,setup.ar);
    yr = yr(:,2:end);
end
% Definition variables.
y = y(setup.ar+1:end,:);
x = x(setup.ar+1:end,:);
xe= x;

% Defining exogenous variables..
x = [xe yr];
k = size(x,2);
T = size(y,1);
clear yr i j;
% First window.
nini = setup.nwin;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. OLS recursive estimation.
if setup.opt == 0
    j = 1;
    b   = zeros(T - nini,k);
    ic1 = zeros(T - nini,k);
    ic2 = zeros(T - nini,k);
    % Asymptotic confidence interval.
    for i = nini:size(y,1)
        yaux = y(1:i,:);
        xaux = x(1:i,:);           
        res_aux = OLSest(yaux,xaux,setup.method,aalpha,0);
        if i == nini
            uhat = res_aux.uhat;
            yhat = res_aux.yhat;
        else
            uhat = [uhat; res_aux.uhat(end,1)];
            yhat = [yhat; res_aux.yhat(end,1)];
        end
        b(j,:)     = res_aux.b;
        ic1(j,:)   = res_aux.bIC(:,1);
        ic2(j,:)   = res_aux.bIC(:,2);
        ttest(j,:) = res_aux.ttest;
        R2(j,:)    = res_aux.R2;
        R2adj(j,:) = res_aux.R2adj; 
        clear xaux yaux btemp ictemp res_aux;
        j = j + 1;
    end
    results.method = 'Recursive Estimation';
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. OLS moving window.
if setup.opt == 1
    j = 1;
    % Asymptotic confidence interval.
    for i = nini:size(y,1)
        xaux = x(j:i,:); 
        yaux = y(j:i,:);                
        res_aux = OLSest(yaux,xaux,setup.method,aalpha,0);
        if i == nini
            uhat = res_aux.uhat;
            yhat = res_aux.yhat;
        else
            uhat = [uhat; res_aux.uhat(end,1)];
            yhat = [yhat; res_aux.yhat(end,1)];
        end
        b(j,:)     = res_aux.b;
        ic1(j,:)   = res_aux.bIC(:,1);
        ic2(j,:)   = res_aux.bIC(:,2);
        ttest(j,:) = res_aux.ttest;
        R2(j,:)    = res_aux.R2;
        R2adj(j,:) = res_aux.R2adj; 
        clear xaux yaux btemp ictemp res_aux;
        j = j + 1;
    end
    results.method = 'Moving window of data';
end

% Saving results.
results.betas = b;
results.uhat  = uhat;
results.yhat  = yhat;
results.ic    = [ic1 ic2];
results.ttest = ttest;
results.R2    = R2;
results.R2adj = R2adj;
clear i j;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Graphs.
% Setup
aux = size(x,2);
if aux <= 3
    k1 = 1; k2 = aux;
elseif aux <= 4
    k1 = 2; k2 = 2;
elseif aux > 4 && aux <= 6
    k1 = 3; k2 = 2;
elseif aux > 6 && aux <= 9
    k1 = 3; k2 = 3;
elseif aux > 9 && aux <= 16
    k1 = 4; k2 = 4;
elseif aux > 16
    error('Max number of parameters reached.');
end

% Graphs of betas
if exist('print','var')
    if print == 1
        % Checking dates.
        if exist('dates','var') == 0 || isempty(dates)
            dates = [1900,1,1];
        end
        % Dates
        if dates(end) == 1
            freq = 'm';
        else
            freq = 'q';
        end
        [xTick,xTickLabel] = calendar(dates(1),dates(2),T,freq);
        
        % Labels        
        lab = {'cte'};
        if isempty(labels)
            for i0 = 2:size(xe,2)
                lab2 = strcat('var ',num2str(i0));
                lab = [lab; lab2];
            end
        else
            for i0 = 2:size(xe,2)
                lab2 = labels(i0,:);
                lab = [lab; lab2];
            end
        end
        for i0 = 1:setup.ar
            lab2 = strcat('ylag ',num2str(i0));
            lab = [lab; lab2];
        end
        % Graphs
        b  = [NaN(T-size(b,1),aux); b];
        ic1= [NaN(T-size(ic1,1),aux); ic1];
        ic2= [NaN(T-size(ic2,1),aux); ic2];
        for i = 1:size(b,2)
            subplot(k1,k2,i);
            plot(b(:,i), '-b');
            hold on
            plot(ic1(:,i), '-r');
            hold on
            h(2) = plot(ic2(:,i), '-r');
            hold on
            plot(zeros(size(b,1),1), '-k');            
            title((lab(i)),'FontWeight','bold','FontSize',11,'FontName','Arial');
            xlim([xTick(1) xTick(end)]);
            set(gca,'xTick',xTick);
            set(gca,'xTickLabel', xTickLabel);
            grid on    
        end
        legend1 = legend(h(2),['Confidence interval with ',num2str(100-aalpha*100) ' percent confidence bands']);
        set(legend1,'FontSize',10,'Orientation','horizontal','Position',[0.327835 0.00079499 0.3672619 0.05176190476],'Box', 'off');
        clear i j k1 k2 aux;
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
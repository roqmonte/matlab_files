function results = FOREols(y,yl,x,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Jan/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation/forecast of AR(p) model by OLS. Note, data for
% code is consistent with the following notation (row t):
% 
% y(t) = B*x(t-h) + A*y(t-h) + e(t)
%
% Where y(t) = f(y(t),y(t-h)) and y(t-h) = f(y(t-h),y(t-h-1)).
% Inputs:
%   y  : Endogenous vairable.
%   yl : Lags of dept. variable.
%   x  : Independet variables (constant term by default if not included in first col).
%   setup:
%   -.mfore : (0) recursive estimation; (1) rolling window estimation.
%   -.fhr   : Forecast horizon; (1) computes direct and recursive forecast.
%   -.frp   : Evaluation window.
%
% Outputs:
%   results:
%   -.dta     : Initial data.
%   -.dtf     : Initial evaluation sample.
%   -.yhat    : In-sample fit.
%   -.uhat    : In-sample residuals.
%   -.b       : Parameters.
%   -.info    : Options.
%   -.yeft    : Vector with forecast data.
%   -.fore    : Vectot h-steap-ahead forecas (direct forecast).
%   -.fore_rec: Matrix h-steap-ahead forecas (per column, recursive forecast).
%   -.ForeF   : Type of forecast.
%   -.ForeT   : Estimation method.
%
% Index.
% 1. Data setup.
% 2. Forecast.
% 3. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Data setup.
% Checking inputs.
if size(x,2) == 0 && size(yl,2) == 0
    error('Wrong arguments for the code.');
end
% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
% Options
setup.method = 'NWest';
% Evaluation window
P = setup.frp;
% Data.
dta  = [y x yl];
ylini= [];
ylf  = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Forecast.
h_wait = waitbar(0,'Generating forecast, please wait...');
% Forecasting.
wx = 1;
for w = 1:P+1-setup.fhr
    % Waiting bar.
    waitbar(w/setup.frp,h_wait)
    % Forecast exercise: (0) recursive; (1) rolling estimation.
    if setup.mfore == 1
        wx = w;
    end
    % Generating Dependent variable.
    yini = y(wx:end-P+w-1,:);
    % Generating Exogenous variables and lags dep. variable.
    xini = x(wx:end-P+w-1,:);
    xf2  = x(end-P+w:end,:);
    if size(yl,2) > 0
        ylini = yl(wx:end-P+w-1,:);
        ylf   = yl(end-P+w:end,:);
    end
    
    % Model estimation.
    xtemp = [xini ylini];
    b     = (xtemp'*xtemp)\(xtemp'*yini);
    bfcas(:,w) = b;
    yhat(w).yt = xtemp*b;
    uhat(w).u  = yini - xtemp*b;

    % Forecasting.
    setup.junk = w;
    fcast(:,w) = fore(yini,xf2,ylf,setup,b);
    clear xtemp b;
end
close(h_wait)

% Formating the results.
if setup.fhr > 1
    fcast = fcast(1,:)';
    ForeF = {'Direct forecast'};
elseif setup.fhr == 1
    results.fcast_rec = format(fcast,P);
    fcast = fcast(1,:)';   
    ForeF = {'Recursive forecast'};    
end

% Results.
results.dta  = [dta(1:end-P,1)     dta(1:end-P,2:end)];
results.dtf  = [dta(end-P+1:end,1) dta(end-P+1:end,2:end)];
results.b    = bfcas;
results.info = setup;
% Forecast info options.
results.ForeF= char(ForeF);
results.yeft = dta(end-P+1:end,1);
results.fore = fcast;
results.yhat = yhat;
results.uhat = uhat;
if setup.mfore == 0
    results.ForeT = 'Recursive Estimation';
else
    results.ForeT = 'Rolling window estimation';
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions.
% Function calculates the h step ahead forecast matrix.
function yf = fore(y,xf,ylf,setup,param)
% Imputs.
%   y      : Data from Estimation window, target variable.
%   xf     : Data from Evaluation window, exo variables.
%   ylf    : Lags from Evaluation window, lags.
%   setup  : Options.
%   param  : Vector of parameters.
% Outputs:
%   yf     : h-step ahead forecast.

% Parameters 
b = param;
% Matrix to store results.
yf = zeros(setup.frp,1);
% Id variables.
junk = setup.junk-1;

% Direct forecast for h = 1 and recursive forecast.
if setup.fhr == 1
    % Storing last p lags from evaluation window.
    ar   = size(ylf,2);
    yaux = y(end-ar+1:end);
    yfun = yaux(ar:-1:1);
    clear yaux;
    % Forecasting.
    for i = 1:setup.frp-junk
        % Forecast.
        yf2= [xf(i,:) yfun']*b;
        % Storing forecast.
        yf(i,1) = yf2;
        % Adding forecast for recursive forecast.
        y  = [y; yf2];
        % Storing last p lags form evaluation window.
        yaux = y(end-ar+1:end);
        yfun = yaux(ar:-1:1);
        clear yaux yf2;
    end
    
% Direct forecast for h > 1: y_{t+h|t}
elseif setup.fhr > 1
    % Forecast horizon.
    hf = setup.fhr;
    % Condition for lags.
    yl_fore = [];
    if size(ylf,2) > 0
       yl_fore = ylf(hf,:);
    end
    % Forecast.
    yf = [xf(hf,:) yl_fore]*b;
end

% Formating forecast.
function fcast = format(fcast,a)
% Imputs.
%   fcast : Matrix forecast raw.
%   a     : Size evaluation window.
% Outputs:
%   fcast : Forecast Matrix (each row: h-step-ahead forecast).
fcast = fcast';
% Forecast
fcast2 = NaN(a,a);
i = 1;
for j0 = 1:a
    fcast2(i:end,j0)= fcast(1:end-i+1,j0);
    i = i + 1;
end
fcast = fcast2;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
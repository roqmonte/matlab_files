function [logf,yhat] = armax_mlike(theta,y,x,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 18/Dec/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Computes log-likelihood of ARMA/ARMAX model using Kalman filter.
% -arma(p,q) model:
%  y(t) =  cte         + rho(1)y(t-1)   + ... + rho(p)y(t-p) + 
%                 e(t) + gamma(1)e(t-1) + ... + gamma(q)e(t-q)
% -armax(p,q) model:
%  y(t) =  cte + bx(t) + rho(1)y(t-1) + ... + rho(p)y(t-p) + 
%                 e(t) + gamma(1)e(t-1) + ... + gamma(q)e(t-q)
%
% Inputs:
%   y       : Dependent variable,
%   x       : Independet variables, lags not included.
%   setup   : Options for the code:
%   -.arma  : Setup arma(p,q) terms.
%
% Outputs:
%   logf   : Log likelihood.
%   yhat   : In-sample Predicted values.
%
% Index.
% 1. Setup.
% 2. kf for the arma(p,q) model.
% 3. kf for the armax(p,q) model.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup.
% Checking type of model
if mean(x(:,1),1) == 1 && size(x,2) == 1
    % arima(p,q) type of model with constant term.
    model_type = 0;
else
    % arimax(p,q) type of model with constant term.
    model_type = 1;
end

% Info for the estimation.
p = setup.arma(1,1);
q = setup.arma(1,2);
n = size(y,1);
r = max(p,q+1);
% Getting parameters for the equation.
if model_type == 0
    beta = theta(1);
    rho  = theta(2:size(x,2)+p);
    gamma= theta(size(x,2)+1+p:end-1);
    Sg2  = theta(end);
    mu   = beta / (1 - sum(rho));
elseif model_type == 1
    k    = size(x,2);
    beta = theta(1:k);
    rho  = theta(k+1:k+p);
    gamma= theta(k+p+1:end-1);
    Sg2  = theta(end);
end
yhat = zeros(n,1);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. kf for the arma(p,q) model.
% Computing the log-likelihood of the model using Kalman filter.
if model_type == 0
    % Build matrices of state space representation:
    T = zeros(r,r);
    R = zeros(r,1);
    R(1:1+size(gamma,1)) = [1; gamma];
    Z = [1 zeros(r-1,1)']';
    % Constructing the space representation:
    T(1,1:p)    = rho; 
    T(1:r-1,2:r)=eye(r-1);
    Q(1,1)      = Sg2;
    % Initialize state and covariance matrix
    s_tt = zeros(r,1);
    P_tt = abs(reshape((eye(r^2)-kron(T,T) ) \ vec(R*Q*R'),r,r));
    logf = zeros(n,1);
    % Kalman Filter Recursion
    if Sg2 > 0
        for i = 0:n-1
            % Forecast of the state equation.
            s_t1t = T*s_tt;
            P_t1t = T*P_tt*T' + R*Q*R';
            % Forecast of the observational equation.
            y_t1t = mu + Z'*s_t1t;
            V_t1t = Z'*P_t1t*Z;
            yhat(i+1,1) = y_t1t;

            % Add likelihood terms:
            temp0 = (y(i+1) - y_t1t);
            temp1 = (2*pi)^(-0.5)*V_t1t^(-0.5);
            temp2 = temp0'*V_t1t^(-1)*temp0;
            ll = log(temp1*exp(-0.5*temp2));
            logf(i+1) = ll;

            % Updating
            s_t1t1 = s_t1t + P_t1t*Z*V_t1t^(-1)*temp0;
            P_t1t1 = P_t1t - P_t1t*Z*V_t1t^(-1)*Z'*P_t1t;
            s_tt = s_t1t1;
            P_tt = P_t1t1;
            clear temp0 temp1 temp2;
        end
    else
        logf = -Inf;
    end
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. kf for the armax(p,q) model.
if model_type == 1
    % Build matrices of state space representation:
    T = zeros(r,r);
    R = zeros(r,1);
    R(1:1+size(gamma,1)) = [1; gamma];
    Z = [1 zeros(r-1,1)']';
    G = [beta'; zeros(r-1,k)];
    % Constructing the space representation:
    T(1,1:p)    = rho; 
    T(1:r-1,2:r)=eye(r-1);
    Q(1,1)      = Sg2;
    % Initialize state and covariance matrix
    s_tt = zeros(r,1);
    s_tt(1,1) = (beta'*mean(x)') / (1 - sum(rho));
    P_tt = abs(reshape((eye(r^2)-kron(T,T) ) \ vec(R*Q*R'),r,r));
    logf = zeros(n,1);
    % Kalman Filter Recursion
    if Sg2 > 0
        for i = 0:n-1
            % Forecast of the state equation.
            s_t1t = T*s_tt + G*x(i+1,:)';
            P_t1t = T*P_tt*T' + R*Q*R';
            % Forecast of the observational equation.
            y_t1t = Z'*s_t1t;
            V_t1t = Z'*P_t1t*Z;
            yhat(i+1,1) = y_t1t;

            % Add likelihood terms:
            temp0 = (y(i+1) - y_t1t);
            temp1 = (2*pi)^(-0.5)*V_t1t^(-0.5);
            temp2 = temp0'*V_t1t^(-1)*temp0;
            ll = log(temp1*exp(-0.5*temp2));
            logf(i+1) = ll;

            % Updating
            s_t1t1 = s_t1t + P_t1t*Z*V_t1t^(-1)*temp0;
            P_t1t1 = P_t1t - P_t1t*Z*V_t1t^(-1)*Z'*P_t1t;
            s_tt = s_t1t1;
            P_tt = P_t1t1;
            clear temp0 temp1 temp2;
        end
    else
        logf = -Inf;
    end
end

% Results.
logf = -1*sum(logf);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function results = FMOLS(y,x,dt1,dt2,aalpha,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 17/Dec/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Code esitmates Fully Modified OLS as in Phillips and Hansen (1990).
% The estimator which employs a semi-parametric correction to eliminate the 
% problems caused by the long run correlation between the cointegrating equation 
% and stochastic regressors innovations. The resulting Fully Modified OLS (FMOLS) 
% estimator is asymptotically unbiased and has fully efficient mixture normal 
% asymptotics allowing for standard Wald tests using asymptotic Chi-square 
% statistical inference.
% Model:
% (1)   y(t) = x(t)b   + dt1*gamma + u1(t)
% (2)   x(t) = R21*d1t + R22*d2t   + e2(t)
% With delta(e2(t)) = u2(t).
%
% Inputs:
%   y       : Dependent variable,
%   x       : Stochastic regressors.
%   dt1     : Deterministic regressors that enter in all equations (cte by default).
%   dt2     : Deterministic regressors that enter in secondary equations,
%   aalpha  : Significance level for ttest and confidence intervals.
%   print   : (1) Do charts and print results on screen.
%   labels  : Column vector with labels for dep. and indep variables.
%   dates   : Vector with info for dates: [year,month,freq].
%             Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results :
%   -.dta    : Original Data.
%   -.yhat   : Fit of the model.
%   -.uhat   : residuals.
%   -.b      : Parameters estimation.
%   -.bvar   : Var/cov betas.
%   -.ttest  : t-test.
%   -.bIC    : Betas Confidence interval.
%   -.Pval   : Asymtotic Pvalues.
%   -.Sg2    : variance.
%   -.SSR    : Sum square resids.
%   -.R2     : R-square.
%   -.R2adj  : Adjusted R-square.
%   -.Dw     : Durbin Watson statistic.
%   -.AIC    : AIC.
%   -.HQC    : HQC.
%   -.BIC    : BIC.
%   -.method : model and method for var/cov. 
%   -.T      : Sample size.
%   -.k      : Number of parameters.
%   -.SgLR   : Long run variance of u1(t)|u2(t).
%   -.table  : Table with print results.
%
% Index.
% 1. Estimation and t-test.
% 2. Results.
% 3. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Estimation and t-test.
% Significance level for ttest and confidence interval.
if exist('aalpha','var') == 0 || isempty(aalpha)
    aalpha = 0.05;
end
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end
% Checking common treds (Dt1).
if exist('dt1','var') == 0 || isempty(dt1)
    dt1 = ones(size(y,1),1);
end
% Checking additional deterministic trends.
if exist('dt2','var') == 0
    dt2 = [];
end
% Checking for constant term in the model.
if size(dt1,2) == 0
    dt1 = ones(size(y,1),1);
end
if mean(dt1(:,1),1) ~= 1
    dt1 = [ones(size(y,1),1) dt1];
end

% Parameters estimation.
T  = size(y,1);
k1 = size(x,2);

% OLS estimation
mX   = [dt1 x];
by   = (mX'*mX)^(-1)*(mX'*y);
resy = y - mX*by;
% OLS for each Xs'
resx = zeros(T,k1);
dt = [dt1 dt2];
for i0 = 1:k1    
    bx = (dt'*dt)^(-1)*(dt'*x(:,i0));
    resx(:,i0) = x(:,i0) - dt*bx;
end
delta_et = resx(2:end,:) - resx(1:end-1,:);
clear bx i0 mX dt;

% Building var/cov matrix
ut = [resy(2:end,1) delta_et];
% LR var/cov matrix
[Sigma,Gamma,Delta] = NWhac(ut);

% Adjusting data
y_plus = y(2:end) - ut(:,2:end)*(Gamma(1,2:end)*(Gamma(2:end,2:end))^(-1))';
% Estimation of bias correcting term.
lambda12 = Delta(1,2:end)' - (Gamma(1,2:end)*(Gamma(2:end,2:end))^(-1)*Delta(2:end,2:end))';
% Long run vaciande of u1(t) conditional on u2(t)
Sglr = Gamma(1,1) - (Gamma(1,2:end)*(Gamma(2:end,2:end))^(-1)*Gamma(2:end,1))';

% OLS with adjusted data and betas.
% Defining Zt
Zt  = [x(2:end,:) dt1(2:end,:)];
Blr = (Zt'*Zt)^(-1)*(Zt'*y_plus - (T-1)*[lambda12; 0]);
% Cleaning memory
clear y_plus resy resx
% Residuals.
betas = [Blr(end-size(dt1,2)+1:end); Blr(1:end-size(dt1,2))];
Xmat  = [dt1 x];
resid = y - Xmat*betas;


% Perform Newey-West correction
emat = [];
k    = k1 + size(dt1,2);
for i = 1:k;
    emat = [emat; resid'];
end  
hhat= emat.*Xmat';
% Matriz with results.
nlag = round(4*(size(y,1)/100)^(2/9));
G    = zeros(k,k); 
w    = zeros(2*nlag+1,1);
a    = 0;
while a ~= nlag + 1
    ga = zeros(k,k);
    w(nlag+1+a,1) = (nlag+1-a)/(nlag+1);
    za = hhat(:,(a+1):T)*hhat(:,1:T-a)';
    % First lag.
    if a == 0
        ga = ga + za;
    % Taking care of autocorrelations.
    else
        ga = ga + za + za';
    end;
    % Result.
    G = G + w(nlag+1+a,1)*ga;
    a = a + 1;
end 
clear a ga w za hhat emat nlag by delta_et i Zt;
% Var/cov matrix
xpxi  = (Xmat'*Xmat)^(-1);
V     = xpxi*G*xpxi;

% Results
tstd  = sqrt(diag(V));
tstat = betas./tstd;
sige  = (resid'*resid)/(T-k);
% Pvalues
Pval  = zeros(size(x,2),1);
for i0 = 1:k
    p_temp  = 2*(1-tcdf(abs(tstat(i0,1)),T - k));    
    if p_temp < 0.001
        Pval(i0,1) = 0;
    else
        Pval(i0,1) = p_temp;
    end
end
clear p_temp G;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Results.
t1 = tinv(aalpha/2,T - k);
t2 = -1*t1;

% Saving results.
results.dta    = [y dt1 x];
results.yhat   = Xmat*betas;
results.uhat   = resid;
results.b      = betas;
results.bvar   = V;
results.ttest  = tstat;
results.bIC    = [betas + t1*tstat betas + t2*tstat];
results.Pval   = Pval;
results.Sg2    = sige;
results.SSR    = resid'*resid;
results.R2     = 1 - results.SSR / ((y-mean(y))'*(y-mean(y)));
results.R2adj  = 1 - (1 - results.R2)*(T - 1)/(T - k);
results.Dw     = ((resid(2:end,1) - resid(1:end-1))'*(resid(2:end,1) - resid(1:end-1))) / results.SSR;
results.AIC    = log(results.SSR/T) + 2*(k/T);
results.HQC    = log(results.SSR/T) + 2*(k/T)*log(log(T));
results.BIC    = log(results.SSR/T) +   (k/T)*log(T);
results.method = 'FMOLS NW';
results.T      = T;
results.k      = k;
results.SgLR   = Sglr;
% Table.
results.table = print_res(results,aalpha,labels,print);

% Do charts
if print == 1       
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1];
    end
    print_charts(results,dates,labels);
end    
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions

% Computes Newey & West HAC matrix.
function [Sigma,Gamma,Delta] = NWhac(y,qn)
% Inputs:
%   y   : Vector with data.
%   qn  : Truncation lag.
%
% Outputs:
%   Sigma : Contemporaneous var/cov matrix
%   Gamma : Long-run var/cov matrix (HAC).
%   Delta : One-side var/cov matrix.

% Deviation to mean.
T  = size(y,1); 
dy = y - repmat(mean(y),T,1);
% Case on which no truncation lag is specified.
if nargin == 1
   qn = floor(T^(1/4));  
end

% Variance at t.
G0 = dy'*dy/T;

% Adding auto-covariance.
temp = 0;
for j = 1:qn-1
   % Covariance.
   gamma = (dy(j+1:T,:)'*dy(1:T-j,:))./(T-1);
   % Summation.
   G0 = G0 + (gamma+gamma').*(1-abs(j/qn));
   % One-side var/cov matrix
   temp = temp + gamma.*(1-abs(j/qn));
end
% HAC matrix according to Newey and West.
Sigma = dy'*dy/T;
Gamma = G0;
Delta = temp;

% Funtion do table.
function Estimation_results = print_res(results,aalpha,labels,print)
% Labels
if isempty(labels)
    lab_0 = [];
else
    lab_0 = labels(2:end);
end      

% Do table.
% labels for exo variables.
if mean(results.dta(:,2)) == 1
    lab = {'cte'};
    for i0 = 1:results.k-1
        if isempty(lab_0)
            lab2 = strcat('b',num2str(i0));
        else
            lab2 = lab_0(i0,:);
        end        
        lab = [lab; lab2];
    end
else
    if isempty(lab_0)
        lab = {'b1'};
        for i0 = 2:results.k
            lab2 = strcat('b',num2str(i0));
            lab = [lab; lab2];
        end
    else
        lab = lab_0(1,:);
        for i0 = 2:results.k
            lab2 = lab_0(i0,:);
            lab = [lab; lab2];
        end
    end
end
% Sigma square.
lab = [lab; 'Sg2'];

% Building table
% First part.
labels = {'Param' 'Coef' 't-test' 'Pvalue' 'CI_l' 'CI_u'};
temp_1 = num2cell([results.b results.ttest results.Pval results.bIC]);
temp_2 = [num2cell(results.Sg2) ' ' ' ' ' ' ' '];
temp_3 = [temp_1; temp_2];
temp_4 = [lab temp_3];
part_1 = [labels; temp_4];
clear labels lab temp_1 temp_2 temp_3 temp_4;
% Second part
temp_1 = {'AIC'; 'HQC';  'BIC'};
temp_2 = num2cell([results.AIC;results.HQC;results.BIC]);
temp_3 = [temp_1 temp_2];
temp_4 = [{'R2 Adj'; 'R2'; 'SSR'} num2cell([results.R2adj;results.R2;results.SSR])];
temp_5 = [{'DW'} results.Dw; {'T'} num2cell(results.T); {'k'} num2cell(results.k)];
part_2 = [{'' '' '' '' '' ''} ;[temp_3 temp_4 temp_5]];
part_2 = [part_2; {'Var/cov' results.method 'alpha' aalpha 'Sg2LR' results.SgLR}];
clear temp_1 temp_2 temp_3 temp_4 temp_5 i0;
% Print results.
Estimation_results = [part_1; part_2];
if print == 1
    fid = 1;
    fprintf(fid,'****************************************************************************\n');
    display(Estimation_results);
    fprintf(fid,'****************************************************************************\n');
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),results.T,freq);

% Label for chart.
if isempty(labels)
    lab_dep_var = 'data';
else
    lab_dep_var = char(labels(1,:));
end      
% In-sample fit
figure(1)
subplot(2,2,1)
plot(results.dta(:,1), '-b');
hold on
plot(results.yhat, '--r');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fit of the model versus data','FontSize',11);
% Residuals
legend(lab_dep_var,'model fit','Location','northwest')
subplot(2,2,3)
plot(results.uhat, '-b');
hold on
plot(repmat(2*sqrt(results.Sg2),results.T,1), ':k');
hold on
plot(repmat(-2*sqrt(results.Sg2),results.T,1), ':k');
hold on
plot(zeros(results.T,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Residuals +/- 2 S.D.','FontSize',11);

% ACF and PAC functions
subplot(2,2,2)     
[~,temp1] = acf(results.uhat);
if size(temp1,1) < 25
    n_aux = size(temp1,1);
    n_lim = n_aux-1;
else
    n_aux = 25;
    n_lim = 18;
end
bar((-1:n_aux-1),[NaN(1,2); temp1(1:n_aux,[1,2])]);
hold on        
plot((-1:n_aux-1),repmat(temp1(1:n_aux,3),1,n_aux+1), ':k');
hold on
plot((-1:n_aux-1),repmat(temp1(1:n_aux,4),1,n_aux+1), ':k');
xlim([-1 n_lim]);
ylim([-1 1]);
title('AC and PAC functions','FontSize',11);
legend('Sample Auto-correlations','Partial correlation function','Location','northwest')

% Distribution of the residuals.
subplot(2,2,4)
histogram(results.uhat,15,'FaceColor',[0 0 1],'EdgeAlpha',1);
title('Histogram for residuals','FontSize',11);
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
function results = armax_opt(y,x,setup,print)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 17/Dec/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Function estimates several arma/armax(p,q) models using 
% Kalman filter. Then, it chooses best specification according to an 
% information criteria.
%
%  y(t) = cte + b*x(t) + rho(1)y(t-1) + ... + rho(p)y(t-p) + 
%                 e(t) + gamma(1)e(t-1) + ... + gamma(q)e(t-q)
% Inputs:
%   y      : Dependent variable,
%   x      : Independet variables (constant term by default if not included in first col).
%   setup:
%   -.arma : Setup arma(p,q) terms, max order for each term.
%   -.type : (0) csimwel (default); (1) matlab algorithm.
%   print  : (1) print table with results.
%
% Outputs:
%   results:
%   -.lags   : Lags selected model x Information Criteria.
%             (AIC; HQN; BIC).
%   -.matci  : Matrix with the Information Criteria (AIC; HQC; BIC).
%   -.mestim : Estimation method.
% 	-.modell : Type of model.
%   -.table  : Table with print results.
%
% Index.
% 1. Setup.
% 2. Model estimations.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup.
if isfield(setup,'type') == 0
    setup.type = 0;
end
% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
% Selecting model
if size(x,2) == 1
    model_type = 'arma';
elseif  size(x,2) > 1
    model_type = 'armax';
end
% Lags orders
pmax = setup.arma(1,1);
qmax = setup.arma(1,2);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Model estimations.
% Matrix to store results: AIC; HQC; BIC.
mat = zeros(pmax,qmax,3);

% Estimation arma/armax(p,q) models for p = 1,...,pmax and q = 1,...,qmax
st2.type = setup.type;
% AR part of the model.
for i0 = 1:pmax
    % MA part of the model.
    for i1 = 1:qmax
        st2.arma = [i0 i1];
        res0 = armax_model(y(pmax+1:end),x(pmax+1:end,:),st2);
        mat(i0,i1,1) = res0.AIC;
        mat(i0,i1,2) = res0.HQC;
        mat(i0,i1,3) = res0.BIC;
    end
end
% Building results
id1 = repmat([NaN; (1:pmax)'],1,1,3);
id2 = repmat(1:qmax,1,1,3);
% id1 = repmat([NaN; (1:pmax)'],[1 1 3]);
% id2 = repmat(1:qmax,[1 1 3]);
mat = [id2; mat];
res = [id1  mat];
clear id1 id2 mat;

% Bulding results for the code.
results.matci = res;
results.lags = zeros(3,3);
[row1,col1,AIC] = minMaxMat(res(2:end,2:end,1),1);
[row2,col2,HQN] = minMaxMat(res(2:end,2:end,2),1);
[row3,col3,BIC] = minMaxMat(res(2:end,2:end,3),1);
results.lags(:,1) = [row1; row2; row3];
results.lags(:,2) = [col1; col2; col3];
results.lags(:,3) = [AIC; HQN; BIC];
% Code setup.
results.modell = model_type;
if setup.type == 0
    % Computing Hessian.
    results.mestim = 'Kalman_filter';
elseif setup.type == 1
    % Bulding model in matlab notation.
    results.mestim = 'Matlab_Estimation';
end

% Do tables
AIC = num2cell(results.matci(:,:,1));
HQC = num2cell(results.matci(:,:,2));
BIC = num2cell(results.matci(:,:,3));
AIC(1,1) = {'AIC p/q'};
HQC(1,1) = {'HQC p/q'};
BIC(1,1) = {'BIC p/q'};
table = [AIC HQC BIC];
if nargin == 4
    if print == 1
        display(table);        
    end
end
results.table = table;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
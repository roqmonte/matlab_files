function results = OLSgen(y,x,yl,setup,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 18/Dec/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Genetic Algorithm for estimation AR(p) model. Note, model 
% selection is performed using Information Criteria.
% Inputs:
%   y           : Dependent variable,
%   x           : Independet variables (constant term by default if not included in first col).
%   yl          : Lags dependent variable.
%   setup:
%   -.sim       : # simulations genetic algorithm.
%   -.gen       : # generations genetic algorithm.
%   -.sel       : Model Selection: AIC, HQC, BIC (Default).
%   -.method    : VAR/cov matrix White/NWest/OLS (Default: NWest).
%   -.options_ga: Parameters Shuffle crossover (Default: 0.5).
%   print       : (1) Do charts and print results on screen.
%   labels      : Column vector with labels for dep. and indep variables.
%   dates       : Vector with info for dates: [year,month,freq].
%                 Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results : 
%   -.feval      : Information criteria best model.
%   -.seed       : Seed of best model.
%   -.feval_all  : IC best model for each generation.
%   -.theta_all  : Best model from each generation.
%   -.theta      : beta estimator of the best model.
%   -.dta_o      : Data full model.
%   -.dta        : Original Data.
%   -.yhat       : Fit of the model.
%   -.uhat       : residuals.
%   -.b          : Parameters estimation.
%   -.ttest      : t-test.
%   -.bIC        : Betas Confidence interval.
%   -.Pval       : Asymtotic Pvalues.
%   -.Sg2        : variance.
%   -.SSR        : Sum square resids.
%   -.R2         : R-square.
%   -.R2adj      : Adjusted R-square.
%   -.AIC        : AIC.
%   -.HQC        : HQC.
%   -.BIC        : BIC.
%   -.method     : method for var/cov. 
%   -.T          : Sample size.
%   -.k          : Number of parameters.
%   -.table      : Table with print results.
%
% Index.
% 1. Setup data.
% 2. Genetic algorithm.
% 3. Saving results.
% 4. Function.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup data.
% Getting info for code.
% Checking print.
if exist('print','var') == 0
    print = 0;
end
if isfield(setup,'sel') == 0
    setup.sel = 'BIC';
end
if isfield(setup,'method') == 0
    method = 'NWest';
else
    method = setup.method;
end;
if isfield(setup,'options_ga') == 0
    options_ga = 1/2;
else
    options_ga = setup.options_ga;
end

% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end

% Checking labels.
lab_yl = {' '};
for i0 = 1:size(yl,2)
    lab_yl2 = strcat('ylag',num2str(i0));
    lab_yl = [lab_yl; lab_yl2];
end
lab_yl = lab_yl(2:end,:);
if exist('labels','var') == 0 || isempty(labels)
    lab_x = {'dep var'};
    for i0 = 2:size(x,2)
        lab_x2 = strcat('xvar ',num2str(i0-1));
        lab_x = [lab_x; lab_x2];
    end
else
    lab_x = labels;
end
labels = [lab_x; lab_yl];
clear lav_yl lav_yl2 lab_x lab_x2

% Building final matrix with exogenous variables.
x = [x yl];

% Setup
k = size(x,2);
% Initial seed (including constant term by default).
seeds = randi([0 1],k,setup.sim);
seeds(1,:) = 1;
% Matrix results for generation "i".
sdaux = zeros(k,setup.sim);       
% Matriz con resultados historicos.
f_opt = zeros(setup.gen+1,2);     % Chains of Information Criteria and IDs.
x_opt = zeros(k,setup.gen+1);     % Chains with parameter estimators.
% Model selection
if strcmp(setup.sel,'AIC') == 1
    m_sel = 1;
elseif strcmp(setup.sel,'HQC') == 1
    m_sel = 2;
elseif strcmp(setup.sel,'BIC') == 1
    m_sel = 3;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Genetic algorithm.
% Iterations
for ig = 1:setup.gen
    % Selection.
    sd = 1;
    while sd <= setup.sim
        % Checking consistency of initial generation (excluding "zeros").
        for j = 1:setup.sim
            if sum(seeds(:,j),1) == 0
                seeds(:,j) = ones(k,1);
            end;
        end;
        
        % Selection of candidates.
        id = randi(setup.sim,1,2);        
        parents = [seeds(:,id(1)) seeds(:,id(2))];
        % Generation of new candidates.
        childs = zeros(k,2);
        aux = rand;
        
        % Single point crossover
        if aux <= options_ga
            I = round(1+(k-2)*rand);
            childs(1:I,1) = parents(1:I,1);
            childs(1:I,2) = parents(1:I,2);
            for i = I+1:k
                childs(i,1) = parents(round(I+1+(k-I-1)*rand),2);
                childs(i,2) = parents(round(I+1+(k-I-1)*rand),1);
            end;
        % Shuffle crossover.
        else
            childs(:,1) = parents(randi([1 k],k,1),2);
            childs(:,2) = parents(randi([1 k],k,1),1);
        end;
        
        % Introducing random mutation to new vectors.
        pr = 0.15 + 0.33/ig;
        aux = rand;
        if aux <= pr
            for q = 1:2
                for i = 1:k
                    if childs(i,q) == 1
                        childs(i,q) = 0;
                    else
                        childs(i,q) = 1;
                    end;
                end;
            end;
        end;
        % Cleaning variables.
        clear aux q i pr I j id;
        
        % Checking consistency.
        fam = [parents childs];
        fam(1,:) = 1;   % Including constant term by defaul.
        
        % Computing Information criteria for each candidate.
        mat_ic = zeros(3,4);
        for i =1:size(fam,2)
            mat_ic(:,i) = fun01(y,x,fam(:,i));
        end;       
        [~,id] = min(mat_ic(m_sel,:));
        
        % Candidates next generation.
        sdaux(:,sd) = fam(:,id);
        sd = sd + 1;
        clear fam famval i id parents childs mat_ic;
    end;
    
    % Introducing elitism.
    ff = zeros(size(seeds,2),2);
    for i =1:size(seeds,2)
        temp_old = fun01(y,x,seeds(:,i)); 
        temp_new = fun01(y,x,sdaux(:,i));
        ff(i,1) = min(temp_old(1,m_sel));
        ff(i,2) = min(temp_new(1,m_sel));
    end;
    % Replacing worst seed from new generation by best seed of old
    % generation.
    % Best candidate Initial generation.
    [min1,id1] = min(ff(:,1));
    % Best candidate new generation.
    [min2,id2] = min(ff(:,2));
    % Worst candidate new generation.
    [~,id3]    = max(ff(:,2));
    sdaux(:,id3) = seeds(:,id1); 
    clear id3 temp_old temp_new i ff;
    
    % Saving candidates from each generation.
    if ig == 1
        f_opt(1,:) = [min1 id1];
        x_opt(:,1) = seeds(:,id1); 
    end
    f_opt(ig+1,:) = [min2 id2];
    x_opt(:,ig+1) = sdaux(:,id2);
    % Defining the new generation.
    seeds = sdaux;
    clear min1 id1 min2;
    
    % Terminal condition in case of convergency of the algorithm
    temp = 0;
    for kk = 1:size(seeds,2)
        if seeds(:,kk) == seeds(:,1)
            temp = temp + 1;
        end
    end
    if temp == setup.sim
        fid = 2;
        fprintf(fid,'Convergency achieved before end of simulations...\n');
        break
    end
    clear temp kk;
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Saving results.
% Getting Matrix with exo variables for the best model.
[~,xmat] = fun01(y,x,seeds(:,id2));
% Model estimation.
r_aux = OLSest(y,xmat,method);
% Results
results.theta  = [r_aux.b; r_aux.Sg2];
results.seed   = x_opt(:,ig+1);      % Seed best model.
results.feval  = f_opt(ig+1,1);      % Information criteria best model.
results.feval_all = f_opt(1:ig+1,:); % IC best model for each generation X Id.
results.theta_all = x_opt(:,1:ig+1); % Best model from each generation.
% Regression results.
results.dta_o  = [y x];
results.dta    = r_aux.dta;
results.yhat   = r_aux.yhat;
results.uhat   = r_aux.uhat;
results.b      = r_aux.b;
results.ttest  = r_aux.ttest;
results.bIC    = r_aux.bIC;
results.Pval   = r_aux.Pval;
results.Sg2    = r_aux.Sg2;
results.SSR    = r_aux.SSR;
results.R2     = r_aux.R2;
results.R2adj  = r_aux.R2adj;
results.AIC    = r_aux.AIC;
results.HQC    = r_aux.HQC;
results.BIC    = r_aux.BIC;
results.method = method;
results.T      = r_aux.T;
results.k      = r_aux.k;
% Table.
results.table = print_res(results,labels,print);

% Do charts
if print == 1
    % Checking dates.
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1]; 
    end        
    print_charts(results,dates,labels);
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Function.
% Function estimates an AR(p) model conditional to the seed given.
function [feval,x] = fun01(y,x,seed)
% Inputs: 
%   y    : dependent variable vector (nobs x 1)
%   x    : independent variables matrix (nobs x nvar)
%   seed : Model Id.
% Outputs:
%   feval: Information criteria of the model.
%   x    : Matrix with exogenous variables.
T    = size(y,1);
seed = seed';
k    = sum(seed,2);
matx = zeros(T,k);
n = 1;
for j = 1:size(seed,2)
    if seed(1,j) == 1
        matx(:,n) = x(:,j);
        n = n + 1;
    end;
end;
% Estimation of parameters.
b    = (matx'*matx)\(matx'*y);
yhat = matx*b;
uhat = y - yhat;
SSR  = uhat'*uhat;
Sg2  = SSR/T;

% Selection of model.
feval(1) = log(Sg2) + 2*(k/T);
feval(2) = log(Sg2) + 2*(k/T)*log(log(T));
feval(3) = log(Sg2) + (k/T)*log(T);
x = matx;

% Funtion do table.
function Estimation_results = print_res(results,labels,print)
% Labels
lab_0 = labels(2:end);
% Do table.
% labels for exo variables.
lab1 = {'cte'};
for i0 = 2:length(results.seed)
    if results.seed(i0) == 1
        lab2 = lab_0(i0-1,:);
        lab1 = [lab1 lab2];
        clear lab2;
    end
end
% Sigma square.
lab = [lab1'; 'Sg2'];
clear lab1 i i0;

% Building table
% First part.
labels = {'Param' 'Coef' 't-test' 'Pvalue' 'CI_l' 'CI_u'};
temp_1 = num2cell([results.b results.ttest results.Pval results.bIC]);
temp_2 = [num2cell(results.Sg2) ' ' ' ' ' ' ' '];
temp_3 = [temp_1; temp_2];
temp_4 = [lab temp_3];
part_1 = [labels; temp_4];
clear labels lab temp_1 temp_2 temp_3 temp_4;
% Second part
temp_1 = {'AIC'; 'HQC';  'BIC'};
temp_2 = num2cell([results.AIC;results.HQC;results.BIC]);
temp_3 = [temp_1 temp_2];
temp_4 = [{'R2 Adj'; 'R2'; 'SSR'} num2cell([results.R2adj;results.R2;results.SSR])];
temp_5 = [{'Var/cov'} results.method; {'T'} num2cell(results.T); {'k'} num2cell(results.k)];
part_2 = [{'' '' '' '' '' ''} ;[temp_3 temp_4 temp_5]];
clear temp_1 temp_2 temp_3 temp_4 temp_5;
% Print results.
Estimation_results = [part_1; part_2];
if print == 1
fid = 1;
    fprintf(fid,'****************************************************************************\n');    
    display(Estimation_results);
    fprintf(fid,'****************************************************************************\n');    
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),results.T,freq);

% Label for chart.
lab_dep_var = char(labels(1,:));
% In-sample fit
figure(1)
subplot(2,1,1)
plot(results.dta(:,1), '-b');
hold on
plot(results.yhat, '--r');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fit of the model versus data','FontSize',11);
legend(lab_dep_var,'model fit','Location','northwest')
% Residuals
subplot(2,1,2)
plot(results.uhat, '-b');
hold on
plot(repmat(2*sqrt(results.Sg2),results.T,1), ':k');
hold on
plot(repmat(-2*sqrt(results.Sg2),results.T,1), ':k');
hold on
plot(zeros(results.T,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Residuals +/- 2 S.D.','FontSize',11);
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function results = ARxopt(y,x,yl,print)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 17/Dec/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Descripci�n: The code estimate an ARx(p) model for p = "1 to Pmax". Lag 
% order "p" is determined using Information criterias: AIC,HQC or BIC.
% Inputs:
%   y     : Dependent variable,
%   x     : Independet variables.
%   yl    : Lags dependent variable.
%   print : (1) print table with results.
%
% Outputs:
%   results :
%   -.lags  : Lags selected model x Information Criteria (AIC; HQC; BIC).
%   -.matci : Matrix with the Information Criteria (AIC; HQC; BIC).
%   -.bbest : Parameters of each specification.
%   -.table : Table with print results.
%
% Index.
% 1. Setup.
% 2. Estimation.
% 3. Model selection.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Setup.
% Number of lags and exo variables.
ar = size(yl,2);
% Exogenous variables.
x = [x yl];
if size(x,2) == size(yl,2)
    ini = 1;
else
    ini = size(x,2) - ar;
end
% Total # of exo variables (cte + exo + lags).
id    = size(x,2);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation.
% Estimation of model AR(p) for p = 1...Pmax by ols.
j = 1;
for i = ini:id
    x2 = x(:,1:i);
    bt = (x2'*x2)\(x2'*y);
    T  = size(y,1);
    k2 = size(x2,2);
    u  = y - x2*bt;
    Sg2= (u'*u)/T;
    % Computing Information criterias.
    if size(x,2) == size(yl,2)
        matCI(j,1) = j;
    else
        matCI(j,1) = j-1;
    end    
    matCI(j,2) = log(Sg2) + 2*(k2/T);
    matCI(j,3) = log(Sg2) + 2*(k2/T)*log(log(T));  
    matCI(j,4) = log(Sg2) +   (k2/T)*log(T);
    % Saving Beta for each model
    temp_b(j,:) = [bt' NaN(1,id-i)];
    clear x2 bt T k2 u Sg2 like;
    j = j + 1;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Model selection.
kopt = zeros(3,2);
% AIC.
[~,id1] = min(matCI(:,2)); 
kopt(1,1) = matCI(id1,1);
kopt(1,2) = matCI(id1,2);
% HQN.
[~,id2] = min(matCI(:,3));
kopt(2,1) = matCI(id2,1);
kopt(2,2) = matCI(id2,3);
% BIC.
[~,id3] = min(matCI(:,4));
kopt(3,1) = matCI(id3,1);
kopt(3,2) = matCI(id3,4);
% Results.
results.lags = kopt;
results.matci= matCI;
results.bbest= temp_b;
clear i id id1 id2 id3 j

% Do table
temp_0 = results.matci;
labels= {'Lags' 'AIC' 'HQC' 'BIC'};
Results = [labels; num2cell(temp_0)];
if nargin == 4
    if print == 1
        display(Results);
    end
end
results.table = Results;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
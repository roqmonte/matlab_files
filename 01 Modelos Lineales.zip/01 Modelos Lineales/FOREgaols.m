function results = FOREgaols(y,x,yl,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Jan/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation/forecast AR(p) model using a genetic algorithm.
% Note, data for code is consistent with the following notation (row t):
%                               
% y(t) = B*x(t-h) + A*y(t-h) + e(t)
%
% Where y(t) = f(y(t),y(t-h)) and y(t-h) = f(y(t-h),y(t-h-1)).
% Inputs:
%   y              : Dependent variable,
%   x              : Exogenous variables (constant term by default if not included in first col).
%   yl             : Lags dependent variable.
%   setup:
%   -.sim          : # simulations genetic algorithm.
%   -.gen          : # generations genetic algorithm.
%   -.sel          : Selection criteria: AIC, HQC, BIC (Default).
%   -.mfore        : (0) recursive estimation; (1) rolling window estimation.
%   -.fhr          : Forecast horizon; (1) computes direct and recursive forecast.
%   -.frp          : Evaluation window.
%   -.options_ga:  : Shuffle crossover (Default: 0.05).
%
% Outputs:
%   results :
%   -.dta     : Initial data.
%   -.dtf     : Initial evaluation sample.
%   -.yhat    : In-sample fit.
%   -.uhat    : In-sample residuals.
%   -.b       : Parameters.
%   -.adn     : ID of each model used to forecast.
%   -.info    : Options.
%   -.yeft    : Vector with forecast data.
%   -.fore    : Vectot h-steap-ahead forecas (direct forecast).
%   -.fore_rec: Matrix h-steap-ahead forecas (per column, recursive forecast).
%   -.ForeF   : Type of forecast.
%   -.ForeT   : Estimation method.
%
% Index.
% 1. Data setup.
% 2. Forecast.
% 3. Functions.   
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Data setup.
% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
% Evaluation window.
P = setup.frp;
% Total number of parameters
k = size(x,2) + size(yl,2);
% Data.
dta  = [y x yl];
ylini= [];
ylf  = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Forecast.
h_wait = waitbar(0,'Generating forecast, please wait...');
% Forecasting.
adnm= zeros(P,k);
wx  = 1;
for w = 1:P+1-setup.fhr
    % Waiting bar.
    waitbar(w/setup.frp,h_wait)
    % Forecast exercise (recursive or rolling estimation).
    if setup.mfore == 1
        wx = w;
    end
    % Generating Dependent variable.
    yini = y(wx:end-P+w-1,:);
    % Generating Exogenous variables and lags dep. variable.
    xini = x(wx:end-P+w-1,:);            
    xf2  = x(end-P+w:end,:);    
    if size(yl,2) > 0
        ylini = yl(wx:end-P+w-1,:);
        ylf   = yl(end-P+w:end,:);
    end;
    
    % Model estimation.
    res_o = OLSgen(yini,xini,ylini,setup);    
    adnm(w,:)  = res_o.seed';
    betas(:,w) = b_shape(res_o.theta(1:end-1),res_o.seed)';
    uhat(w).u  = res_o.uhat;
    yhat(w).yt = res_o.yhat;

    % Forecasting
    setup.junk = w;
    param.b    = betas(w).b;
    fcast(:,w) = fore(yini,xf2,ylf,setup,param);
    clear res_o;
end
close(h_wait)

% Formating the results.
if setup.fhr > 1
    fcast = fcast(1,:)';
    ForeF = {'Direct forecast'};
elseif setup.fhr == 1
    results.fcast_rec = format(fcast,P);
    fcast = fcast(1,:)';   
    ForeF = {'Recursive forecast'};
end

% Results.
results.dta  = [dta(1:end-P,1)     dta(1:end-P,2:end)];
results.dtf  = [dta(end-P+1:end,1) dta(end-P+1:end,2:end)];
results.b    = betas;
results.adn  = adnm;
results.info = setup;
% Forecast info options.
results.ForeF= char(ForeF);
results.yeft = dta(end-P+1:end,1);
results.fore = fcast;
results.yhat = yhat;
results.uhat = uhat;
if setup.mfore == 0
    results.ForeT = 'Recursive Estimation';
else
    results.ForeT = 'Rolling window estimation';
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions.
% Function calculates the h step ahead forecast matrix.
function yf = fore(y,xf,ylf,setup,param)
% Imputs.
%   y          : Data from Estimation window, target variable.
%   xf         : Data from Evaluation window, exo variables.
%   ylf        : Lags from Evaluation window, lags.
%   setup      : options for simulations of the GA
%   param  : Vector of parameters.
% Outputs:
%   yf         : h-step ahead forecast.

% Parameters 
b    = param.b;
% Matrix to store results.
yf = zeros(setup.frp,1);
% Id variables.
junk = setup.junk-1;

% Direct forecast for h = 1 and recursive forecast.
if setup.fhr == 1
    % Storing last p lags form the evaluation window.
    ar   = size(ylf,2);
    yaux = y(end-ar+1:end);
    yfun = yaux(ar:-1:1);
    clear yaux;
    % Forecasting.
    for i = 1:setup.frp-junk       
        % Forecast.    
        yf2= [xf(i,:) yfun']*b;
        % Storing forecast.
        yf(i,1) = yf2;
        % Adding forecast for recursive forecast.
        y = [y; yf2];
        % Storing last p lags form the evaluation window.
        yaux = y(end-ar+1:end);
        yfun = yaux(ar:-1:1);
        clear yaux yf2;
    end
    
% Direct forecast for h > 1: y_{t+h|t}
elseif setup.fhr > 1
    % Forecast horizon.
    hf = setup.fhr;
    % Condition for lags.
    yl_fore = [];
    if size(ylf,2) > 0
       yl_fore = ylf(hf,:);
    end
    % Forecast.
    yf = [xf(hf,:) yl_fore]*b;
end

% Function selects parameters of a vector according to the seed.
function bsh = b_shape(b,seed)
% Imputs:
%   mat1  : Vector of parameter estimates
%   seed  : ID of vector.
% Outputs:
%   bsh   : Vector with parameters and zeros.
bsh = zeros(length(seed),1);
n   = 1;
% Reshaping beta.
for j = 1:length(seed)
    if seed(j) == 1
        bsh(j,1) = b(n,1);
        n = n + 1;
    end;
end;

% Formating the forecast.
function fcast = format(fcast,a)
% Imputs.
%   fcast : Matrix forecast raw.
%   a     : Size evaluation window.
% Outputs:
%   fcast : Forecast Matrix (each row: h-step-ahead forecast).
fcast = fcast';
% Forecast
fcast2 = NaN(a,a);
i = 1;
for j0 = 1:a
    fcast2(i:end,j0)= fcast(1:end-i+1,j0);
    i = i + 1;
end
fcast = fcast2;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
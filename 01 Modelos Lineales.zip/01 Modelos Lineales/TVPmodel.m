function results = TVPmodel(y,xtvp,determ,setup,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 08/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of a TVP linear model. The code allows for AR
% components (lags dep. variable to be included) and discards draws that
% are not stationary. 
% State-space representation of the model:
%
% Observation Equation : y(t) = b(t)x(t) + alpha*h(t) +e(t)
% Transition Equation  : b(t) = mu + F*B(t-1) + v(t)
%
% Where: var(et) = R and var(vt) = Q. Note that F is an a identity matrix 
% and mu is equal to zero.
%
% Inputs:
%   y           : Dependent variable,
%   xtvp        : Time varying parameters.
%   determ      : Additional exogenous variables.
%   setup       : 
%   -.artvp     : Lag order of the model, time varying parameters.
%   -.ar        : Lag order of the model, contant parameters.
%   -.alpha     : Significance level for ttest and confidence intervals.
%   -.presample : Presample data for prior, if 0 then diffure prior for initial state and 
%                 25% of data for prior and GS initialization, but use full sample for draws.
%   -.bini      : Intial state vector, state variable (default zero vector).
%   -.Q0_Tau    : Controls uncertainty in state equation.
%   -.rep       : Number of final draws from posterior posterior.
%   -.burn      : Burning sample.
%   -.keep      : Keep every x draws, to reduce correlation among draws (default 1).
%   print       : (1) Do charts and print results on screen.
%   labels      : Column vector with labels for dep. and indep variables.
%   dates       : Vector with info for dates: [year,month,freq].
%                 Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results :
%   -.dta        : Original data.
%   -.yhat       : Fit of the model.
%   -.uhat       : residuals.
%   -.btvp       : Time varying parameters (state variables).
%   -.b          : Posterior median betas T|T.
%   -.bvar       : Var/cov betas T|T.
%   -.ttest      : t-test betas T|T.
%   -.bIC        : Posterior betas Confidence interval T|T.
%   -.Pval       : Asymtotic Pvalues.
%   -.Sg2        : Sigma2 from observation equation.
%   -.Q          : Var/cov matrix from state equation.
%   -.SSR        : Sum square resids.
%   -.R2         : R-square.
%   -.R2adj      : Adjusted R-square.
%   -.Dw         : Durbin Watson statistic.
%   -.AIC        : AIC.
%   -.HQC        : HQC.
%   -.BIC        : BIC.
%   -.T          : Sample size.
%   -.k          : Number of parameters.
%   -.btvp_draws : GS draws btvp.
%   -.bx_draws   : GS draws betas.
%   -.R_draws    : GS draws Sigma2.
%   -.Q_draws    : GS draws var/cov state equation.
%   -.table      : Table with print results.
%   -.check01    : Check explosive roots in simulations.
%   -.prior      : Data from priors.
%
% Index.
% 1. Checking code
% 2. Estimation
% 3. Results.
% 4. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Checking code
% Checking deterministic variables.
if isempty(determ)
    determ = [];
end

% Checking time varying AR terms and adjusting data.
if isfield(setup,'artvp') == 0
    setup.artvp = 0;
else
    % Getting lags
    temp = LagN(y,setup.artvp);
    % Adjusting sample size and data
    y = temp(:,1);    
    xtvp = [xtvp(setup.artvp+1:end,:) temp(:,2:end)];
    if size(determ,1) > 0
        determ = determ(setup.artvp+1:end,:);
    end
end
% Checking fix AR terms and adjusting data.
if isfield(setup,'ar') == 0
    setup.ar = 0;    
else
    % Getting lags
    temp = LagN(y,setup.ar);
    % Adjusting sample size and data
    y = temp(:,1);    
    xtvp = xtvp(setup.ar+1:end,:);
    if size(determ,1) > 0
        determ = [determ(setup.ar+1:end,:) temp(:,2:end)];
    else
        determ = temp(:,2:end);
    end
end
clear temp

% Checking lag structure of the model.
if setup.artvp*setup.ar > 0
    error('Check lag configuration of the model');
end

% Significance level for ttest and confidence interval.
if isfield(setup,'alpha') == 0
    setup.alpha = 0.05;
end
% Checkinf presample data
if isfield(setup,'presample') == 0
    setup.presample = 20;
end
% Controls uncertainty around first state.
if isfield(setup,'Q0_Tau') == 0
    setup.Q0_Tau = 3.5e-04;
end
% Checking which draws to kepp from final simulations.
if isfield(setup,'keep') == 0
    setup.keep = 1;
end
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end

% Number of state variables.
nst = size(xtvp,2);
% Rigth hand saide variables.
x00 = [xtvp determ];

% Checking presample
if setup.presample == 0
    % Pre-sample data for prior.
    T0 = round(size(y,1)*0.25);
else
    % Pre-sample data for prior.
    T0 = setup.presample;
end   
y0 = y(1:T0,:);
x0 = x00(1:T0,:);
b0 = (x0'*x0)^(-1)*x0'*y0;
e0 = y0-x0*b0;
% Setting Priors with pre-sample data.
sigma0= (e0'*e0)/T0;        % Initial R draw.
V00   = sigma0*(x0'*x0)^(-1);
V0    = V00(1:nst,1:nst);
Q0    = V0*T0*setup.Q0_Tau; % Prior variance transition equation; initial Q draw.
R0    = 0;                  % Prior variance observation equation error.
P00   = V0;                 % Variance intial state vector: p[t-1/t-1]
beta0 = b0(1:nst);          % Intial state vector: b[t-1/t-1]
% Prior for determinic variables.
if isempty(determ) == 0;
    bdt0 = b0(nst+1:end);           % Prior fixxed betas.
    Vbdt0= V00(nst+1:end,nst+1:end);% Prior variance fixxed betas.
else
    bdt0 = [];
end
clear y0 x0 b0 e0 V00 V0;

% Data for model estimation.
T0    = setup.presample;
Ybar  = y(T0+1:end,:);
Xbar  = x00(T0+1:end,:);
Tbar  = size(Xbar,1);
% Initialise Gibbs Sampling
Q = Q0;
R = sigma0;

% Getting info from the code.
nvar  = 1;
nexo  = size(determ,2);
draws = setup.rept*setup.keep;
burn  = setup.burn;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation
% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');

% Betas deterministic varuables.
if isempty(determ) == 0;
    bx = bdt0;
else
    bx = 0;
end
% Checking diffure prior for initial state.
if T0 == 0
    P00 = diag(ones(nst,1))*10000;
end

% Simulations.
record  = 0;
ndraw   = 1;
check01 = zeros(1,2); % Check for chol decomp of pm matrix on kalman filter backwards iterations.
while record < burn + draws + 1
    % Set up matrices for the Kalman Filter
    ns = size(beta0,1);
    F  = eye(ns); % FIX

    % Kalman Filter
    [beta_tt,~,~,ptt] = kfilter_LJ(Ybar,F,Xbar(:,1:end-nexo),Q,R,Xbar(:,end-nexo+1:end),bx',[],[],beta0,P00);
    
    % Backward recursion from Kalman Filter to compute mean and variance of the 
    % distribution of the state vector.
    % Check stable draws
    scheck = -1;
    while scheck < 0
        % Matrix to store draws from posterior distirbutions.
        beta2 = zeros(Tbar,ns);
        wa    = randn(Tbar,ns);
        % First iteration, period T.
        i  = Tbar;
        p00= squeeze(ptt(i,:,:)); 
        % Draw for beta ~ N(beta_tt,ptt)
        beta2(i,:) = beta_tt(i:i,:) + (wa(i:i,:)*chol(p00));

        % Rest of backward iterations, from t-1..to .1
        i = Tbar-1;
        while i >= 1
            pt = squeeze(ptt(i,:,:));
            % Update the filtered beta for information contained in beta[t+1], i.e. beta2(i+1:i+1,:) eq 8.16 pp193 in Kim Nelson
            bm = beta_tt(i:i,:) + (pt*F'*(F*pt*F'+Q)^(-1)*(beta2(i+1:i+1,:) - beta_tt(i,:)*F')')';
            % Update covariance of beta
            pm = pt - pt*F'*(F*pt*F' + Q)^(-1)*F*pt;
            % Checking pm matrix in burning sample and estimation smaple.
            [~,temp] = chol(pm);
            if temp > 0 
                pm = eye(size(beta0,2))*0.00000001+pm;
                % Tracking explosive roots.
                if record <= burn
                    check01(1,1) = check01(1,1) + 1;
                elseif record > burn
                    check01(1,2) = check01(1,2) + 1;
                end
            end
            clear temp
            % Draw for beta in period t from N(bm,pm)eq 8.17 pp193 in Kim Nelson
            beta2(i:i,:) = bm + (wa(i:i,:)*chol(pm));
            % Checking stable draw for the AR component.
            if setup.artvp > 0
                temp = StatioFun(beta2(i:i,end-setup.artvp+1:end));
                if temp == -1
                    i = 0;
                    clear pt bm pm beta2 wa p00;
                else
                    i = i - 1;
                    % Terminal condition
                    if i == 0
                       scheck = 1; 
                    end
                end
            % No AR components in the model.
            else
                i = i - 1;
                % Terminal condition
                if i == 0
                    scheck = 1; 
                end
            end
            clear temp
        end
    end
    clear scheck

    % Conditional on state variable, sample Q from IW distribution..
    errorq = diff(beta2);
    T1     = Tbar + T0;
    scaleQ = (errorq'*errorq) + Q0;
    if nst == 1
        % Draw from IG
        z0   = randn(T1,1);
        z0z0 = z0'*z0;
        Q = scaleQ/z0z0;
    else
        Q = iwpQ(T1,scaleQ^(-1));
    end

    % Conditional on state variable and R and Q, sample betas from deterministic variables.
    if isempty(determ) == 0;
        % Posterior estimates.
        xx = Xbar(:,end-nexo+1:end);
        yy = Ybar - sum(Xbar(:,1:end-nexo).*beta2,2);
        M = (Vbdt0^(-1) + (1/R)*(xx'*xx))^(-1) * (Vbdt0^(-1)*bdt0 + (1/R)*xx'*yy);
        V = (Vbdt0^(-1) + (1/R)*(xx'*xx))^(-1);
        % Checking draw
        scheck = -1;
        while scheck < 0
            % Draw betas deterministic variables.
            bx = M + (randn(1,nexo)*chol(V))';
            % Checking stable draw for the AR component.
            if setup.ar > 0
                scheck = StatioFun(bx(end-setup.ar+1:end));
            else
                scheck = 1;
            end
        end
        clear xx yy M V scheck;
    end

    % Conditional on state variable and Q, sample R IW distribution.
    if isempty(determ) == 0;
        errorR = Ybar - (sum(Xbar(:,1:end-nexo).*beta2,2) + Xbar(:,end-nexo+1:end)*bx);
    else
        errorR = Ybar - sum(Xbar(:,1:end-nexo).*beta2,2);
    end
    % Draw from IG
    scaleR = (errorR'*errorR);
    T1   = Tbar + T0;
    z0   = randn(T1,1);
    z0z0 = z0'*z0;
    R    = scaleR/z0z0 + R0;
        
    % Storing draws after the burning period.
    if record > burn
        % Update waitbar
        waitbar(ndraw/draws,h_wait);
        out1bt(:,:,ndraw) = beta2;
        if isempty(determ) == 0;
            out1bx(ndraw,:) = bx;
        end
        out2(ndraw,1) = R;
        out3(:,:,ndraw) = Q;
        ndraw = ndraw + 1;
    end

    % Moving top next draw if all conditions are satisfied.            
    record = record + 1;

    % Cleaning memory.
    clear F mu i errorq scaleQ T1 z0 z0z0 scaleR T1 errorR;
end
close(h_wait);
clear record ndraw;

% Adjusting draws fom posterior to reduce correlation in draws.
if setup.keep > 1
    out1bt = out1bt(:,:,1:setup.keep:end);
    if isempty(determ) == 0;
        out1bx = out1bx(1:setup.keep:end,:);
    end
    out2 = out2(1:setup.keep:end,1);
    out3 = out3(:,:,1:setup.keep:end);
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Number of total parameters in the model
k = nst + nexo;
% Posterior means
if isempty(determ) == 0;
    bmed = [median(out1bt,3) repmat(median(out1bx),Tbar,1)];        
else
    bmed = median(out1bt,3);
    out1bx = [];
end
bmedT  = bmed(end,:);
Rmed   = median(out2);
Qmed   = median(out3,3);

% Computing residuals and confidance bands for betas
aux   = setup.alpha;
bands = [];
bstd  = [];
for i0 = 1:nst
    % Bands
    temp1 = squeeze(out1bt(end,i0,:))';
    temp2 = quantile(temp1,[aux 1-aux],2);
    bands = [bands; temp2];
    % BTT draws
    temp3 = squeeze(out1bt(end,i0,:));
    bstd  = [bstd temp3];
    clear temp1 temp2;
end
% Checking deterministic variables.
if isempty(determ) == 0;
    bands = ([bands; quantile(out1bx,[aux 1-aux],1)']);
    bstd  = [bstd out1bx];
    yhat = sum(Xbar(:,1:end-nexo).*beta2,2) + Xbar(:,end-nexo+1:end)*bx;
    uhat = Ybar - yhat;
else
    yhat = sum(Xbar(:,1:end-nexo).*bmed,2);
    uhat = Ybar - yhat;
end
clear aux i0;

% Ttest and Pvalues for betas T|T
VbmedT= cov(bstd);
ttest = bmedT'./sqrt(diag(VbmedT));
Pval  = zeros(k,1);
for i0 = 1:k
    % Pvalues.
    Pval(i0,1)  = 2*(1-tcdf(abs(ttest(i0)),size(Ybar,1) - k));    
    if Pval(i0,1) < 0.001
        Pval(i0,1) = 0;    
    end
    if ttest(i0) < 1e-3
        ttest(i0) = 0;
    end
end

% Saving results.
results.dta    = [y x00];
results.yhat   = yhat;
results.uhat   = uhat;
results.btvp   = median(out1bt,3);
results.b      = bmedT';
results.bvar   = VbmedT;
results.ttest  = ttest;
results.bIC    = bands;
results.Pval   = Pval;
results.Sg2    = Rmed;
results.Q      = Qmed;
results.SSR    = uhat'*uhat;
results.R2     = 1 - results.SSR / ((Ybar-mean(Ybar))'*(Ybar-mean(Ybar)));
results.R2adj  = 1 - (1 - results.R2)*(Tbar - 1)/(Tbar - k);
results.Dw     = ((uhat(2:end,1) - uhat(1:end-1))' * (uhat(2:end,1) - uhat(1:end-1))) / results.SSR;
results.AIC    = log(results.SSR/Tbar) + 2*(k/Tbar);          
results.HQC    = log(results.SSR/Tbar) + 2*(k/Tbar)*log(log(Tbar));
results.BIC    = log(results.SSR/Tbar) +   (k/Tbar)*log(Tbar);
results.T      = Tbar;
results.k      = k;
% Gibb Sampling draws
results.btvp_draws = out1bt;
results.bx_draws   = out1bx;
results.R_draws = out2;
results.Q_draws = out3;
% Table.
results.table = print_res(results,setup.alpha,labels,print);
% Check draws
results.check01 = check01;
% Priors.
results.prior_Q0    = Q0;
results.prior_P00   = P00;
results.prior_beta0 = [beta0; bdt0]; % Initial state vector.

% Do charts
if print == 1       
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1];
    end
    print_charts(results,dates,labels);
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions

% Funtion check stationarity of a companion form matrix.
function check = StatioFun(betas)
b = vec(betas);
k = size(b,1);
% One parameter.
if k == 1
    F = b;
    if abs(F) < 1
        check = 0;
    elseif abs(F) >= 1
        check = -1;
    end
% More than one parameter.
elseif k > 1
    F = [b'; eye(k-1) zeros(k-1,1)];
    if max(abs(eig(F))) < 1
        check = 0;
    else
        check = -1;
    end
end

% Funtion do table.
function Estimation_results = print_res(results,aalpha,labels,print)
% Labels
if isempty(labels)
    lab_0 = [];
else
    lab_0 = labels(2:end);
end      

% Do table.
% labels for exo variables.
temp = zeros(size(results.b,1),1);
temp(1:size(results.btvp,2)) = 1;
if isempty(lab_0)
    if temp(1) == 1
        lab = {'b(T|T)1'};
    else
        lab = {'b1'}; 
    end
    for i0 = 2:results.k
        if temp(i0) == 1
            lab2 = strcat('b(T|T)',num2str(i0));
        else
            lab2 = strcat('b',num2str(i0));
        end        
        lab = [lab; lab2];
    end
else
    lab = lab_0(1,:);
    for i0 = 2:results.k
        lab2 = lab_0(i0,:);
        lab = [lab; lab2];
    end
end
% Sigma square.
lab = [lab; 'Sg2'];

% Building table
% First part.
labels = {'Param' 'Coef' 't-test' 'Pvalue' 'CI_l' 'CI_u'};
temp_1 = num2cell([results.b results.ttest results.Pval results.bIC]);
temp_2 = [num2cell(results.Sg2) ' ' ' ' ' ' ' '];
temp_3 = [temp_1; temp_2];
temp_4 = [lab temp_3];
part_1 = [labels; temp_4];
clear labels lab temp_1 temp_2 temp_3 temp_4;
% Second part
temp_1 = {'AIC'; 'HQC';  'BIC'};
temp_2 = num2cell([results.AIC;results.HQC;results.BIC]);
temp_3 = [temp_1 temp_2];
temp_4 = [{'R2 Adj'; 'R2'; 'SSR'} num2cell([results.R2adj;results.R2;results.SSR])];
temp_5 = [{'alpha'} aalpha; {'T'} results.T; {'k'} results.k];
part_2 = [{'' '' '' '' '' ''} ;[temp_3 temp_4 temp_5]];
clear temp_1 temp_2 temp_3 temp_4 temp_5 i0;
% Print results.
Estimation_results = [part_1; part_2];
if print == 1
    fid = 1;
    fprintf(fid,'****************************************************************************\n');
    display(Estimation_results);
    fprintf(fid,'****************************************************************************\n');
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
Tt = size(results.dta,1);
Tx = Tt-results.T;
[xTick,xTickLabel] = calendar(dates(1),dates(2),Tt,freq);

% Label for chart.
if isempty(labels)
    lab_dep_var = 'data';
else
    lab_dep_var = char(labels(1,:));
end      
% In-sample fit
figure(1)
subplot(2,2,1)
plot(results.dta(:,1), '-b');
hold on
plot([NaN(Tx,1); results.yhat], '--r');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
xlim([Tx xTick(end)]);
title('In sample fit of the model versus data','FontSize',11);
% Residuals
legend(lab_dep_var,'model fit','Location','northwest')
subplot(2,2,3)
plot([NaN(Tx,1); results.uhat], '-b');
hold on
plot(repmat(2*sqrt(results.Sg2),Tt,1), ':k');
hold on
plot(repmat(-2*sqrt(results.Sg2),Tt,1), ':k');
hold on
plot(zeros(Tt,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
xlim([Tx xTick(end)]);
title('Residuals +/- 2 S.D.','FontSize',11);

% ACF and PAC functions
subplot(2,2,2)     
[~,temp1] = acf(results.uhat);
if size(temp1,1) < 25
    n_aux = size(temp1,1);
    n_lim = n_aux-1;
else
    n_aux = 25;
    n_lim = 18;
end
bar((-1:n_aux-1),[NaN(1,2); temp1(1:n_aux,[1,2])]);
hold on        
plot((-1:n_aux-1),repmat(temp1(1:n_aux,3),1,n_aux+1), ':k');
hold on
plot((-1:n_aux-1),repmat(temp1(1:n_aux,4),1,n_aux+1), ':k');
xlim([-1 n_lim]);
ylim([-1 1]);
title('AC and PAC functions','FontSize',11);
legend('Sample Auto-correlations','Partial correlation function','Location','northwest')

% Distribution of the residuals.
subplot(2,2,4)
histogram(results.uhat,15,'FaceColor',[0 0 1],'EdgeAlpha',1);
title('Histogram for residuals','FontSize',11);
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
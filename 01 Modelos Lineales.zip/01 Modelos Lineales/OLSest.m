function results = OLSest(y,x,method,aalpha,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 17/Dec/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Code estimates a linear model by OLS. Note, constant term not
% included by default. Code supports three alternative methods to compute the
% stadanr errors of the parameters.
% Inputs:
%   y       : Dependent variable,
%   x       : Independet variables.
%   method  : VAR/cov matrix White/NWest/OLS (Default: NWest).
%   aalpha  : Significance level for ttest and confidence intervals.
%   print   : (1) Do charts and print results on screen.
%   labels  : Column vector with labels for dep. and indep variables.
%   dates   : Vector with info for dates: [year,month,freq].
%             Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results :
%   -.dta    : Original Data.
%   -.yhat   : Fit of the model.
%   -.uhat   : residuals.
%   -.b      : Parameters estimation.
%   -.bvar   : Var/cov betas.
%   -.ttest  : t-test.
%   -.bIC    : Betas Confidence interval.
%   -.Pval   : Asymtotic Pvalues.
%   -.Sg2    : variance.
%   -.SSR    : Sum square resids.
%   -.R2     : R-square.
%   -.R2adj  : Adjusted R-square.
%   -.Dw     : Durbin Watson statistic.
%   -.AIC    : AIC.
%   -.HQC    : HQC.
%   -.BIC    : BIC.
%   -.method : method for var/cov. 
%   -.T      : Sample size.
%   -.k      : Number of parameters.
%   -.table  : Table with print results.
%
% Index.
% 1. Estimation and t-test.
% 2. Results.
% 3. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Estimation and t-test.
% Significance level for ttest and confidence interval.
if exist('aalpha','var') == 0 || isempty(aalpha)
    aalpha = 0.05;
end
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking var/cov matrix for ttest.
if exist('method','var') == 0 || isempty(method)
    method = 'NWest';
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end
% Warnings.
if nargin == 1
    error('wrong number of inputs');
end

% Parameters estimation.
b    = (x'*x)\(x'*y);
yhat = x*b;
u    = y - yhat;
SSR  = u'*u;

% Var/cov correction method.
% SE using White (1980).
if strcmp(method, 'White')
    rini = OLShwhite(y,x);    
% SE using Newey & West (1987)
elseif strcmp(method, 'NWest')
    nlag = round(4*(size(y,1)/100)^(2/9));
    rini = OLSnwest(y,x,nlag);
% SE from OLS.
elseif strcmp(method, 'OLS')
    rini.beta  = b;
    rini.sige  = (SSR/(size(y,1) - size(x,2)));
    varb = rini.sige*(x'*x)^(-1);    
    rini.bvar  = varb;
    rini.tstat = b./sqrt(diag(varb));
    rini.tstd  = sqrt(diag(varb));
else
    error('Metodo de var/cov no valido');
end
% Pvalues
rini.Pval  = zeros(size(x,2),1);
for i0 = 1:size(x,2)   
    p_temp  = 2*(1-tcdf(abs(rini.tstat(i0,1)),size(y,1) - size(x,2)));    
    if p_temp < 0.001
        rini.Pval(i0,1) = 0;
    else
        rini.Pval(i0,1) = p_temp;
    end
    clear p_temp;
end
clear Pval fbb k nlag ttest var i0;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Results.
T  = size(y,1);
k  = size(x,2);
t1 = tinv(aalpha/2,T - k);
t2 = -1*t1;
rini.dest = rini.tstd;

% Saving results.
results.dta    = [y x];
results.yhat   = yhat;
results.uhat   = u;
results.b      = rini.beta;
results.bvar   = rini.bvar;
results.ttest  = rini.tstat;
results.bIC    = [rini.beta + t1*rini.dest rini.beta + t2*rini.dest];
results.Pval   = rini.Pval;
results.Sg2    = rini.sige;
results.SSR    = u'*u;
results.R2     = 1 - results.SSR / ((y-mean(y))'*(y-mean(y)));
results.R2adj  = 1 - (1 - results.R2)*(T - 1)/(T - k);
results.Dw     = ((u(2:end,1) - u(1:end-1))'*(u(2:end,1) - u(1:end-1))) / results.SSR;
results.AIC    = log(results.SSR/T) + 2*(k/T);          
results.HQC    = log(results.SSR/T) + 2*(k/T)*log(log(T));
results.BIC    = log(results.SSR/T) +   (k/T)*log(T);
results.method = method;
results.T      = T;
results.k      = k;
% Table.
results.table = print_res(results,aalpha,labels,print);

% Do charts
if print == 1       
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1];
    end
    print_charts(results,dates,labels);
end    
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions
% This function computes var/cov matrix according to Newey-West (HAC)
function results = OLSnwest(y,x,nlag)
% Inputs: 
%   y    : Dependent variable vector (nobs x 1)
%   x    : Independent variables matrix (nobs x nvar)
%   nlag : Number of lags to truncate the kernel.
% Outputs:
%   results :
%   -.bvar  : var/cov betas.
%   -.tstat : t-stats.
%   -.tstd  : Standar deviation of t-test.
%   -.beta  : betas.
%   -.sige  : Sigma hat.
% Initial setup and estimation.
[nobs,nvar] = size(x);
xpxi  = (x'*x)^(-1);
beta  = xpxi*(x'*y);
yhat  = x*beta;
resid = y - yhat;
sigu  = resid'*resid;
sige  = sigu/(nobs-nvar);

% Perform Newey-West correction
emat = [];
for i = 1:nvar
    emat = [emat; resid'];
end;    
hhat= emat.*x';
% Matriz with results.
G = zeros(nvar,nvar); 
w = zeros(2*nlag+1,1);
a=0;
while a ~= nlag + 1
    ga = zeros(nvar,nvar);
    w(nlag+1+a,1) = (nlag+1-a)/(nlag+1);
    za = hhat(:,(a+1):nobs)*hhat(:,1:nobs-a)';
    % First lag.
    if a == 0
        ga = ga+za;
    % Taking care of autocorrelations.
    else
        ga = ga+za+za';
    end;
    % Result.
    G = G + w(nlag+1+a,1)*ga;
    a = a+1;
end
clear a ga w za hhat emat;
% Var/cov matrix
V     = xpxi*G*xpxi;
nwerr = sqrt(diag(V));
% Results
results.bvar = V;
results.tstat= beta./nwerr;
results.tstd = nwerr; 
results.sige = sige;
results.beta = beta;

% This function computes var/cov matrix according to White correction.
function results = OLShwhite(y,x)
% Inputs: 
%   y : dependent variable vector (nobs x 1)
%   x : independent variables matrix (nobs x nvar)
% Outputs:
%   results :
%   -.bvar  : var/cov betas.
%   -.tstat : t-stats.
%   -.tstd  : Standar deviation of t-test.
%   -.beta  : betas.
%   -.sige  : Sigma hat.
% Initial setup and estimation.
[nobs,nvar] = size(x);
r     = triu(qr(x,0));
xpxi  = (r'*r)\eye(nvar);
beta  = xpxi*(x'*y);
yhat  = x*beta;
resid = y - yhat;
sigu  = resid'*resid;
sige  = sigu/(nobs-nvar);

% Perform White's correction
xuux  = mcov(x,resid);
xpxia = xpxi*xuux*xpxi;
tmp   = sqrt(diag(xpxia));

% Results
results.bvar  = xpxia;
results.tstat = beta./tmp;
results.tstd  = tmp;
results.sige  = sige;
results.beta  = beta;

% Function computes x'*u*u'*x such that xpx-inverse*xuux*xpx-inverse 
% represents a heteroscedasticity consistent vcv matrix
% References: H. White 1980, Econometrica Vol. 48 pp. 818-838. 
function xuux = mcov(x,u)
% written by:
% James P. LeSage, Dept of Economics
% Texas State University-San Marcos
% 601 University Drive
% San Marcos, TX 78666
% jlesage@spatial-econometrics.com
[nobs,nvar] = size(x);
xuux = zeros(nvar,nvar);
for i=1:nobs
    xp = x(i,:);
    xpx = xp'*xp;
    upu = u(i,1)*u(i,1);
    xuux = xuux + upu*xpx;
end;

% Funtion do table.
function Estimation_results = print_res(results,aalpha,labels,print)
% Labels
if isempty(labels)
    lab_0 = [];
else
    lab_0 = labels(2:end);
end      

% Do table.
% labels for exo variables.
if mean(results.dta(:,2)) == 1
    lab = {'cte'};
    for i0 = 1:results.k-1
        if isempty(lab_0)
            lab2 = strcat('b',num2str(i0));
        else
            lab2 = lab_0(i0,:);
        end        
        lab = [lab; lab2];
    end
else
    if isempty(lab_0)
        lab = {'b1'};
        for i0 = 2:results.k
            lab2 = strcat('b',num2str(i0));
            lab = [lab; lab2];
        end
    else
        lab = lab_0(1,:);
        for i0 = 2:results.k
            lab2 = lab_0(i0,:);
            lab = [lab; lab2];
        end
    end
end
% Sigma square.
lab = [lab; 'Sg2'];

% Building table
% First part.
labels = {'Param' 'Coef' 't-test' 'Pvalue' 'CI_l' 'CI_u'};
temp_1 = num2cell([results.b results.ttest results.Pval results.bIC]);
temp_2 = [num2cell(results.Sg2) ' ' ' ' ' ' ' '];
temp_3 = [temp_1; temp_2];
temp_4 = [lab temp_3];
part_1 = [labels; temp_4];
clear labels lab temp_1 temp_2 temp_3 temp_4;
% Second part
temp_1 = {'AIC'; 'HQC';  'BIC'};
temp_2 = num2cell([results.AIC;results.HQC;results.BIC]);
temp_3 = [temp_1 temp_2];
temp_4 = [{'R2 Adj'; 'R2'; 'SSR'} num2cell([results.R2adj;results.R2;results.SSR])];
temp_5 = [{'DW'} results.Dw; {'T'} num2cell(results.T); {'k'} num2cell(results.k)];
part_2 = [{'' '' '' '' '' ''} ;[temp_3 temp_4 temp_5]];
part_2 = [part_2; {'Var/cov' results.method 'alpha' aalpha '' ''}];
clear temp_1 temp_2 temp_3 temp_4 temp_5 i0;
% Print results.
Estimation_results = [part_1; part_2];
if print == 1
    fid = 1;
    fprintf(fid,'****************************************************************************\n');
    display(Estimation_results);
    fprintf(fid,'****************************************************************************\n');
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),results.T,freq);

% Label for chart.
if isempty(labels)
    lab_dep_var = 'data';
else
    lab_dep_var = char(labels(1,:));
end      
% In-sample fit
figure(1)
subplot(2,2,1)
plot(results.dta(:,1), '-b');
hold on
plot(results.yhat, '--r');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fit of the model versus data','FontSize',11);
% Residuals
legend(lab_dep_var,'model fit','Location','northwest')
subplot(2,2,3)
plot(results.uhat, '-b');
hold on
plot(repmat(2*sqrt(results.Sg2),results.T,1), ':k');
hold on
plot(repmat(-2*sqrt(results.Sg2),results.T,1), ':k');
hold on
plot(zeros(results.T,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Residuals +/- 2 S.D.','FontSize',11);

% ACF and PAC functions
subplot(2,2,2)     
[~,temp1] = acf(results.uhat);
if size(temp1,1) < 25
    n_aux = size(temp1,1);
    n_lim = n_aux-1;
else
    n_aux = 25;
    n_lim = 18;
end
bar((-1:n_aux-1),[NaN(1,2); temp1(1:n_aux,[1,2])]);
hold on        
plot((-1:n_aux-1),repmat(temp1(1:n_aux,3),1,n_aux+1), ':k');
hold on
plot((-1:n_aux-1),repmat(temp1(1:n_aux,4),1,n_aux+1), ':k');
xlim([-1 n_lim]);
ylim([-1 1]);
title('AC and PAC functions','FontSize',11);
legend('Sample Auto-correlations','Partial correlation function','Location','northwest')

% Distribution of the residuals.
subplot(2,2,4)
histogram(results.uhat,15,'FaceColor',[0 0 1],'EdgeAlpha',1);
title('Histogram for residuals','FontSize',11);
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
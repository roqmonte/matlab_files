function results = armax_model(y,x,setup,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 18/Dec/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Function estimates ARMA/ARMAX(p,q) model by MLE.
% The likelihood of the model is computed using the Kalman filter. Two
% alternative estimations procedures are available.
%
%  y(t) = cte + b*x(t) + rho(1)y(t-1)   + ... + rho(p)y(t-p) + 
%                 e(t) + gamma(1)e(t-1) + ... + gamma(q)e(t-q)
%
% State space representation:
%  s(t+1)= T*s(t) + R*v(t+1)
%  y(t)  = mu + Z*s(t)
%
%  Where: v(t)~N(0,Q); Q is diagonal matrix with Sg2.
%         e(t) Distribution of the shocks; u(t) measurement error.
%
% Inputs:
%   y           : Dependent variable.
%   x           : Independet variables (constant term by default if not included in first col).
%   setup:
%   -.arma      : Setup arma(p,q) terms.
%   -.type      : (0) csimwel (default); (1) matlab algorithm.
%   -.theta_ini : Initial value for the optimization routine (Default: []).
%   print       : (1) Do charts and print results on screen.
%   labels      : Column vector with labels for dep. and indep variables.
%   dates       : Vector with info for dates: [year,month,freq].
%                 Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results:
%   -.thetaf    : Theta hat.
%   -.theta_ini : Theta ini.
%   -.Hinv      : Inverse Hessian matrix.
%   -.logf      : Loglikelihood.
%   -.data      : Data estimation.
%   -.yhat      : Fit of the model.
%   -.uhat      : residuals.
%   -.b         : Parameters estimation.
%   -.ttest     : t-test.
%   -.Pval      : Pvalues for the parameters of the model.
%   -.Sg2       : Variance of the residuals.
%   -.SSR       : Sum squared residuals.
%   -.R2        : R-square.
%   -.R2adj     : Adjusted R-square.
%   -.AIC       : AIC.
%   -.HQC       : HQC.
%   -.BIC       : BIC.
%   -.T         : Sample size.
%   -.k   	    : Number of parameters.
%   -.mestim    : Estimation method.
% 	-.modell    : Type of model.
%   -.table     : Table with print results.
%
% Index.
% 1. Setup.
% 2. Optimization.
% 3. Results.
% 4. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
 % 1. Setup.
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end
 % Warnings.
if isfield(setup,'type') == 0
    setup.type = 0;
end
 if isfield(setup,'arma') == 0 || isfield(setup,'type') == 0
    error('Wrong arma option.');
 end
p = setup.arma(1,1);
q = setup.arma(1,2);
if q == 0
   error('Use OLSest code instead'); 
end
% Checking for constant term in the model.
if size(x,2) == 0
    x = ones(size(y,1),1);
end
if mean(x(:,1),1) ~= 1
    x = [ones(size(y,1),1) x];
end
% Selecting model
if size(x,2) == 1
    model_type = 'arma';
elseif  size(x,2) > 1
    model_type = 'armax';
end

% Defining Initial values. Using Hannan and McDougall method.
if isfield(setup,'theta_ini') == 0
    theta = param_ini(y,x,setup);    
else
    theta = setup.theta_ini; 
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Optimization.
% Estimation using own code.
if setup.type == 0
    % Computing Hessian.
    mestim = 'Kalman_filter';
    H = fdhess('armax_mlike',theta,y,x,setup);
    if isnan(det(H)) == 1 || isreal(H) == 0
        H = eye(size(theta,1));
    end      
    H0inv = H\eye(size(H));
    if isnan(det(H0inv)) == 1 || isreal(H0inv) == 0
        H0inv = eye(size(theta,1));
    end
    [V,Diag] = eig(H0inv);
    Diag = abs(Diag);
    H = V*Diag*V';
    % Options.
    tol = 1e-8; nite = 5000;
    % Estimation of the model..
    [~,thetaf,~,H] = csminwel('armax_mlike',theta,H,[],tol,nite,y,x,setup);
    [logf,yhat] = armax_mlike(thetaf,y,x,setup);
    resid = y - yhat;
    clear H0inv V Diag tol nite;
end

% Estimation using matlab built-in function.
if setup.type == 1
    % Bulding model in matlab notation.
    mestim = 'Matlab_Estimation';
    smod  = arima(p,0,q);    
    % Estimation arma(p,q) model.
    if strcmp(model_type,'arma')
        temp0 = estimate(smod,y);
        thetaf= cell2mat([temp0.Constant temp0.AR temp0.MA temp0.Variance]');
        resid = infer(temp0,y);
    % Estimation armax(p,q) model.
    elseif strcmp(model_type,'armax')
        xaux  = [repmat(mean(x),p,1); x];
        temp0 = estimate(smod,y,'X',xaux(:,2:end));  
        thetaf= cell2mat([temp0.Constant temp0.Beta' temp0.AR temp0.MA temp0.Variance]');
        resid = infer(temp0,y,'X',xaux(:,2:end));
    end       
    yhat  = y - resid;
    % Computing Hessian matrix and loglike of the model.
    H = fdhess('armax_mlike',thetaf,y,x,setup);
    logf = armax_mlike(thetaf,y,x,setup);
    clear smod temp0;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Infor for results.
k = size(thetaf,1);
T = size(y,1);
% Results.
results.theta      = thetaf;
results.theta_ini  = theta;
results.Hinv       = H;
results.logf       = -1*logf;
% Model results.
results.data       = [y x];
results.yhat       = yhat;
results.uhat       = resid;
results.b          = thetaf(1:end-1);
results.ttest      = thetaf(1:end-1) ./ sqrt(diag(H(1:end-1,1:end-1)));
results.Sg2        = (resid'*resid)/(T-k);
results.SSR        = resid'*resid;
results.R2         = 1 - results.SSR / ((y-mean(y))'*(y-mean(y)));
results.R2adj      = 1 - (1 - results.R2)*(T - 1)/(T - k);
results.AIC        = -(2/T)*results.logf + 2*(k/T);
results.HQC        = -(2/T)*results.logf + 2*(k/T)*log(log(T));
results.BIC        = -(2/T)*results.logf + (k/T)*log(T);
results.T          = T;
results.k          = k;
results.mestim     = mestim;
results.model      = model_type;
% Computing Pvalues for parameters.
results.Pval = zeros(k-1,1);
for i0 = 1:k-1
    aux = 2*(1-tcdf(abs(results.ttest(i0)),T - k));
    if aux < 0.001
        results.Pval(i0,1) = 0;
    else
        results.Pval(i0,1) = aux;
    end
end
clear aux i0;    
% Table.
results.table = print_res(results,setup,labels,print);

% Do charts
if print == 1
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1]; 
    end
    print_charts(results,dates,labels);
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions.
% Function computes initial values for the estimation of the model.
function theta = param_ini(y,x,setup)
% Inputs:
%   y         : Dependent variable.
%   x         : Exogenous variables.
%   setup     : Options for the code:
%   -.arma    : Setup .arma(p,q) terms.
%   -.type    : (0) own algorithm;(1) matlab algorithm.
% Outputs:
%   theta     : Initial theta.

% Lags of dependent variable.
yr = [];
if setup.arma(1,1) >= 1
    yr = LagN(y,setup.arma(1,1));
    yr = yr(:,2:end);
end;
% Data definition.
x0  = x(setup.arma(1,1)+1:end,:);
% Independent variables.
xall= [x0 yr];

% Defining Initial values. Using Hannan and McDougall method.
% ARMA(p,q)    
% Lags of dependent variable (1/4 of the sample).
T0  = round(size(y,1)/4);
yrx = LagN(y,T0);
yrx = yrx(:,2:end);
% Data definition and Estimation of large AR model.
ytemp = y(T0+1:end,:);
xtemp = [x(T0+1:end,:) yrx];
res = OLSest(ytemp,xtemp,'OLS');
% Model estimation MA part.     
ulags = LagN(res.uhat,setup.arma(1,2));
ulags = ulags(:,2:end);
res = OLSest(ytemp(setup.arma(2)+1:end,1),[xtemp(setup.arma(2)+1:end,1:size(xall,2)) ulags],'OLS');
% Initial values for estimation.
theta = [res.b; res.Sg2];
% Fixing initial values
aux = isnan(theta);
if max(aux) == 1
    theta = rand(sum(aux),1);
end

% Funtion do table.
function Estimation_results = print_res(results,setup,labels,print)
% Labels
if isempty(labels)
    lab_0 = [];
else
    lab_0 = labels(2:end);
end      
% Do table.
% labels for exo variables.
lab = {'cte'};
nx  = size(results.data,2)-1;
for i0 = 2:nx
    if isempty(lab_0)
        lab2 = strcat('b',num2str(i0-1));
    else
        lab2 = lab_0(i0-1,:);
    end        
    lab = [lab; lab2];
end
% labels for AR part of the model.
if setup.arma(1,1) > 0
    for i0 = 1:setup.arma(1,1)
        lab3 = strcat('ar',num2str(i0));
        lab = [lab; lab3];
    end;    
end;
% labels for MA part of the model.
if setup.arma(1,2) > 0
    for i0 = 1:setup.arma(1,2)
        lab4 = strcat('ma',num2str(i0));
        lab = [lab; lab4];
    end;    
end
% Sigma square.
lab = [lab; 'Sg2'];

% Building table
% First part.
labels = {'Param' 'Coef' 't-test' 'Pvalue'};
temp_1 = num2cell([results.theta(1:end-1) results.ttest results.Pval]);
temp_2 = [num2cell(results.Sg2) ' ' ' '];
temp_3 = [temp_1; temp_2];
temp_4 = [lab temp_3];
temp1  = [labels; temp_4];
temp1  = [temp1 repmat({' '},size(temp1,1),2)];
clear labels lab temp_1 temp_2 temp_3 temp_4;
% Second part
temp_1 = {'AIC'; 'HQC';  'BIC'};
temp_2 = num2cell([results.AIC;results.HQC;results.BIC]);
temp_3 = [temp_1 temp_2];
temp_4 = [{'R2 Adj'} num2cell(results.R2adj) ;{'R2'} num2cell(results.R2); {'SSR'} num2cell(results.SSR)]; 
temp_5 = [{'model' results.model}; {'T'} num2cell(results.T); {'k'} num2cell(results.k)];
temp2  = [temp_3 temp_4 temp_5];
% Print results.
Estimation_results = [temp1; repmat({' '},1,6) ;temp2; {'loglike'} num2cell(results.logf) repmat({' '},1,4)];
clear temp_1 temp_2 temp_3 temp_4 temp_5 temp1 temp2 i0;
if print == 1
    fid = 1;
    fprintf(fid,'****************************************************************************\n');
    display(Estimation_results);
    fprintf(fid,'****************************************************************************\n');    
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Info form estimation.
T  = size(results.data,1);
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),results.T,freq);

% Label for chart.
if isempty(labels)
    lab_dep_var = 'data';
else
    lab_dep_var = char(labels(1,:));
end      
% In-sample fit
figure(1)
subplot(2,2,1)
plot(results.data(:,1), '-b');
hold on
plot(results.yhat, '--r');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fir of the model versus data','FontSize',11);
legend(lab_dep_var,'model fit','Location','northwest')
% Residuals.
subplot(2,2,3)
plot(results.uhat, '-b');
hold on
plot(repmat(2*sqrt(results.Sg2),T,1), ':k');
hold on
plot(repmat(-2*sqrt(results.Sg2),T,1), ':k');
hold on
hold on
plot(zeros(T,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Residuals +/- 2 S.D.','FontSize',11);

% ACF and PAC functions
subplot(2,2,2)     
[~,temp1] = acf(results.uhat);
if size(temp1,1) < 25
    n_aux = size(temp1,1);
    n_lim = n_aux-1;
else
    n_aux = 25;
    n_lim = 18;
end
bar((-1:n_aux-1),[NaN(1,2); temp1(1:n_aux,[1,2])]);
hold on        
plot((-1:n_aux-1),repmat(temp1(1:n_aux,3),1,n_aux+1), ':k');
hold on
plot((-1:n_aux-1),repmat(temp1(1:n_aux,4),1,n_aux+1), ':k');
xlim([-1 n_lim]);
ylim([-1 1]);
title('AC and PAC functions','FontSize',11);
legend('Sample Auto-correlations','Partial correlation function','Location','northwest')
% Distribution of the residuals.
subplot(2,2,4)
histogram(results.uhat,31,'FaceColor',[0 0 1],'EdgeAlpha',1);
title('Histogram for residuals','FontSize',11);
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
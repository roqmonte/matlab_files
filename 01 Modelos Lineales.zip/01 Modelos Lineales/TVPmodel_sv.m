function results = TVPmodel_sv(y,xtvp,setup,print,labels,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 08/Jan/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of a TVP linear model. The code allows for AR
% components (lags dep. variable to be included) and discards draws that
% are not stationary. 
% State-space representation of the model:
%
% Observation Equation : y(t) = b(t)x(t) + SIGMA(t)*e(t)
% Transition Equation  : b(t) = mu + F*B(t-1) + v(t)
%                        H(t) = H(t-1) + n(t) ; H(t) = log(sg2)
%
% Where: var(et) = I, var(vt) = Q, and var(nt) = W. Note that F is an a 
% identity matrix and mu is equal to zero.
%
% Inputs:
%   y           : Dependent variable,
%   xtvp        : Time varying parameters.
%   setup       : 
%   -.artvp     : Lag order of the model, time varying parameters.
%   -.alpha     : Significance level for ttest and confidence intervals.
%   -.presample : Presample data for prior, if 0 then diffure prior for initial state and 
%                 25% of data for prior and GS initialization, but use full sample for draws.
%   -.bini      : Intial state vector, state variable (default zero vector).
%   -.Q0_Tau    : Controls uncertainty in state equation and scale for prior Q.
%   -.kW        : Scale parameter for W matrix.
%   -.rep       : Number of final draws from posterior posterior.
%   -.burn      : Burning sample.
%   -.keep      : Keep every x draws, to reduce correlation among draws (default 1).
%   print       : (1) Do charts and print results on screen.
%   labels      : Column vector with labels for dep. and indep variables.
%   dates       : Vector with info for dates: [year,month,freq].
%                 Freq:(1) monthly data; (2) quaterly data.
%
% Outputs:
%   results :
%   -.dta        : Original data.
%   -.yhat       : Fit of the model.
%   -.uhat       : residuals.
%   -.Pval       : Asymtotic Pvalues.
%   -.Sg2        : Posterior median Sg2 T|T.
%   -.Q          : Var/cov matrix from state equation.
%   -.SSR        : Sum square resids.
%   -.R2         : R-square.
%   -.R2adj      : Adjusted R-square.
%   -.Dw         : Durbin Watson statistic.
%   -.AIC        : AIC.
%   -.HQC        : HQC.
%   -.BIC        : BIC.
%   -.T          : Sample size.
%   -.k          : Number of parameters.
%   -.b          : Posterior median betas T|T.
%   -.bvar       : Var/cov betas.
%   -.ttest      : t-test betas T|T.
%   -.bIC        : Posterior betas Confidence interval T|T.
%   -.btvp       : Time varying parameters (state variables).
%   -.btvp_draws : GS draws btvp.
%   -.Sg2_draws  : Draws time varing Sg2(t).
%   -.Q_draws    : GS draws var/cov state equation.
%   -.H_draws    : Draws H(t) matrix.
%   -.W_draws    : Draws for cov matrix of H(t).
%   -.table      : Table with print results.
%   -.check01    : Check explosive roots in simulations.
%
% Index.
% 1. Checking code
% 2. Estimation
% 3. Results.
% 4. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Checking code
% Checking time varying AR terms and adjusting data.
if isfield(setup,'artvp') == 0
    setup.artvp = 0;
else
    % Getting lags
    temp = LagN(y,setup.artvp);
    % Adjusting sample size and data
    y = temp(:,1);    
    xtvp = [xtvp(setup.artvp+1:end,:) temp(:,2:end)];
end

% Significance level for ttest and confidence interval.
if isfield(setup,'alpha') == 0
    setup.alpha = 0.05;
end
% Checkinf presample data
if isfield(setup,'presample') == 0
    setup.presample = 20;
end
% Controls uncertainty around first state and prior for Q.
if isfield(setup,'Q0_Tau') == 0
    setup.Q0_Tau = 0.01;
end
% Controls uncertainty W matrix.
if isfield(setup,'kW') == 0
    setup.kW = 0.01;
end
% Checking which draws to kepp from final simulations.
if isfield(setup,'keep') == 0
    setup.keep = 1;
end
% Checking labels.
if exist('labels','var') == 0 || isempty(labels)
    labels = [];
end
% Checking print.
if exist('print','var') == 0
    print = 0;
end

% Number of state variables.
nst = size(xtvp,2);
% Rigth hand saide variables.
x00 = xtvp;

% Pre-sample data for prior.
T0 = setup.presample;
y0 = y(1:T0,:);
x0 = x00(1:T0,:);
b0 = (x0'*x0)^(-1)*x0'*y0;
e0 = y0-x0*b0;
% Setting Priors with pre-sample data.
sigma0= (e0'*e0)/T0;        % Initial R draw.
V00   = sigma0*(x0'*x0)^(-1);
V0    = V00(1:nst,1:nst);
Q0    = V0*T0*setup.Q0_Tau; % Prior variance transition equation; initial Q draw.
P00   = V0;                 % Variance intial state vector: p[t-1/t-1]
beta0 = b0(1:nst);          % Intial state vector: b[t-1/t-1]
clear y0 x0 b0 e0 V00 V0;

% Data for model estimation.
T0    = setup.presample;
Ybar  = y(T0+1:end,:);
Xbar  = x00(T0+1:end,:);
Tbar  = size(Xbar,1);
kW    = setup.kW;
% Initialise Gibbs Sampling
Q = Q0;

% Priors for H(t) and covariance matrix of H(t)
Hpr  = 0.5*log(sigma0);
VHpr = eye(1);
TW   = 2;
% Initialise W
covW = TW*VHpr*kW^2;
W    = iwishrnd(covW,TW);
% Initialise H and Sigma(t)
H    = NaN(Tbar,1);
Sig  = NaN(1,1,Tbar);
H(1,:)      = mvnrnd(Hpr,VHpr,1);
Sig(:,:,1)  = exp(2*H(1,:));
for t = 2:Tbar
    H(t,:)      = mvnrnd(H(t-1,:),W,1);
    Sig(:,:,t)  = exp(2*H(t,:));
end

% Getting info from the code.
nvar  = 1;
draws = setup.rept*setup.keep+1;
burn  = setup.burn;

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation
% Put waitbar
h_wait = waitbar(0,'Draws from the posterior distribution, please wait...');

% Simulations.
record  = 0;
ndraw   = 1;
check01 = zeros(1,2); % Check for chol decomp of pm matrix on kalman filter backwards iterations.
while record < burn + draws + 1
    % Set up matrices for the Kalman Filter
    ns = size(beta0,1);
    F  = eye(ns); % FIX

    % Kalman Filter
    Omega = reshape(exp(2*H),1,1,Tbar);
    [beta_tt,~,~,ptt] = kfilter_LJ(Ybar,F,Xbar,Q,Omega,[],[],[],[],beta0,P00);
    
    % Backward recursion from Kalman Filter to compute mean and variance of the 
    % distribution of the state vector.
    % Check stable draws
    scheck = -1;
    while scheck < 0
        % Matrix to store draws from posterior distirbutions.
        beta2 = zeros(Tbar,ns);
        wa    = randn(Tbar,ns);
        % First iteration, period T.
        i  = Tbar;
        p00= squeeze(ptt(i,:,:)); 
        % Draw for beta ~ N(beta_tt,ptt)
        beta2(i,:) = beta_tt(i:i,:) + (wa(i:i,:)*chol(p00));

        % Rest of backward iterations, from t-1..to .1
        i = Tbar-1;
        while i >= 1
            pt = squeeze(ptt(i,:,:));
            % Update the filtered beta for information contained in beta[t+1], i.e. beta2(i+1:i+1,:) eq 8.16 pp193 in Kim Nelson
            bm = beta_tt(i:i,:) + (pt*F'*(F*pt*F'+Q)^(-1)*(beta2(i+1:i+1,:) - beta_tt(i,:)*F')')';
            % Update covariance of beta
            pm = pt - pt*F'*(F*pt*F' + Q)^(-1)*F*pt;
            % Checking pm matrix in burning sample and estimation smaple.
            [~,temp] = chol(pm);
            if temp > 0 
                pm = eye(size(beta0,2))*0.00000001+pm;
                % Tracking explosive roots.
                if record <= burn
                    check01(1,1) = check01(1,1) + 1;
                elseif record > burn
                    check01(1,2) = check01(1,2) + 1;
                end
            end
            clear temp
            % Draw for beta in period t from N(bm,pm)eq 8.17 pp193 in Kim Nelson
            beta2(i:i,:) = bm + (wa(i:i,:)*chol(pm));
            % Checking stable draw for the AR component.
            if setup.artvp > 0
                temp = StatioFun(beta2(i:i,end-setup.artvp+1:end));
                if temp == -1
                    i = 0;
                    clear pt bm pm beta2 wa p00;
                else
                    i = i - 1;
                    % Terminal condition
                    if i == 0
                       scheck = 1; 
                    end
                end
            % No AR components in the model.
            else
                i = i - 1;
                % Terminal condition
                if i == 0
                    scheck = 1; 
                end
            end
            clear temp
        end
    end
    clear scheck
   
    % Sample S from a 7-point discrete density (see Kim et al., 1998)
    resB = Ybar - sum(beta2.*Xbar,2);
    [s,v2j,yss_mj] = KF_KimShephardChib([],Tbar,1,resB,H);    
    % Get draw for Sigmas2
    covH = zeros(1,1,Tbar);
    for t = 1:Tbar
        covH(:,:,t) = v2j(s(t));
    end
    H = KalmanCarterKohn_sv(yss_mj,ones(Tbar,1)*2,Hpr,VHpr,covH,W);
    clear t z1 j1 j2;   
        
    % Draw W.
    errorH = diff(H);
    scaleW = errorH'*errorH + TW*VHpr*kW^2;
    W      = iwishrnd(scaleW,Tbar-1+TW);
    
    % Conditional on state variable, sample Q from IW distribution..
    errorq = diff(beta2);
    T1     = Tbar + T0;
    scaleQ = (errorq'*errorq) + Q0;
    if nst == 1
        % Draw from IG
        z0   = randn(T1,1);
        z0z0 = z0'*z0;
        Q = scaleQ/z0z0;
    else
        Q = iwpQ(T1,scaleQ^(-1));
    end
        
    % Storing draws after the burning period.
    if record > burn
        % Update waitbar
        waitbar(ndraw/draws,h_wait);
        out1(:,:,ndraw) = beta2;
        out2(:,:,:,ndraw) = Omega;
        out3(:,:,ndraw) = Q;
        % draws of H(t).
        H_s(:,:,ndraw)   = H;
       % draws of W from IW
        W_s(:,:,ndraw)   = W;
        ndraw = ndraw + 1;
    end

    % Moving top next draw if all conditions are satisfied.            
    record = record + 1;

    % Cleaning memory.
    clear F mu i errorq scaleQ T1 z0 z0z0 scaleR T1 errorR;
end
close(h_wait);
clear record ndraw;

% Adjust out1 and out2 dimension to make draws consistent
out1 = out1(:,:,2:end);
out2 = out2(:,:,:,2:end);

% Adjusting draws fom posterior to reduce correlation in draws.
if setup.keep > 1
    out1 = out1(:,:,1:setup.keep:end);
    out2 = out2(1:setup.keep:end,1);
    out3 = out3(:,:,1:setup.keep:end);
    H_s  = H_s(:,:,1:setup.keep:end);
    W_s  = W_s(:,:,1:setup.keep:end);
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Results.
% Number of total parameters in the model
k = nst;
% Posterior means
bmed   = median(out1,3);
bmedT  = bmed(end,:);
Qmed   = median(out3,3);

% Computing residuals and confidance bands for betas
aux   = setup.alpha;
bands = [];
bstd  = [];
for i0 = 1:nst
    % Bands
    temp1 = squeeze(out1(end,i0,:))';
    temp2 = quantile(temp1,[aux 1-aux],2);
    bands = [bands; temp2];
    % BTT draws
    temp3 = squeeze(out1(end,i0,:));
    bstd  = [bstd temp3];
    clear temp1 temp2;
end
yhat = sum(Xbar.*bmed,2);
uhat = Ybar - yhat;

% Ttest and Pvalues for betas T|T
VbmedT= cov(bstd);
ttest = bmedT'./sqrt(diag(VbmedT));
Pval  = zeros(k,1);
for i0 = 1:k
    % Pvalues.
    Pval(i0,1)  = 2*(1-tcdf(abs(ttest(i0)),size(Ybar,1) - k));    
    if Pval(i0,1) < 0.001
        Pval(i0,1) = 0;    
    end
    if ttest(i0) < 1e-3
        ttest(i0) = 0;
    end
end

% Data
results.dta    = [y x00];
% Fit of the model and results.
results.yhat   = yhat;
results.uhat   = uhat;
results.Pval   = Pval;
results.SSR    = uhat'*uhat;
results.R2     = 1 - results.SSR / ((Ybar-mean(Ybar))'*(Ybar-mean(Ybar)));
results.R2adj  = 1 - (1 - results.R2)*(Tbar - 1)/(Tbar - k);
results.Dw     = ((uhat(2:end,1) - uhat(1:end-1))' * (uhat(2:end,1) - uhat(1:end-1))) / results.SSR;
results.AIC    = log(results.SSR/Tbar) + 2*(k/Tbar);          
results.HQC    = log(results.SSR/Tbar) + 2*(k/Tbar)*log(log(Tbar));
results.BIC    = log(results.SSR/Tbar) +   (k/Tbar)*log(Tbar);
results.T      = Tbar;
results.k      = k;
% Median estimates
results.b      = bmedT';
results.bvar   = VbmedT;
results.ttest  = ttest;
results.bIC    = bands;
results.btvp   = median(out1,3);
results.Sg2    = median(squeeze(out2(:,:,end,:)));
results.Q      = Qmed;
% Gibb Sampling draws
results.btvp_draws = out1;
results.Sg2_draws  = out2;
results.Q_draws    = out3;
results.H_draws    = H_s;
results.W_draws    = W_s;
% Table.
results.table = print_res(results,setup.alpha,labels,print);
% Check draws
results.check01 = check01;

% Do charts
if print == 1       
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1];
    end
    print_charts(results,dates,labels);
    
    % Options for plots.
    info.widths     = [1 0.7];          % Line widths (zero line, point estim.).
    info.fsizes     = [14 10];          % Font sizes (titles, axes).
    info.area_color = [0.9 0.9 0.9];    % Color of area for highest sign. level. 
    info.names      = {'Dependent variable'};
    % Generating dates.
    T = length(y);
    if dates(end) == 1
        freq = 'm';
    elseif dates(end) == 2
        freq = 'q';
    end
    [time1,time2] = calendar(dates(1),dates(2),T,freq);
    info.dates_xTick = time1;
    info.dates_label = time2;
    % Do chart
    Sg2_draws = reshape(squeeze((results.Sg2_draws)),size(out1,1),1,size(out1,3));
    Plot_tvp_sg2(Sg2_draws,info,2)
end

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions

% Funtion check stationarity of a companion form matrix.
function check = StatioFun(betas)
b = vec(betas);
k = size(b,1);
% One parameter.
if k == 1
    F = b;
    if abs(F) < 1
        check = 0;
    elseif abs(F) >= 1
        check = -1;
    end
% More than one parameter.
elseif k > 1
    F = [b'; eye(k-1) zeros(k-1,1)];
    if max(abs(eig(F))) < 1
        check = 0;
    else
        check = -1;
    end
end

% Funtion do table.
function Estimation_results = print_res(results,aalpha,labels,print)
% Labels
if isempty(labels)
    lab_0 = [];
else
    lab_0 = labels(2:end);
end      

% Do table.
% labels for exo variables.
temp = zeros(size(results.b,1),1);
temp(1:size(results.btvp,2)) = 1;
if isempty(lab_0)
    if temp(1) == 1
        lab = {'b(T|T)1'};
    else
        lab = {'b1'}; 
    end
    for i0 = 2:results.k
        if temp(i0) == 1
            lab2 = strcat('b(T|T)',num2str(i0));
        else
            lab2 = strcat('b',num2str(i0));
        end        
        lab = [lab; lab2];
    end
else
    lab = lab_0(1,:);
    for i0 = 2:results.k
        lab2 = lab_0(i0,:);
        lab = [lab; lab2];
    end
end
% Sigma square.
lab = [lab; 'Sg2'];

% Building table
% First part.
labels = {'Param' 'Coef' 't-test' 'Pvalue' 'CI_l' 'CI_u'};
temp_1 = num2cell([results.b results.ttest results.Pval results.bIC]);
temp_2 = [num2cell(results.Sg2) ' ' ' ' ' ' ' '];
temp_3 = [temp_1; temp_2];
temp_4 = [lab temp_3];
part_1 = [labels; temp_4];
clear labels lab temp_1 temp_2 temp_3 temp_4;
% Second part
temp_1 = {'AIC'; 'HQC';  'BIC'};
temp_2 = num2cell([results.AIC;results.HQC;results.BIC]);
temp_3 = [temp_1 temp_2];
temp_4 = [{'R2 Adj'; 'R2'; 'SSR'} num2cell([results.R2adj;results.R2;results.SSR])];
temp_5 = [{'alpha'} aalpha; {'T'} results.T; {'k'} results.k];
part_2 = [{'' '' '' '' '' ''} ;[temp_3 temp_4 temp_5]];
clear temp_1 temp_2 temp_3 temp_4 temp_5 i0;
% Print results.
Estimation_results = [part_1; part_2];
if print == 1
    fid = 1;
    fprintf(fid,'****************************************************************************\n');
    display(Estimation_results);
    fprintf(fid,'****************************************************************************\n');
end

% Funtion print charts.
function charts = print_charts(results,dates,labels)
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
Tt = size(results.dta,1);
Tx = Tt-results.T;
[xTick,xTickLabel] = calendar(dates(1),dates(2),Tt,freq);

% Label for chart.
if isempty(labels)
    lab_dep_var = 'data';
else
    lab_dep_var = char(labels(1,:));
end      
% In-sample fit
figure(1)
subplot(2,2,1)
plot(results.dta(:,1), '-b');
hold on
plot([NaN(Tx,1); results.yhat], '--r');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
xlim([Tx xTick(end)]);
title('In sample fit of the model versus data','FontSize',11);
% Residuals
legend(lab_dep_var,'model fit','Location','northwest')
subplot(2,2,3)
plot([NaN(Tx,1); results.uhat], '-b');
hold on
plot(repmat(2*sqrt(results.Sg2),Tt,1), ':k');
hold on
plot(repmat(-2*sqrt(results.Sg2),Tt,1), ':k');
hold on
plot(zeros(Tt,1), '--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
xlim([Tx xTick(end)]);
title('Residuals +/- 2 S.D.','FontSize',11);

% ACF and PAC functions
subplot(2,2,2)     
[~,temp1] = acf(results.uhat);
if size(temp1,1) < 25
    n_aux = size(temp1,1);
    n_lim = n_aux-1;
else
    n_aux = 25;
    n_lim = 18;
end
bar((-1:n_aux-1),[NaN(1,2); temp1(1:n_aux,[1,2])]);
hold on        
plot((-1:n_aux-1),repmat(temp1(1:n_aux,3),1,n_aux+1), ':k');
hold on
plot((-1:n_aux-1),repmat(temp1(1:n_aux,4),1,n_aux+1), ':k');
xlim([-1 n_lim]);
ylim([-1 1]);
title('AC and PAC functions','FontSize',11);
legend('Sample Auto-correlations','Partial correlation function','Location','northwest')

% Distribution of the residuals.
subplot(2,2,4)
histogram(results.uhat,15,'FaceColor',[0 0 1],'EdgeAlpha',1);
title('Histogram for residuals','FontSize',11);
charts = [];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
function results = NeuralNetwork(y,xl,xnl,setup,print,dates)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Jan/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Estimation of Neural Network models: 
% 1./ mlp: Multilayer Perceptron network 
% 2./ rad: Radial Basis Network, 
% 3./ ric: Ridgelet Network 
% 4./ rec: Recurrent Network). 
%
% Estimation is done in two steps: (1) Genetic algorithm; (2) Back 
% Propagation algorithm (minimization SSR).
%
% Inputs:
%   y      : Dependent variable.
%   xl     : Regressors for linear part of model (constant term by default if not included in first col).
%   xnl    : Regressors for nonlinear part of model (constant term by default if not included in first col).
%   setup  :
%   -.hunits: # layers of the net: 1,2,3 (Default: 1).
%   -.nwt   : # neurons/hidden_units per layer (1 x nxt) (Default: 1).
%   -.fname : Type of Network: 'mlp','rad','rid','rec' (Default: mlp).
%   -.agen  : # simulations and generations for G.A (Default: 100,50).
%   -.mats  : Initial seeds from a previus estimation (Default: []).
%   -.theta : Initial value for Theta (Default: []).
%   print   : (1) Do charts and print results on screen.
%   dates   : Vector with info for dates: [year,month,freq].
%             Freq:(1) monthly data; (2) quaterly data.
%
% ** Activation function for Multilayer Perceptron and Recurrent Network (not ready).
%   -.fnct  : logsigmoid, tansig and gaussian (Default: logsigmoid).
% ** Recurrent network (not ready).
%   -.lags  : Number og lags of the hiddend units (neurons).
%
% Outputs:
%   results :
%   -.fval    : Value of the ojective function for each opt (initial incl).
%   -.theta   : Estimation of Theta for each opt (initial incl).
%   -.fname   : Code Neural Network.
%   -.fname2  : Name Neural Network.
%   -.niter   : Number of iterations.
%   -.dta     : Data estimations.
%   -.yhat2   : Fit of the model for each opt (initial incl).
%   -.yhat    : Fir of the model.
%   -.uhat    : residuals for each opt. step.
%   -.param   : Parameters of the network.
%   -.H       : Inverse of the Hessian Matrix (cminswel).
%   -.Sg2     : variance.
%   -.SSR     : Sum square resids.
%   -.R2      : R-square.
%   -.AIC     : AIC.
%   -.HQC     : HQC.
%   -.BIC     : BIC.
%   -.T       : Sample size.
%   -.k       : Number of parameters.
%   -.addres  : Additional results (see below).
%   -.fconv   : Convergency of the objective funtion.
%   -.table   : Table with print results.
%
% Index.
    % 1. Neural Network selection.
    % 2. Estimation.
    % 3. Storing results.
    % 4. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Neural Network selection.
% Checking inputs.
if size(xl,2) == 0 && size(xnl,2) == 0
    error('Wrong arguments for the code.');
end
if isfield(setup,'agen') == 0
    setup.agen = [100 50];
end;
if isfield(setup,'mats') == 0
    setup.mats = [];
end;
if isfield(setup,'theta') == 0
    setup.theta = [];
end;
% Default network
if isfield(setup,'hunits') == 0
    setup.hunits= 1;
end;
if isfield(setup,'nwt') == 0
    setup.nwt= 1;
end;
if isfield(setup,'fname') == 0
    setup.fname= 'mlp';
    setup.fnct = 'logsigmoid';
end;

% Checking for constant term in the model.
if size(xl,2) == 0
    xl = ones(size(y,1),1);
end
if mean(xl(:,1),1) ~= 1
    xl = [ones(size(y,1),1) xl];
end
if size(xnl,2) == 0
    xnl= ones(size(y,1),1);
end
if mean(xnl(:,1),1) ~= 1
    xnl= [ones(size(y,1),1) xnl];
end

% Checking consistency of the network structure.
if setup.hunits == 1
    setup.nwt(1,2:3) = 0;
elseif setup.hunits == 2
    setup.nwt(1,3) = 0;
    if setup.nwt(1) == 0 || setup.nwt(2) == 0
        error('Error, wrong number of neurons first layer');
    end;
elseif setup.hunits == 3
    if setup.nwt(1) == 0 || setup.nwt(2) == 0
        error('Error, wrong number of neurons first or second layer');
    end;
else
    error('Error, max number of layers is 3');
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation.
% Choosing the network.
% Multilayer Perceptron Network 
if strcmp(setup.fname, 'mlp')
    theta01 = mlp123(y,xl,xnl,setup);
    fname = 'Eval_MLP';
% Radial Basis Functions    
elseif strcmp(setup.fname, 'rad')
    theta01 = radnt(y,xl,setup);
    fname = 'Eval_RAD';
    setup.fnct = {' '};
% Ridgelet Network    
elseif strcmp(setup.fname, 'rid')
    theta01 = ridnt(y,xl,setup);
    fname = 'Eval_RID';
    setup.fnct = {' '};
end 

% Genetic Algorithm.
% First fit without iterations.
eval(['[fini1,yhat_ini] = ' fname '(theta01,y,xl,xnl,setup);']);
% Estimationn using the G.A.
rini = Agenetic_nnetwork(fname,theta01,y,xl,xnl,setup);

% Reset Initial seed.
if size(setup.mats,1) > 0
    setup.mats = [];
end;
% Fiting according to the G.A.
eval(['[fagen,yhat_nn1] = ' fname '(rini.theta,y,xl,xnl,setup);']);

% Numerical optimization.
% Hessian estimation.
H     = fdhess(fname,rini.theta,y,xl,xnl,setup);
H0inv = H\eye(size(H));
% Checking the consistency of the Hessian Matrix.
if max(max(isnan(H0inv))) == 1 || max(max(isinf(H0inv))) == 1 || isreal(H0inv) == 0 || isreal(H) == 0
    H = eye(size(theta01,1));
else
    [V,Diag] = eig(H0inv);
    Diag     = abs(Diag);
    H        = V*Diag*V';
end;
% Optimization.
nite = 5000; tol = 1e-8;
[fcn2, theta02, ~, H, fchain, xchain,niter] = csminwel(fname,rini.theta,H,[],tol,nite,y,xl,xnl,setup);
clear H0inv V Diag i tol nite;
% Fitting according to the numerical optimization..
eval(['[~,yhat_cms,param] = ' fname '(theta02,y,xl,xnl,setup);']);

% Name of the network.
% Multilayer Perceptron Network 
if strcmp(setup.fname, 'mlp')
    setup.fname2 = 'Multilayer Perceptron Network';
% Radial Basis Functions    
elseif strcmp(setup.fname, 'rad')
    setup.fname2 = 'Radial Basis Function';    
% Ridgelet Network    
elseif strcmp(setup.fname, 'rid')
% Results = Est_RID(y,x,setup);
    setup.fname2 = 'Ridgelet Network ';
else        
    error('Error, check Name of the Network.');
end;

% Itereations and convergency of the optimization
i_ga = [rini.feval_all(:,1) NaN(size(rini.feval_all(:,1),1),1)];
i_cm = [NaN(size(fchain(:,1),1),1) fchain(:,1)];
i_nn = [i_ga; i_cm];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Storing results.
T = size(y,1);
k = size(theta02,1);

% Resluts from optimization procedures.
results.fval  = [fini1       fagen      fcn2    ];
results.theta = [theta01     rini.theta theta02 ];
results.fname = setup.fname;
results.niter = niter;
% Results for the network.
results.dta   = [y xl xnl];
results.yhat2 = [y yhat_ini  yhat_nn1 yhat_cms];
results.yhat  = yhat_cms;
results.uhat  = y - yhat_cms;
results.param = param;
results.H     = H;
% More resluts for the fit of the network.
results.SSR  = results.uhat'*results.uhat;
results.Sg2  = results.SSR / (T - k);
results.R2   = 1 - results.SSR / ((y-mean(y))'*(y-mean(y)));
results.AIC = log(results.SSR/T) + 2*(k/T);
results.HQC = log(results.SSR/T) + 2*(k/T)*log(log(T));
results.BIC = log(results.SSR/T) + (k/T)*log(T);
results.T   = T;
results.k   = k;
results.fconv= i_nn;
% Table.
results.table = print_res(y,xl,results,setup,print);

% Do charts
if print == 1       
    if exist('dates','var') == 0 || isempty(dates)
        dates = [1900,1,1];
    end
    print_charts(results,dates);
end   

% Additional results from the procedure.
% Reults from the G.A.
results.addres.ga = rini; 
% Lags of the dept variable and number of parameters estimated.
results.addres.st = [setup.hunits rini.error];
% Total number of parameters.
results.addres.nparam = size(theta01,1);
% Setup of the estimation of the network.
results.addres.setup = setup;
% Thetas from each iterations of csminswel.
results.addres.theta_cmw = xchain;
% Objectives fns. for each theta of csminswel.
results.addres.feval_cmw = fchain;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 4. Functions.
% Function computes additional statistics for the Neural Network model
% and a linear model as a benchmark. The code also do table
function Estimation_results = print_res(y,x,results,setup,print)
% Inputs:
%   y      : Dependent variable.
%   xl     : Regressors for the linear part of the model (constant term by default if not included).
%   results: Results from the neutal network.
%   setup  : Info network.

% Building stats.
% Neural network
% Durbin Watson
Dwt_nn = ((results.uhat(2:end,1) - results.uhat(1:end-1))'*(results.uhat(2:end,1) - results.uhat(1:end-1))) / results.SSR;
% Skewness.
SK_nn = skewness(results.uhat,0);
% Kurtosis
KR_nn = kurtosis(results.uhat,0);
% Jarque Bera test of normality.
JB_nn(1,1) = ((results.T - 6)/results.k)*(SK_nn^(2) + 0.25*(KR_nn - 3)^(2));
JB_nn(1,2) = 1 - chi2cdf(JB_nn(1,1),2);
% Linear model (benchmark using xl).
res_ols = OLSest(y,x,'NWest');
% Durbin Watson.
Dwt = ((res_ols.uhat(2:end,1) - res_ols.uhat(1:end-1))'*(res_ols.uhat(2:end,1) - res_ols.uhat(1:end-1))) / results.SSR;
% Skewness.
SK = skewness(res_ols.uhat,0);
% Kurtosis.
KR = kurtosis(res_ols.uhat,0);
% Jarque Bera test of normality.
JB(1,1) = ((res_ols.T - 6)/res_ols.k)*(SK^(2) + 0.25*(KR - 3)^(2));
JB(1,2) = 1 - chi2cdf(JB(1,1),2);

% Building table
if strcmp(setup.fname, 'mlp')
    l_temp =  {'First layer'; 'Second layer'; 'Third layer'};
elseif strcmp(setup.fname, 'rad') || strcmp(setup.fname, 'rid')
    l_temp =  {'hidden unit'; 'Cof. ActFnc'};
end
% Labels for linear part: betas and weights.
aux_max = max(setup.nwt)+5;
aux_m(1,1:aux_max) = {' '};
lab = {'cte'};
for i0 = 2:size(x,2)
    lab2 = strcat('b',num2str(i0-1));
    lab = [lab; lab2];
end
for i0 = 1:size(results.param.xnl,2)
    lab2 = strcat('weights ',num2str(i0));
    lab = [lab; lab2];
end
% Labels for nonlinear part, case for 1 layer.
lab_nl = {'cte'};
for i0     = 2:size(results.param.xnl,1)
    lab2   = strcat('bnl_1',num2str(i0-1));
    lab_nl = [lab_nl; lab2];
end
% Labels for nonlinear part, case for 2 layer.
if isfield(results.param,'xnl2') == 1
    lab_nl2 = {'cte'};
    for i0     = 2:size(results.param.xnl2,1)
        lab2   = strcat('bnl_2',num2str(i0-1));
        lab_nl2 = [lab_nl2; lab2];
    end
    lab_nl2 = [' '; lab_nl2];
    temp_xnl2(1:size(results.param.xnl2,1),1:aux_max) = {' '};
    temp_xnl2(1:size(results.param.xnl2,1),1:size(results.param.xnl2,2)) = num2cell(results.param.xnl2);
    temp_xnl2 = [[l_temp(2) cellstr(strcat(num2str(size(results.param.xnl2,2)),' Neurons')) aux_m(1,3:end)]; temp_xnl2];
else
    lab_nl2 = [];
    temp_xnl2 = [];
end
% Labels for nonlinear part, case for 3 layer.
if isfield(results.param,'xnl3') == 1
    lab_nl3 = {'cte'};
    for i0     = 2:size(results.param.xnl3,1)
        lab2   = strcat('bnl_3',num2str(i0-1));
        lab_nl3 = [lab_nl3; lab2];
    end 
    lab_nl3 = [' '; lab_nl3];
    temp_xnl3(1:size(results.param.xnl3,1),1:aux_max) = {' '};
    temp_xnl3(1:size(results.param.xnl3,1),1:size(results.param.xnl3,2)) = num2cell(results.param.xnl3);
    temp_xnl3 = [[l_temp(3) cellstr(strcat(num2str(size(results.param.xnl3,2)),' Neurons')) aux_m(1,3:end)]; temp_xnl3];
else
    lab_nl3 = [];
    temp_xnl3 = [];
end

% First part.
labels = [lab; {''}; lab_nl; lab_nl2; lab_nl3];
temp_b(1:size(lab,1),1:aux_max) = {' '};
temp_xnl(1:size(results.param.xnl,1),1:aux_max) = {' '};
temp_b(:,1) = num2cell(results.param.b);
temp_xnl(:,1:size(results.param.xnl,2)) = num2cell(results.param.xnl);
temp_1 = [temp_b; [l_temp(1) cellstr(strcat(num2str(size(results.param.xnl,2)),' Neurons')) aux_m(1,3:end)]; temp_xnl;temp_xnl2;temp_xnl3];
part_1 = [labels temp_1];
part_1(1:res_ols.k,3) = num2cell(res_ols.b);
clear i0 lab2 temp_b temp_xnl temp_xnl2 lab_nl2 temp_xnl3 lab_nl3 lab lab_nl lab_n2 lab_n3;
% Second part
temp_1 = [{'AIC'; 'HQC';  'BIC'} num2cell([results.AIC;results.HQC;results.BIC])];
temp_2 = [{'SSR'; 'R2'; 'Sg2'} num2cell([results.SSR;results.R2;results.Sg2])];
temp_3 = [{'Network' setup.fname 'Act. fnc' setup.fnct}; {'Hid units' setup.hunits 'Neurons' (strcat(num2str(setup.nwt(1)),'/',...
          num2str(setup.nwt(2)),'/',num2str(setup.nwt(3))))}; [temp_1 temp_2]];
clear temp_1  temp_2;
temp_4 = {' ' ' ' ' ';'Stats' 'OLS' 'Network'};
temp_5 = {'DW stat'; 'skewness';  'kurtosis'; 'JB Pval';  'R2'; 'AIC'; 'HQC'; 'BIC'; 'T'; 'k'};
temp_6 = [ [Dwt; SK; KR; JB(1,2); res_ols.R2; res_ols.AIC; res_ols.HQC; res_ols.BIC; res_ols.T; res_ols.k] ...
         [Dwt_nn; SK_nn; KR_nn; JB_nn(1,2); results.R2; results.AIC; results.HQC; results.BIC; results.T; results.k]];
temp_7 = [temp_4; [temp_5 num2cell(temp_6)]];
temp_7(1:11,4) = {' '};
temp_8 = ['n iter.' num2cell(results.niter) 'fval' num2cell(results.fval(end))];
part_2 = [temp_3; temp_7; temp_8];
clear temp_1 temp_2 temp_3 temp_4 temp_5 temp_6 temp_7 temp_8;
% Print results.
if size(part_2,1) > size(part_1,1)
    part_x(1:size(part_2,1),1:aux_max+1) = {' '};
    part_x(1:size(part_1,1),:) = part_1;   
else
    part_x = part_1;
end
part_x(1:size(part_2,1),end-3:end) = part_2;
part_h = part_x(1,:);
part_h(1,1:3) = {'Param' 'Coef l model' 'OLS'};
part_h(1,4:end) = {' '};
Estimation_results = [part_h; part_x];
if print == 1
    fid = 1;
    fprintf(fid,'**************************************************************************************************\n');    
    display(Estimation_results);
    fprintf(fid,'**************************************************************************************************\n');
end
end

% Do charts.
function charts= print_charts(results,dates)
% Dates
if dates(end) == 1
    freq = 'm';
else
    freq = 'q';
end
[xTick,xTickLabel] = calendar(dates(1),dates(2),results.T,freq);
% In-sample fit
figure(1)
subplot(2,3,1)
plot(results.dta(:,1), '-b');
hold on
plot(results.yhat, '-r');
hold on
plot(results.yhat2(:,3),'--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('In sample fit of the network versus data','FontSize',11);
legend('data','model fit','GA fit','Location','northwest')
% Residuals
subplot(2,3,4)
plot(results.uhat, '-b');
hold on
plot(repmat(2*sqrt(results.Sg2),results.T,1), ':k');
hold on
plot(repmat(-2*sqrt(results.Sg2),results.T,1), ':k');
hold on
plot(zeros(results.T,1),'--k');
% xTickLabel Labels for chart.
xlim([xTick(1) xTick(end)]);            
set(gca,'xTick',xTick);
set(gca,'xTickLabel', xTickLabel);
title('Residuals +/- 2 S.D.','FontSize',11);

% ACF and PAC functions
subplot(2,3,2)     
[~,temp1] = acf(results.uhat);
if size(temp1,1) < 25
    n_aux = size(temp1,1);
    n_lim = n_aux-1;
else
    n_aux = 25;
    n_lim = 18;
end
bar((-1:n_aux-1),[NaN(1,2); temp1(1:n_aux,[1,2])]);
hold on        
plot((-1:n_aux-1),repmat(temp1(1:n_aux,3),1,n_aux+1), ':k');
hold on
plot((-1:n_aux-1),repmat(temp1(1:n_aux,4),1,n_aux+1), ':k');
xlim([-1 n_lim]);
ylim([-1 1]);
title('AC and PAC functions','FontSize',11);        
legend('Sample Auto-correlations','Partial correlation function','Location','northwest')

% Distribution of the residuals.
subplot(2,3,5)
histogram(results.uhat,31,'FaceColor',[0 0 1],'EdgeAlpha',1);
title('Histogram for residuals','FontSize',11);

% Distribution dependent variable
subplot(2,3,6)
histogram(results.dta(:,1),31,'FaceColor',[0 0 1],'EdgeAlpha',1);
title('Histogram dependent variable','FontSize',11);

% Convergency of the objective function.
subplot(2,3,3)
plot(results.fconv(:,1), '-b');
hold on
plot(results.fconv(:,2), '-r');
xlim([0 size(results.fconv,1)]);
ylim([min(min(results.fconv))*0.975 max(max(results.fconv))*1.025]);
% xTickLabel Labels for chart.
title('Optimization objective funtion','FontSize',11);        
legend('GA','NR method','Location','northeast')
charts = [];
end

% This function creates the initial theta for the Radial Basis Network
% with one, two or three layers.
function theta01 = radnt(y,x,setup)
% Estimation linear part of the model.
aux = OLSest(y,x);
if setup.hunits == 1
    % Condition over initial thetat.
    if size(setup.theta,1) == 0
        theta01 = [rand(size(x,2),1); rand(3*setup.nwt(1),1); aux.b];
    else
        theta01 = setup.theta;
    end; 
% Checking number of layers.    
else
    error('Error, max number of layers is one.');
end
end

% This function creates the initial theta for the Multilayer Perceptron Network
% with one, two or three layers.
function theta01 = mlp123(y,xl,xnl,setup)
% Estimation linear part of the model.
aux = OLSest(y,xl);
% # of parameters.
knl= size(xnl,2);

% (1) Layer.
if setup.hunits == 1 
    % Condition over initial thetat.
    if size(setup.theta,1) == 0
        theta01 = [rand(knl*setup.nwt(1),1); rand(setup.nwt(1),1); aux.b];
    else
        theta01 = setup.theta;
    end;
 
% (2) Layers.
elseif setup.hunits == 2
    % Condition over initial thetat.
    if size(setup.theta,1) == 0
        theta01 = [rand(knl*setup.nwt(1),1); rand((setup.nwt(1)+1)*setup.nwt(2),1); rand(setup.nwt(2),1); aux.b];
    else
        theta01 = setup.theta;
    end;
    
% (3) Layers.
elseif setup.hunits == 3
    % Condition over initial thetat.
    if size(setup.theta,1) == 0
        theta01 = [rand(knl*setup.nwt(1),1); rand((setup.nwt(1)+1)*setup.nwt(2),1); rand((setup.nwt(2)+1)*setup.nwt(3),1); rand(setup.nwt(3),1); aux.b];
    else
        theta01 = setup.theta;
    end;
end;
end

% This function creates the initial theta for the Ridgelet Network
% with one, two or three layers.
function theta01 = ridnt(y,x,setup)
aux = OLSest(y,x);
% (1) Layer.
if setup.hunits == 1
    % Condition over initial thetat.
    if size(setup.theta,1) == 0
        theta01 = [rand(size(x,2)-1,1); rand(3*setup.nwt(1),1); rand(setup.nwt(1),1); aux.b];
    else
        theta01 = setup.theta;
    end;       
% Checking number of layers.
else
    error('Error, max number of layers is three.');
end;
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
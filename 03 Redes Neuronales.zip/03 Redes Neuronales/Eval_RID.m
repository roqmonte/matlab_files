function [fobj,yhat,param] = Eval_RID(theta,y,xl,xnl,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 23/Jul/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Code evaluates the SSR for the  Ridgelet Network.
% Inputs:
%   y      : Dependent variable.
%   xl     : Regressors for the linear part of the model.
%   xnl    : Regressors for the nonlinear part of the model.
%   setup  : Check NNestim.m for details.
%
% Outputs:
%   fobj   : Value of the objective function.
%   yhat   : Fit of the Neural Network.
%   param  : Parameters of the network evaluated.
%
% Index.
% 1. Ridgelet Network one layer.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Ridgelet Network one layer.
if isreal(theta) == 1
    if setup.hunits == 1
        % Data info for network.
        nn1 = setup.nwt(1);
        T = size(y,1);
        k = size(xnl,2);

        % Model has one hidden unit.
        w01 = theta(1:k-1);
        yst = xnl(:,2:end)*w01;

        % Coeff. Activation function.
        w02 = theta(k:k+nn1*3-1);
        w02 = reshape(w02,3,nn1);
        nwt = zeros(T,nn1);
        for j = 1:nn1
            nwt(:,j) = w02(1,j)^(-1)*(w02(2,j)*yst - w02(3,j));
        end;
        % Output form hidden units.
        % Activation fnuction.
        Nkt = (-15*nwt + 10*nwt.^(3) - nwt.^(5)).*exp(-0.5*nwt.^(2));   
        % Final computation.
        id = size(w01,1) + size(vec(w02),1) + 1;
        bN    = theta(id:id+setup.nwt(1)-1);
        bx    = theta(id+setup.nwt(1):end);
        % Fit of the model.
        yhat = Nkt*bN + xl*bx;
        % Objective function.
        fobj = (y -yhat)'*(y -yhat);
        % Parameters of the network.
        param.xnl = w02;
        param.xnl2= w01;
        param.b   = [bN; bx];
    end;
else
    fobj = Inf;    
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
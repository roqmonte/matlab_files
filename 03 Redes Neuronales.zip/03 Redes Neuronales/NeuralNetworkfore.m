function results = NeuralNetworkfore(y,xl,xnl,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 28/Jan/2017
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Forecasrt of Neural Network models: (mlp: Multilayer Perceptron 
% network., rad: Radial Basis Network, ric: Ridgelet Network and rec: Recurrent 
% Network). 
% Estimation is done in two steps: (1) Genetic algorithm and (2)
% Back Propagation algorithm by minimizing the SSR using "csminwell". 
% For recursive forecast; AR variables should be included in the final
% columns of xl and xnl.
% Note, data for code is consistent with the following notation (row t):
%                               y(t) = A*y(t-h) + e(t)
% Where y(t) = f(y(t),y(t-h)) and y(t-h) = f(y(t-h),y(t-h-1))
% Inputs:
%   y      : Dependent variable.
%   xl     : Regressors for the linear part of the model (constant term by default if not included in first col).
%   xnl    : Regressors for the nonlinear part of the model (constant term by default if not included in first col).
%   setup  :
%   -.hunits: # of layers for the net: 1,2,3 (Default: 1).
%   -.nwt   : # neurons/hidden_units per layer (1 x nxt) (Default: 1).
%   -.fname : Type of Network: 'mlp','rad','rid','rec' (Default: mlp).
%   -.agen  : # simulations and generations for G.A (Default: 100,50).
%   -.mats  : Initial seeds from a previus estimation (Default: []).
%   -.theta : Initial value for Theta (Default: []).
%   -.mfore : (0) Recursive evaluation ; (1) rolling evaluation.
%   -.fhr   : Forecast horizon; (1) computes direct and recursive forecast.
%   -.frp   : Number of observations for evaluation.
%
% ** For recursive forecast.
%   -.ar    : Lag order.
%   -.ar_id : (1/0) Id variable to identify AR parts in linear/nonlinear part of the network
% ** Activation function for Multilayer Perceptron and Recurrent Network (not ready).
%   -.fnct  : logsigmoid, tansig and gaussian (Default: logsigmoid).
% ** Recurrent network (not ready).
%   -.lags  : Number og lags of the hiddend units (neurons).
%
% Outputs:
%   results :
%   -.dta     : Initial data.
%   -.dtf     : Initial evaluation sample.
%   -.betas   : Vector of parameters.
%   -.yhat    : In-sample fit.
%   -.uhat    : In-sample residuals.
%   -.ForeF   : Type of forecast.
%   -.yeft    : Vector with forecast data.
%   -.fore    : Vectot h-steap-ahead forecas (direct forecast).
%   -.fore_rec: Matrix h-steap-ahead forecas (per column, recursive forecast).
%   -.ForeT   : Estimation method.
%   -.setup   : Options.
%   -.filter  : #times the filter forecast was applied.
%   -.Network : Type of network.
%   -.niter   : Number of iterations.
%
% Index.
% 1. Data setup.
% 2. Forecasts.
% 3. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Data setup.
% Checking inputs.
if size(xl,2) == 0 && size(xnl,2) == 0
    error('Wrong arguments for the code.');
end
if isfield('setup','agen') == 0
    setup.agen = [100 50];
end;
if isfield('setup','mats') == 0
    setup.mats = [];
end;
if isfield('setup','theta') == 0
    setup.theta = [];
end;
% Default network
if isfield(setup,'hunits') == 0
    setup.hunits= 1;
end;
if isfield(setup,'nwt') == 0
    setup.nwt= 1;
end;
if isfield(setup,'fname') == 0
    setup.fname= 'mlp';
    setup.fnct = 'logsigmoid';
end;
if isfield('setup','ar') == 1
    if isfield('setup','ar_id') == 0
        error('Check variable setup.ar_id');
    end
end

% Checking for constant term in the model.
if size(xl,2) == 0
    xl = ones(size(y,1),1);
end
if mean(xl(:,1),1) ~= 1
    xl = [ones(size(y,1),1) xl];
end
if size(xnl,2) == 0
    xnl= ones(size(y,1),1);
end
if mean(xnl(:,1),1) ~= 1
    xnl= [ones(size(y,1),1) xnl];
end

% Neural Network selection
if strcmp(setup.fname, 'mlp')
    setup.feval1 = 'Eval_MLP';
elseif strcmp(setup.fname, 'rad')
    setup.feval1 = 'Eval_RAD';
elseif strcmp(setup.fname, 'rid')
    setup.feval1 = 'Eval_RID';
else
    error('Error, worng function..');
end;
% Evaluation window.
P = setup.frp;
% Data
dta  = [y xl xnl];
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Forecast.
h_wait = waitbar(0,'Generating forecast, please wait...');
% Forecasting.
wx = 1;
for w = 1:P+1-setup.fhr
    % Waiting bar.
    waitbar(w/setup.frp,h_wait)
    % Forecast exercise (recursive or rolling estimation).
    if setup.mfore == 1
        wx = w;
    end
    % Generating Dependent variable.
    yini = y(wx:end-P+w-1,:);
    % Spliting xl matrix.
    xlini= xl(wx:end-P+w-1,:);
	xlf  = xl(end-P+w:end,:); 
    % Spliting xnl matrix.
    xnlini= xnl(wx:end-P+w-1,:);
    xnlf  = xnl(end-P+w:end,:);
    
    % Model estimation.
    res_o     = NeuralNetwork(yini,xlini,xnlini,setup);
    bw(:,w).b = res_o.theta(:,end);
    uhat(w).u = res_o.uhat;
    yhat(w).yt = res_o.yhat;

    % Forecasting.
    setup.junk  = w;    
    [fcast(:,w),idx] = fore(yini,xlf,xnlf,setup,res_o.theta(:,end));
    id(w) = idx;
    niter(w) = res_o.niter;
    clear res_o;
end
close(h_wait)

% Formating the results.
if setup.fhr > 1
    fcast = fcast(1,:)';
    ForeF = {'Direct forecast'};
elseif setup.fhr == 1
    results.fcast_rec = format(fcast,P);
    fcast = fcast(1,:)';   
    ForeF = {'Recursive forecast'};
end

% Results.
results.dta   = [dta(1:end-P,1)     dta(1:end-P,2:end)];
results.dtf   = [dta(end-P+1:end,1) dta(end-P+1:end,2:end)];
results.setup = setup;
results.filter= id;
results.niter = niter;
% Forecast info options.
results.betas = bw;
results.ForeF = char(ForeF);
results.yeft  = dta(end-P+1:end,1);
results.fore  = fcast;
results.yhat  = yhat;
results.uhat  = uhat;
results.Network = setup.feval1 ;
if setup.mfore == 0
    results.ForeT = 'Recursive Estimation';
else
    results.ForeT = 'Rolling window estimation';
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Functions.
% Function calculates the h step ahead forecast matrix.
function [yf,id] = fore(y,xlf,xnlf,setup,param)
% Imputs.
%   y      : Data from Estimation window, target variable.
%   xlf    : Linear part, evaluation window.
%   xnlf   : Nonlinear part, evaluation window.
%   setup  : Options.
%   param  : Vector of parameters
% Outputs:
%   yf    : h step ahead forecast.
%   id    : Indicator of the forecast filter.

% Parameters of the model.
thetaf = param;

% Matrix to store results.
yf = zeros(setup.frp,1);
% Id variable.
junk= setup.junk-1;
% Defining filter.
mod = 'max';
if strcmp(mod, 'max')
    trimb = max(abs(y));
elseif strcmp(mod, 'desv')
    trimb = std(y);
else
    error('Wrong filter for the forecast.');
end;

% Direct forecast for h = 1 and recursive forecast.
if setup.fhr == 1
    % Reshape of variables.
    ar   = setup.ar;
    yaux = y(end-ar+1:end);
    yfun = yaux(size(yaux,1):-1:1);
    clear yaux;
    % Number of variables of each part of the network.
    n_arl  = setup.ar_id(1)*ar;
    n_arnl = setup.ar_id(2)*ar;
    n_xl   = size(xlf,2) - n_arl;
    n_xnl  = size(xnlf,2)- n_arnl;
    % Forecasting.
    for i = 1:setup.frp-junk
        % Building lags for recursive forecast.
        x2l = [xlf(i,1:n_xl) yfun(1:n_arl)];
        x2nl= [xnlf(i,1:n_xnl) yfun(1:n_arnl)];
        % Forecast
        eval(['[~,yf2] =' setup.feval1 '(thetaf,0,x2l,x2nl,setup);']);
        yf3b = yf2(end);
        % Applying insanity filter
        [yf3,id] = insanity(y,yf3b,trimb);
        % Storing forecast.
        yf(i,1) = yf3;
        % Adding forecast for recursive forecast.
        y   = [y; yf3];
        % Sorting forecast.
        yaux = y(end-ar+1:end);
        yfun = yaux(ar:-1:1);
        clear yaux yf2 yf3b yf3;
    end
    
% Direct forecast for h > 1: y_{t+h|t}
elseif setup.fhr > 1
    % Forecast horizon.
    hf = setup.fhr;
    % Forecasting.
    xl_aux = xlf(hf,:);
    xnl_aux= xnlf(hf,:);
    eval(['[~,yf2] =' setup.feval1 '(thetaf,0,xl_aux,xnl_aux,setup);']);
    yf3 = yf2(end);
    % Applying insanity filter
    [yf,id] = insanity(y,yf3,trimb);
end

% Insanity filter: Swason & White (1995).
function [yfil,id]= insanity(y,yf,trimb)
% Imputs.
%   y     : Endogenous variable.
%   yf    : Forecast.
%   trim  : Threshold for filtering forecast.
% Outputs:
%   yfil  : Filter forecast.
%   id    : Tag of filter.
% Filtering
if abs(yf) > trimb
    yfil = mean(y);
    id = 1;
else
    yfil = yf;
    id = 0;
end

% Formating the forecast.
function fcast = format(fcast,a)
% Imputs.
%   fcast : Matrix forecast raw.
%   a     : Size evaluation window.
% Outputs:
%   fcast : Forecast Matrix (each row: h-step-ahead forecast).
fcast = fcast';
% Forecast
fcast2 = NaN(a,a);
i = 1;
for j0 = 1:a
    fcast2(i:end,j0)= fcast(1:end-i+1,j0);
    i = i + 1;
end
fcast = fcast2;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
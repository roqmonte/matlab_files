function [fobj,yhat,param] = Eval_MLP(theta,y,xl,xnl,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 23/Jul/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Code evaluates the SSR for the Multilayer perceptron network.
% Inputs:
%   y      : Dependent variable.
%   xl     : Regressors for the linear part of the model.
%   xnl    : Regressors for the nonlinear part of the model.
%   setup  : Check NeuralNetwork.m for details.
%
% Outputs:
%   fobj   : Value of the objective function.
%   yhat   : Fit of the Neural Network.
%   param  : Parameters of the network evaluated.
%
% Index.
% 1. Neural Network one layer.
% 2. Neural Network two layers.
% 3. Neural Network three layer.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
if isreal(theta) == 1
    % 1. Estimation Neural Network one layer.
    if setup.hunits == 1
        % Data info for network.
        nn1 = setup.nwt(1);
        k = size(xnl,2);

        % Computing values for the hidden units.
        w01 = theta(1:k*nn1);
        w01 = reshape(w01,k,nn1);
        nwt = xnl*w01;
        % Output form hidden units.
        if strcmp(setup.fnct, 'logsigmoid')
            Nkt = 1 ./ (1 + exp(-nwt) );
        elseif strcmp(setup.fnct, 'tansig')
            Nkt = (exp(nwt) - exp(-1*nwt)) ./ (exp(nwt) + exp(-1*nwt));
        elseif strcmp(setup.fnct, 'gaussian')
            Nkt = normcdf(nwt,0,1);
        end;
        % Final computation.
        id = size(vec(w01),1) + 1;
        bN    = theta(id:id+nn1-1);
        bx    = theta(id+nn1:end);
        % Fit of the model.
        yhat = Nkt*bN + xl*bx;
       % Objective function.
        fobj = (y -yhat)'*(y -yhat);
        % Parameters of the network.
        param.xnl = w01;
        param.b   = [bN; bx];
    end;
else
    fobj = Inf;    
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation Neural Network two layers.
if isreal(theta) == 1
    if setup.hunits == 2
        % Data info for network.
        nn1 = setup.nwt(1);
        nn2 = setup.nwt(2);
        T = size(y,1);
        k = size(xnl,2);

        % First Layer.
        % Computing values for the hidden units.
        w01 = theta(1:k*nn1);
        w01 = reshape(w01,k,nn1);
        nwt = xnl*w01;
        % Output form hidden units.
        if strcmp(setup.fnct, 'logsigmoid')
            Nkt = 1 ./ (1 + exp(-nwt) );
        elseif strcmp(setup.fnct, 'tansig')
            Nkt = (exp(nwt) - exp(-1*nwt)) ./ (exp(nwt) + exp(-1*nwt));
        elseif strcmp(setup.fnct, 'gaussian')
            Nkt = normcdf(nwt,0,1);
        end;    
        % Second layer.
        % Computing values for the hidden units.
        id1 = size(vec(w01),1) + 1;
        w02 = theta(id1:id1+(nn1+1)*nn2-1);
        w02 = reshape(w02,nn1+1,nn2);
        pkt = [ones(T,1) Nkt]*w02;
        % Output form hidden units.
        if strcmp(setup.fnct, 'logsigmoid')
            Pkt = 1 ./ (1 + exp(-pkt) );
        elseif strcmp(setup.fnct, 'tansig')
            Pkt = (exp(pkt) - exp(-1*pkt)) ./ (exp(pkt) + exp(-1*pkt));
        elseif strcmp(setup.fnct, 'gaussian')
            Pkt = normcdf(pkt,0,1);
        end;
        % Final computation.
        id2 = size(vec(w01),1) + size(vec(w02),1) + 1;
        bN    = theta(id2:id2+nn2-1);
        bx    = theta(id2+nn2:end);
        % Fit of the model.
        yhat = Pkt*bN + xl*bx;
       % Objective function.
        fobj = (y -yhat)'*(y -yhat);
        % Parameters of the network.
        param.xnl  = w02;
        param.xnl2 = w01;
        param.b   = [bN; bx];
    end;
else
    fobj = Inf;    
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Estimation Neural Network three layers.
if isreal(theta) == 1
    if setup.hunits == 3
        % Data info for network.
        nn1 = setup.nwt(1);
        nn2 = setup.nwt(2);
        nn3 = setup.nwt(3);
        T = size(y,1);
        k = size(xnl,2);

        % First Layer.
        % Computing values for the hidden units.
        w01 = theta(1:k*nn1);
        w01 = reshape(w01,k,nn1);
        nwt = xnl*w01;
        % Output form hidden units.
        if strcmp(setup.fnct, 'logsigmoid')
            Nkt = 1 ./ (1 + exp(-nwt) );
        elseif strcmp(setup.fnct, 'tansig')
            Nkt = (exp(nwt) - exp(-1*nwt)) ./ (exp(nwt) + exp(-1*nwt));
        elseif strcmp(setup.fnct, 'gaussian')
            Nkt = normcdf(nwt,0,1);
        end;    
        % Second layer.
        % Computing values for the hidden units.
        id1 = size(vec(w01),1) + 1;
        w02 = theta(id1:id1+(nn1+1)*nn2-1);
        w02 = reshape(w02,nn1+1,nn2);
        pkt = [ones(T,1) Nkt]*w02;
        % Output form hidden units.
        if strcmp(setup.fnct, 'logsigmoid')
            Pkt = 1 ./ (1 + exp(-pkt) );
        elseif strcmp(setup.fnct, 'tansig')
            Pkt = (exp(pkt) - exp(-1*pkt)) ./ (exp(pkt) + exp(-1*pkt));
        elseif strcmp(setup.fnct, 'gaussian')
            Pkt = normcdf(pkt,0,1);
        end;
        % Third layer.
        % Computing values for the hidden units.
        id2 = size(vec(w01),1) + size(vec(w02),1) + 1; 
        w03 = theta(id2:id2+(nn2+1)*nn3-1);
        w03 = reshape(w03,nn2+1,nn3);
        rkt = [ones(T,1) Pkt]*w03;
        % Output form hidden units.
        if strcmp(setup.fnct, 'logsigmoid')
            Rkt = 1 ./ (1 + exp(-rkt) );
        elseif strcmp(setup.fnct, 'tansig')
            Rkt = (exp(rkt) - exp(-1*rkt)) ./ (exp(rkt) + exp(-1*rkt));
        elseif strcmp(setup.fnct, 'gaussian')
            Rkt = normcdf(rkt,0,1);
        end;
        % Final computation.
        id3 = size(vec(w01),1) + size(vec(w02),1) + size(vec(w03),1) + 1;
        bN    = theta(id3:id3+nn3-1);
        bx    = theta(id3+nn3:end);
        % Fit of the model.
        yhat = Rkt*bN + xl*bx;
       % Objective function.
        fobj = (y -yhat)'*(y -yhat);
        % Parameters of the network.
        param.xnl  = w03;        
        param.xnl2 = w02;
        param.xnl3 = w01;
        param.b   = [bN; bx];
    end;
else
    fobj = Inf;    
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
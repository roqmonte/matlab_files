function [fobj,yhat,param] = Eval_RAD(theta,y,xl,xnl,setup)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 23/Jul/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Code evaluates the SSR for the Radial Basis Network.
% Inputs:
%   y      : Dependent variable.
%   xl     : Regressors for the linear part of the model.
%   xnl    : Regressors for the nonlinear part of the model.
%   setup  : Check NNestim.m for details.
%
% Outputs:
%   fobj   : Value of the objective function.
%   yhat   : Fit of the Neural Network.
%   param  : Parameters of the network evaluated.
%
% Index.
% 1. Radial Basis network one layer.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Radial Basis network one layer.
if isreal(theta) == 1
    if setup.hunits == 1
        % Data info for network.
        nn1 = setup.nwt(1);
        T = size(y,1);
        k = size(xnl,2);

        % Model has one hidden unit.
        w01 = theta(1:k);
        nwt = xnl*w01;
        % Coeff. Activation function.
        w02 = theta(k+1:k+setup.nwt(1)*2);
        w02 = reshape(w02,setup.nwt(1),2);
        Nkt = zeros(T,nn1);  
        % Output form hidden units.
        for j = 1:setup.nwt(1)
            Nkt(:,j) = exp(-1*w02(j,1)*(nwt-w02(j,2)).^2);
        end;
        % Final computation.
        id = size(w01,1) + size(vec(w02),1) + 1;
        bN    = theta(id:id+setup.nwt(1)-1);
        bx    = theta(id+setup.nwt(1):end);
        % Fit of the model.
        yhat = Nkt*bN + xl*bx;
        % Ojective function.
        fobj = (y -yhat)'*(y -yhat);
        % Parameters of the network.
        param.xnl = w02;
        param.xnl2= w01;
        param.b   = [bN; bx];
    end;
else
    fobj = Inf;    
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
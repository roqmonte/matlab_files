function result = johansen(data,info)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 22/Jul/2019
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: The code estimate the rank(PHI), and the cointegrating vectors. 
% using Johansen's procedure. Note, c_sja(), c_sjt() provide critical values 
% generated using a method of MacKinnon (1994, 1996). Critical values are 
% available for n<=12 and -1 <= p <= 1, zeros are returned for other cases.
% Input:
%   data         : Data all variables of the system.
%   info:
%   -.p          : Lag order of the VAR model.
%   -.mod_type   : Conf. for deterministic terms of the model.
%   -.endo_names : Vector with labels for variables of the system (1 x n).
%
% Output:
%  results
%   -.eig      : Eigenvalues (m,1).
%   -.evec     : Eigenvectors (m,m), first r columns are normalized coint vectors.
%   -.lr1      : Likelihood ratio trace statistic, for r=0 to m-1 (m,1).
%   -.lr2      : Maximum eigenvalue statistic, for r=0 to m-1 (m,1).
%   -.cvt      : CV trace statistic at [90% 95% 99%] sig. levels.
%   -.cvm      : CV max eigen value statistic at [90% 95% 99%] sig. levels.
%   -.ind      : Index of co-integrating variables ordered by size of the 
%                eigenvalues from large to small.
%
% Index.
% 1. Getting info from core.
% 2. Functions.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%% 
% Getting info form code.
k  = info.p;
m  = size(data,2);
% Configuration deterministic part of th emodel
if (info.mod_type > -1)
    f = 0;
else 
    f = info.mod_type;
end
% Detrended data
x     = detrend(data,info.mod_type);
% First difference and matrix with lags.
dx    = x(2:end,:)-x(1:end-1,:);
z     = mlag(dx,k);
% Detrending deltas and levels.
z     = detrend(trimr(z,k,0),f);
dx    = detrend(trimr(dx,k,0),f);

% Bulding RR terms from Johansen.
r0t   = dx - z*(z\dx);
dx    = detrend(x(2:end-k,:),f);
rkt   = dx - z*(z\dx);     
skk   = rkt'*rkt / size(rkt,1);
sk0   = rkt'*r0t / size(rkt,1); 
s00   = r0t'*r0t / size(r0t,1); 
sig   = sk0*(s00)^(-1)*(sk0');
tmp   = skk^(-1);

% Computing eigenvalues and eigenvectors.
[du,au] = eig(tmp*sig);
orig = tmp*sig;

% Normalize the eigen vectors such that (du'skk*du) = I 
dt   = du*(chol(du'*skk*du))^(-1);
temp = (chol(du'*skk*du))^(-1);
     
% Sorting eigenvalues and vectors
dt         = dt';
[au,auind] = sort(diag(au)); 
a          = flipud(au);
aind       = flipud(auind);
d          = dt(aind,:);
% Re-ordening eigenvectors
d  =  d';
test = d'*skk*d;

% Matrix to store results.
lr1 = zeros(m,1);
lr2 = zeros(m,1);
cvm = zeros(m,3);
cvt = zeros(m,3);
% Compute the trace and max eigenvalue statistics
iota = ones(m,1);
t    = size(rkt,1);
for i = 1:m
    tmp = trimr(log(iota-a),i-1,0);
    lr1(i,1) = -t*sum(tmp);
    lr2(i,1) = -t*log(1-a(i,1));
    cvm(i,:) = c_sja(m-i+1,info.mod_type);
    cvt(i,:) = c_sjt(m-i+1,info.mod_type);
    aind(i)  = i;
end
     
% Saving results.
result.eig = a;
result.evec = d;
result.lr1 = lr1;
result.lr2 = lr2;
result.cvt = cvt;
result.cvm = cvm;
result.ind = aind;
% Printing table with results.
print_res(result,info);

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Functions.

% Function detrends the data based on the conf. of the mod.
function resid = detrend(y,p) 
% Inputs: 
%   y      : Data.
%   p      : [0] subtracts mean, [1] constant plus trend model, 
%            [>1] higher order polynomial model and [-1] raw data.
% Outputs:
%   resid  : Residuals from the detrending regression

% Case for no detrending.
if p == -1
    resid = y;
end

% Sample info.
nobs = size(y,1);
u    = ones(nobs,1);

% Building deterministic terms.
if p > 0
    % Constant term and other deterministic terms.
    timep = zeros(nobs,p);
    t  = 1:nobs;
    tp = (t')/nobs;
    m  = 1;
    while (m <= p)
        timep(:,m) = tp.^m;
        m = m+1;
    end
    xmat = [u timep];
else
    % Constant term only.
    xmat = u;
end

% Detrendin data
xpxi = (xmat'*xmat)^(-1);
beta = xpxi*(xmat'*y);
resid = y - xmat*beta;

% Function generates a matrix with lags from a matrix.
function xlag = mlag(x,nlag)
% Inputs: 
%   x      : Data.
%   nlag   : Number of lags.
% Outputs:
%   xlag   : Matrix with lags.

% Info from code.
[nobs,nvar] = size(x);
% Matrix to store results.
xlag = zeros(nobs,nvar*nlag);

% Getting lags.
icnt = 0;
for i=1:nvar;
    for j=1:nlag;
        xlag(j+1:nobs,icnt+j) = x(1:nobs-j,i);
    end
    icnt = icnt+nlag;
end

% Funtion do table.
function Estimation_results = print_res(results,info)
% Building table
lab = [];
r = size(results.evec,1);
for i0 = 1:r
    lab2 = {['r',num2str(i0)]};
    lab = [lab lab2];
end
% First part.
labels = [{''}; info.names'];
temp_1 = [lab; num2cell(results.evec)];
part_1 = [labels temp_1];
% Second part
temp_2 = {'H0' 'LR trace' '90%' '95%' '99%'};
temp_3 = [num2cell(0:r-1)' num2cell(results.lr1) num2cell(results.cvt)];
part_2 = [{' ' ' ' ' ' ' ' ' '}; temp_2; temp_3];
% Third part
temp_4 = {'H0' 'Max. eig' '90%' '95%' '99%'};
temp_5 = [num2cell(0:r-1)' num2cell(results.lr2) num2cell(results.cvm)];
part_3 = [{' ' ' ' ' ' ' ' ' '}; temp_4; temp_5];
part_4 = [part_2;part_3];
% Print results.
aux = repmat({' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' '},size(part_1,1)+size(part_2,1)+size(part_3,1)+1,1);
aux(1:size(part_1,1),1:size(part_1,2)) = part_1;
aux(size(part_1,1)+1:size(part_1,1)+size(part_4,1),1:size(part_4,2)) = part_4;
% Final table
Estimation_results = aux(:,1:max([size(temp_1,1) size(temp_4,1)]));
print = 1;
if print == 1
    fid = 1;
    fprintf(fid,'****************************************************************************\n');
    display(Estimation_results);
    fprintf(fid,'****************************************************************************\n');
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
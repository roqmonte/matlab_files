function [beta,sseb, beta1] = Simanneal(fun,theta,y,x,T0)
%-------------------------------------------------------------------------%
% Matlab 7.1
% Autor: Roque Montero
% Date: 27/Jan/2015
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Simulated Annealing Program.
% Inputs:
%   fcn    : Name of the function to optimize.
%   theta  : Initial value for theta.
%   y      : Endogenous vairable.
%   x      : Exogenous variables (no lags and constant term goes here).
%   T0     : Temperature to stop.
%   norm   : 
%
% Outputs:
%   results :
%
% Index.
% 1. Code.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 1. Code.
% Size of the perturbation.
norm = 1; 

% Matrix to store results (aprox size).
T     = zeros(5000,1);
sse   = zeros(5000,1);
metro = zeros(5000,1);

% Info
nparm       = cols(theta);
weight(1,:) = theta;
% Defining cooling schedule.
T(1)  = T0 / (1 + log(1));

% Initial evaluation function.
sse(1)     = feval(fun,theta,y,x,setup);

% Estimation loop.
j = 1;
logsa(1,:) = [j T(1) sse(1)];
for j = 2:T0,
	% Temperature of the iteration.
    T(j) = T0 / (1 + log(j));
    cutpoint = round(rand(1,1) * (nparm-1)) + 1; 
    
    % Previous Weight.
    w1 = weight(j-1,:);
    % Random perturbation.
    dw = randn(1,1) * norm;
    % New Weights candidate.
    w1(:,cutpoint) = w1(:,cutpoint) + dw;
    
    % New value of the function.
    sse(j) = feval(fun,w1);
    % Change function with respect to last iteration.
    dsse = sse(j) - sse(j-1);
    % Computing Metropilis ratio M(j).
    metro(j) = exp(-dsse/T(j));
    
    % Condition to accept the new weights.
    % Random draw form uniform distribution.
    pm = rand(1,1);

    if dsse < 0 && pm > metro(j), 
        weight(j,:) = w1; 
        
    elseif dsse < 0  && pm < metro(j), 
        weight(j,:) = w1;
        
    elseif dsse > 0 && pm > metro(j), 
        weight(j,:) = w1;
    % Keep theta from last iteration.
    else
        weight(j,:) = weight(j-1,:); 
    end;
    % Summary of iterations.
    logsa(j,:) = [j T(j) sse(j) metro(j)];
end;
% Solution.
[sseb, ind] = min(sse);
% Results.
beta = weight(ind,:);
beta1 = weight(end,:);
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
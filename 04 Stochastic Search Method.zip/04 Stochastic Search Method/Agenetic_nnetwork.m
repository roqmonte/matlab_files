function results = Agenetic_nnetwork(fcn,theta0,y,xl,xnl,setup,options_ga)
%-------------------------------------------------------------------------%
% Matlab 9.0
% Autor: Roque Montero
% Date: 23/Jul/2016
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Description: Codes implement estimation using a Genetic Algorithm for
% model estimation. Note that, theta0 must be provided.
% Inputs:
%   fcn    : Name of the function to optimize.
%   theta0 : Initial value for theta.
%   y      : Endogenous vairable.
%   xl     : Regressors for the linear part of the model.
%   xnl    : Regressors for the nonlinear part of the model.
%   setup  :
%   -.agen : Number of simulations and generations of G.A.
%   -.mats : Initial seeds from a previus estimation.
%   options_ga: parameters to tune the GA algorith.
%   -.ga_scross    : Shuffle crossover.
%   -.ga_across(1) : Arithmetic crossover param 1.
%   -.ga_across(2) : Arithmetic crossover param 2.
%   -.ga_pcross    : Single point crossover
%
% Outputs:
%   results :
%   -.theta     : Estimation of Theta.
%   -.feval     : Value of the ojective function.
%   -.error     : Number of wrong iterations.
%   -.theta_all : Candiates from the generations.
%   -.feval_all : Min value objective function for each generation.
%
% Index.
% 1. Setup.
% 2. Genetic Algorithm.
% 3. Saving Results.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%    
% 1. Setup.
simul = setup.agen(1);
ngene = setup.agen(2);

% initial seed.
% Random seed to start the algorithm.
if size(setup.mats,1) == 0
    seed_aux = zeros(size(theta0,1),simul);
    for j = 1:simul
        seed_aux(:,j) = theta0.*(randn(size(theta0,1),1));
    end;
    seeds = [theta0 seed_aux(:,1:end-1)];
else
    seeds = [theta0 setup.mats(:,1:end-1)];
end;
% Initial definitions.        
k     = size(seeds,1);
% Matrix results for generation "i".
sdaux = zeros(k,simul);
% Matriz con resultados historicos.
f_opt = zeros(setup.agen(2)+1,2);     % Chains of SSR and Ids.
x_opt = zeros(k,setup.agen(2)+1);     % Chains with parameter estimators.
clear seed_aux j theta0;
% ID wrong iterations.
error = 0;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 2. Genetic Algorithm.
% Paremeters of the Algorithm.
% Shuffle crossover, Arithmetic crossover and Single point crossover    
if nargin == 6
    ga_scross   = 1/3;
    ga_across(1)= 1/3;
    ga_across(2)= 2/3;
    ga_pcross   = 2/3;
elseif nargin == 7
    ga_scross   = options_ga.ga_scross;
    ga_across(1)= options_ga.ga_across(1);
    ga_across(2)= options_ga.ga_across(2);
    ga_pcross   = options_ga.ga_pcross;
end

% Iterations
for ig =1:ngene
    % Selection.
    sd = 1;
    while sd <= simul        
        % Variable to select candidate form past generation.
        id = randi(simul,1,2);
        % Vectors selected for reproduction.
        parents = [seeds(:,id(1,1)) seeds(:,id(1,2))];
        % New breed.
        childs = zeros(k,2);
        p = rand;
        
        % Shuffle crossover.
        if p <= ga_scross            
            for i = 1:k
                aux = binornd(k,1/k,k,1);
                if aux(end,1) == 1
                    childs(i,1) = parents(round(1+(k-1)*rand),2);
                    childs(i,2) = parents(round(1+(k-1)*rand),1);
                else
                    childs(i,1) = parents(i,1);
                    childs(i,2) = parents(i,2);
                end;
            end;
        % Arithmetic crossover.
        elseif p > ga_across(1) && p <= ga_across(2)
            w = rand;
            childs(:,1) = w*parents(:,1) + (1-w)*parents(:,2);
            childs(:,2) = (1 - w*parents(:,1) + w).*parents(:,2);                
        % Single point crossover
        elseif p > ga_pcross
            I = round(1+(k-2)*rand);
            childs(1:I,1) = parents(1:I,1);
            childs(1:I,2) = parents(1:I,2);
            for i = I+1:k
                childs(i,1) = parents(round(I+(k-I)*rand),2);
                childs(i,2) = parents(round(I+(k-I)*rand),1);
            end;                    
        end;            
        
        % Introducion random mutation.
        pr = 0.15 + 0.33/ngene; 
        b = 2;
        for q = 1:2
            for i = 1:k
                s  = randn;  r1 = rand; r2 = rand; 
                aux = rand;                   
                if aux <= pr
                    if r1 > 0.5
                        childs(i,q) = childs(i,q) + s*(1 - r2^(1 - ig/ngene)^(b));
                    else
                        childs(i,q) = childs(i,q) - s*(1 - r2^(1 - ig/ngene)^(b));
                    end
                end;
            end;
        end;
        clear p aux I pr s r1 r2 b q i id;            

        % Evaluation of candidates.
        fam = [parents childs];
        ssr = zeros(4,1);
        for i =1:size(fam,2)
            eval(['ssr(i,1) =', fcn, '(fam(:,i),y,xl,xnl,setup);']);
        end;
        % Checking consistency.
        if max(ssr) == Inf         
            disp('The iteration was discarded because fvalue was not a real number (Inf+/-)');
            error = error + 1;
        else
            [~,id] = min(ssr);
            % Defining next generation.
            sdaux(:,sd) = fam(:,id);
            sd = sd + 1;
        end;
        clear fam famval id i childs parents ssr;
    end;
    
    % Introducing elitism.
    ff = zeros(size(seeds,2),2);
    for i =1:size(seeds,2)
        eval(['ff(i,1) =', fcn, '(seeds(:,i),y,xl,xnl,setup);']);
        eval(['ff(i,2) =', fcn, '(sdaux(:,i),y,xl,xnl,setup);']);
    end;
    % Replacing worst seed from new generation by best seed of old
    % generation.
    % Best candidate Initial generation.
    [min1,id1] = min(ff(:,1));
    % Best candidate new generation.
    [min2,id2] = min(ff(:,2));
    % Worst candidate new generation.
    [~,id3] = max(ff(:,2));
    if min1 < min2
       sdaux(:,id3) = seeds(:,id1); 
    end
    
    % Saving best min values and thetas.
    if ig == 1
        f_opt(1,:) = [min1 id1];
        x_opt(:,1) = seeds(:,id1); 
    end
    f_opt(ig+1,:) = [min2 id2];
    x_opt(:,ig+1) = sdaux(:,id2);
    
    % Defining new seed for the next iteration of generation.
    seeds = sdaux;
    clear min1 min2 id1 id2 id3 i ff w;
end;
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% 3. Saving Results.
% Results from the genetic Algorithm.
results.theta  = x_opt(:,end);  % Best candidate.
results.feval  = f_opt(end,1);  % Final value of the function.
results.error  = error;         % Wron number of iterations (individuals).
results.theta_all = x_opt;      % Candidates from each generation.
results.feval_all = f_opt;      % Min value of the function from each generation.
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%